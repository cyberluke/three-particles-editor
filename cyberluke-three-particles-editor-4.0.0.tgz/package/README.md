# THREE Particles Editor

The best-in-class particle framework for Three.js — now with a WebGPU compute simulation. This is the Unity-style visual editor and offline example gallery that goes with it: tune effects live, then export ready-to-paste configs for the [@cyberluke/three-particles](https://github.com/cyberluke/three-particles) library.

Why it stands out:

- **WebGPU compute** — gravity, velocity, 7 lifetime modifiers, point/directional force fields and 3D simplex noise run in GPU compute kernels (Three.js TSL): 50K–350K+ textured particles at full framerate, one draw call.
- **Four renderers** — POINTS billboard quads, GPU-INSTANCED sprites (no `gl_PointSize` limit), TRAIL ribbons with width/opacity/color tapering, MESH particles (debris, gems, coins) with full 3D rotation and lighting.
- **Unity-familiar workflow** — bursts, sub-emitters, collision planes (kill/clamp/bounce), Bézier over-lifetime curves, serialization; every example ships as a copy-paste config.
- **Deterministic** — a CPU reference path keeps identical results for tests and headless pipelines.

Author: **CyberLuke** — the single maintained line since v4.

## Live Demo

[https://newkrok.com/three-particles-editor/index.html](https://newkrok.com/three-particles-editor/index.html)

## Installation

```bash
# Clone the repository
git clone https://github.com/NewKrok/three-particles-editor.git

# Navigate to the project directory
cd three-particles-editor

# Install dependencies
npm install

# Start the development server
npm run dev
```

## Development

- `npm run dev` - Start the development server with hot reloading
- `npm run build` - Build the project for production
- `npm run start` - Serve the production build
- `npm run lint` - Run ESLint to check code quality
- `npm run format` - Format code with Prettier

## Features

- Visual editor for creating and fine-tuning particle effects
- Real-time preview of particle systems
- Export configurations for use with the @cyberluke/three-particles library
- Customizable particle properties (position, velocity, size, color, alpha, rotation, etc.)
- Support for various emitter shapes and parameters

## Videos

- [Unity asset store](https://youtu.be/fdtoft1AXBk)
- [In action](https://youtu.be/5IUqO5P-T6Q)
- [Projectiles](https://youtu.be/Q352JuxON04)
- [First preview](https://youtu.be/dtN_bndvoGU)

## Screenshots

<img src="https://user-images.githubusercontent.com/13141660/167223378-e3002af9-2800-49b3-a955-9cb5fb54b103.png" width="320px">
<img src="https://user-images.githubusercontent.com/13141660/167223438-493cf422-c327-43d3-a622-dacc20ddc07e.png" width="320px">
<img src="https://user-images.githubusercontent.com/13141660/167223497-c4880d7c-eec2-4c41-b83e-82cc571e64c3.png" width="320px">
<img src="https://user-images.githubusercontent.com/13141660/167223587-a5bd6e40-ef4f-434f-a952-aad56041def7.png" width="320px">
