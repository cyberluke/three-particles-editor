import { AdditiveBlending as __WEBPACK_EXTERNAL_MODULE_three_AdditiveBlending__, AmbientLight as __WEBPACK_EXTERNAL_MODULE_three_AmbientLight__, AnimationClip as __WEBPACK_EXTERNAL_MODULE_three_AnimationClip__, Audio as __WEBPACK_EXTERNAL_MODULE_three_Audio__, AudioListener as __WEBPACK_EXTERNAL_MODULE_three_AudioListener__, AudioLoader as __WEBPACK_EXTERNAL_MODULE_three_AudioLoader__, Bone as __WEBPACK_EXTERNAL_MODULE_three_Bone__, Box3 as __WEBPACK_EXTERNAL_MODULE_three_Box3__, BufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_BufferAttribute__, BufferGeometry as __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__, ClampToEdgeWrapping as __WEBPACK_EXTERNAL_MODULE_three_ClampToEdgeWrapping__, Color as __WEBPACK_EXTERNAL_MODULE_three_Color__, ColorManagement as __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__, Curve as __WEBPACK_EXTERNAL_MODULE_three_Curve__, DataTexture as __WEBPACK_EXTERNAL_MODULE_three_DataTexture__, DirectionalLight as __WEBPACK_EXTERNAL_MODULE_three_DirectionalLight__, DoubleSide as __WEBPACK_EXTERNAL_MODULE_three_DoubleSide__, EquirectangularReflectionMapping as __WEBPACK_EXTERNAL_MODULE_three_EquirectangularReflectionMapping__, Euler as __WEBPACK_EXTERNAL_MODULE_three_Euler__, FileLoader as __WEBPACK_EXTERNAL_MODULE_three_FileLoader__, Float32BufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__, FrontSide as __WEBPACK_EXTERNAL_MODULE_three_FrontSide__, Group as __WEBPACK_EXTERNAL_MODULE_three_Group__, ImageBitmapLoader as __WEBPACK_EXTERNAL_MODULE_three_ImageBitmapLoader__, InstancedBufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_InstancedBufferAttribute__, InstancedMesh as __WEBPACK_EXTERNAL_MODULE_three_InstancedMesh__, InterleavedBuffer as __WEBPACK_EXTERNAL_MODULE_three_InterleavedBuffer__, InterleavedBufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_InterleavedBufferAttribute__, Interpolant as __WEBPACK_EXTERNAL_MODULE_three_Interpolant__, InterpolateDiscrete as __WEBPACK_EXTERNAL_MODULE_three_InterpolateDiscrete__, InterpolateLinear as __WEBPACK_EXTERNAL_MODULE_three_InterpolateLinear__, Line as __WEBPACK_EXTERNAL_MODULE_three_Line__, LineBasicMaterial as __WEBPACK_EXTERNAL_MODULE_three_LineBasicMaterial__, LineLoop as __WEBPACK_EXTERNAL_MODULE_three_LineLoop__, LineSegments as __WEBPACK_EXTERNAL_MODULE_three_LineSegments__, LinearFilter as __WEBPACK_EXTERNAL_MODULE_three_LinearFilter__, LinearMipmapLinearFilter as __WEBPACK_EXTERNAL_MODULE_three_LinearMipmapLinearFilter__, LinearMipmapNearestFilter as __WEBPACK_EXTERNAL_MODULE_three_LinearMipmapNearestFilter__, LinearSRGBColorSpace as __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__, Loader as __WEBPACK_EXTERNAL_MODULE_three_Loader__, LoaderUtils as __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__, Material as __WEBPACK_EXTERNAL_MODULE_three_Material__, MathUtils as __WEBPACK_EXTERNAL_MODULE_three_MathUtils__, Matrix3 as __WEBPACK_EXTERNAL_MODULE_three_Matrix3__, Matrix4 as __WEBPACK_EXTERNAL_MODULE_three_Matrix4__, Mesh as __WEBPACK_EXTERNAL_MODULE_three_Mesh__, MeshBasicMaterial as __WEBPACK_EXTERNAL_MODULE_three_MeshBasicMaterial__, MeshLambertMaterial as __WEBPACK_EXTERNAL_MODULE_three_MeshLambertMaterial__, MeshPhongMaterial as __WEBPACK_EXTERNAL_MODULE_three_MeshPhongMaterial__, MeshPhysicalMaterial as __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__, MeshStandardMaterial as __WEBPACK_EXTERNAL_MODULE_three_MeshStandardMaterial__, MirroredRepeatWrapping as __WEBPACK_EXTERNAL_MODULE_three_MirroredRepeatWrapping__, MultiplyBlending as __WEBPACK_EXTERNAL_MODULE_three_MultiplyBlending__, NearestFilter as __WEBPACK_EXTERNAL_MODULE_three_NearestFilter__, NearestMipmapLinearFilter as __WEBPACK_EXTERNAL_MODULE_three_NearestMipmapLinearFilter__, NearestMipmapNearestFilter as __WEBPACK_EXTERNAL_MODULE_three_NearestMipmapNearestFilter__, NoBlending as __WEBPACK_EXTERNAL_MODULE_three_NoBlending__, NormalBlending as __WEBPACK_EXTERNAL_MODULE_three_NormalBlending__, NumberKeyframeTrack as __WEBPACK_EXTERNAL_MODULE_three_NumberKeyframeTrack__, Object3D as __WEBPACK_EXTERNAL_MODULE_three_Object3D__, OrthographicCamera as __WEBPACK_EXTERNAL_MODULE_three_OrthographicCamera__, PerspectiveCamera as __WEBPACK_EXTERNAL_MODULE_three_PerspectiveCamera__, PointLight as __WEBPACK_EXTERNAL_MODULE_three_PointLight__, Points as __WEBPACK_EXTERNAL_MODULE_three_Points__, PointsMaterial as __WEBPACK_EXTERNAL_MODULE_three_PointsMaterial__, PositionalAudio as __WEBPACK_EXTERNAL_MODULE_three_PositionalAudio__, PropertyBinding as __WEBPACK_EXTERNAL_MODULE_three_PropertyBinding__, Quaternion as __WEBPACK_EXTERNAL_MODULE_three_Quaternion__, QuaternionKeyframeTrack as __WEBPACK_EXTERNAL_MODULE_three_QuaternionKeyframeTrack__, RepeatWrapping as __WEBPACK_EXTERNAL_MODULE_three_RepeatWrapping__, SRGBColorSpace as __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__, ShapeUtils as __WEBPACK_EXTERNAL_MODULE_three_ShapeUtils__, Skeleton as __WEBPACK_EXTERNAL_MODULE_three_Skeleton__, SkinnedMesh as __WEBPACK_EXTERNAL_MODULE_three_SkinnedMesh__, Sphere as __WEBPACK_EXTERNAL_MODULE_three_Sphere__, SphereGeometry as __WEBPACK_EXTERNAL_MODULE_three_SphereGeometry__, SpotLight as __WEBPACK_EXTERNAL_MODULE_three_SpotLight__, SubtractiveBlending as __WEBPACK_EXTERNAL_MODULE_three_SubtractiveBlending__, Texture as __WEBPACK_EXTERNAL_MODULE_three_Texture__, TextureLoader as __WEBPACK_EXTERNAL_MODULE_three_TextureLoader__, TriangleFanDrawMode as __WEBPACK_EXTERNAL_MODULE_three_TriangleFanDrawMode__, TriangleStripDrawMode as __WEBPACK_EXTERNAL_MODULE_three_TriangleStripDrawMode__, TrianglesDrawMode as __WEBPACK_EXTERNAL_MODULE_three_TrianglesDrawMode__, Uint16BufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_Uint16BufferAttribute__, Vector2 as __WEBPACK_EXTERNAL_MODULE_three_Vector2__, Vector3 as __WEBPACK_EXTERNAL_MODULE_three_Vector3__, Vector4 as __WEBPACK_EXTERNAL_MODULE_three_Vector4__, VectorKeyframeTrack as __WEBPACK_EXTERNAL_MODULE_three_VectorKeyframeTrack__ } from "three";
import { MeshBasicNodeMaterial as __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_MeshBasicNodeMaterial__, PointsNodeMaterial as __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_PointsNodeMaterial__, StorageBufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__, StorageInstancedBufferAttribute as __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageInstancedBufferAttribute__ } from "three/webgpu";
import { Continue as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Continue__, Discard as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__, Fn as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__, If as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__, Loop as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Loop__, abs as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_abs__, atomicAdd as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicAdd__, atomicLoad as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__, atomicStore as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicStore__, attribute as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__, buffer as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_buffer__, cameraPosition as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraPosition__, cameraProjectionMatrix as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraProjectionMatrix__, cameraViewMatrix as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraViewMatrix__, compute as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__, cos as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__, cross as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cross__, dot as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__, float as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__, floor as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__, fract as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_fract__, instanceIndex as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__, length as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__, max as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__, min as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__, mix as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__, mod as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mod__, modelViewMatrix as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__, normalLocal as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalLocal__, normalize as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__, positionLocal as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__, round as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_round__, screenUV as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_screenUV__, sin as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__, smoothstep as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_smoothstep__, sqrt as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sqrt__, step as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_step__, storage as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__, texture as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__, uint as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__, uniform as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__, uv as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uv__, varyingProperty as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__, vec2 as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__, vec3 as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__, vec4 as __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__ } from "three/tsl";
/******/ var __webpack_modules__ = ({

/***/ 300
(module) {

// Linear easing.
//
// @class Easing.Linear
const Linear = k => k

// Quadratic easing.
//
// @class Easing.Quadratic
const Quadratic = {

  // Ease-in.
  //
  // @method Easing.Quadratic#In
  // @param {number} k - The value to be tweened.
  // @returns {number} k^2.
  In (k) {
    return k * k
  },

  // Ease-out.
  //
  // @method Easing.Quadratic#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} k * (2 - k).
  Out (k) {
    return k * (2 - k)
  },

  // Ease-in/out.
  //
  // @method Easing.Quadratic#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    let dk = k * 2
    if (dk < 1) {
      return 0.5 * dk * dk
    }
    dk -= 1
    return - 0.5 * (dk * (dk - 2) - 1)
  }

}

// Cubic easing.
//
// @class Easing.Cubic
const Cubic = {

  // Cubic ease-in.
  //
  // @method Easing.Cubic#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return k * k * k
  },

  // Cubic ease-out.
  //
  // @method Easing.Cubic#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    return -- k * k * k + 1
  },

  // Cubic ease-in/out.
  //
  // @method Easing.Cubic#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    let dk = k * 2
    if (dk < 1) {
      return 0.5 * dk * dk * dk
    }
    dk -= 2
    return 0.5 * (dk * dk * dk + 2)
  }

}

// Quartic easing.
//
// @class Easing.Quartic
const Quartic = {

  // Quartic ease-in.
  //
  // @method Easing.Quartic#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return k * k * k * k
  },

  // Quartic ease-out.
  //
  // @method Easing.Quartic#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    return 1 - (-- k * k * k * k)
  },

  // Quartic ease-in/out.
  //
  // @method Easing.Quartic#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    let dk = k * 2
    if (dk < 1) {
      return 0.5 * dk * dk * dk * dk
    }
    dk -= 2
    return - 0.5 * (dk * dk * dk * dk - 2)
  }

}

// Quintic easing.
//
// @class Easing.Quintic
const Quintic = {

  // Quintic ease-in.
  //
  // @method Easing.Quintic#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return k * k * k * k * k
  },

  // Quintic ease-out.
  //
  // @method Easing.Quintic#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    return -- k * k * k * k * k + 1
  },

  // Quintic ease-in/out.
  //
  // @method Easing.Quintic#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    let dk = k * 2
    if (dk < 1) {
      return 0.5 * dk * dk * dk * dk * dk
    }
    dk -= 2
    return 0.5 * (dk * dk * dk * dk * dk + 2)
  }

}

// Sinusoidal easing.
//
// @class Easing.Sinusoidal
const Sinusoidal = {

  // Sinusoidal ease-in.
  //
  // @method Easing.Sinusoidal#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return 1 - Math.cos(k * Math.PI / 2)
  },

  // Sinusoidal ease-out.
  //
  // @method Easing.Sinusoidal#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    return Math.sin(k * Math.PI / 2)
  },

  // Sinusoidal ease-in/out.
  //
  // @method Easing.Sinusoidal#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    return 0.5 * (1 - Math.cos(Math.PI * k))
  }

}

// Exponential easing.
//
// @class Easing.Exponential
const Exponential = {

  // Exponential ease-in.
  //
  // @method Easing.Exponential#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return k === 0 ? 0 : 1024 ** (k - 1)
  },

  // Exponential ease-out.
  //
  // @method Easing.Exponential#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    return k === 1 ? 1 : 1 - (2 ** (- 10 * k))
  },

  // Exponential ease-in/out.
  //
  // @method Easing.Exponential#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    if (k === 0) return 0
    if (k === 1) return 1
    const dk = k * 2
    if (dk < 1) {
      return 0.5 * (1024 ** (dk - 1))
    }
    return 0.5 * (- (2 ** (- 10 * (dk - 1))) + 2)
  }

}

// Circular easing.
//
// @class Easing.Circular
const Circular = {

  // Circular ease-in.
  //
  // @method Easing.Circular#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return 1 - Math.sqrt(1 - k * k)
  },

  // Circular ease-out.
  //
  // @method Easing.Circular#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    return Math.sqrt(1 - (-- k * k))
  },

  // Circular ease-in/out.
  //
  // @method Easing.Circular#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    let dk = k * 2
    if (dk < 1) {
      return - 0.5 * (Math.sqrt(1 - dk * dk) - 1)
    }
    dk -= 2
    return 0.5 * (Math.sqrt(1 - dk * dk) + 1)
  }

}

// Elastic easing.
//
// @class Easing.Elastic
const Elastic = {

  // Elastic ease-in.
  //
  // @method Easing.Elastic#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    let a = 0.1
    const p = 0.4
    let s
    if (k === 0) return 0
    if (k === 1) return 1
    if (a < 1) {
      a = 1
      s = p / 4
    } else {
      s = p * Math.asin(1 / a) / (2 * Math.PI)
    }
    k -= 1
    return - (a * (2 ** (10 * k)) * Math.sin((k - s) * (2 * Math.PI) / p))
  },

  // Elastic ease-out.
  //
  // @method Easing.Elastic#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    let a = 0.1
    const p = 0.4
    let s
    if (k === 0) return 0
    if (k === 1) return 1
    if (a < 1) {
      a = 1
      s = p / 4
    } else {
      s = p * Math.asin(1 / a) / (2 * Math.PI)
    }
    return (a * (2 ** (- 10 * k)) * Math.sin((k - s) * (2 * Math.PI) / p) + 1)
  },

  // Elastic ease-in/out.
  //
  // @method Easing.Elastic#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    let a = 0.1
    const p = 0.4
    let s
    if (k === 0) return 0
    if (k === 1) return 1
    if (a < 1) {
      a = 1
      s = p / 4
    } else {
      s = p * Math.asin(1 / a) / (2 * Math.PI)
    }
    const dk = k * 2
    if (dk < 1) {
      const kInner = dk - 1
      return - 0.5 * (a * (2 ** (10 * kInner)) * Math.sin((kInner - s) * (2 * Math.PI) / p))
    }
    const kInner = dk - 1
    return a * (2 ** (- 10 * kInner)) * Math.sin((kInner - s) * (2 * Math.PI) / p) * 0.5 + 1
  }

}

// Back easing.
//
// @class Easing.Back
const Back = {

  // Back ease-in.
  //
  // @method Easing.Back#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    const s = 1.70158
    return k * k * ((s + 1) * k - s)
  },

  // Back ease-out.
  //
  // @method Easing.Back#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    const s = 1.70158
    return -- k * k * ((s + 1) * k + s) + 1
  },

  // Back ease-in/out.
  //
  // @method Easing.Back#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    const s = 1.70158 * 1.525
    let dk = k * 2
    if (dk < 1) {
      return 0.5 * (dk * dk * ((s + 1) * dk - s))
    }
    dk -= 2
    return 0.5 * (dk * dk * ((s + 1) * dk + s) + 2)
  }

}

// Bounce easing.
//
// @class Easing.Bounce
const Bounce = {

  // Bounce ease-in.
  //
  // @method Easing.Bounce#In
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  In (k) {
    return 1 - Bounce.Out(1 - k)
  },

  // Bounce ease-out.
  //
  // @method Easing.Bounce#Out
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  Out (k) {
    if (k < 1 / 2.75) {
      return 7.5625 * k * k
    } if (k < 2 / 2.75) {
      const k2 = k - (1.5 / 2.75)
      return 7.5625 * k2 * k2 + 0.75
    } if (k < 2.5 / 2.75) {
      const k2 = k - (2.25 / 2.75)
      return 7.5625 * k2 * k2 + 0.9375
    }
    const k2 = k - (2.625 / 2.75)
    return 7.5625 * k2 * k2 + 0.984375
  },

  // Bounce ease-in/out.
  //
  // @method Easing.Bounce#InOut
  // @param {number} k - The value to be tweened.
  // @returns {number} The tweened value.
  InOut (k) {
    if (k < 0.5) return Bounce.In(k * 2) * 0.5
    return Bounce.Out(k * 2 - 1) * 0.5 + 0.5
  }

}

const Easing = {
  Quadratic,
  Cubic,
  Quartic,
  Quintic,
  Sinusoidal,
  Exponential,
  Circular,
  Elastic,
  Back,
  Bounce,
}

const define = (obj, key, value) => Object.defineProperty(obj, key, {
  value
})

for (const key of Object.keys(Easing)) {
  const obj = Easing[key]
  const lowerKey = key.toLowerCase()
  define(Easing, lowerKey, obj)

  for (const prop of Object.keys(obj)) {
    const fn = obj[prop]
    const lowerProp = prop.toLowerCase()

    // Easing['Quadratic.In']
    define(Easing, `${key}.${prop}`, fn)

    // Easing['quadratic.in']
    define(Easing, `${lowerKey}.${lowerProp}`, fn)
    define(obj, lowerProp, fn)
  }
}

Easing.Linear = Linear
define(Easing, 'linear', Linear)

module.exports = Easing

if (typeof window !== 'undefined') {
  window.Easing = Easing
}


/***/ }

/******/ });
/************************************************************************/
/******/ // The module cache
/******/ var __webpack_module_cache__ = {};
/******/ 
/******/ // The require function
/******/ function __webpack_require__(moduleId) {
/******/ 	// Check if module is in cache
/******/ 	var cachedModule = __webpack_module_cache__[moduleId];
/******/ 	if (cachedModule !== undefined) {
/******/ 		return cachedModule.exports;
/******/ 	}
/******/ 	// Create a new module (and put it into the cache)
/******/ 	var module = __webpack_module_cache__[moduleId] = {
/******/ 		// no module.id needed
/******/ 		// no module.loaded needed
/******/ 		exports: {}
/******/ 	};
/******/ 
/******/ 	// Execute the module function
/******/ 	__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 
/******/ 	// Return the exports of the module
/******/ 	return module.exports;
/******/ }
/******/ 
/************************************************************************/
/******/ /* webpack/runtime/define property getters */
/******/ (() => {
/******/ 	// define getter functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ })();
/******/ 
/******/ /* webpack/runtime/hasOwnProperty shorthand */
/******/ (() => {
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ })();
/******/ 
/************************************************************************/

// EXTERNAL MODULE: ./node_modules/easing-functions/index.js
var easing_functions = __webpack_require__(300);
;// external "three"

;// ./node_modules/@newkrok/three-utils/dist/callback-utils.js
const CallLimits = {
    NO_LIMIT: -1,
    CALL_1_PER_SECONDS: 1000,
    CALL_15_PER_SECONDS: 1000 / 15,
    CALL_30_PER_SECONDS: 1000 / 30,
    CALL_45_PER_SECONDS: 1000 / 45,
    CALL_60_PER_SECONDS: 1000 / 60,
    CALL_120_PER_SECONDS: 1000 / 120,
};
let callData = {};
const callWithReducer = ({ id, callback, callLimit, elapsed, callbackParam, forceCallCount = false, }) => {
    if (!elapsed)
        return;
    if (!callData[id])
        callData[id] = { lastUpdate: -1, callCount: 0 };
    const call = () => {
        if (callbackParam)
            callback(callbackParam);
        else
            callback();
    };
    if (callLimit === CallLimits.NO_LIMIT) {
        call();
        return;
    }
    if (forceCallCount) {
        const expectedCallCount = Math.floor(elapsed / (callLimit * 1000));
        while (callData[id].lastUpdate === -1 ||
            expectedCallCount > callData[id].callCount) {
            call();
            callData[id].lastUpdate += callLimit;
            callData[id].callCount++;
        }
        callData[id].lastUpdate = elapsed;
    }
    else if (callData[id].lastUpdate === -1 ||
        elapsed - callData[id].lastUpdate >= callLimit) {
        call();
        callData[id].lastUpdate = elapsed;
    }
};
const clearCallReducerData = (id) => delete callData[id];
const clearAllCallReducerData = () => {
    callData = {};
};

;// ./node_modules/@newkrok/three-utils/dist/time-utils.js
const TimePattern = {
    HH_MM_SS: 'HH:MM:SS',
    MM_SS: 'MM:SS',
    MM_SS_MS: 'MM:SS.MS',
};
const patterns = [
    { pattern: 'HH', routine: ({ hours }) => String(hours).padStart(2, '0') },
    { pattern: 'MM', routine: ({ minutes }) => String(minutes).padStart(2, '0') },
    { pattern: 'SS', routine: ({ seconds }) => String(seconds).padStart(2, '0') },
    {
        pattern: 'MS',
        routine: ({ milliseconds }) => String(milliseconds).padStart(3, '0'),
    },
];
const formatTime = (timeInMS, pattern) => {
    const milliseconds = Math.floor(timeInMS % 1000);
    const seconds = Math.floor((timeInMS / 1000) % 60);
    const minutes = Math.floor(Math.floor(timeInMS / 1000 / 60) % 60);
    const hours = Math.floor((Math.floor(timeInMS / 1000 / 60) / 60) % 24);
    const timeDetails = { hours, minutes, seconds, milliseconds };
    let result = pattern;
    patterns.forEach(({ pattern: currentPattern, routine }) => (result = result.replace(currentPattern, routine(timeDetails))));
    return result;
};

;// ../../node_modules/three/examples/jsm/libs/fflate.module.js
/*!
fflate - fast JavaScript compression/decompression
<https://101arrowz.github.io/fflate>
Licensed under MIT. https://github.com/101arrowz/fflate/blob/master/LICENSE
version 0.8.2
*/

// DEFLATE is a complex format; to read this code, you should probably check the RFC first:
// https://tools.ietf.org/html/rfc1951
// You may also wish to take a look at the guide I made about this program:
// https://gist.github.com/101arrowz/253f31eb5abc3d9275ab943003ffecad
// Some of the following code is similar to that of UZIP.js:
// https://github.com/photopea/UZIP.js
// However, the vast majority of the codebase has diverged from UZIP.js to increase performance and reduce bundle size.
// Sometimes 0 will appear where -1 would be more appropriate. This is because using a uint
// is better for memory in most engines (I *think*).
var ch2 = {};
var wk = (function (c, id, msg, transfer, cb) {
    var w = new Worker(ch2[id] || (ch2[id] = URL.createObjectURL(new Blob([
        c + ';addEventListener("error",function(e){e=e.error;postMessage({$e$:[e.message,e.code,e.stack]})})'
    ], { type: 'text/javascript' }))));
    w.onmessage = function (e) {
        var d = e.data, ed = d.$e$;
        if (ed) {
            var err = new Error(ed[0]);
            err['code'] = ed[1];
            err.stack = ed[2];
            cb(err, null);
        }
        else
            cb(null, d);
    };
    w.postMessage(msg, transfer);
    return w;
});

// aliases for shorter compressed code (most minifers don't do this)
var u8 = Uint8Array, u16 = Uint16Array, i32 = Int32Array;
// fixed length extra bits
var fleb = new u8([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, /* unused */ 0, 0, /* impossible */ 0]);
// fixed distance extra bits
var fdeb = new u8([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, /* unused */ 0, 0]);
// code length index map
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
// get base, reverse index map from extra bits
var freb = function (eb, start) {
    var b = new u16(31);
    for (var i = 0; i < 31; ++i) {
        b[i] = start += 1 << eb[i - 1];
    }
    // numbers here are at max 18 bits
    var r = new i32(b[30]);
    for (var i = 1; i < 30; ++i) {
        for (var j = b[i]; j < b[i + 1]; ++j) {
            r[j] = ((j - b[i]) << 5) | i;
        }
    }
    return { b: b, r: r };
};
var _a = freb(fleb, 2), fl = _a.b, revfl = _a.r;
// we can ignore the fact that the other numbers are wrong; they never happen anyway
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0), fd = _b.b, revfd = _b.r;
// map of value to reverse (assuming 16 bits)
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
    // reverse table algorithm from SO
    var x = ((i & 0xAAAA) >> 1) | ((i & 0x5555) << 1);
    x = ((x & 0xCCCC) >> 2) | ((x & 0x3333) << 2);
    x = ((x & 0xF0F0) >> 4) | ((x & 0x0F0F) << 4);
    rev[i] = (((x & 0xFF00) >> 8) | ((x & 0x00FF) << 8)) >> 1;
}
// create huffman tree from u8 "map": index -> code length for code index
// mb (max bits) must be at most 15
// TODO: optimize/split up?
var hMap = (function (cd, mb, r) {
    var s = cd.length;
    // index
    var i = 0;
    // u16 "map": index -> # of codes with bit length = index
    var l = new u16(mb);
    // length of cd must be 288 (total # of codes)
    for (; i < s; ++i) {
        if (cd[i])
            ++l[cd[i] - 1];
    }
    // u16 "map": index -> minimum code for bit length = index
    var le = new u16(mb);
    for (i = 1; i < mb; ++i) {
        le[i] = (le[i - 1] + l[i - 1]) << 1;
    }
    var co;
    if (r) {
        // u16 "map": index -> number of actual bits, symbol for code
        co = new u16(1 << mb);
        // bits to remove for reverser
        var rvb = 15 - mb;
        for (i = 0; i < s; ++i) {
            // ignore 0 lengths
            if (cd[i]) {
                // num encoding both symbol and bits read
                var sv = (i << 4) | cd[i];
                // free bits
                var r_1 = mb - cd[i];
                // start value
                var v = le[cd[i] - 1]++ << r_1;
                // m is end value
                for (var m = v | ((1 << r_1) - 1); v <= m; ++v) {
                    // every 16 bit value starting with the code yields the same result
                    co[rev[v] >> rvb] = sv;
                }
            }
        }
    }
    else {
        co = new u16(s);
        for (i = 0; i < s; ++i) {
            if (cd[i]) {
                co[i] = rev[le[cd[i] - 1]++] >> (15 - cd[i]);
            }
        }
    }
    return co;
});
// fixed length tree
var flt = new u8(288);
for (var i = 0; i < 144; ++i)
    flt[i] = 8;
for (var i = 144; i < 256; ++i)
    flt[i] = 9;
for (var i = 256; i < 280; ++i)
    flt[i] = 7;
for (var i = 280; i < 288; ++i)
    flt[i] = 8;
// fixed distance tree
var fdt = new u8(32);
for (var i = 0; i < 32; ++i)
    fdt[i] = 5;
// fixed length map
var flm = /*#__PURE__*/ (/* unused pure expression or super */ null && (hMap(flt, 9, 0))), flrm = /*#__PURE__*/ hMap(flt, 9, 1);
// fixed distance map
var fdm = /*#__PURE__*/ (/* unused pure expression or super */ null && (hMap(fdt, 5, 0))), fdrm = /*#__PURE__*/ hMap(fdt, 5, 1);
// find max of array
var max = function (a) {
    var m = a[0];
    for (var i = 1; i < a.length; ++i) {
        if (a[i] > m)
            m = a[i];
    }
    return m;
};
// read d, starting at bit p and mask with m
var bits = function (d, p, m) {
    var o = (p / 8) | 0;
    return ((d[o] | (d[o + 1] << 8)) >> (p & 7)) & m;
};
// read d, starting at bit p continuing for at least 16 bits
var bits16 = function (d, p) {
    var o = (p / 8) | 0;
    return ((d[o] | (d[o + 1] << 8) | (d[o + 2] << 16)) >> (p & 7));
};
// get end of byte
var shft = function (p) { return ((p + 7) / 8) | 0; };
// typed array slice - allows garbage collector to free original reference,
// while being more compatible than .slice
var slc = function (v, s, e) {
    if (s == null || s < 0)
        s = 0;
    if (e == null || e > v.length)
        e = v.length;
    // can't use .constructor in case user-supplied
    return new u8(v.subarray(s, e));
};
/**
 * Codes for errors generated within this library
 */
var FlateErrorCode = {
    UnexpectedEOF: 0,
    InvalidBlockType: 1,
    InvalidLengthLiteral: 2,
    InvalidDistance: 3,
    StreamFinished: 4,
    NoStreamHandler: 5,
    InvalidHeader: 6,
    NoCallback: 7,
    InvalidUTF8: 8,
    ExtraFieldTooLong: 9,
    InvalidDate: 10,
    FilenameTooLong: 11,
    StreamFinishing: 12,
    InvalidZipData: 13,
    UnknownCompressionMethod: 14
};
// error codes
var ec = [
    'unexpected EOF',
    'invalid block type',
    'invalid length/literal',
    'invalid distance',
    'stream finished',
    'no stream handler',
    ,
    'no callback',
    'invalid UTF-8 data',
    'extra field too long',
    'date not in range 1980-2099',
    'filename too long',
    'stream finishing',
    'invalid zip data'
    // determined by unknown compression method
];
;
var err = function (ind, msg, nt) {
    var e = new Error(msg || ec[ind]);
    e.code = ind;
    if (Error.captureStackTrace)
        Error.captureStackTrace(e, err);
    if (!nt)
        throw e;
    return e;
};
// expands raw DEFLATE data
var inflt = function (dat, st, buf, dict) {
    // source length       dict length
    var sl = dat.length, dl = dict ? dict.length : 0;
    if (!sl || st.f && !st.l)
        return buf || new u8(0);
    var noBuf = !buf;
    // have to estimate size
    var resize = noBuf || st.i != 2;
    // no state
    var noSt = st.i;
    // Assumes roughly 33% compression ratio average
    if (noBuf)
        buf = new u8(sl * 3);
    // ensure buffer can fit at least l elements
    var cbuf = function (l) {
        var bl = buf.length;
        // need to increase size to fit
        if (l > bl) {
            // Double or set to necessary, whichever is greater
            var nbuf = new u8(Math.max(bl * 2, l));
            nbuf.set(buf);
            buf = nbuf;
        }
    };
    //  last chunk         bitpos           bytes
    var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
    // total bits
    var tbts = sl * 8;
    do {
        if (!lm) {
            // BFINAL - this is only 1 when last chunk is next
            final = bits(dat, pos, 1);
            // type: 0 = no compression, 1 = fixed huffman, 2 = dynamic huffman
            var type = bits(dat, pos + 1, 3);
            pos += 3;
            if (!type) {
                // go to end of byte boundary
                var s = shft(pos) + 4, l = dat[s - 4] | (dat[s - 3] << 8), t = s + l;
                if (t > sl) {
                    if (noSt)
                        err(0);
                    break;
                }
                // ensure size
                if (resize)
                    cbuf(bt + l);
                // Copy over uncompressed data
                buf.set(dat.subarray(s, t), bt);
                // Get new bitpos, update byte count
                st.b = bt += l, st.p = pos = t * 8, st.f = final;
                continue;
            }
            else if (type == 1)
                lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
            else if (type == 2) {
                //  literal                            lengths
                var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
                var tl = hLit + bits(dat, pos + 5, 31) + 1;
                pos += 14;
                // length+distance tree
                var ldt = new u8(tl);
                // code length tree
                var clt = new u8(19);
                for (var i = 0; i < hcLen; ++i) {
                    // use index map to get real code
                    clt[clim[i]] = bits(dat, pos + i * 3, 7);
                }
                pos += hcLen * 3;
                // code lengths bits
                var clb = max(clt), clbmsk = (1 << clb) - 1;
                // code lengths map
                var clm = hMap(clt, clb, 1);
                for (var i = 0; i < tl;) {
                    var r = clm[bits(dat, pos, clbmsk)];
                    // bits read
                    pos += r & 15;
                    // symbol
                    var s = r >> 4;
                    // code length to copy
                    if (s < 16) {
                        ldt[i++] = s;
                    }
                    else {
                        //  copy   count
                        var c = 0, n = 0;
                        if (s == 16)
                            n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
                        else if (s == 17)
                            n = 3 + bits(dat, pos, 7), pos += 3;
                        else if (s == 18)
                            n = 11 + bits(dat, pos, 127), pos += 7;
                        while (n--)
                            ldt[i++] = c;
                    }
                }
                //    length tree                 distance tree
                var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
                // max length bits
                lbt = max(lt);
                // max dist bits
                dbt = max(dt);
                lm = hMap(lt, lbt, 1);
                dm = hMap(dt, dbt, 1);
            }
            else
                err(1);
            if (pos > tbts) {
                if (noSt)
                    err(0);
                break;
            }
        }
        // Make sure the buffer can hold this + the largest possible addition
        // Maximum chunk size (practically, theoretically infinite) is 2^17
        if (resize)
            cbuf(bt + 131072);
        var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
        var lpos = pos;
        for (;; lpos = pos) {
            // bits read, code
            var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
            pos += c & 15;
            if (pos > tbts) {
                if (noSt)
                    err(0);
                break;
            }
            if (!c)
                err(2);
            if (sym < 256)
                buf[bt++] = sym;
            else if (sym == 256) {
                lpos = pos, lm = null;
                break;
            }
            else {
                var add = sym - 254;
                // no extra bits needed if less
                if (sym > 264) {
                    // index
                    var i = sym - 257, b = fleb[i];
                    add = bits(dat, pos, (1 << b) - 1) + fl[i];
                    pos += b;
                }
                // dist
                var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
                if (!d)
                    err(3);
                pos += d & 15;
                var dt = fd[dsym];
                if (dsym > 3) {
                    var b = fdeb[dsym];
                    dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
                }
                if (pos > tbts) {
                    if (noSt)
                        err(0);
                    break;
                }
                if (resize)
                    cbuf(bt + 131072);
                var end = bt + add;
                if (bt < dt) {
                    var shift = dl - dt, dend = Math.min(dt, end);
                    if (shift + bt < 0)
                        err(3);
                    for (; bt < dend; ++bt)
                        buf[bt] = dict[shift + bt];
                }
                for (; bt < end; ++bt)
                    buf[bt] = buf[bt - dt];
            }
        }
        st.l = lm, st.p = lpos, st.b = bt, st.f = final;
        if (lm)
            final = 1, st.m = lbt, st.d = dm, st.n = dbt;
    } while (!final);
    // don't reallocate for streams or user buffers
    return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
// starting at p, write the minimum number of bits that can hold v to d
var wbits = function (d, p, v) {
    v <<= p & 7;
    var o = (p / 8) | 0;
    d[o] |= v;
    d[o + 1] |= v >> 8;
};
// starting at p, write the minimum number of bits (>8) that can hold v to d
var wbits16 = function (d, p, v) {
    v <<= p & 7;
    var o = (p / 8) | 0;
    d[o] |= v;
    d[o + 1] |= v >> 8;
    d[o + 2] |= v >> 16;
};
// creates code lengths from a frequency table
var hTree = function (d, mb) {
    // Need extra info to make a tree
    var t = [];
    for (var i = 0; i < d.length; ++i) {
        if (d[i])
            t.push({ s: i, f: d[i] });
    }
    var s = t.length;
    var t2 = t.slice();
    if (!s)
        return { t: et, l: 0 };
    if (s == 1) {
        var v = new u8(t[0].s + 1);
        v[t[0].s] = 1;
        return { t: v, l: 1 };
    }
    t.sort(function (a, b) { return a.f - b.f; });
    // after i2 reaches last ind, will be stopped
    // freq must be greater than largest possible number of symbols
    t.push({ s: -1, f: 25001 });
    var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
    t[0] = { s: -1, f: l.f + r.f, l: l, r: r };
    // efficient algorithm from UZIP.js
    // i0 is lookbehind, i2 is lookahead - after processing two low-freq
    // symbols that combined have high freq, will start processing i2 (high-freq,
    // non-composite) symbols instead
    // see https://reddit.com/r/photopea/comments/ikekht/uzipjs_questions/
    while (i1 != s - 1) {
        l = t[t[i0].f < t[i2].f ? i0++ : i2++];
        r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
        t[i1++] = { s: -1, f: l.f + r.f, l: l, r: r };
    }
    var maxSym = t2[0].s;
    for (var i = 1; i < s; ++i) {
        if (t2[i].s > maxSym)
            maxSym = t2[i].s;
    }
    // code lengths
    var tr = new u16(maxSym + 1);
    // max bits in tree
    var mbt = ln(t[i1 - 1], tr, 0);
    if (mbt > mb) {
        // more algorithms from UZIP.js
        // TODO: find out how this code works (debt)
        //  ind    debt
        var i = 0, dt = 0;
        //    left            cost
        var lft = mbt - mb, cst = 1 << lft;
        t2.sort(function (a, b) { return tr[b.s] - tr[a.s] || a.f - b.f; });
        for (; i < s; ++i) {
            var i2_1 = t2[i].s;
            if (tr[i2_1] > mb) {
                dt += cst - (1 << (mbt - tr[i2_1]));
                tr[i2_1] = mb;
            }
            else
                break;
        }
        dt >>= lft;
        while (dt > 0) {
            var i2_2 = t2[i].s;
            if (tr[i2_2] < mb)
                dt -= 1 << (mb - tr[i2_2]++ - 1);
            else
                ++i;
        }
        for (; i >= 0 && dt; --i) {
            var i2_3 = t2[i].s;
            if (tr[i2_3] == mb) {
                --tr[i2_3];
                ++dt;
            }
        }
        mbt = mb;
    }
    return { t: new u8(tr), l: mbt };
};
// get the max length and assign length codes
var ln = function (n, l, d) {
    return n.s == -1
        ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1))
        : (l[n.s] = d);
};
// length codes generation
var lc = function (c) {
    var s = c.length;
    // Note that the semicolon was intentional
    while (s && !c[--s])
        ;
    var cl = new u16(++s);
    //  ind      num         streak
    var cli = 0, cln = c[0], cls = 1;
    var w = function (v) { cl[cli++] = v; };
    for (var i = 1; i <= s; ++i) {
        if (c[i] == cln && i != s)
            ++cls;
        else {
            if (!cln && cls > 2) {
                for (; cls > 138; cls -= 138)
                    w(32754);
                if (cls > 2) {
                    w(cls > 10 ? ((cls - 11) << 5) | 28690 : ((cls - 3) << 5) | 12305);
                    cls = 0;
                }
            }
            else if (cls > 3) {
                w(cln), --cls;
                for (; cls > 6; cls -= 6)
                    w(8304);
                if (cls > 2)
                    w(((cls - 3) << 5) | 8208), cls = 0;
            }
            while (cls--)
                w(cln);
            cls = 1;
            cln = c[i];
        }
    }
    return { c: cl.subarray(0, cli), n: s };
};
// calculate the length of output from tree, code lengths
var clen = function (cf, cl) {
    var l = 0;
    for (var i = 0; i < cl.length; ++i)
        l += cf[i] * cl[i];
    return l;
};
// writes a fixed block
// returns the new bit pos
var wfblk = function (out, pos, dat) {
    // no need to write 00 as type: TypedArray defaults to 0
    var s = dat.length;
    var o = shft(pos + 2);
    out[o] = s & 255;
    out[o + 1] = s >> 8;
    out[o + 2] = out[o] ^ 255;
    out[o + 3] = out[o + 1] ^ 255;
    for (var i = 0; i < s; ++i)
        out[o + i + 4] = dat[i];
    return (o + 4 + s) * 8;
};
// writes a block
var wblk = function (dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
    wbits(out, p++, final);
    ++lf[256];
    var _a = hTree(lf, 15), dlt = _a.t, mlb = _a.l;
    var _b = hTree(df, 15), ddt = _b.t, mdb = _b.l;
    var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
    var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
    var lcfreq = new u16(19);
    for (var i = 0; i < lclt.length; ++i)
        ++lcfreq[lclt[i] & 31];
    for (var i = 0; i < lcdt.length; ++i)
        ++lcfreq[lcdt[i] & 31];
    var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
    var nlcc = 19;
    for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc)
        ;
    var flen = (bl + 5) << 3;
    var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
    var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
    if (bs >= 0 && flen <= ftlen && flen <= dtlen)
        return wfblk(out, p, dat.subarray(bs, bs + bl));
    var lm, ll, dm, dl;
    wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
    if (dtlen < ftlen) {
        lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
        var llm = hMap(lct, mlcb, 0);
        wbits(out, p, nlc - 257);
        wbits(out, p + 5, ndc - 1);
        wbits(out, p + 10, nlcc - 4);
        p += 14;
        for (var i = 0; i < nlcc; ++i)
            wbits(out, p + 3 * i, lct[clim[i]]);
        p += 3 * nlcc;
        var lcts = [lclt, lcdt];
        for (var it = 0; it < 2; ++it) {
            var clct = lcts[it];
            for (var i = 0; i < clct.length; ++i) {
                var len = clct[i] & 31;
                wbits(out, p, llm[len]), p += lct[len];
                if (len > 15)
                    wbits(out, p, (clct[i] >> 5) & 127), p += clct[i] >> 12;
            }
        }
    }
    else {
        lm = flm, ll = flt, dm = fdm, dl = fdt;
    }
    for (var i = 0; i < li; ++i) {
        var sym = syms[i];
        if (sym > 255) {
            var len = (sym >> 18) & 31;
            wbits16(out, p, lm[len + 257]), p += ll[len + 257];
            if (len > 7)
                wbits(out, p, (sym >> 23) & 31), p += fleb[len];
            var dst = sym & 31;
            wbits16(out, p, dm[dst]), p += dl[dst];
            if (dst > 3)
                wbits16(out, p, (sym >> 5) & 8191), p += fdeb[dst];
        }
        else {
            wbits16(out, p, lm[sym]), p += ll[sym];
        }
    }
    wbits16(out, p, lm[256]);
    return p + ll[256];
};
// deflate options (nice << 13) | chain
var deo = /*#__PURE__*/ new i32([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]);
// empty
var et = /*#__PURE__*/ new u8(0);
// compresses data into a raw DEFLATE buffer
var dflt = function (dat, lvl, plvl, pre, post, st) {
    var s = st.z || dat.length;
    var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7000)) + post);
    // writing to this writes to the output buffer
    var w = o.subarray(pre, o.length - post);
    var lst = st.l;
    var pos = (st.r || 0) & 7;
    if (lvl) {
        if (pos)
            w[0] = st.r >> 3;
        var opt = deo[lvl - 1];
        var n = opt >> 13, c = opt & 8191;
        var msk_1 = (1 << plvl) - 1;
        //    prev 2-byte val map    curr 2-byte val map
        var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
        var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
        var hsh = function (i) { return (dat[i] ^ (dat[i + 1] << bs1_1) ^ (dat[i + 2] << bs2_1)) & msk_1; };
        // 24576 is an arbitrary number of maximum symbols per block
        // 424 buffer for last block
        var syms = new i32(25000);
        // length/literal freq   distance freq
        var lf = new u16(288), df = new u16(32);
        //  l/lcnt  exbits  index          l/lind  waitdx          blkpos
        var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
        for (; i + 2 < s; ++i) {
            // hash value
            var hv = hsh(i);
            // index mod 32768    previous index mod
            var imod = i & 32767, pimod = head[hv];
            prev[imod] = pimod;
            head[hv] = imod;
            // We always should modify head and prev, but only add symbols if
            // this data is not yet processed ("wait" for wait index)
            if (wi <= i) {
                // bytes remaining
                var rem = s - i;
                if ((lc_1 > 7000 || li > 24576) && (rem > 423 || !lst)) {
                    pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
                    li = lc_1 = eb = 0, bs = i;
                    for (var j = 0; j < 286; ++j)
                        lf[j] = 0;
                    for (var j = 0; j < 30; ++j)
                        df[j] = 0;
                }
                //  len    dist   chain
                var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
                if (rem > 2 && hv == hsh(i - dif)) {
                    var maxn = Math.min(n, rem) - 1;
                    var maxd = Math.min(32767, i);
                    // max possible length
                    // not capped at dif because decompressors implement "rolling" index population
                    var ml = Math.min(258, rem);
                    while (dif <= maxd && --ch_1 && imod != pimod) {
                        if (dat[i + l] == dat[i + l - dif]) {
                            var nl = 0;
                            for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl)
                                ;
                            if (nl > l) {
                                l = nl, d = dif;
                                // break out early when we reach "nice" (we are satisfied enough)
                                if (nl > maxn)
                                    break;
                                // now, find the rarest 2-byte sequence within this
                                // length of literals and search for that instead.
                                // Much faster than just using the start
                                var mmd = Math.min(dif, nl - 2);
                                var md = 0;
                                for (var j = 0; j < mmd; ++j) {
                                    var ti = i - dif + j & 32767;
                                    var pti = prev[ti];
                                    var cd = ti - pti & 32767;
                                    if (cd > md)
                                        md = cd, pimod = ti;
                                }
                            }
                        }
                        // check the previous match
                        imod = pimod, pimod = prev[imod];
                        dif += imod - pimod & 32767;
                    }
                }
                // d will be nonzero only when a match was found
                if (d) {
                    // store both dist and len data in one int32
                    // Make sure this is recognized as a len/dist with 28th bit (2^28)
                    syms[li++] = 268435456 | (revfl[l] << 18) | revfd[d];
                    var lin = revfl[l] & 31, din = revfd[d] & 31;
                    eb += fleb[lin] + fdeb[din];
                    ++lf[257 + lin];
                    ++df[din];
                    wi = i + l;
                    ++lc_1;
                }
                else {
                    syms[li++] = dat[i];
                    ++lf[dat[i]];
                }
            }
        }
        for (i = Math.max(i, wi); i < s; ++i) {
            syms[li++] = dat[i];
            ++lf[dat[i]];
        }
        pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
        if (!lst) {
            st.r = (pos & 7) | w[(pos / 8) | 0] << 3;
            // shft(pos) now 1 less if pos & 7 != 0
            pos -= 7;
            st.h = head, st.p = prev, st.i = i, st.w = wi;
        }
    }
    else {
        for (var i = st.w || 0; i < s + lst; i += 65535) {
            // end
            var e = i + 65535;
            if (e >= s) {
                // write final block
                w[(pos / 8) | 0] = lst;
                e = s;
            }
            pos = wfblk(w, pos + 1, dat.subarray(i, e));
        }
        st.i = s;
    }
    return slc(o, 0, pre + shft(pos) + post);
};
// CRC32 table
var crct = /*#__PURE__*/ (/* unused pure expression or super */ null && ((function () {
    var t = new Int32Array(256);
    for (var i = 0; i < 256; ++i) {
        var c = i, k = 9;
        while (--k)
            c = ((c & 1) && -306674912) ^ (c >>> 1);
        t[i] = c;
    }
    return t;
})()));
// CRC32
var crc = function () {
    var c = -1;
    return {
        p: function (d) {
            // closures have awful performance
            var cr = c;
            for (var i = 0; i < d.length; ++i)
                cr = crct[(cr & 255) ^ d[i]] ^ (cr >>> 8);
            c = cr;
        },
        d: function () { return ~c; }
    };
};
// Adler32
var adler = function () {
    var a = 1, b = 0;
    return {
        p: function (d) {
            // closures have awful performance
            var n = a, m = b;
            var l = d.length | 0;
            for (var i = 0; i != l;) {
                var e = Math.min(i + 2655, l);
                for (; i < e; ++i)
                    m += n += d[i];
                n = (n & 65535) + 15 * (n >> 16), m = (m & 65535) + 15 * (m >> 16);
            }
            a = n, b = m;
        },
        d: function () {
            a %= 65521, b %= 65521;
            return (a & 255) << 24 | (a & 0xFF00) << 8 | (b & 255) << 8 | (b >> 8);
        }
    };
};
;
// deflate with opts
var dopt = function (dat, opt, pre, post, st) {
    if (!st) {
        st = { l: 1 };
        if (opt.dictionary) {
            var dict = opt.dictionary.subarray(-32768);
            var newDat = new u8(dict.length + dat.length);
            newDat.set(dict);
            newDat.set(dat, dict.length);
            dat = newDat;
            st.w = dict.length;
        }
    }
    return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? (st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20) : (12 + opt.mem), pre, post, st);
};
// Walmart object spread
var mrg = function (a, b) {
    var o = {};
    for (var k in a)
        o[k] = a[k];
    for (var k in b)
        o[k] = b[k];
    return o;
};
// worker clone
// This is possibly the craziest part of the entire codebase, despite how simple it may seem.
// The only parameter to this function is a closure that returns an array of variables outside of the function scope.
// We're going to try to figure out the variable names used in the closure as strings because that is crucial for workerization.
// We will return an object mapping of true variable name to value (basically, the current scope as a JS object).
// The reason we can't just use the original variable names is minifiers mangling the toplevel scope.
// This took me three weeks to figure out how to do.
var wcln = function (fn, fnStr, td) {
    var dt = fn();
    var st = fn.toString();
    var ks = st.slice(st.indexOf('[') + 1, st.lastIndexOf(']')).replace(/\s+/g, '').split(',');
    for (var i = 0; i < dt.length; ++i) {
        var v = dt[i], k = ks[i];
        if (typeof v == 'function') {
            fnStr += ';' + k + '=';
            var st_1 = v.toString();
            if (v.prototype) {
                // for global objects
                if (st_1.indexOf('[native code]') != -1) {
                    var spInd = st_1.indexOf(' ', 8) + 1;
                    fnStr += st_1.slice(spInd, st_1.indexOf('(', spInd));
                }
                else {
                    fnStr += st_1;
                    for (var t in v.prototype)
                        fnStr += ';' + k + '.prototype.' + t + '=' + v.prototype[t].toString();
                }
            }
            else
                fnStr += st_1;
        }
        else
            td[k] = v;
    }
    return fnStr;
};
var ch = (/* unused pure expression or super */ null && ([]));
// clone bufs
var cbfs = function (v) {
    var tl = [];
    for (var k in v) {
        if (v[k].buffer) {
            tl.push((v[k] = new v[k].constructor(v[k])).buffer);
        }
    }
    return tl;
};
// use a worker to execute code
var wrkr = function (fns, init, id, cb) {
    if (!ch[id]) {
        var fnStr = '', td_1 = {}, m = fns.length - 1;
        for (var i = 0; i < m; ++i)
            fnStr = wcln(fns[i], fnStr, td_1);
        ch[id] = { c: wcln(fns[m], fnStr, td_1), e: td_1 };
    }
    var td = mrg({}, ch[id].e);
    return wk(ch[id].c + ';onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=' + init.toString() + '}', id, td, cbfs(td), cb);
};
// base async inflate fn
var bInflt = function () { return [u8, u16, i32, fleb, fdeb, clim, fl, fd, flrm, fdrm, rev, ec, hMap, max, bits, bits16, shft, slc, err, inflt, inflateSync, pbf, gopt]; };
var bDflt = function () { return [u8, u16, i32, fleb, fdeb, clim, revfl, revfd, flm, flt, fdm, fdt, rev, deo, et, hMap, wbits, wbits16, hTree, ln, lc, clen, wfblk, wblk, shft, slc, dflt, dopt, deflateSync, pbf]; };
// gzip extra
var gze = function () { return [gzh, gzhl, wbytes, crc, crct]; };
// gunzip extra
var guze = function () { return [gzs, gzl]; };
// zlib extra
var zle = function () { return [zlh, wbytes, adler]; };
// unzlib extra
var zule = function () { return [zls]; };
// post buf
var pbf = function (msg) { return postMessage(msg, [msg.buffer]); };
// get opts
var gopt = function (o) { return o && {
    out: o.size && new u8(o.size),
    dictionary: o.dictionary
}; };
// async helper
var cbify = function (dat, opts, fns, init, id, cb) {
    var w = wrkr(fns, init, id, function (err, dat) {
        w.terminate();
        cb(err, dat);
    });
    w.postMessage([dat, opts], opts.consume ? [dat.buffer] : []);
    return function () { w.terminate(); };
};
// auto stream
var astrm = function (strm) {
    strm.ondata = function (dat, final) { return postMessage([dat, final], [dat.buffer]); };
    return function (ev) {
        if (ev.data.length) {
            strm.push(ev.data[0], ev.data[1]);
            postMessage([ev.data[0].length]);
        }
        else
            strm.flush();
    };
};
// async stream attach
var astrmify = function (fns, strm, opts, init, id, flush, ext) {
    var t;
    var w = wrkr(fns, init, id, function (err, dat) {
        if (err)
            w.terminate(), strm.ondata.call(strm, err);
        else if (!Array.isArray(dat))
            ext(dat);
        else if (dat.length == 1) {
            strm.queuedSize -= dat[0];
            if (strm.ondrain)
                strm.ondrain(dat[0]);
        }
        else {
            if (dat[1])
                w.terminate();
            strm.ondata.call(strm, err, dat[0], dat[1]);
        }
    });
    w.postMessage(opts);
    strm.queuedSize = 0;
    strm.push = function (d, f) {
        if (!strm.ondata)
            err(5);
        if (t)
            strm.ondata(err(4, 0, 1), null, !!f);
        strm.queuedSize += d.length;
        w.postMessage([d, t = f], [d.buffer]);
    };
    strm.terminate = function () { w.terminate(); };
    if (flush) {
        strm.flush = function () { w.postMessage([]); };
    }
};
// read 2 bytes
var b2 = function (d, b) { return d[b] | (d[b + 1] << 8); };
// read 4 bytes
var b4 = function (d, b) { return (d[b] | (d[b + 1] << 8) | (d[b + 2] << 16) | (d[b + 3] << 24)) >>> 0; };
var b8 = function (d, b) { return b4(d, b) + (b4(d, b + 4) * 4294967296); };
// write bytes
var wbytes = function (d, b, v) {
    for (; v; ++b)
        d[b] = v, v >>>= 8;
};
// gzip header
var gzh = function (c, o) {
    var fn = o.filename;
    c[0] = 31, c[1] = 139, c[2] = 8, c[8] = o.level < 2 ? 4 : o.level == 9 ? 2 : 0, c[9] = 3; // assume Unix
    if (o.mtime != 0)
        wbytes(c, 4, Math.floor(new Date(o.mtime || Date.now()) / 1000));
    if (fn) {
        c[3] = 8;
        for (var i = 0; i <= fn.length; ++i)
            c[i + 10] = fn.charCodeAt(i);
    }
};
// gzip footer: -8 to -4 = CRC, -4 to -0 is length
// gzip start
var gzs = function (d) {
    if (d[0] != 31 || d[1] != 139 || d[2] != 8)
        err(6, 'invalid gzip data');
    var flg = d[3];
    var st = 10;
    if (flg & 4)
        st += (d[10] | d[11] << 8) + 2;
    for (var zs = (flg >> 3 & 1) + (flg >> 4 & 1); zs > 0; zs -= !d[st++])
        ;
    return st + (flg & 2);
};
// gzip length
var gzl = function (d) {
    var l = d.length;
    return (d[l - 4] | d[l - 3] << 8 | d[l - 2] << 16 | d[l - 1] << 24) >>> 0;
};
// gzip header length
var gzhl = function (o) { return 10 + (o.filename ? o.filename.length + 1 : 0); };
// zlib header
var zlh = function (c, o) {
    var lv = o.level, fl = lv == 0 ? 0 : lv < 6 ? 1 : lv == 9 ? 3 : 2;
    c[0] = 120, c[1] = (fl << 6) | (o.dictionary && 32);
    c[1] |= 31 - ((c[0] << 8) | c[1]) % 31;
    if (o.dictionary) {
        var h = adler();
        h.p(o.dictionary);
        wbytes(c, 2, h.d());
    }
};
// zlib start
var zls = function (d, dict) {
    if ((d[0] & 15) != 8 || (d[0] >> 4) > 7 || ((d[0] << 8 | d[1]) % 31))
        err(6, 'invalid zlib data');
    if ((d[1] >> 5 & 1) == +!dict)
        err(6, 'invalid zlib data: ' + (d[1] & 32 ? 'need' : 'unexpected') + ' dictionary');
    return (d[1] >> 3 & 4) + 2;
};
function StrmOpt(opts, cb) {
    if (typeof opts == 'function')
        cb = opts, opts = {};
    this.ondata = cb;
    return opts;
}
/**
 * Streaming DEFLATE compression
 */
var Deflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Deflate(opts, cb) {
        if (typeof opts == 'function')
            cb = opts, opts = {};
        this.ondata = cb;
        this.o = opts || {};
        this.s = { l: 0, i: 32768, w: 32768, z: 32768 };
        // Buffer length must always be 0 mod 32768 for index calculations to be correct when modifying head and prev
        // 98304 = 32768 (lookback) + 65536 (common chunk size)
        this.b = new u8(98304);
        if (this.o.dictionary) {
            var dict = this.o.dictionary.subarray(-32768);
            this.b.set(dict, 32768 - dict.length);
            this.s.i = 32768 - dict.length;
        }
    }
    Deflate.prototype.p = function (c, f) {
        this.ondata(dopt(c, this.o, 0, 0, this.s), f);
    };
    /**
     * Pushes a chunk to be deflated
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Deflate.prototype.push = function (chunk, final) {
        if (!this.ondata)
            err(5);
        if (this.s.l)
            err(4);
        var endLen = chunk.length + this.s.z;
        if (endLen > this.b.length) {
            if (endLen > 2 * this.b.length - 32768) {
                var newBuf = new u8(endLen & -32768);
                newBuf.set(this.b.subarray(0, this.s.z));
                this.b = newBuf;
            }
            var split = this.b.length - this.s.z;
            this.b.set(chunk.subarray(0, split), this.s.z);
            this.s.z = this.b.length;
            this.p(this.b, false);
            this.b.set(this.b.subarray(-32768));
            this.b.set(chunk.subarray(split), 32768);
            this.s.z = chunk.length - split + 32768;
            this.s.i = 32766, this.s.w = 32768;
        }
        else {
            this.b.set(chunk, this.s.z);
            this.s.z += chunk.length;
        }
        this.s.l = final & 1;
        if (this.s.z > this.s.w + 8191 || final) {
            this.p(this.b, final || false);
            this.s.w = this.s.i, this.s.i -= 2;
        }
    };
    /**
     * Flushes buffered uncompressed data. Useful to immediately retrieve the
     * deflated output for small inputs.
     */
    Deflate.prototype.flush = function () {
        if (!this.ondata)
            err(5);
        if (this.s.l)
            err(4);
        this.p(this.b, false);
        this.s.w = this.s.i, this.s.i -= 2;
    };
    return Deflate;
}())));

/**
 * Asynchronous streaming DEFLATE compression
 */
var AsyncDeflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncDeflate(opts, cb) {
        astrmify([
            bDflt,
            function () { return [astrm, Deflate]; }
        ], this, StrmOpt.call(this, opts, cb), function (ev) {
            var strm = new Deflate(ev.data);
            onmessage = astrm(strm);
        }, 6, 1);
    }
    return AsyncDeflate;
}())));

function deflate(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return cbify(data, opts, [
        bDflt,
    ], function (ev) { return pbf(deflateSync(ev.data[0], ev.data[1])); }, 0, cb);
}
/**
 * Compresses data with DEFLATE without any wrapper
 * @param data The data to compress
 * @param opts The compression options
 * @returns The deflated version of the data
 */
function deflateSync(data, opts) {
    return dopt(data, opts || {}, 0, 0);
}
/**
 * Streaming DEFLATE decompression
 */
var Inflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Inflate(opts, cb) {
        // no StrmOpt here to avoid adding to workerizer
        if (typeof opts == 'function')
            cb = opts, opts = {};
        this.ondata = cb;
        var dict = opts && opts.dictionary && opts.dictionary.subarray(-32768);
        this.s = { i: 0, b: dict ? dict.length : 0 };
        this.o = new u8(32768);
        this.p = new u8(0);
        if (dict)
            this.o.set(dict);
    }
    Inflate.prototype.e = function (c) {
        if (!this.ondata)
            err(5);
        if (this.d)
            err(4);
        if (!this.p.length)
            this.p = c;
        else if (c.length) {
            var n = new u8(this.p.length + c.length);
            n.set(this.p), n.set(c, this.p.length), this.p = n;
        }
    };
    Inflate.prototype.c = function (final) {
        this.s.i = +(this.d = final || false);
        var bts = this.s.b;
        var dt = inflt(this.p, this.s, this.o);
        this.ondata(slc(dt, bts, this.s.b), this.d);
        this.o = slc(dt, this.s.b - 32768), this.s.b = this.o.length;
        this.p = slc(this.p, (this.s.p / 8) | 0), this.s.p &= 7;
    };
    /**
     * Pushes a chunk to be inflated
     * @param chunk The chunk to push
     * @param final Whether this is the final chunk
     */
    Inflate.prototype.push = function (chunk, final) {
        this.e(chunk), this.c(final);
    };
    return Inflate;
}())));

/**
 * Asynchronous streaming DEFLATE decompression
 */
var AsyncInflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncInflate(opts, cb) {
        astrmify([
            bInflt,
            function () { return [astrm, Inflate]; }
        ], this, StrmOpt.call(this, opts, cb), function (ev) {
            var strm = new Inflate(ev.data);
            onmessage = astrm(strm);
        }, 7, 0);
    }
    return AsyncInflate;
}())));

function inflate(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return cbify(data, opts, [
        bInflt
    ], function (ev) { return pbf(inflateSync(ev.data[0], gopt(ev.data[1]))); }, 1, cb);
}
/**
 * Expands DEFLATE data with no wrapper
 * @param data The data to decompress
 * @param opts The decompression options
 * @returns The decompressed version of the data
 */
function inflateSync(data, opts) {
    return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
// before you yell at me for not just using extends, my reason is that TS inheritance is hard to workerize.
/**
 * Streaming GZIP compression
 */
var Gzip = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Gzip(opts, cb) {
        this.c = crc();
        this.l = 0;
        this.v = 1;
        Deflate.call(this, opts, cb);
    }
    /**
     * Pushes a chunk to be GZIPped
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Gzip.prototype.push = function (chunk, final) {
        this.c.p(chunk);
        this.l += chunk.length;
        Deflate.prototype.push.call(this, chunk, final);
    };
    Gzip.prototype.p = function (c, f) {
        var raw = dopt(c, this.o, this.v && gzhl(this.o), f && 8, this.s);
        if (this.v)
            gzh(raw, this.o), this.v = 0;
        if (f)
            wbytes(raw, raw.length - 8, this.c.d()), wbytes(raw, raw.length - 4, this.l);
        this.ondata(raw, f);
    };
    /**
     * Flushes buffered uncompressed data. Useful to immediately retrieve the
     * GZIPped output for small inputs.
     */
    Gzip.prototype.flush = function () {
        Deflate.prototype.flush.call(this);
    };
    return Gzip;
}())));

/**
 * Asynchronous streaming GZIP compression
 */
var AsyncGzip = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncGzip(opts, cb) {
        astrmify([
            bDflt,
            gze,
            function () { return [astrm, Deflate, Gzip]; }
        ], this, StrmOpt.call(this, opts, cb), function (ev) {
            var strm = new Gzip(ev.data);
            onmessage = astrm(strm);
        }, 8, 1);
    }
    return AsyncGzip;
}())));

function gzip(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return cbify(data, opts, [
        bDflt,
        gze,
        function () { return [gzipSync]; }
    ], function (ev) { return pbf(gzipSync(ev.data[0], ev.data[1])); }, 2, cb);
}
/**
 * Compresses data with GZIP
 * @param data The data to compress
 * @param opts The compression options
 * @returns The gzipped version of the data
 */
function gzipSync(data, opts) {
    if (!opts)
        opts = {};
    var c = crc(), l = data.length;
    c.p(data);
    var d = dopt(data, opts, gzhl(opts), 8), s = d.length;
    return gzh(d, opts), wbytes(d, s - 8, c.d()), wbytes(d, s - 4, l), d;
}
/**
 * Streaming single or multi-member GZIP decompression
 */
var Gunzip = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Gunzip(opts, cb) {
        this.v = 1;
        this.r = 0;
        Inflate.call(this, opts, cb);
    }
    /**
     * Pushes a chunk to be GUNZIPped
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Gunzip.prototype.push = function (chunk, final) {
        Inflate.prototype.e.call(this, chunk);
        this.r += chunk.length;
        if (this.v) {
            var p = this.p.subarray(this.v - 1);
            var s = p.length > 3 ? gzs(p) : 4;
            if (s > p.length) {
                if (!final)
                    return;
            }
            else if (this.v > 1 && this.onmember) {
                this.onmember(this.r - p.length);
            }
            this.p = p.subarray(s), this.v = 0;
        }
        // necessary to prevent TS from using the closure value
        // This allows for workerization to function correctly
        Inflate.prototype.c.call(this, final);
        // process concatenated GZIP
        if (this.s.f && !this.s.l && !final) {
            this.v = shft(this.s.p) + 9;
            this.s = { i: 0 };
            this.o = new u8(0);
            this.push(new u8(0), final);
        }
    };
    return Gunzip;
}())));

/**
 * Asynchronous streaming single or multi-member GZIP decompression
 */
var AsyncGunzip = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncGunzip(opts, cb) {
        var _this = this;
        astrmify([
            bInflt,
            guze,
            function () { return [astrm, Inflate, Gunzip]; }
        ], this, StrmOpt.call(this, opts, cb), function (ev) {
            var strm = new Gunzip(ev.data);
            strm.onmember = function (offset) { return postMessage(offset); };
            onmessage = astrm(strm);
        }, 9, 0, function (offset) { return _this.onmember && _this.onmember(offset); });
    }
    return AsyncGunzip;
}())));

function gunzip(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return cbify(data, opts, [
        bInflt,
        guze,
        function () { return [gunzipSync]; }
    ], function (ev) { return pbf(gunzipSync(ev.data[0], ev.data[1])); }, 3, cb);
}
/**
 * Expands GZIP data
 * @param data The data to decompress
 * @param opts The decompression options
 * @returns The decompressed version of the data
 */
function gunzipSync(data, opts) {
    var st = gzs(data);
    if (st + 8 > data.length)
        err(6, 'invalid gzip data');
    return inflt(data.subarray(st, -8), { i: 2 }, opts && opts.out || new u8(gzl(data)), opts && opts.dictionary);
}
/**
 * Streaming Zlib compression
 */
var Zlib = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Zlib(opts, cb) {
        this.c = adler();
        this.v = 1;
        Deflate.call(this, opts, cb);
    }
    /**
     * Pushes a chunk to be zlibbed
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Zlib.prototype.push = function (chunk, final) {
        this.c.p(chunk);
        Deflate.prototype.push.call(this, chunk, final);
    };
    Zlib.prototype.p = function (c, f) {
        var raw = dopt(c, this.o, this.v && (this.o.dictionary ? 6 : 2), f && 4, this.s);
        if (this.v)
            zlh(raw, this.o), this.v = 0;
        if (f)
            wbytes(raw, raw.length - 4, this.c.d());
        this.ondata(raw, f);
    };
    /**
     * Flushes buffered uncompressed data. Useful to immediately retrieve the
     * zlibbed output for small inputs.
     */
    Zlib.prototype.flush = function () {
        Deflate.prototype.flush.call(this);
    };
    return Zlib;
}())));

/**
 * Asynchronous streaming Zlib compression
 */
var AsyncZlib = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncZlib(opts, cb) {
        astrmify([
            bDflt,
            zle,
            function () { return [astrm, Deflate, Zlib]; }
        ], this, StrmOpt.call(this, opts, cb), function (ev) {
            var strm = new Zlib(ev.data);
            onmessage = astrm(strm);
        }, 10, 1);
    }
    return AsyncZlib;
}())));

function zlib(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return cbify(data, opts, [
        bDflt,
        zle,
        function () { return [zlibSync]; }
    ], function (ev) { return pbf(zlibSync(ev.data[0], ev.data[1])); }, 4, cb);
}
/**
 * Compress data with Zlib
 * @param data The data to compress
 * @param opts The compression options
 * @returns The zlib-compressed version of the data
 */
function zlibSync(data, opts) {
    if (!opts)
        opts = {};
    var a = adler();
    a.p(data);
    var d = dopt(data, opts, opts.dictionary ? 6 : 2, 4);
    return zlh(d, opts), wbytes(d, d.length - 4, a.d()), d;
}
/**
 * Streaming Zlib decompression
 */
var Unzlib = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Unzlib(opts, cb) {
        Inflate.call(this, opts, cb);
        this.v = opts && opts.dictionary ? 2 : 1;
    }
    /**
     * Pushes a chunk to be unzlibbed
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Unzlib.prototype.push = function (chunk, final) {
        Inflate.prototype.e.call(this, chunk);
        if (this.v) {
            if (this.p.length < 6 && !final)
                return;
            this.p = this.p.subarray(zls(this.p, this.v - 1)), this.v = 0;
        }
        if (final) {
            if (this.p.length < 4)
                err(6, 'invalid zlib data');
            this.p = this.p.subarray(0, -4);
        }
        // necessary to prevent TS from using the closure value
        // This allows for workerization to function correctly
        Inflate.prototype.c.call(this, final);
    };
    return Unzlib;
}())));

/**
 * Asynchronous streaming Zlib decompression
 */
var AsyncUnzlib = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncUnzlib(opts, cb) {
        astrmify([
            bInflt,
            zule,
            function () { return [astrm, Inflate, Unzlib]; }
        ], this, StrmOpt.call(this, opts, cb), function (ev) {
            var strm = new Unzlib(ev.data);
            onmessage = astrm(strm);
        }, 11, 0);
    }
    return AsyncUnzlib;
}())));

function unzlib(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return cbify(data, opts, [
        bInflt,
        zule,
        function () { return [unzlibSync]; }
    ], function (ev) { return pbf(unzlibSync(ev.data[0], gopt(ev.data[1]))); }, 5, cb);
}
/**
 * Expands Zlib data
 * @param data The data to decompress
 * @param opts The decompression options
 * @returns The decompressed version of the data
 */
function unzlibSync(data, opts) {
    return inflt(data.subarray(zls(data, opts && opts.dictionary), -4), { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
// Default algorithm for compression (used because having a known output size allows faster decompression)


/**
 * Streaming GZIP, Zlib, or raw DEFLATE decompression
 */
var Decompress = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function Decompress(opts, cb) {
        this.o = StrmOpt.call(this, opts, cb) || {};
        this.G = Gunzip;
        this.I = Inflate;
        this.Z = Unzlib;
    }
    // init substream
    // overriden by AsyncDecompress
    Decompress.prototype.i = function () {
        var _this = this;
        this.s.ondata = function (dat, final) {
            _this.ondata(dat, final);
        };
    };
    /**
     * Pushes a chunk to be decompressed
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Decompress.prototype.push = function (chunk, final) {
        if (!this.ondata)
            err(5);
        if (!this.s) {
            if (this.p && this.p.length) {
                var n = new u8(this.p.length + chunk.length);
                n.set(this.p), n.set(chunk, this.p.length);
            }
            else
                this.p = chunk;
            if (this.p.length > 2) {
                this.s = (this.p[0] == 31 && this.p[1] == 139 && this.p[2] == 8)
                    ? new this.G(this.o)
                    : ((this.p[0] & 15) != 8 || (this.p[0] >> 4) > 7 || ((this.p[0] << 8 | this.p[1]) % 31))
                        ? new this.I(this.o)
                        : new this.Z(this.o);
                this.i();
                this.s.push(this.p, final);
                this.p = null;
            }
        }
        else
            this.s.push(chunk, final);
    };
    return Decompress;
}())));

/**
 * Asynchronous streaming GZIP, Zlib, or raw DEFLATE decompression
 */
var AsyncDecompress = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function AsyncDecompress(opts, cb) {
        Decompress.call(this, opts, cb);
        this.queuedSize = 0;
        this.G = AsyncGunzip;
        this.I = AsyncInflate;
        this.Z = AsyncUnzlib;
    }
    AsyncDecompress.prototype.i = function () {
        var _this = this;
        this.s.ondata = function (err, dat, final) {
            _this.ondata(err, dat, final);
        };
        this.s.ondrain = function (size) {
            _this.queuedSize -= size;
            if (_this.ondrain)
                _this.ondrain(size);
        };
    };
    /**
     * Pushes a chunk to be decompressed
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    AsyncDecompress.prototype.push = function (chunk, final) {
        this.queuedSize += chunk.length;
        Decompress.prototype.push.call(this, chunk, final);
    };
    return AsyncDecompress;
}())));

function decompress(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    return (data[0] == 31 && data[1] == 139 && data[2] == 8)
        ? gunzip(data, opts, cb)
        : ((data[0] & 15) != 8 || (data[0] >> 4) > 7 || ((data[0] << 8 | data[1]) % 31))
            ? inflate(data, opts, cb)
            : unzlib(data, opts, cb);
}
/**
 * Expands compressed GZIP, Zlib, or raw DEFLATE data, automatically detecting the format
 * @param data The data to decompress
 * @param opts The decompression options
 * @returns The decompressed version of the data
 */
function decompressSync(data, opts) {
    return (data[0] == 31 && data[1] == 139 && data[2] == 8)
        ? gunzipSync(data, opts)
        : ((data[0] & 15) != 8 || (data[0] >> 4) > 7 || ((data[0] << 8 | data[1]) % 31))
            ? inflateSync(data, opts)
            : unzlibSync(data, opts);
}
// flatten a directory structure
var fltn = function (d, p, t, o) {
    for (var k in d) {
        var val = d[k], n = p + k, op = o;
        if (Array.isArray(val))
            op = mrg(o, val[1]), val = val[0];
        if (val instanceof u8)
            t[n] = [val, op];
        else {
            t[n += '/'] = [new u8(0), op];
            fltn(val, n, t, o);
        }
    }
};
// text encoder
var te = typeof TextEncoder != 'undefined' && /*#__PURE__*/ new TextEncoder();
// text decoder
var td = typeof TextDecoder != 'undefined' && /*#__PURE__*/ new TextDecoder();
// text decoder stream
var tds = 0;
try {
    td.decode(et, { stream: true });
    tds = 1;
}
catch (e) { }
// decode UTF8
var dutf8 = function (d) {
    for (var r = '', i = 0;;) {
        var c = d[i++];
        var eb = (c > 127) + (c > 223) + (c > 239);
        if (i + eb > d.length)
            return { s: r, r: slc(d, i - 1) };
        if (!eb)
            r += String.fromCharCode(c);
        else if (eb == 3) {
            c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | (d[i++] & 63)) - 65536,
                r += String.fromCharCode(55296 | (c >> 10), 56320 | (c & 1023));
        }
        else if (eb & 1)
            r += String.fromCharCode((c & 31) << 6 | (d[i++] & 63));
        else
            r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | (d[i++] & 63));
    }
};
/**
 * Streaming UTF-8 decoding
 */
var DecodeUTF8 = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a UTF-8 decoding stream
     * @param cb The callback to call whenever data is decoded
     */
    function DecodeUTF8(cb) {
        this.ondata = cb;
        if (tds)
            this.t = new TextDecoder();
        else
            this.p = et;
    }
    /**
     * Pushes a chunk to be decoded from UTF-8 binary
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    DecodeUTF8.prototype.push = function (chunk, final) {
        if (!this.ondata)
            err(5);
        final = !!final;
        if (this.t) {
            this.ondata(this.t.decode(chunk, { stream: true }), final);
            if (final) {
                if (this.t.decode().length)
                    err(8);
                this.t = null;
            }
            return;
        }
        if (!this.p)
            err(4);
        var dat = new u8(this.p.length + chunk.length);
        dat.set(this.p);
        dat.set(chunk, this.p.length);
        var _a = dutf8(dat), s = _a.s, r = _a.r;
        if (final) {
            if (r.length)
                err(8);
            this.p = null;
        }
        else
            this.p = r;
        this.ondata(s, final);
    };
    return DecodeUTF8;
}())));

/**
 * Streaming UTF-8 encoding
 */
var EncodeUTF8 = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a UTF-8 decoding stream
     * @param cb The callback to call whenever data is encoded
     */
    function EncodeUTF8(cb) {
        this.ondata = cb;
    }
    /**
     * Pushes a chunk to be encoded to UTF-8
     * @param chunk The string data to push
     * @param final Whether this is the last chunk
     */
    EncodeUTF8.prototype.push = function (chunk, final) {
        if (!this.ondata)
            err(5);
        if (this.d)
            err(4);
        this.ondata(strToU8(chunk), this.d = final || false);
    };
    return EncodeUTF8;
}())));

/**
 * Converts a string into a Uint8Array for use with compression/decompression methods
 * @param str The string to encode
 * @param latin1 Whether or not to interpret the data as Latin-1. This should
 *               not need to be true unless decoding a binary string.
 * @returns The string encoded in UTF-8/Latin-1 binary
 */
function strToU8(str, latin1) {
    if (latin1) {
        var ar_1 = new u8(str.length);
        for (var i = 0; i < str.length; ++i)
            ar_1[i] = str.charCodeAt(i);
        return ar_1;
    }
    if (te)
        return te.encode(str);
    var l = str.length;
    var ar = new u8(str.length + (str.length >> 1));
    var ai = 0;
    var w = function (v) { ar[ai++] = v; };
    for (var i = 0; i < l; ++i) {
        if (ai + 5 > ar.length) {
            var n = new u8(ai + 8 + ((l - i) << 1));
            n.set(ar);
            ar = n;
        }
        var c = str.charCodeAt(i);
        if (c < 128 || latin1)
            w(c);
        else if (c < 2048)
            w(192 | (c >> 6)), w(128 | (c & 63));
        else if (c > 55295 && c < 57344)
            c = 65536 + (c & 1023 << 10) | (str.charCodeAt(++i) & 1023),
                w(240 | (c >> 18)), w(128 | ((c >> 12) & 63)), w(128 | ((c >> 6) & 63)), w(128 | (c & 63));
        else
            w(224 | (c >> 12)), w(128 | ((c >> 6) & 63)), w(128 | (c & 63));
    }
    return slc(ar, 0, ai);
}
/**
 * Converts a Uint8Array to a string
 * @param dat The data to decode to string
 * @param latin1 Whether or not to interpret the data as Latin-1. This should
 *               not need to be true unless encoding to binary string.
 * @returns The original UTF-8/Latin-1 string
 */
function strFromU8(dat, latin1) {
    if (latin1) {
        var r = '';
        for (var i = 0; i < dat.length; i += 16384)
            r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
        return r;
    }
    else if (td) {
        return td.decode(dat);
    }
    else {
        var _a = dutf8(dat), s = _a.s, r = _a.r;
        if (r.length)
            err(8);
        return s;
    }
}
;
// deflate bit flag
var dbf = function (l) { return l == 1 ? 3 : l < 6 ? 2 : l == 9 ? 1 : 0; };
// skip local zip header
var slzh = function (d, b) { return b + 30 + b2(d, b + 26) + b2(d, b + 28); };
// read zip header
var zh = function (d, b, z) {
    var fnl = b2(d, b + 28), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl, bs = b4(d, b + 20);
    var _a = z && bs == 4294967295 ? z64e(d, es) : [bs, b4(d, b + 24), b4(d, b + 42)], sc = _a[0], su = _a[1], off = _a[2];
    return [b2(d, b + 10), sc, su, fn, es + b2(d, b + 30) + b2(d, b + 32), off];
};
// read zip64 extra field
var z64e = function (d, b) {
    for (; b2(d, b) != 1; b += 4 + b2(d, b + 2))
        ;
    return [b8(d, b + 12), b8(d, b + 4), b8(d, b + 20)];
};
// extra field length
var exfl = function (ex) {
    var le = 0;
    if (ex) {
        for (var k in ex) {
            var l = ex[k].length;
            if (l > 65535)
                err(9);
            le += l + 4;
        }
    }
    return le;
};
// write zip header
var wzh = function (d, b, f, fn, u, c, ce, co) {
    var fl = fn.length, ex = f.extra, col = co && co.length;
    var exl = exfl(ex);
    wbytes(d, b, ce != null ? 0x2014B50 : 0x4034B50), b += 4;
    if (ce != null)
        d[b++] = 20, d[b++] = f.os;
    d[b] = 20, b += 2; // spec compliance? what's that?
    d[b++] = (f.flag << 1) | (c < 0 && 8), d[b++] = u && 8;
    d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
    var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
    if (y < 0 || y > 119)
        err(10);
    wbytes(d, b, (y << 25) | ((dt.getMonth() + 1) << 21) | (dt.getDate() << 16) | (dt.getHours() << 11) | (dt.getMinutes() << 5) | (dt.getSeconds() >> 1)), b += 4;
    if (c != -1) {
        wbytes(d, b, f.crc);
        wbytes(d, b + 4, c < 0 ? -c - 2 : c);
        wbytes(d, b + 8, f.size);
    }
    wbytes(d, b + 12, fl);
    wbytes(d, b + 14, exl), b += 16;
    if (ce != null) {
        wbytes(d, b, col);
        wbytes(d, b + 6, f.attrs);
        wbytes(d, b + 10, ce), b += 14;
    }
    d.set(fn, b);
    b += fl;
    if (exl) {
        for (var k in ex) {
            var exf = ex[k], l = exf.length;
            wbytes(d, b, +k);
            wbytes(d, b + 2, l);
            d.set(exf, b + 4), b += 4 + l;
        }
    }
    if (col)
        d.set(co, b), b += col;
    return b;
};
// write zip footer (end of central directory)
var wzf = function (o, b, c, d, e) {
    wbytes(o, b, 0x6054B50); // skip disk
    wbytes(o, b + 8, c);
    wbytes(o, b + 10, c);
    wbytes(o, b + 12, d);
    wbytes(o, b + 16, e);
};
/**
 * A pass-through stream to keep data uncompressed in a ZIP archive.
 */
var ZipPassThrough = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a pass-through stream that can be added to ZIP archives
     * @param filename The filename to associate with this data stream
     */
    function ZipPassThrough(filename) {
        this.filename = filename;
        this.c = crc();
        this.size = 0;
        this.compression = 0;
    }
    /**
     * Processes a chunk and pushes to the output stream. You can override this
     * method in a subclass for custom behavior, but by default this passes
     * the data through. You must call this.ondata(err, chunk, final) at some
     * point in this method.
     * @param chunk The chunk to process
     * @param final Whether this is the last chunk
     */
    ZipPassThrough.prototype.process = function (chunk, final) {
        this.ondata(null, chunk, final);
    };
    /**
     * Pushes a chunk to be added. If you are subclassing this with a custom
     * compression algorithm, note that you must push data from the source
     * file only, pre-compression.
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    ZipPassThrough.prototype.push = function (chunk, final) {
        if (!this.ondata)
            err(5);
        this.c.p(chunk);
        this.size += chunk.length;
        if (final)
            this.crc = this.c.d();
        this.process(chunk, final || false);
    };
    return ZipPassThrough;
}())));

// I don't extend because TypeScript extension adds 1kB of runtime bloat
/**
 * Streaming DEFLATE compression for ZIP archives. Prefer using AsyncZipDeflate
 * for better performance
 */
var ZipDeflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a DEFLATE stream that can be added to ZIP archives
     * @param filename The filename to associate with this data stream
     * @param opts The compression options
     */
    function ZipDeflate(filename, opts) {
        var _this = this;
        if (!opts)
            opts = {};
        ZipPassThrough.call(this, filename);
        this.d = new Deflate(opts, function (dat, final) {
            _this.ondata(null, dat, final);
        });
        this.compression = 8;
        this.flag = dbf(opts.level);
    }
    ZipDeflate.prototype.process = function (chunk, final) {
        try {
            this.d.push(chunk, final);
        }
        catch (e) {
            this.ondata(e, null, final);
        }
    };
    /**
     * Pushes a chunk to be deflated
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    ZipDeflate.prototype.push = function (chunk, final) {
        ZipPassThrough.prototype.push.call(this, chunk, final);
    };
    return ZipDeflate;
}())));

/**
 * Asynchronous streaming DEFLATE compression for ZIP archives
 */
var AsyncZipDeflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates an asynchronous DEFLATE stream that can be added to ZIP archives
     * @param filename The filename to associate with this data stream
     * @param opts The compression options
     */
    function AsyncZipDeflate(filename, opts) {
        var _this = this;
        if (!opts)
            opts = {};
        ZipPassThrough.call(this, filename);
        this.d = new AsyncDeflate(opts, function (err, dat, final) {
            _this.ondata(err, dat, final);
        });
        this.compression = 8;
        this.flag = dbf(opts.level);
        this.terminate = this.d.terminate;
    }
    AsyncZipDeflate.prototype.process = function (chunk, final) {
        this.d.push(chunk, final);
    };
    /**
     * Pushes a chunk to be deflated
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    AsyncZipDeflate.prototype.push = function (chunk, final) {
        ZipPassThrough.prototype.push.call(this, chunk, final);
    };
    return AsyncZipDeflate;
}())));

// TODO: Better tree shaking
/**
 * A zippable archive to which files can incrementally be added
 */
var Zip = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates an empty ZIP archive to which files can be added
     * @param cb The callback to call whenever data for the generated ZIP archive
     *           is available
     */
    function Zip(cb) {
        this.ondata = cb;
        this.u = [];
        this.d = 1;
    }
    /**
     * Adds a file to the ZIP archive
     * @param file The file stream to add
     */
    Zip.prototype.add = function (file) {
        var _this = this;
        if (!this.ondata)
            err(5);
        // finishing or finished
        if (this.d & 2)
            this.ondata(err(4 + (this.d & 1) * 8, 0, 1), null, false);
        else {
            var f = strToU8(file.filename), fl_1 = f.length;
            var com = file.comment, o = com && strToU8(com);
            var u = fl_1 != file.filename.length || (o && (com.length != o.length));
            var hl_1 = fl_1 + exfl(file.extra) + 30;
            if (fl_1 > 65535)
                this.ondata(err(11, 0, 1), null, false);
            var header = new u8(hl_1);
            wzh(header, 0, file, f, u, -1);
            var chks_1 = [header];
            var pAll_1 = function () {
                for (var _i = 0, chks_2 = chks_1; _i < chks_2.length; _i++) {
                    var chk = chks_2[_i];
                    _this.ondata(null, chk, false);
                }
                chks_1 = [];
            };
            var tr_1 = this.d;
            this.d = 0;
            var ind_1 = this.u.length;
            var uf_1 = mrg(file, {
                f: f,
                u: u,
                o: o,
                t: function () {
                    if (file.terminate)
                        file.terminate();
                },
                r: function () {
                    pAll_1();
                    if (tr_1) {
                        var nxt = _this.u[ind_1 + 1];
                        if (nxt)
                            nxt.r();
                        else
                            _this.d = 1;
                    }
                    tr_1 = 1;
                }
            });
            var cl_1 = 0;
            file.ondata = function (err, dat, final) {
                if (err) {
                    _this.ondata(err, dat, final);
                    _this.terminate();
                }
                else {
                    cl_1 += dat.length;
                    chks_1.push(dat);
                    if (final) {
                        var dd = new u8(16);
                        wbytes(dd, 0, 0x8074B50);
                        wbytes(dd, 4, file.crc);
                        wbytes(dd, 8, cl_1);
                        wbytes(dd, 12, file.size);
                        chks_1.push(dd);
                        uf_1.c = cl_1, uf_1.b = hl_1 + cl_1 + 16, uf_1.crc = file.crc, uf_1.size = file.size;
                        if (tr_1)
                            uf_1.r();
                        tr_1 = 1;
                    }
                    else if (tr_1)
                        pAll_1();
                }
            };
            this.u.push(uf_1);
        }
    };
    /**
     * Ends the process of adding files and prepares to emit the final chunks.
     * This *must* be called after adding all desired files for the resulting
     * ZIP file to work properly.
     */
    Zip.prototype.end = function () {
        var _this = this;
        if (this.d & 2) {
            this.ondata(err(4 + (this.d & 1) * 8, 0, 1), null, true);
            return;
        }
        if (this.d)
            this.e();
        else
            this.u.push({
                r: function () {
                    if (!(_this.d & 1))
                        return;
                    _this.u.splice(-1, 1);
                    _this.e();
                },
                t: function () { }
            });
        this.d = 3;
    };
    Zip.prototype.e = function () {
        var bt = 0, l = 0, tl = 0;
        for (var _i = 0, _a = this.u; _i < _a.length; _i++) {
            var f = _a[_i];
            tl += 46 + f.f.length + exfl(f.extra) + (f.o ? f.o.length : 0);
        }
        var out = new u8(tl + 22);
        for (var _b = 0, _c = this.u; _b < _c.length; _b++) {
            var f = _c[_b];
            wzh(out, bt, f, f.f, f.u, -f.c - 2, l, f.o);
            bt += 46 + f.f.length + exfl(f.extra) + (f.o ? f.o.length : 0), l += f.b;
        }
        wzf(out, bt, this.u.length, tl, l);
        this.ondata(null, out, true);
        this.d = 2;
    };
    /**
     * A method to terminate any internal workers used by the stream. Subsequent
     * calls to add() will fail.
     */
    Zip.prototype.terminate = function () {
        for (var _i = 0, _a = this.u; _i < _a.length; _i++) {
            var f = _a[_i];
            f.t();
        }
        this.d = 2;
    };
    return Zip;
}())));

function zip(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    var r = {};
    fltn(data, '', r, opts);
    var k = Object.keys(r);
    var lft = k.length, o = 0, tot = 0;
    var slft = lft, files = new Array(lft);
    var term = [];
    var tAll = function () {
        for (var i = 0; i < term.length; ++i)
            term[i]();
    };
    var cbd = function (a, b) {
        mt(function () { cb(a, b); });
    };
    mt(function () { cbd = cb; });
    var cbf = function () {
        var out = new u8(tot + 22), oe = o, cdl = tot - o;
        tot = 0;
        for (var i = 0; i < slft; ++i) {
            var f = files[i];
            try {
                var l = f.c.length;
                wzh(out, tot, f, f.f, f.u, l);
                var badd = 30 + f.f.length + exfl(f.extra);
                var loc = tot + badd;
                out.set(f.c, loc);
                wzh(out, o, f, f.f, f.u, l, tot, f.m), o += 16 + badd + (f.m ? f.m.length : 0), tot = loc + l;
            }
            catch (e) {
                return cbd(e, null);
            }
        }
        wzf(out, o, files.length, cdl, oe);
        cbd(null, out);
    };
    if (!lft)
        cbf();
    var _loop_1 = function (i) {
        var fn = k[i];
        var _a = r[fn], file = _a[0], p = _a[1];
        var c = crc(), size = file.length;
        c.p(file);
        var f = strToU8(fn), s = f.length;
        var com = p.comment, m = com && strToU8(com), ms = m && m.length;
        var exl = exfl(p.extra);
        var compression = p.level == 0 ? 0 : 8;
        var cbl = function (e, d) {
            if (e) {
                tAll();
                cbd(e, null);
            }
            else {
                var l = d.length;
                files[i] = mrg(p, {
                    size: size,
                    crc: c.d(),
                    c: d,
                    f: f,
                    m: m,
                    u: s != fn.length || (m && (com.length != ms)),
                    compression: compression
                });
                o += 30 + s + exl + l;
                tot += 76 + 2 * (s + exl) + (ms || 0) + l;
                if (!--lft)
                    cbf();
            }
        };
        if (s > 65535)
            cbl(err(11, 0, 1), null);
        if (!compression)
            cbl(null, file);
        else if (size < 160000) {
            try {
                cbl(null, deflateSync(file, p));
            }
            catch (e) {
                cbl(e, null);
            }
        }
        else
            term.push(deflate(file, p, cbl));
    };
    // Cannot use lft because it can decrease
    for (var i = 0; i < slft; ++i) {
        _loop_1(i);
    }
    return tAll;
}
/**
 * Synchronously creates a ZIP file. Prefer using `zip` for better performance
 * with more than one file.
 * @param data The directory structure for the ZIP archive
 * @param opts The main options, merged with per-file options
 * @returns The generated ZIP archive
 */
function zipSync(data, opts) {
    if (!opts)
        opts = {};
    var r = {};
    var files = [];
    fltn(data, '', r, opts);
    var o = 0;
    var tot = 0;
    for (var fn in r) {
        var _a = r[fn], file = _a[0], p = _a[1];
        var compression = p.level == 0 ? 0 : 8;
        var f = strToU8(fn), s = f.length;
        var com = p.comment, m = com && strToU8(com), ms = m && m.length;
        var exl = exfl(p.extra);
        if (s > 65535)
            err(11);
        var d = compression ? deflateSync(file, p) : file, l = d.length;
        var c = crc();
        c.p(file);
        files.push(mrg(p, {
            size: file.length,
            crc: c.d(),
            c: d,
            f: f,
            m: m,
            u: s != fn.length || (m && (com.length != ms)),
            o: o,
            compression: compression
        }));
        o += 30 + s + exl + l;
        tot += 76 + 2 * (s + exl) + (ms || 0) + l;
    }
    var out = new u8(tot + 22), oe = o, cdl = tot - o;
    for (var i = 0; i < files.length; ++i) {
        var f = files[i];
        wzh(out, f.o, f, f.f, f.u, f.c.length);
        var badd = 30 + f.f.length + exfl(f.extra);
        out.set(f.c, f.o + badd);
        wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
    }
    wzf(out, o, files.length, cdl, oe);
    return out;
}
/**
 * Streaming pass-through decompression for ZIP archives
 */
var UnzipPassThrough = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    function UnzipPassThrough() {
    }
    UnzipPassThrough.prototype.push = function (data, final) {
        this.ondata(null, data, final);
    };
    UnzipPassThrough.compression = 0;
    return UnzipPassThrough;
}())));

/**
 * Streaming DEFLATE decompression for ZIP archives. Prefer AsyncZipInflate for
 * better performance.
 */
var UnzipInflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a DEFLATE decompression that can be used in ZIP archives
     */
    function UnzipInflate() {
        var _this = this;
        this.i = new Inflate(function (dat, final) {
            _this.ondata(null, dat, final);
        });
    }
    UnzipInflate.prototype.push = function (data, final) {
        try {
            this.i.push(data, final);
        }
        catch (e) {
            this.ondata(e, null, final);
        }
    };
    UnzipInflate.compression = 8;
    return UnzipInflate;
}())));

/**
 * Asynchronous streaming DEFLATE decompression for ZIP archives
 */
var AsyncUnzipInflate = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a DEFLATE decompression that can be used in ZIP archives
     */
    function AsyncUnzipInflate(_, sz) {
        var _this = this;
        if (sz < 320000) {
            this.i = new Inflate(function (dat, final) {
                _this.ondata(null, dat, final);
            });
        }
        else {
            this.i = new AsyncInflate(function (err, dat, final) {
                _this.ondata(err, dat, final);
            });
            this.terminate = this.i.terminate;
        }
    }
    AsyncUnzipInflate.prototype.push = function (data, final) {
        if (this.i.terminate)
            data = slc(data, 0);
        this.i.push(data, final);
    };
    AsyncUnzipInflate.compression = 8;
    return AsyncUnzipInflate;
}())));

/**
 * A ZIP archive decompression stream that emits files as they are discovered
 */
var Unzip = /*#__PURE__*/ ((/* unused pure expression or super */ null && (function () {
    /**
     * Creates a ZIP decompression stream
     * @param cb The callback to call whenever a file in the ZIP archive is found
     */
    function Unzip(cb) {
        this.onfile = cb;
        this.k = [];
        this.o = {
            0: UnzipPassThrough
        };
        this.p = et;
    }
    /**
     * Pushes a chunk to be unzipped
     * @param chunk The chunk to push
     * @param final Whether this is the last chunk
     */
    Unzip.prototype.push = function (chunk, final) {
        var _this = this;
        if (!this.onfile)
            err(5);
        if (!this.p)
            err(4);
        if (this.c > 0) {
            var len = Math.min(this.c, chunk.length);
            var toAdd = chunk.subarray(0, len);
            this.c -= len;
            if (this.d)
                this.d.push(toAdd, !this.c);
            else
                this.k[0].push(toAdd);
            chunk = chunk.subarray(len);
            if (chunk.length)
                return this.push(chunk, final);
        }
        else {
            var f = 0, i = 0, is = void 0, buf = void 0;
            if (!this.p.length)
                buf = chunk;
            else if (!chunk.length)
                buf = this.p;
            else {
                buf = new u8(this.p.length + chunk.length);
                buf.set(this.p), buf.set(chunk, this.p.length);
            }
            var l = buf.length, oc = this.c, add = oc && this.d;
            var _loop_2 = function () {
                var _a;
                var sig = b4(buf, i);
                if (sig == 0x4034B50) {
                    f = 1, is = i;
                    this_1.d = null;
                    this_1.c = 0;
                    var bf = b2(buf, i + 6), cmp_1 = b2(buf, i + 8), u = bf & 2048, dd = bf & 8, fnl = b2(buf, i + 26), es = b2(buf, i + 28);
                    if (l > i + 30 + fnl + es) {
                        var chks_3 = [];
                        this_1.k.unshift(chks_3);
                        f = 2;
                        var sc_1 = b4(buf, i + 18), su_1 = b4(buf, i + 22);
                        var fn_1 = strFromU8(buf.subarray(i + 30, i += 30 + fnl), !u);
                        if (sc_1 == 4294967295) {
                            _a = dd ? [-2] : z64e(buf, i), sc_1 = _a[0], su_1 = _a[1];
                        }
                        else if (dd)
                            sc_1 = -1;
                        i += es;
                        this_1.c = sc_1;
                        var d_1;
                        var file_1 = {
                            name: fn_1,
                            compression: cmp_1,
                            start: function () {
                                if (!file_1.ondata)
                                    err(5);
                                if (!sc_1)
                                    file_1.ondata(null, et, true);
                                else {
                                    var ctr = _this.o[cmp_1];
                                    if (!ctr)
                                        file_1.ondata(err(14, 'unknown compression type ' + cmp_1, 1), null, false);
                                    d_1 = sc_1 < 0 ? new ctr(fn_1) : new ctr(fn_1, sc_1, su_1);
                                    d_1.ondata = function (err, dat, final) { file_1.ondata(err, dat, final); };
                                    for (var _i = 0, chks_4 = chks_3; _i < chks_4.length; _i++) {
                                        var dat = chks_4[_i];
                                        d_1.push(dat, false);
                                    }
                                    if (_this.k[0] == chks_3 && _this.c)
                                        _this.d = d_1;
                                    else
                                        d_1.push(et, true);
                                }
                            },
                            terminate: function () {
                                if (d_1 && d_1.terminate)
                                    d_1.terminate();
                            }
                        };
                        if (sc_1 >= 0)
                            file_1.size = sc_1, file_1.originalSize = su_1;
                        this_1.onfile(file_1);
                    }
                    return "break";
                }
                else if (oc) {
                    if (sig == 0x8074B50) {
                        is = i += 12 + (oc == -2 && 8), f = 3, this_1.c = 0;
                        return "break";
                    }
                    else if (sig == 0x2014B50) {
                        is = i -= 4, f = 3, this_1.c = 0;
                        return "break";
                    }
                }
            };
            var this_1 = this;
            for (; i < l - 4; ++i) {
                var state_1 = _loop_2();
                if (state_1 === "break")
                    break;
            }
            this.p = et;
            if (oc < 0) {
                var dat = f ? buf.subarray(0, is - 12 - (oc == -2 && 8) - (b4(buf, is - 16) == 0x8074B50 && 4)) : buf.subarray(0, i);
                if (add)
                    add.push(dat, !!f);
                else
                    this.k[+(f == 2)].push(dat);
            }
            if (f & 2)
                return this.push(buf.subarray(i), final);
            this.p = buf.subarray(i);
        }
        if (final) {
            if (this.c)
                err(13);
            this.p = null;
        }
    };
    /**
     * Registers a decoder with the stream, allowing for files compressed with
     * the compression type provided to be expanded correctly
     * @param decoder The decoder constructor
     */
    Unzip.prototype.register = function (decoder) {
        this.o[decoder.compression] = decoder;
    };
    return Unzip;
}())));

var mt = typeof queueMicrotask == 'function' ? queueMicrotask : typeof setTimeout == 'function' ? setTimeout : function (fn) { fn(); };
function unzip(data, opts, cb) {
    if (!cb)
        cb = opts, opts = {};
    if (typeof cb != 'function')
        err(7);
    var term = [];
    var tAll = function () {
        for (var i = 0; i < term.length; ++i)
            term[i]();
    };
    var files = {};
    var cbd = function (a, b) {
        mt(function () { cb(a, b); });
    };
    mt(function () { cbd = cb; });
    var e = data.length - 22;
    for (; b4(data, e) != 0x6054B50; --e) {
        if (!e || data.length - e > 65558) {
            cbd(err(13, 0, 1), null);
            return tAll;
        }
    }
    ;
    var lft = b2(data, e + 8);
    if (lft) {
        var c = lft;
        var o = b4(data, e + 16);
        var z = o == 4294967295 || c == 65535;
        if (z) {
            var ze = b4(data, e - 12);
            z = b4(data, ze) == 0x6064B50;
            if (z) {
                c = lft = b4(data, ze + 32);
                o = b4(data, ze + 48);
            }
        }
        var fltr = opts && opts.filter;
        var _loop_3 = function (i) {
            var _a = zh(data, o, z), c_1 = _a[0], sc = _a[1], su = _a[2], fn = _a[3], no = _a[4], off = _a[5], b = slzh(data, off);
            o = no;
            var cbl = function (e, d) {
                if (e) {
                    tAll();
                    cbd(e, null);
                }
                else {
                    if (d)
                        files[fn] = d;
                    if (!--lft)
                        cbd(null, files);
                }
            };
            if (!fltr || fltr({
                name: fn,
                size: sc,
                originalSize: su,
                compression: c_1
            })) {
                if (!c_1)
                    cbl(null, slc(data, b, b + sc));
                else if (c_1 == 8) {
                    var infl = data.subarray(b, b + sc);
                    // Synchronously decompress under 512KB, or barely-compressed data
                    if (su < 524288 || sc > 0.8 * su) {
                        try {
                            cbl(null, inflateSync(infl, { out: new u8(su) }));
                        }
                        catch (e) {
                            cbl(e, null);
                        }
                    }
                    else
                        term.push(inflate(infl, { size: su }, cbl));
                }
                else
                    cbl(err(14, 'unknown compression type ' + c_1, 1), null);
            }
            else
                cbl(null, null);
        };
        for (var i = 0; i < c; ++i) {
            _loop_3(i);
        }
    }
    else
        cbd(null, {});
    return tAll;
}
/**
 * Synchronously decompresses a ZIP archive. Prefer using `unzip` for better
 * performance with more than one file.
 * @param data The raw compressed ZIP file
 * @param opts The ZIP extraction options
 * @returns The decompressed files
 */
function unzipSync(data, opts) {
    var files = {};
    var e = data.length - 22;
    for (; b4(data, e) != 0x6054B50; --e) {
        if (!e || data.length - e > 65558)
            err(13);
    }
    ;
    var c = b2(data, e + 8);
    if (!c)
        return {};
    var o = b4(data, e + 16);
    var z = o == 4294967295 || c == 65535;
    if (z) {
        var ze = b4(data, e - 12);
        z = b4(data, ze) == 0x6064B50;
        if (z) {
            c = b4(data, ze + 32);
            o = b4(data, ze + 48);
        }
    }
    var fltr = opts && opts.filter;
    for (var i = 0; i < c; ++i) {
        var _a = zh(data, o, z), c_2 = _a[0], sc = _a[1], su = _a[2], fn = _a[3], no = _a[4], off = _a[5], b = slzh(data, off);
        o = no;
        if (!fltr || fltr({
            name: fn,
            size: sc,
            originalSize: su,
            compression: c_2
        })) {
            if (!c_2)
                files[fn] = slc(data, b, b + sc);
            else if (c_2 == 8)
                files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
            else
                err(14, 'unknown compression type ' + c_2);
        }
    }
    return files;
}

;// ../../node_modules/three/examples/jsm/curves/NURBSUtils.js
/* unused harmony import specifier */ var Vector4;


/**
 * @module NURBSUtils
 * @three_import import * as NURBSUtils from 'three/addons/curves/NURBSUtils.js';
 */

/**
 * Finds knot vector span.
 *
 * @param {number} p - The degree.
 * @param {number} u - The parametric value.
 * @param {Array<number>} U - The knot vector.
 * @return {number} The span.
 */
function findSpan( p, u, U ) {

	const n = U.length - p - 1;

	if ( u >= U[ n ] ) {

		return n - 1;

	}

	if ( u <= U[ p ] ) {

		return p;

	}

	let low = p;
	let high = n;
	let mid = Math.floor( ( low + high ) / 2 );

	while ( u < U[ mid ] || u >= U[ mid + 1 ] ) {

		if ( u < U[ mid ] ) {

			high = mid;

		} else {

			low = mid;

		}

		mid = Math.floor( ( low + high ) / 2 );

	}

	return mid;

}

/**
 * Calculates basis functions. See The NURBS Book, page 70, algorithm A2.2.
 *
 * @param {number} span - The span in which `u` lies.
 * @param {number} u - The parametric value.
 * @param {number} p - The degree.
 * @param {Array<number>} U - The knot vector.
 * @return {Array<number>} Array[p+1] with basis functions values.
 */
function calcBasisFunctions( span, u, p, U ) {

	const N = [];
	const left = [];
	const right = [];
	N[ 0 ] = 1.0;

	for ( let j = 1; j <= p; ++ j ) {

		left[ j ] = u - U[ span + 1 - j ];
		right[ j ] = U[ span + j ] - u;

		let saved = 0.0;

		for ( let r = 0; r < j; ++ r ) {

			const rv = right[ r + 1 ];
			const lv = left[ j - r ];
			const temp = N[ r ] / ( rv + lv );
			N[ r ] = saved + rv * temp;
			saved = lv * temp;

		}

		N[ j ] = saved;

	}

	return N;

}

/**
 * Calculates B-Spline curve points. See The NURBS Book, page 82, algorithm A3.1.
 *
 * @param {number} p - The degree of the B-Spline.
 * @param {Array<number>} U - The knot vector.
 * @param {Array<Vector4>} P - The control points
 * @param {number} u - The parametric point.
 * @return {Vector4} The point for given `u`.
 */
function calcBSplinePoint( p, U, P, u ) {

	const span = findSpan( p, u, U );
	const N = calcBasisFunctions( span, u, p, U );
	const C = new __WEBPACK_EXTERNAL_MODULE_three_Vector4__( 0, 0, 0, 0 );

	for ( let j = 0; j <= p; ++ j ) {

		const point = P[ span - p + j ];
		const Nj = N[ j ];
		const wNj = point.w * Nj;
		C.x += point.x * wNj;
		C.y += point.y * wNj;
		C.z += point.z * wNj;
		C.w += point.w * Nj;

	}

	return C;

}

/**
 * Calculates basis functions derivatives. See The NURBS Book, page 72, algorithm A2.3.
 *
 * @param {number} span - The span in which `u` lies.
 * @param {number} u - The parametric point.
 * @param {number} p - The degree.
 * @param {number} n - number of derivatives to calculate
 * @param {Array<number>} U - The knot vector.
 * @return {Array<Array<number>>} An array[n+1][p+1] with basis functions derivatives.
 */
function calcBasisFunctionDerivatives( span, u, p, n, U ) {

	const zeroArr = [];
	for ( let i = 0; i <= p; ++ i )
		zeroArr[ i ] = 0.0;

	const ders = [];

	for ( let i = 0; i <= n; ++ i )
		ders[ i ] = zeroArr.slice( 0 );

	const ndu = [];

	for ( let i = 0; i <= p; ++ i )
		ndu[ i ] = zeroArr.slice( 0 );

	ndu[ 0 ][ 0 ] = 1.0;

	const left = zeroArr.slice( 0 );
	const right = zeroArr.slice( 0 );

	for ( let j = 1; j <= p; ++ j ) {

		left[ j ] = u - U[ span + 1 - j ];
		right[ j ] = U[ span + j ] - u;

		let saved = 0.0;

		for ( let r = 0; r < j; ++ r ) {

			const rv = right[ r + 1 ];
			const lv = left[ j - r ];
			ndu[ j ][ r ] = rv + lv;

			const temp = ndu[ r ][ j - 1 ] / ndu[ j ][ r ];
			ndu[ r ][ j ] = saved + rv * temp;
			saved = lv * temp;

		}

		ndu[ j ][ j ] = saved;

	}

	for ( let j = 0; j <= p; ++ j ) {

		ders[ 0 ][ j ] = ndu[ j ][ p ];

	}

	for ( let r = 0; r <= p; ++ r ) {

		let s1 = 0;
		let s2 = 1;

		const a = [];
		for ( let i = 0; i <= p; ++ i ) {

			a[ i ] = zeroArr.slice( 0 );

		}

		a[ 0 ][ 0 ] = 1.0;

		for ( let k = 1; k <= n; ++ k ) {

			let d = 0.0;
			const rk = r - k;
			const pk = p - k;

			if ( r >= k ) {

				a[ s2 ][ 0 ] = a[ s1 ][ 0 ] / ndu[ pk + 1 ][ rk ];
				d = a[ s2 ][ 0 ] * ndu[ rk ][ pk ];

			}

			const j1 = ( rk >= - 1 ) ? 1 : - rk;
			const j2 = ( r - 1 <= pk ) ? k - 1 : p - r;

			for ( let j = j1; j <= j2; ++ j ) {

				a[ s2 ][ j ] = ( a[ s1 ][ j ] - a[ s1 ][ j - 1 ] ) / ndu[ pk + 1 ][ rk + j ];
				d += a[ s2 ][ j ] * ndu[ rk + j ][ pk ];

			}

			if ( r <= pk ) {

				a[ s2 ][ k ] = - a[ s1 ][ k - 1 ] / ndu[ pk + 1 ][ r ];
				d += a[ s2 ][ k ] * ndu[ r ][ pk ];

			}

			ders[ k ][ r ] = d;

			const j = s1;
			s1 = s2;
			s2 = j;

		}

	}

	let r = p;

	for ( let k = 1; k <= n; ++ k ) {

		for ( let j = 0; j <= p; ++ j ) {

			ders[ k ][ j ] *= r;

		}

		r *= p - k;

	}

	return ders;

}

/**
 * Calculates derivatives of a B-Spline. See The NURBS Book, page 93, algorithm A3.2.
 *
 * @param {number} p - The degree.
 * @param {Array<number>} U - The knot vector.
 * @param {Array<Vector4>} P - The control points
 * @param {number} u - The parametric point.
 * @param {number} nd - The number of derivatives.
 * @return {Array<Vector4>} An array[d+1] with derivatives.
 */
function calcBSplineDerivatives( p, U, P, u, nd ) {

	const du = nd < p ? nd : p;
	const CK = [];
	const span = findSpan( p, u, U );
	const nders = calcBasisFunctionDerivatives( span, u, p, du, U );
	const Pw = [];

	for ( let i = 0; i < P.length; ++ i ) {

		const point = P[ i ].clone();
		const w = point.w;

		point.x *= w;
		point.y *= w;
		point.z *= w;

		Pw[ i ] = point;

	}

	for ( let k = 0; k <= du; ++ k ) {

		const point = Pw[ span - p ].clone().multiplyScalar( nders[ k ][ 0 ] );

		for ( let j = 1; j <= p; ++ j ) {

			point.add( Pw[ span - p + j ].clone().multiplyScalar( nders[ k ][ j ] ) );

		}

		CK[ k ] = point;

	}

	for ( let k = du + 1; k <= nd + 1; ++ k ) {

		CK[ k ] = new __WEBPACK_EXTERNAL_MODULE_three_Vector4__( 0, 0, 0 );

	}

	return CK;

}

/**
 * Calculates "K over I".
 *
 * @param {number} k - The K value.
 * @param {number} i - The I value.
 * @return {number} k!/(i!(k-i)!)
 */
function calcKoverI( k, i ) {

	let nom = 1;

	for ( let j = 2; j <= k; ++ j ) {

		nom *= j;

	}

	let denom = 1;

	for ( let j = 2; j <= i; ++ j ) {

		denom *= j;

	}

	for ( let j = 2; j <= k - i; ++ j ) {

		denom *= j;

	}

	return nom / denom;

}

/**
 * Calculates derivatives (0-nd) of rational curve. See The NURBS Book, page 127, algorithm A4.2.
 *
 * @param {Array<Vector4>} Pders - Array with derivatives.
 * @return {Array<Vector3>} An array with derivatives for rational curve.
 */
function calcRationalCurveDerivatives( Pders ) {

	const nd = Pders.length;
	const Aders = [];
	const wders = [];

	for ( let i = 0; i < nd; ++ i ) {

		const point = Pders[ i ];
		Aders[ i ] = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( point.x, point.y, point.z );
		wders[ i ] = point.w;

	}

	const CK = [];

	for ( let k = 0; k < nd; ++ k ) {

		const v = Aders[ k ].clone();

		for ( let i = 1; i <= k; ++ i ) {

			v.sub( CK[ k - i ].clone().multiplyScalar( calcKoverI( k, i ) * wders[ i ] ) );

		}

		CK[ k ] = v.divideScalar( wders[ 0 ] );

	}

	return CK;

}

/**
 * Calculates NURBS curve derivatives. See The NURBS Book, page 127, algorithm A4.2.
 *
 * @param {number} p - The degree.
 * @param {Array<number>} U - The knot vector.
 * @param {Array<Vector4>} P - The control points in homogeneous space.
 * @param {number} u - The parametric point.
 * @param {number} nd - The number of derivatives.
 * @return {Array<Vector3>} array with derivatives for rational curve.
 */
function calcNURBSDerivatives( p, U, P, u, nd ) {

	const Pders = calcBSplineDerivatives( p, U, P, u, nd );
	return calcRationalCurveDerivatives( Pders );

}

/**
 * Calculates a rational B-Spline surface point. See The NURBS Book, page 134, algorithm A4.3.
 *
 * @param {number} p - The first degree of B-Spline surface.
 * @param {number} q - The second degree of B-Spline surface.
 * @param {Array<number>} U - The first knot vector.
 * @param {Array<number>} V - The second knot vector.
 * @param {Array<Array<Vector4>>} P - The control points in homogeneous space.
 * @param {number} u - The first parametric point.
 * @param {number} v - The second parametric point.
 * @param {Vector3} target - The target vector.
 */
function calcSurfacePoint( p, q, U, V, P, u, v, target ) {

	const uspan = findSpan( p, u, U );
	const vspan = findSpan( q, v, V );
	const Nu = calcBasisFunctions( uspan, u, p, U );
	const Nv = calcBasisFunctions( vspan, v, q, V );
	const temp = [];

	for ( let l = 0; l <= q; ++ l ) {

		temp[ l ] = new Vector4( 0, 0, 0, 0 );
		for ( let k = 0; k <= p; ++ k ) {

			const point = P[ uspan - p + k ][ vspan - q + l ].clone();
			const w = point.w;
			point.x *= w;
			point.y *= w;
			point.z *= w;
			temp[ l ].add( point.multiplyScalar( Nu[ k ] ) );

		}

	}

	const Sw = new Vector4( 0, 0, 0, 0 );
	for ( let l = 0; l <= q; ++ l ) {

		Sw.add( temp[ l ].multiplyScalar( Nv[ l ] ) );

	}

	Sw.divideScalar( Sw.w );
	target.set( Sw.x, Sw.y, Sw.z );

}

/**
 * Calculates a rational B-Spline volume point. See The NURBS Book, page 134, algorithm A4.3.
 *
 * @param {number} p - The first degree of B-Spline surface.
 * @param {number} q - The second degree of B-Spline surface.
 * @param {number} r - The third degree of B-Spline surface.
 * @param {Array<number>} U - The first knot vector.
 * @param {Array<number>} V - The second knot vector.
 * @param {Array<number>} W - The third knot vector.
 * @param {Array<Array<Array<Vector4>>>} P - The control points in homogeneous space.
 * @param {number} u - The first parametric point.
 * @param {number} v - The second parametric point.
 * @param {number} w - The third parametric point.
 * @param {Vector3} target - The target vector.
 */
function calcVolumePoint( p, q, r, U, V, W, P, u, v, w, target ) {

	const uspan = findSpan( p, u, U );
	const vspan = findSpan( q, v, V );
	const wspan = findSpan( r, w, W );
	const Nu = calcBasisFunctions( uspan, u, p, U );
	const Nv = calcBasisFunctions( vspan, v, q, V );
	const Nw = calcBasisFunctions( wspan, w, r, W );
	const temp = [];

	for ( let m = 0; m <= r; ++ m ) {

		temp[ m ] = [];

		for ( let l = 0; l <= q; ++ l ) {

			temp[ m ][ l ] = new Vector4( 0, 0, 0, 0 );
			for ( let k = 0; k <= p; ++ k ) {

				const point = P[ uspan - p + k ][ vspan - q + l ][ wspan - r + m ].clone();
				const w = point.w;
				point.x *= w;
				point.y *= w;
				point.z *= w;
				temp[ m ][ l ].add( point.multiplyScalar( Nu[ k ] ) );

			}

		}

	}

	const Sw = new Vector4( 0, 0, 0, 0 );
	for ( let m = 0; m <= r; ++ m ) {

		for ( let l = 0; l <= q; ++ l ) {

			Sw.add( temp[ m ][ l ].multiplyScalar( Nw[ m ] ).multiplyScalar( Nv[ l ] ) );

		}

	}

	Sw.divideScalar( Sw.w );
	target.set( Sw.x, Sw.y, Sw.z );

}



;// ../../node_modules/three/examples/jsm/curves/NURBSCurve.js



/**
 * This class represents a NURBS curve.
 *
 * Implementation is based on `(x, y [, z=0 [, w=1]])` control points with `w=weight`.
 *
 * @augments Curve
 * @three_import import { NURBSCurve } from 'three/addons/curves/NURBSCurve.js';
 */
class NURBSCurve extends __WEBPACK_EXTERNAL_MODULE_three_Curve__ {

	/**
	 * Constructs a new NURBS curve.
	 *
	 * @param {number} degree - The NURBS degree.
	 * @param {Array<number>} knots - The knots as a flat array of numbers.
	 * @param {Array<Vector2|Vector3|Vector4>} controlPoints - An array holding control points.
	 * @param {number} [startKnot] - Index of the start knot into the `knots` array.
	 * @param {number} [endKnot] - Index of the end knot into the `knots` array.
	 */
	constructor( degree, knots, controlPoints, startKnot, endKnot ) {

		super();

		const knotsLength = knots ? knots.length - 1 : 0;
		const pointsLength = controlPoints ? controlPoints.length : 0;

		/**
		 * The NURBS degree.
		 *
		 * @type {number}
		 */
		this.degree = degree;

		/**
		 * The knots as a flat array of numbers.
		 *
		 * @type {Array<number>}
		 */
		this.knots = knots;

		/**
		 * An array of control points.
		 *
		 * @type {Array<Vector4>}
		 */
		this.controlPoints = [];

		/**
		 * Index of the start knot into the `knots` array.
		 *
		 * @type {number}
		 */
		this.startKnot = startKnot || 0;

		/**
		 * Index of the end knot into the `knots` array.
		 *
		 * @type {number}
		 */
		this.endKnot = endKnot || knotsLength;

		for ( let i = 0; i < pointsLength; ++ i ) {

			// ensure Vector4 for control points
			const point = controlPoints[ i ];
			this.controlPoints[ i ] = new __WEBPACK_EXTERNAL_MODULE_three_Vector4__( point.x, point.y, point.z, point.w );

		}

	}

	/**
	 * This method returns a vector in 3D space for the given interpolation factor.
	 *
	 * @param {number} t - A interpolation factor representing a position on the curve. Must be in the range `[0,1]`.
	 * @param {Vector3} [optionalTarget] - The optional target vector the result is written to.
	 * @return {Vector3} The position on the curve.
	 */
	getPoint( t, optionalTarget = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__() ) {

		const point = optionalTarget;

		const u = this.knots[ this.startKnot ] + t * ( this.knots[ this.endKnot ] - this.knots[ this.startKnot ] ); // linear mapping t->u

		// following results in (wx, wy, wz, w) homogeneous point
		const hpoint = calcBSplinePoint( this.degree, this.knots, this.controlPoints, u );

		if ( hpoint.w !== 1.0 ) {

			// project to 3D space: (wx, wy, wz, w) -> (x, y, z, 1)
			hpoint.divideScalar( hpoint.w );

		}

		return point.set( hpoint.x, hpoint.y, hpoint.z );

	}

	/**
	 * Returns a unit vector tangent for the given interpolation factor.
	 *
	 * @param {number} t - The interpolation factor.
	 * @param {Vector3} [optionalTarget] - The optional target vector the result is written to.
	 * @return {Vector3} The tangent vector.
	 */
	getTangent( t, optionalTarget = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__() ) {

		const tangent = optionalTarget;

		const u = this.knots[ 0 ] + t * ( this.knots[ this.knots.length - 1 ] - this.knots[ 0 ] );
		const ders = calcNURBSDerivatives( this.degree, this.knots, this.controlPoints, u, 1 );
		tangent.copy( ders[ 1 ] ).normalize();

		return tangent;

	}

	toJSON() {

		const data = super.toJSON();

		data.degree = this.degree;
		data.knots = [ ...this.knots ];
		data.controlPoints = this.controlPoints.map( p => p.toArray() );
		data.startKnot = this.startKnot;
		data.endKnot = this.endKnot;

		return data;

	}

	fromJSON( json ) {

		super.fromJSON( json );

		this.degree = json.degree;
		this.knots = [ ...json.knots ];
		this.controlPoints = json.controlPoints.map( p => new __WEBPACK_EXTERNAL_MODULE_three_Vector4__( p[ 0 ], p[ 1 ], p[ 2 ], p[ 3 ] ) );
		this.startKnot = json.startKnot;
		this.endKnot = json.endKnot;

		return this;

	}

}



;// ../../node_modules/three/examples/jsm/loaders/FBXLoader.js





let fbxTree;
let connections;
let sceneGraph;

/**
 * A loader for the FBX format.
 *
 * Requires FBX file to be >= 7.0 and in ASCII or >= 6400 in Binary format.
 * Versions lower than this may load but will probably have errors.
 *
 * Needs Support:
 * - Morph normals / blend shape normals
 *
 * FBX format references:
 * - [C++ SDK reference](https://help.autodesk.com/view/FBX/2017/ENU/?guid=__cpp_ref_index_html)
 *
 * Binary format specification:
 * - [FBX binary file format specification](https://code.blender.org/2013/08/fbx-binary-file-format-specification/)
 *
 * ```js
 * const loader = new FBXLoader();
 * const object = await loader.loadAsync( 'models/fbx/stanford-bunny.fbx' );
 * scene.add( object );
 * ```
 *
 * @augments Loader
 * @three_import import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
 */
class FBXLoader extends __WEBPACK_EXTERNAL_MODULE_three_Loader__ {

	/**
	 * Constructs a new FBX loader.
	 *
	 * @param {LoadingManager} [manager] - The loading manager.
	 */
	constructor( manager ) {

		super( manager );

		/**
		 * Whether to trim animation clips to the time range of their
		 * animation stacks and shift them to start at time zero. Useful
		 * for assets that define multiple clips on a single timeline.
		 *
		 * @type {boolean}
		 * @default false
		 */
		this.trimAnimationClips = false;

	}

	/**
	 * Starts loading from the given URL and passes the loaded FBX asset
	 * to the `onLoad()` callback.
	 *
	 * @param {string} url - The path/URL of the file to be loaded. This can also be a data URI.
	 * @param {function(Group)} onLoad - Executed when the loading process has been finished.
	 * @param {onProgressCallback} onProgress - Executed while the loading is in progress.
	 * @param {onErrorCallback} onError - Executed when errors occur.
	 */
	load( url, onLoad, onProgress, onError ) {

		const scope = this;

		const path = ( scope.path === '' ) ? __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__.extractUrlBase( url ) : scope.path;

		const loader = new __WEBPACK_EXTERNAL_MODULE_three_FileLoader__( this.manager );
		loader.setPath( scope.path );
		loader.setResponseType( 'arraybuffer' );
		loader.setRequestHeader( scope.requestHeader );
		loader.setWithCredentials( scope.withCredentials );

		loader.load( url, function ( buffer ) {

			try {

				onLoad( scope.parse( buffer, path ) );

			} catch ( e ) {

				if ( onError ) {

					onError( e );

				} else {

					console.error( e );

				}

				scope.manager.itemError( url );

			}

		}, onProgress, onError );

	}

	/**
	 * Parses the given FBX data and returns the resulting group.
	 *
	 * @param {ArrayBuffer} FBXBuffer - The raw FBX data as an array buffer.
	 * @param {string} path - The URL base path.
	 * @return {Group} An object representing the parsed asset.
	 */
	parse( FBXBuffer, path ) {

		if ( isFbxFormatBinary( FBXBuffer ) ) {

			fbxTree = new BinaryParser().parse( FBXBuffer );

		} else {

			const FBXText = convertArrayBufferToString( FBXBuffer );

			if ( ! isFbxFormatASCII( FBXText ) ) {

				throw new Error( 'THREE.FBXLoader: Unknown format.' );

			}

			if ( getFbxVersion( FBXText ) < 7000 ) {

				throw new Error( 'THREE.FBXLoader: FBX version not supported, FileVersion: ' + getFbxVersion( FBXText ) );

			}

			fbxTree = new TextParser().parse( FBXText );

		}

		// console.log( fbxTree );

		const textureLoader = new __WEBPACK_EXTERNAL_MODULE_three_TextureLoader__( this.manager ).setPath( this.resourcePath || path ).setCrossOrigin( this.crossOrigin );

		return new FBXTreeParser( textureLoader, this.manager, this.trimAnimationClips ).parse( fbxTree );

	}

}

// Parse the FBXTree object returned by the BinaryParser or TextParser and return a Group
class FBXTreeParser {

	constructor( textureLoader, manager, trimAnimationClips ) {

		this.textureLoader = textureLoader;
		this.manager = manager;
		this.trimAnimationClips = trimAnimationClips;

	}

	parse() {

		connections = this.parseConnections();

		const images = this.parseImages();
		const textures = this.parseTextures( images );
		const materials = this.parseMaterials( textures );
		const deformers = this.parseDeformers();
		const geometryMap = new GeometryParser().parse( deformers );

		this.parseScene( deformers, geometryMap, materials );

		return sceneGraph;

	}

	// Parses FBXTree.Connections which holds parent-child connections between objects (e.g. material -> texture, model->geometry )
	// and details the connection type
	parseConnections() {

		const connectionMap = new Map();

		if ( 'Connections' in fbxTree ) {

			const rawConnections = fbxTree.Connections.connections;

			rawConnections.forEach( function ( rawConnection ) {

				const fromID = rawConnection[ 0 ];
				const toID = rawConnection[ 1 ];
				const relationship = rawConnection[ 2 ];

				if ( ! connectionMap.has( fromID ) ) {

					connectionMap.set( fromID, {
						parents: [],
						children: []
					} );

				}

				const parentRelationship = { ID: toID, relationship: relationship };
				connectionMap.get( fromID ).parents.push( parentRelationship );

				if ( ! connectionMap.has( toID ) ) {

					connectionMap.set( toID, {
						parents: [],
						children: []
					} );

				}

				const childRelationship = { ID: fromID, relationship: relationship };
				connectionMap.get( toID ).children.push( childRelationship );

			} );

		}

		return connectionMap;

	}

	// Parse FBXTree.Objects.Video for embedded image data
	// These images are connected to textures in FBXTree.Objects.Textures
	// via FBXTree.Connections.
	parseImages() {

		const images = {};
		const blobs = {};

		if ( 'Video' in fbxTree.Objects ) {

			const videoNodes = fbxTree.Objects.Video;

			for ( const nodeID in videoNodes ) {

				const videoNode = videoNodes[ nodeID ];

				const id = parseInt( nodeID );

				images[ id ] = videoNode.RelativeFilename || videoNode.Filename;

				// raw image data is in videoNode.Content
				if ( 'Content' in videoNode ) {

					const arrayBufferContent = ( videoNode.Content instanceof ArrayBuffer ) && ( videoNode.Content.byteLength > 0 );
					const base64Content = ( typeof videoNode.Content === 'string' ) && ( videoNode.Content !== '' );

					if ( arrayBufferContent || base64Content ) {

						const image = this.parseImage( videoNodes[ nodeID ] );

						blobs[ videoNode.RelativeFilename || videoNode.Filename ] = image;

					}

				}

			}

		}

		for ( const id in images ) {

			const filename = images[ id ];

			if ( blobs[ filename ] !== undefined ) images[ id ] = blobs[ filename ];
			else images[ id ] = images[ id ].split( '\\' ).pop();

		}

		return images;

	}

	// Parse embedded image data in FBXTree.Video.Content
	parseImage( videoNode ) {

		const content = videoNode.Content;
		const fileName = videoNode.RelativeFilename || videoNode.Filename;
		const extension = fileName.slice( fileName.lastIndexOf( '.' ) + 1 ).toLowerCase();

		let type;

		switch ( extension ) {

			case 'bmp':

				type = 'image/bmp';
				break;

			case 'jpg':
			case 'jpeg':

				type = 'image/jpeg';
				break;

			case 'png':

				type = 'image/png';
				break;

			case 'tif':

				type = 'image/tiff';
				break;

			case 'tga':

				if ( this.manager.getHandler( '.tga' ) === null ) {

					console.warn( 'FBXLoader: TGA loader not found, skipping ', fileName );

				}

				type = 'image/tga';
				break;

			case 'webp':

				type = 'image/webp';
				break;

			default:

				console.warn( 'FBXLoader: Image type "' + extension + '" is not supported.' );
				return;

		}

		if ( typeof content === 'string' ) { // ASCII format

			return 'data:' + type + ';base64,' + content;

		} else { // Binary Format

			const array = new Uint8Array( content );
			return URL.createObjectURL( new Blob( [ array ], { type: type } ) );

		}

	}

	// Parse nodes in FBXTree.Objects.Texture
	// These contain details such as UV scaling, cropping, rotation etc and are connected
	// to images in FBXTree.Objects.Video
	parseTextures( images ) {

		const textureMap = new Map();

		if ( 'Texture' in fbxTree.Objects ) {

			const textureNodes = fbxTree.Objects.Texture;
			for ( const nodeID in textureNodes ) {

				const texture = this.parseTexture( textureNodes[ nodeID ], images );
				textureMap.set( parseInt( nodeID ), texture );

			}

		}

		return textureMap;

	}

	// Parse individual node in FBXTree.Objects.Texture
	parseTexture( textureNode, images ) {

		const texture = this.loadTexture( textureNode, images );

		texture.ID = textureNode.id;

		texture.name = textureNode.attrName;

		const wrapModeU = textureNode.WrapModeU;
		const wrapModeV = textureNode.WrapModeV;

		const valueU = wrapModeU !== undefined ? wrapModeU.value : 0;
		const valueV = wrapModeV !== undefined ? wrapModeV.value : 0;

		// http://download.autodesk.com/us/fbx/SDKdocs/FBX_SDK_Help/files/fbxsdkref/class_k_fbx_texture.html#889640e63e2e681259ea81061b85143a
		// 0: repeat(default), 1: clamp

		texture.wrapS = valueU === 0 ? __WEBPACK_EXTERNAL_MODULE_three_RepeatWrapping__ : __WEBPACK_EXTERNAL_MODULE_three_ClampToEdgeWrapping__;
		texture.wrapT = valueV === 0 ? __WEBPACK_EXTERNAL_MODULE_three_RepeatWrapping__ : __WEBPACK_EXTERNAL_MODULE_three_ClampToEdgeWrapping__;

		if ( 'Scaling' in textureNode ) {

			const values = textureNode.Scaling.value;

			texture.repeat.x = values[ 0 ];
			texture.repeat.y = values[ 1 ];

		}

		if ( 'Translation' in textureNode ) {

			const values = textureNode.Translation.value;

			texture.offset.x = values[ 0 ];
			texture.offset.y = values[ 1 ];

		}

		return texture;

	}

	// load a texture specified as a blob or data URI, or via an external URL using TextureLoader
	loadTexture( textureNode, images ) {

		const extension = textureNode.FileName.split( '.' ).pop().toLowerCase();

		let loader = this.manager.getHandler( `.${extension}` );
		if ( loader === null ) loader = this.textureLoader;

		const loaderPath = loader.path;

		if ( ! loaderPath ) {

			loader.setPath( this.textureLoader.path );

		}

		const children = connections.get( textureNode.id ).children;

		let fileName;

		if ( children !== undefined && children.length > 0 && images[ children[ 0 ].ID ] !== undefined ) {

			fileName = images[ children[ 0 ].ID ];

			if ( fileName.indexOf( 'blob:' ) === 0 || fileName.indexOf( 'data:' ) === 0 ) {

				loader.setPath( undefined );

			}

		}

		if ( fileName === undefined ) {

			console.warn( 'FBXLoader: Undefined filename, creating placeholder texture.' );
			return new __WEBPACK_EXTERNAL_MODULE_three_Texture__();

		}

		const texture = loader.load( fileName );

		// revert to initial path
		loader.setPath( loaderPath );

		return texture;

	}

	// Parse nodes in FBXTree.Objects.Material
	parseMaterials( textureMap ) {

		const materialMap = new Map();

		if ( 'Material' in fbxTree.Objects ) {

			const materialNodes = fbxTree.Objects.Material;

			for ( const nodeID in materialNodes ) {

				const material = this.parseMaterial( materialNodes[ nodeID ], textureMap );

				if ( material !== null ) materialMap.set( parseInt( nodeID ), material );

			}

		}

		return materialMap;

	}

	// Parse single node in FBXTree.Objects.Material
	// Materials are connected to texture maps in FBXTree.Objects.Textures
	// FBX format currently only supports Lambert and Phong shading models
	parseMaterial( materialNode, textureMap ) {

		const ID = materialNode.id;
		const name = materialNode.attrName;
		let type = materialNode.ShadingModel;

		// Case where FBX wraps shading model in property object.
		if ( typeof type === 'object' ) {

			type = type.value;

		}

		// Ignore unused materials which don't have any connections.
		if ( ! connections.has( ID ) ) return null;

		const parameters = this.parseParameters( materialNode, textureMap, ID );

		let material;

		switch ( type.toLowerCase() ) {

			case 'phong':
				material = new __WEBPACK_EXTERNAL_MODULE_three_MeshPhongMaterial__();
				break;
			case 'lambert':
				material = new __WEBPACK_EXTERNAL_MODULE_three_MeshLambertMaterial__();
				break;
			default:
				console.warn( 'THREE.FBXLoader: unknown material type "%s". Defaulting to MeshPhongMaterial.', type );
				material = new __WEBPACK_EXTERNAL_MODULE_three_MeshPhongMaterial__();
				break;

		}

		material.setValues( parameters );
		material.name = name;

		return material;

	}

	// Parse FBX material and return parameters suitable for a three.js material
	// Also parse the texture map and return any textures associated with the material
	parseParameters( materialNode, textureMap, ID ) {

		const parameters = {};

		if ( materialNode.BumpFactor ) {

			parameters.bumpScale = materialNode.BumpFactor.value;

		}

		if ( materialNode.Diffuse ) {

			parameters.color = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( materialNode.Diffuse.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

		} else if ( materialNode.DiffuseColor && ( materialNode.DiffuseColor.type === 'Color' || materialNode.DiffuseColor.type === 'ColorRGB' ) ) {

			// The blender exporter exports diffuse here instead of in materialNode.Diffuse
			parameters.color = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( materialNode.DiffuseColor.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

		}

		if ( materialNode.DisplacementFactor ) {

			parameters.displacementScale = materialNode.DisplacementFactor.value;

		}

		if ( materialNode.Emissive ) {

			parameters.emissive = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( materialNode.Emissive.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

		} else if ( materialNode.EmissiveColor && ( materialNode.EmissiveColor.type === 'Color' || materialNode.EmissiveColor.type === 'ColorRGB' ) ) {

			// The blender exporter exports emissive color here instead of in materialNode.Emissive
			parameters.emissive = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( materialNode.EmissiveColor.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

		}

		if ( materialNode.EmissiveFactor ) {

			parameters.emissiveIntensity = parseFloat( materialNode.EmissiveFactor.value );

		}

		// the transparency handling is implemented based on Blender's approach:
		// https://github.com/blender/blender/blob/main/scripts/addons_core/io_scene_fbx/import_fbx.py

		parameters.opacity = 1 - ( materialNode.TransparencyFactor ? parseFloat( materialNode.TransparencyFactor.value ) : 0 );

		if ( parameters.opacity === 1 || parameters.opacity === 0 ) {

			parameters.opacity = ( materialNode.Opacity ? parseFloat( materialNode.Opacity.value ) : null );

			if ( parameters.opacity === null ) {

				// Default to opaque. Some exporters (e.g. 3ds Max) define TransparentColor
				// as white (1,1,1) without intending transparency, which makes the Unity-style
				// fallback of `1 - TransparentColor.r` produce incorrect zero opacity.
				parameters.opacity = 1;

			}

		}

		if ( parameters.opacity < 1.0 ) {

			parameters.transparent = true;

		}

		if ( materialNode.ReflectionFactor ) {

			parameters.reflectivity = materialNode.ReflectionFactor.value;

		}

		if ( materialNode.Shininess ) {

			parameters.shininess = materialNode.Shininess.value;

		}

		if ( materialNode.Specular ) {

			parameters.specular = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( materialNode.Specular.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

		} else if ( materialNode.SpecularColor && materialNode.SpecularColor.type === 'Color' ) {

			// The blender exporter exports specular color here instead of in materialNode.Specular
			parameters.specular = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( materialNode.SpecularColor.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

		}

		const scope = this;
		connections.get( ID ).children.forEach( function ( child ) {

			const type = child.relationship;

			switch ( type ) {

				case 'Bump':
					parameters.bumpMap = scope.getTexture( textureMap, child.ID );
					break;

				case 'Maya|TEX_ao_map':
					parameters.aoMap = scope.getTexture( textureMap, child.ID );
					break;

				case 'DiffuseColor':
				case 'Maya|TEX_color_map':
					parameters.map = scope.getTexture( textureMap, child.ID );
					if ( parameters.map !== undefined ) {

						parameters.map.colorSpace = __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__;

					}

					break;

				case 'DisplacementColor':
					parameters.displacementMap = scope.getTexture( textureMap, child.ID );
					break;

				case 'EmissiveColor':
					parameters.emissiveMap = scope.getTexture( textureMap, child.ID );
					if ( parameters.emissiveMap !== undefined ) {

						parameters.emissiveMap.colorSpace = __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__;

					}

					break;

				case 'NormalMap':
				case 'Maya|TEX_normal_map':
					parameters.normalMap = scope.getTexture( textureMap, child.ID );
					break;

				case 'ReflectionColor':
					parameters.envMap = scope.getTexture( textureMap, child.ID );
					if ( parameters.envMap !== undefined ) {

						parameters.envMap.mapping = __WEBPACK_EXTERNAL_MODULE_three_EquirectangularReflectionMapping__;
						parameters.envMap.colorSpace = __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__;

					}

					break;

				case 'SpecularColor':
					parameters.specularMap = scope.getTexture( textureMap, child.ID );
					if ( parameters.specularMap !== undefined ) {

						parameters.specularMap.colorSpace = __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__;

					}

					break;

				case 'TransparentColor':
				case 'TransparencyFactor':
					parameters.alphaMap = scope.getTexture( textureMap, child.ID );
					parameters.transparent = true;
					break;

				case 'AmbientColor':
				case 'ShininessExponent': // AKA glossiness map
				case 'SpecularFactor': // AKA specularLevel
				case 'VectorDisplacementColor': // NOTE: Seems to be a copy of DisplacementColor
				default:
					console.warn( 'THREE.FBXLoader: %s map is not supported in three.js, skipping texture.', type );
					break;

			}

		} );

		return parameters;

	}

	// get a texture from the textureMap for use by a material.
	getTexture( textureMap, id ) {

		// if the texture is a layered texture, just use the first layer and issue a warning
		if ( 'LayeredTexture' in fbxTree.Objects && id in fbxTree.Objects.LayeredTexture ) {

			console.warn( 'THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer.' );
			id = connections.get( id ).children[ 0 ].ID;

		}

		return textureMap.get( id );

	}

	// Parse nodes in FBXTree.Objects.Deformer
	// Deformer node can contain skinning or Vertex Cache animation data, however only skinning is supported here
	// Generates map of Skeleton-like objects for use later when generating and binding skeletons.
	parseDeformers() {

		const skeletons = {};
		const morphTargets = {};

		if ( 'Deformer' in fbxTree.Objects ) {

			const DeformerNodes = fbxTree.Objects.Deformer;

			for ( const nodeID in DeformerNodes ) {

				const deformerNode = DeformerNodes[ nodeID ];

				const relationships = connections.get( parseInt( nodeID ) );

				if ( deformerNode.attrType === 'Skin' ) {

					const skeleton = this.parseSkeleton( relationships, DeformerNodes );
					skeleton.ID = nodeID;

					if ( relationships.parents.length > 1 ) console.warn( 'THREE.FBXLoader: skeleton attached to more than one geometry is not supported.' );
					skeleton.geometryID = relationships.parents[ 0 ].ID;

					skeletons[ nodeID ] = skeleton;

				} else if ( deformerNode.attrType === 'BlendShape' ) {

					const morphTarget = {
						id: nodeID,
					};

					morphTarget.rawTargets = this.parseMorphTargets( relationships, DeformerNodes );
					morphTarget.id = nodeID;

					if ( relationships.parents.length > 1 ) console.warn( 'THREE.FBXLoader: morph target attached to more than one geometry is not supported.' );

					morphTargets[ nodeID ] = morphTarget;

				}

			}

		}

		return {

			skeletons: skeletons,
			morphTargets: morphTargets,

		};

	}

	// Parse single nodes in FBXTree.Objects.Deformer
	// The top level skeleton node has type 'Skin' and sub nodes have type 'Cluster'
	// Each skin node represents a skeleton and each cluster node represents a bone
	parseSkeleton( relationships, deformerNodes ) {

		const rawBones = [];

		relationships.children.forEach( function ( child ) {

			const boneNode = deformerNodes[ child.ID ];

			if ( boneNode.attrType !== 'Cluster' ) return;

			const rawBone = {

				ID: child.ID,
				indices: [],
				weights: [],
				transformLink: new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__().fromArray( boneNode.TransformLink.a ),

			};

			if ( 'Indexes' in boneNode ) {

				rawBone.indices = boneNode.Indexes.a;
				rawBone.weights = boneNode.Weights.a;

			}

			rawBones.push( rawBone );

		} );

		return {

			rawBones: rawBones,
			bones: []

		};

	}

	// The top level morph deformer node has type "BlendShape" and sub nodes have type "BlendShapeChannel"
	parseMorphTargets( relationships, deformerNodes ) {

		const rawMorphTargets = [];

		for ( let i = 0; i < relationships.children.length; i ++ ) {

			const child = relationships.children[ i ];

			const morphTargetNode = deformerNodes[ child.ID ];

			const rawMorphTarget = {

				name: morphTargetNode.attrName,
				initialWeight: morphTargetNode.DeformPercent,
				id: morphTargetNode.id,
				fullWeights: morphTargetNode.FullWeights.a

			};

			if ( morphTargetNode.attrType !== 'BlendShapeChannel' ) return;

			rawMorphTarget.geoID = connections.get( parseInt( child.ID ) ).children.filter( function ( child ) {

				return child.relationship === undefined;

			} )[ 0 ].ID;

			rawMorphTargets.push( rawMorphTarget );

		}

		return rawMorphTargets;

	}

	// create the main Group() to be returned by the loader
	parseScene( deformers, geometryMap, materialMap ) {

		sceneGraph = new __WEBPACK_EXTERNAL_MODULE_three_Group__();

		const modelMap = this.parseModels( deformers.skeletons, geometryMap, materialMap );

		const modelNodes = fbxTree.Objects.Model;

		const scope = this;
		modelMap.forEach( function ( model ) {

			const modelNode = modelNodes[ model.ID ];
			scope.setLookAtProperties( model, modelNode );

			const parentConnections = connections.get( model.ID ).parents;

			parentConnections.forEach( function ( connection ) {

				const parent = modelMap.get( connection.ID );
				if ( parent !== undefined ) parent.add( model );

			} );

			if ( model.parent === null ) {

				sceneGraph.add( model );

			}


		} );

		this.addGlobalSceneSettings();

		sceneGraph.traverse( function ( node ) {

			if ( node.userData.transformData ) {

				if ( node.parent ) {

					node.userData.transformData.parentMatrix = node.parent.matrix;
					node.userData.transformData.parentMatrixWorld = node.parent.matrixWorld;

				}

				const transform = generateTransform( node.userData.transformData );

				node.applyMatrix4( transform );
				node.updateWorldMatrix();

			}

		} );

		// Like Blender's FBX importer, use the BindPose section to set the
		// rest pose for bones that are not part of a skin cluster. The BindPose
		// provides a more authoritative rest pose than the Lcl properties which
		// may represent an animation frame rather than the true rest state.
		// Bones WITH clusters will get their bind pose from TransformLink
		// (set via bindSkeleton below), which takes priority.
		const bindPoseMatrices = this.parsePoseNodes();
		const clusterBoneIDs = new Set();

		for ( const ID in deformers.skeletons ) {

			deformers.skeletons[ ID ].rawBones.forEach( function ( _, i ) {

				const bone = deformers.skeletons[ ID ].bones[ i ];
				if ( bone ) clusterBoneIDs.add( bone.ID );

			} );

		}

		const tempMatrix = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

		sceneGraph.traverse( function ( node ) {

			if ( node.isBone && node.ID !== undefined && ! clusterBoneIDs.has( node.ID ) ) {

				const bindPose = bindPoseMatrices[ node.ID ];

				if ( bindPose !== undefined ) {

					if ( node.parent ) {

						tempMatrix.copy( node.parent.matrixWorld ).invert();
						tempMatrix.multiply( bindPose );

					} else {

						tempMatrix.copy( bindPose );

					}

					tempMatrix.decompose( node.position, node.quaternion, node.scale );
					node.updateMatrix();
					node.matrixWorld.copy( bindPose );

				}

			}

		} );

		// Bind skeletons after transforms are applied so that bind matrices
		// are computed from the final scene state. This ensures the rest pose
		// is correct even when the FBX file's Cluster TransformLink matrices
		// differ from the reconstructed bone transforms (common in files
		// without a BindPose section).
		this.bindSkeleton( deformers.skeletons, geometryMap, modelMap );

		const animations = new AnimationParser( this.trimAnimationClips ).parse();

		// if all the models where already combined in a single group, just return that
		if ( sceneGraph.children.length === 1 && sceneGraph.children[ 0 ].isGroup ) {

			sceneGraph.children[ 0 ].animations = animations;
			Object.assign( sceneGraph.children[ 0 ].userData, sceneGraph.userData );
			sceneGraph = sceneGraph.children[ 0 ];

		}

		sceneGraph.animations = animations;

		// Apply coordinate system correction. FBX files can use different
		// up-axis conventions (Y-up or Z-up). Three.js uses Y-up, so rotate
		// the scene when the file uses Z-up (UpAxis === 2).

		if ( 'GlobalSettings' in fbxTree && 'UpAxis' in fbxTree.GlobalSettings ) {

			const upAxis = fbxTree.GlobalSettings.UpAxis.value;

			if ( upAxis === 2 ) {

				console.warn( 'THREE.FBXLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted.' );

				sceneGraph.rotation.set( - Math.PI / 2, 0, 0 );

			}

		}

	}

	// parse nodes in FBXTree.Objects.Model
	parseModels( skeletons, geometryMap, materialMap ) {

		const modelMap = new Map();
		const modelNodes = fbxTree.Objects.Model;

		for ( const nodeID in modelNodes ) {

			const id = parseInt( nodeID );
			const node = modelNodes[ nodeID ];
			const relationships = connections.get( id );

			let model = this.buildSkeleton( relationships, skeletons, id, node.attrName );

			if ( ! model ) {

				switch ( node.attrType ) {

					case 'Camera':
						model = this.createCamera( relationships );
						break;
					case 'Light':
						model = this.createLight( relationships );
						break;
					case 'Mesh':
						model = this.createMesh( relationships, geometryMap, materialMap );
						break;
					case 'NurbsCurve':
						model = this.createCurve( relationships, geometryMap );
						break;
					case 'LimbNode':
					case 'Root':
						model = new __WEBPACK_EXTERNAL_MODULE_three_Bone__();
						break;
					case 'Null':
					default:
						model = new __WEBPACK_EXTERNAL_MODULE_three_Group__();
						break;

				}

				model.name = node.attrName ? __WEBPACK_EXTERNAL_MODULE_three_PropertyBinding__.sanitizeNodeName( node.attrName ) : '';
				model.userData.originalName = node.attrName;

				model.ID = id;

			}

			this.getTransformData( model, node );
			modelMap.set( id, model );

		}

		return modelMap;

	}

	buildSkeleton( relationships, skeletons, id, name ) {

		let bone = null;

		relationships.parents.forEach( function ( parent ) {

			for ( const ID in skeletons ) {

				const skeleton = skeletons[ ID ];

				skeleton.rawBones.forEach( function ( rawBone, i ) {

					if ( rawBone.ID === parent.ID ) {

						const subBone = bone;
						bone = new __WEBPACK_EXTERNAL_MODULE_three_Bone__();

						bone.matrixWorld.copy( rawBone.transformLink );

						// set name and id here - otherwise in cases where "subBone" is created it will not have a name / id

						bone.name = name ? __WEBPACK_EXTERNAL_MODULE_three_PropertyBinding__.sanitizeNodeName( name ) : '';
						bone.userData.originalName = name;
						bone.ID = id;

						skeleton.bones[ i ] = bone;

						// In cases where a bone is shared between multiple meshes
						// duplicate the bone here and add it as a child of the first bone
						if ( subBone !== null ) {

							bone.add( subBone );

						}

					}

				} );

			}

		} );

		return bone;

	}

	// create a PerspectiveCamera or OrthographicCamera
	createCamera( relationships ) {

		let model;
		let cameraAttribute;

		relationships.children.forEach( function ( child ) {

			const attr = fbxTree.Objects.NodeAttribute[ child.ID ];

			if ( attr !== undefined ) {

				cameraAttribute = attr;

			}

		} );

		if ( cameraAttribute === undefined ) {

			model = new __WEBPACK_EXTERNAL_MODULE_three_Object3D__();

		} else {

			let type = 0;
			if ( cameraAttribute.CameraProjectionType !== undefined && cameraAttribute.CameraProjectionType.value === 1 ) {

				type = 1;

			}

			let nearClippingPlane = 1;
			if ( cameraAttribute.NearPlane !== undefined ) {

				nearClippingPlane = cameraAttribute.NearPlane.value / 1000;

			}

			let farClippingPlane = 1000;
			if ( cameraAttribute.FarPlane !== undefined ) {

				farClippingPlane = cameraAttribute.FarPlane.value / 1000;

			}


			let width = window.innerWidth;
			let height = window.innerHeight;

			if ( cameraAttribute.AspectWidth !== undefined && cameraAttribute.AspectHeight !== undefined ) {

				width = cameraAttribute.AspectWidth.value;
				height = cameraAttribute.AspectHeight.value;

			}

			const aspect = width / height;

			let fov = 45;
			if ( cameraAttribute.FieldOfView !== undefined ) {

				fov = cameraAttribute.FieldOfView.value;

			}

			const focalLength = cameraAttribute.FocalLength ? cameraAttribute.FocalLength.value : null;

			switch ( type ) {

				case 0: // Perspective
					model = new __WEBPACK_EXTERNAL_MODULE_three_PerspectiveCamera__( fov, aspect, nearClippingPlane, farClippingPlane );
					if ( focalLength !== null ) model.setFocalLength( focalLength );
					break;

				case 1: // Orthographic
					console.warn( 'THREE.FBXLoader: Orthographic cameras not supported yet.' );
					model = new __WEBPACK_EXTERNAL_MODULE_three_Object3D__();
					break;

				default:
					console.warn( 'THREE.FBXLoader: Unknown camera type ' + type + '.' );
					model = new __WEBPACK_EXTERNAL_MODULE_three_Object3D__();
					break;

			}

		}

		return model;

	}

	// Create a DirectionalLight, PointLight or SpotLight
	createLight( relationships ) {

		let model;
		let lightAttribute;

		relationships.children.forEach( function ( child ) {

			const attr = fbxTree.Objects.NodeAttribute[ child.ID ];

			if ( attr !== undefined ) {

				lightAttribute = attr;

			}

		} );

		if ( lightAttribute === undefined ) {

			model = new __WEBPACK_EXTERNAL_MODULE_three_Object3D__();

		} else {

			let type;

			// LightType can be undefined for Point lights
			if ( lightAttribute.LightType === undefined ) {

				type = 0;

			} else {

				type = lightAttribute.LightType.value;

			}

			let color = 0xffffff;

			if ( lightAttribute.Color !== undefined ) {

				color = __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( new __WEBPACK_EXTERNAL_MODULE_three_Color__().fromArray( lightAttribute.Color.value ), __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );

			}

			let intensity = ( lightAttribute.Intensity === undefined ) ? 1 : lightAttribute.Intensity.value / 100;

			// light disabled
			if ( lightAttribute.CastLightOnObject !== undefined && lightAttribute.CastLightOnObject.value === 0 ) {

				intensity = 0;

			}

			let distance = 0;
			if ( lightAttribute.FarAttenuationEnd !== undefined ) {

				if ( lightAttribute.EnableFarAttenuation !== undefined && lightAttribute.EnableFarAttenuation.value === 0 ) {

					distance = 0;

				} else {

					distance = lightAttribute.FarAttenuationEnd.value;

				}

			}

			// TODO: could this be calculated linearly from FarAttenuationStart to FarAttenuationEnd?
			const decay = 1;

			switch ( type ) {

				case 0: // Point
					model = new __WEBPACK_EXTERNAL_MODULE_three_PointLight__( color, intensity, distance, decay );
					break;

				case 1: // Directional
					model = new __WEBPACK_EXTERNAL_MODULE_three_DirectionalLight__( color, intensity );
					break;

				case 2: // Spot
					let angle = Math.PI / 3;
					let penumbra = 0;

					if ( lightAttribute.OuterAngle !== undefined ) {

						angle = __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( lightAttribute.OuterAngle.value );

						if ( lightAttribute.InnerAngle !== undefined ) {

							penumbra = 1 - ( lightAttribute.InnerAngle.value / lightAttribute.OuterAngle.value );
							penumbra = Math.max( 0, penumbra ); // penumbra must be in the range [0,1]

						}

					} else if ( lightAttribute.InnerAngle !== undefined ) {

						// fallback if only InnerAngle is defined

						angle = __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( lightAttribute.InnerAngle.value );

					}

					model = new __WEBPACK_EXTERNAL_MODULE_three_SpotLight__( color, intensity, distance, angle, penumbra, decay );
					break;

				default:
					console.warn( 'THREE.FBXLoader: Unknown light type ' + lightAttribute.LightType.value + ', defaulting to a PointLight.' );
					model = new __WEBPACK_EXTERNAL_MODULE_three_PointLight__( color, intensity );
					break;

			}

			if ( lightAttribute.CastShadows !== undefined && lightAttribute.CastShadows.value === 1 ) {

				model.castShadow = true;

			}

		}

		return model;

	}

	createMesh( relationships, geometryMap, materialMap ) {

		let model;
		let geometry = null;
		let material = null;
		const materials = [];

		// get geometry and materials(s) from connections
		relationships.children.forEach( function ( child ) {

			if ( geometryMap.has( child.ID ) ) {

				geometry = geometryMap.get( child.ID );

			}

			if ( materialMap.has( child.ID ) ) {

				materials.push( materialMap.get( child.ID ) );

			}

		} );

		if ( materials.length > 1 ) {

			material = materials;

		} else if ( materials.length > 0 ) {

			material = materials[ 0 ];

		} else {

			material = new __WEBPACK_EXTERNAL_MODULE_three_MeshPhongMaterial__( {
				name: __WEBPACK_EXTERNAL_MODULE_three_Loader__.DEFAULT_MATERIAL_NAME,
				color: 0xcccccc
			} );
			materials.push( material );

		}

		if ( 'color' in geometry.attributes ) {

			materials.forEach( function ( material ) {

				material.vertexColors = true;

			} );

		}

		// Sanitization: If geometry has groups, then it must match the provided material array.
		// If not, we need to clean up the `group.materialIndex` properties inside the groups and point at a (new) default material.
		// This isn't well defined; Unity creates default material, while Blender implicitly uses the previous material in the list.
		if ( geometry.groups.length > 0 ) {

			let needsDefaultMaterial = false;

			for ( let i = 0, il = geometry.groups.length; i < il; i ++ ) {

				const group = geometry.groups[ i ];

				if ( group.materialIndex < 0 || group.materialIndex >= materials.length ) {

					group.materialIndex = materials.length;
					needsDefaultMaterial = true;

				}

			}

			if ( needsDefaultMaterial ) {

				const defaultMaterial = new __WEBPACK_EXTERNAL_MODULE_three_MeshPhongMaterial__();
				materials.push( defaultMaterial );

			}

		}

		if ( geometry.FBX_Deformer ) {

			model = new __WEBPACK_EXTERNAL_MODULE_three_SkinnedMesh__( geometry, material );
			model.normalizeSkinWeights();

		} else {

			model = new __WEBPACK_EXTERNAL_MODULE_three_Mesh__( geometry, material );

		}

		return model;

	}

	createCurve( relationships, geometryMap ) {

		const geometry = relationships.children.reduce( function ( geo, child ) {

			if ( geometryMap.has( child.ID ) ) geo = geometryMap.get( child.ID );

			return geo;

		}, null );

		// FBX does not list materials for Nurbs lines, so we'll just put our own in here.
		const material = new __WEBPACK_EXTERNAL_MODULE_three_LineBasicMaterial__( {
			name: __WEBPACK_EXTERNAL_MODULE_three_Loader__.DEFAULT_MATERIAL_NAME,
			color: 0x3300ff,
			linewidth: 1
		} );
		return new __WEBPACK_EXTERNAL_MODULE_three_Line__( geometry, material );

	}

	// parse the model node for transform data
	getTransformData( model, modelNode ) {

		const transformData = {};

		if ( 'InheritType' in modelNode ) transformData.inheritType = parseInt( modelNode.InheritType.value );

		if ( 'RotationOrder' in modelNode ) transformData.eulerOrder = getEulerOrder( modelNode.RotationOrder.value );
		else transformData.eulerOrder = getEulerOrder( 0 );

		if ( 'Lcl_Translation' in modelNode ) transformData.translation = modelNode.Lcl_Translation.value;

		if ( 'PreRotation' in modelNode ) transformData.preRotation = modelNode.PreRotation.value;
		if ( 'Lcl_Rotation' in modelNode ) transformData.rotation = modelNode.Lcl_Rotation.value;
		if ( 'PostRotation' in modelNode ) transformData.postRotation = modelNode.PostRotation.value;

		if ( 'Lcl_Scaling' in modelNode ) transformData.scale = modelNode.Lcl_Scaling.value;

		if ( 'ScalingOffset' in modelNode ) transformData.scalingOffset = modelNode.ScalingOffset.value;
		if ( 'ScalingPivot' in modelNode ) transformData.scalingPivot = modelNode.ScalingPivot.value;

		if ( 'RotationOffset' in modelNode ) transformData.rotationOffset = modelNode.RotationOffset.value;
		if ( 'RotationPivot' in modelNode ) transformData.rotationPivot = modelNode.RotationPivot.value;

		model.userData.transformData = transformData;

	}

	setLookAtProperties( model, modelNode ) {

		if ( 'LookAtProperty' in modelNode ) {

			const children = connections.get( model.ID ).children;

			children.forEach( function ( child ) {

				if ( child.relationship === 'LookAtProperty' ) {

					const lookAtTarget = fbxTree.Objects.Model[ child.ID ];

					if ( 'Lcl_Translation' in lookAtTarget ) {

						const pos = lookAtTarget.Lcl_Translation.value;

						// DirectionalLight, SpotLight
						if ( model.target !== undefined ) {

							model.target.position.fromArray( pos );
							sceneGraph.add( model.target );

						} else { // Cameras and other Object3Ds

							model.lookAt( new __WEBPACK_EXTERNAL_MODULE_three_Vector3__().fromArray( pos ) );

						}

					}

				}

			} );

		}

	}

	bindSkeleton( skeletons, geometryMap, modelMap ) {

		for ( const ID in skeletons ) {

			const skeleton = skeletons[ ID ];

			// Compute bone inverses from TransformLink rather than from the
			// bones' current matrixWorld. The TransformLink matrices represent
			// each bone's global transform at the time the skin weights were
			// painted, which may differ from the scene-reconstructed transforms.
			const boneInverses = [];

			for ( let i = 0, l = skeleton.bones.length; i < l; i ++ ) {

				const inverse = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

				if ( skeleton.bones[ i ] && skeleton.rawBones[ i ] ) {

					inverse.copy( skeleton.rawBones[ i ].transformLink ).invert();

				}

				boneInverses.push( inverse );

			}

			const parents = connections.get( parseInt( skeleton.ID ) ).parents;

			parents.forEach( function ( parent ) {

				if ( geometryMap.has( parent.ID ) ) {

					const geoID = parent.ID;
					const geoRelationships = connections.get( geoID );

					geoRelationships.parents.forEach( function ( geoConnParent ) {

						if ( modelMap.has( geoConnParent.ID ) ) {

							const model = modelMap.get( geoConnParent.ID );

							// Use the mesh's current matrixWorld as bind matrix.
							// The BindPose section is intentionally not used here
							// since it may contain scale/rotation from the model
							// hierarchy that is inconsistent with the TransformLink-
							// based bone inverses. Always provide a bind matrix to
							// prevent bind() from calling calculateInverses() which
							// would overwrite the bone inverses computed above.
							model.updateMatrixWorld( true );

							model.bind( new __WEBPACK_EXTERNAL_MODULE_three_Skeleton__( skeleton.bones, boneInverses ), model.matrixWorld );

						}

					} );

				}

			} );

		}

	}

	// Parse BindPose nodes and return a map of node ID to bind matrix.
	parsePoseNodes() {

		const bindMatrices = {};

		if ( 'Pose' in fbxTree.Objects ) {

			const BindPoseNode = fbxTree.Objects.Pose;

			for ( const nodeID in BindPoseNode ) {

				if ( BindPoseNode[ nodeID ].attrType === 'BindPose' && BindPoseNode[ nodeID ].NbPoseNodes > 0 ) {

					const poseNodes = BindPoseNode[ nodeID ].PoseNode;

					if ( Array.isArray( poseNodes ) ) {

						poseNodes.forEach( function ( poseNode ) {

							bindMatrices[ poseNode.Node ] = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__().fromArray( poseNode.Matrix.a );

						} );

					} else {

						bindMatrices[ poseNodes.Node ] = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__().fromArray( poseNodes.Matrix.a );

					}

				}

			}

		}

		return bindMatrices;

	}

	addGlobalSceneSettings() {

		if ( 'GlobalSettings' in fbxTree ) {

			if ( 'AmbientColor' in fbxTree.GlobalSettings ) {

				// Parse ambient color - if it's not set to black (default), create an ambient light

				const ambientColor = fbxTree.GlobalSettings.AmbientColor.value;
				const r = ambientColor[ 0 ];
				const g = ambientColor[ 1 ];
				const b = ambientColor[ 2 ];

				if ( r !== 0 || g !== 0 || b !== 0 ) {

					const color = new __WEBPACK_EXTERNAL_MODULE_three_Color__().setRGB( r, g, b, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );
					sceneGraph.add( new __WEBPACK_EXTERNAL_MODULE_three_AmbientLight__( color, 1 ) );

				}

			}

			if ( 'UnitScaleFactor' in fbxTree.GlobalSettings ) {

				sceneGraph.userData.unitScaleFactor = fbxTree.GlobalSettings.UnitScaleFactor.value;

			}

		}

	}

}

// parse Geometry data from FBXTree and return map of BufferGeometries
class GeometryParser {

	constructor() {

		this.negativeMaterialIndices = false;

	}

	// Parse nodes in FBXTree.Objects.Geometry
	parse( deformers ) {

		const geometryMap = new Map();

		if ( 'Geometry' in fbxTree.Objects ) {

			const geoNodes = fbxTree.Objects.Geometry;

			for ( const nodeID in geoNodes ) {

				const relationships = connections.get( parseInt( nodeID ) );
				const geo = this.parseGeometry( relationships, geoNodes[ nodeID ], deformers );

				geometryMap.set( parseInt( nodeID ), geo );

			}

		}

		// report warnings

		if ( this.negativeMaterialIndices === true ) {

			console.warn( 'THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected.' );

		}

		return geometryMap;

	}

	// Parse single node in FBXTree.Objects.Geometry
	parseGeometry( relationships, geoNode, deformers ) {

		switch ( geoNode.attrType ) {

			case 'Mesh':
				return this.parseMeshGeometry( relationships, geoNode, deformers );

			case 'NurbsCurve':
				return this.parseNurbsGeometry( geoNode );

		}

	}

	// Parse single node mesh geometry in FBXTree.Objects.Geometry
	parseMeshGeometry( relationships, geoNode, deformers ) {

		const skeletons = deformers.skeletons;
		const morphTargets = [];

		const modelNodes = relationships.parents.map( function ( parent ) {

			return fbxTree.Objects.Model[ parent.ID ];

		} );

		// don't create geometry if it is not associated with any models
		if ( modelNodes.length === 0 ) return;

		const skeleton = relationships.children.reduce( function ( skeleton, child ) {

			if ( skeletons[ child.ID ] !== undefined ) skeleton = skeletons[ child.ID ];

			return skeleton;

		}, null );

		relationships.children.forEach( function ( child ) {

			if ( deformers.morphTargets[ child.ID ] !== undefined ) {

				morphTargets.push( deformers.morphTargets[ child.ID ] );

			}

		} );

		// Assume one model and get the preRotation from that
		// if there is more than one model associated with the geometry this may cause problems
		const modelNode = modelNodes[ 0 ];

		const transformData = {};

		if ( 'RotationOrder' in modelNode ) transformData.eulerOrder = getEulerOrder( modelNode.RotationOrder.value );
		if ( 'InheritType' in modelNode ) transformData.inheritType = parseInt( modelNode.InheritType.value );

		if ( 'GeometricTranslation' in modelNode ) transformData.translation = modelNode.GeometricTranslation.value;
		if ( 'GeometricRotation' in modelNode ) transformData.rotation = modelNode.GeometricRotation.value;
		if ( 'GeometricScaling' in modelNode ) transformData.scale = modelNode.GeometricScaling.value;

		const transform = generateTransform( transformData );

		return this.genGeometry( geoNode, skeleton, morphTargets, transform );

	}

	// Generate a BufferGeometry from a node in FBXTree.Objects.Geometry
	genGeometry( geoNode, skeleton, morphTargets, preTransform ) {

		const geo = new __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__();
		if ( geoNode.attrName ) geo.name = geoNode.attrName;

		const geoInfo = this.parseGeoNode( geoNode, skeleton );
		const buffers = this.genBuffers( geoInfo );

		const positionAttribute = new __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__( buffers.vertex, 3 );

		positionAttribute.applyMatrix4( preTransform );

		geo.setAttribute( 'position', positionAttribute );

		if ( buffers.colors.length > 0 ) {

			geo.setAttribute( 'color', new __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__( buffers.colors, 3 ) );

		}

		if ( skeleton ) {

			geo.setAttribute( 'skinIndex', new __WEBPACK_EXTERNAL_MODULE_three_Uint16BufferAttribute__( buffers.weightsIndices, 4 ) );

			geo.setAttribute( 'skinWeight', new __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__( buffers.vertexWeights, 4 ) );

			// used later to bind the skeleton to the model
			geo.FBX_Deformer = skeleton;

		}

		if ( buffers.normal.length > 0 ) {

			const normalMatrix = new __WEBPACK_EXTERNAL_MODULE_three_Matrix3__().getNormalMatrix( preTransform );

			const normalAttribute = new __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__( buffers.normal, 3 );
			normalAttribute.applyNormalMatrix( normalMatrix );

			geo.setAttribute( 'normal', normalAttribute );

		}

		buffers.uvs.forEach( function ( uvBuffer, i ) {

			const name = i === 0 ? 'uv' : `uv${ i }`;

			geo.setAttribute( name, new __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__( buffers.uvs[ i ], 2 ) );

		} );

		if ( geoInfo.material && geoInfo.material.mappingType !== 'AllSame' ) {

			// Convert the material indices of each vertex into rendering groups on the geometry.
			let prevMaterialIndex = buffers.materialIndex[ 0 ];
			let startIndex = 0;

			buffers.materialIndex.forEach( function ( currentIndex, i ) {

				if ( currentIndex !== prevMaterialIndex ) {

					geo.addGroup( startIndex, i - startIndex, prevMaterialIndex );

					prevMaterialIndex = currentIndex;
					startIndex = i;

				}

			} );

			// the loop above doesn't add the last group, do that here.
			if ( geo.groups.length > 0 ) {

				const lastGroup = geo.groups[ geo.groups.length - 1 ];
				const lastIndex = lastGroup.start + lastGroup.count;

				if ( lastIndex !== buffers.materialIndex.length ) {

					geo.addGroup( lastIndex, buffers.materialIndex.length - lastIndex, prevMaterialIndex );

				}

			}

			// case where there are multiple materials but the whole geometry is only
			// using one of them
			if ( geo.groups.length === 0 ) {

				geo.addGroup( 0, buffers.materialIndex.length, buffers.materialIndex[ 0 ] );

			}

		}

		this.addMorphTargets( geo, geoNode, morphTargets, preTransform );

		return geo;

	}

	parseGeoNode( geoNode, skeleton ) {

		const geoInfo = {};

		geoInfo.vertexPositions = ( geoNode.Vertices !== undefined ) ? geoNode.Vertices.a : [];
		geoInfo.vertexIndices = ( geoNode.PolygonVertexIndex !== undefined ) ? geoNode.PolygonVertexIndex.a : [];

		if ( geoNode.LayerElementColor && geoNode.LayerElementColor[ 0 ].Colors ) {

			geoInfo.color = this.parseVertexColors( geoNode.LayerElementColor[ 0 ] );

		}

		if ( geoNode.LayerElementMaterial ) {

			geoInfo.material = this.parseMaterialIndices( geoNode.LayerElementMaterial[ 0 ] );

		}

		if ( geoNode.LayerElementNormal ) {

			geoInfo.normal = this.parseNormals( geoNode.LayerElementNormal[ 0 ] );

		}

		if ( geoNode.LayerElementUV ) {

			geoInfo.uv = [];

			let i = 0;
			while ( geoNode.LayerElementUV[ i ] ) {

				if ( geoNode.LayerElementUV[ i ].UV ) {

					geoInfo.uv.push( this.parseUVs( geoNode.LayerElementUV[ i ] ) );

				}

				i ++;

			}

		}

		geoInfo.weightTable = {};

		if ( skeleton !== null ) {

			geoInfo.skeleton = skeleton;

			skeleton.rawBones.forEach( function ( rawBone, i ) {

				// loop over the bone's vertex indices and weights
				rawBone.indices.forEach( function ( index, j ) {

					if ( geoInfo.weightTable[ index ] === undefined ) geoInfo.weightTable[ index ] = [];

					geoInfo.weightTable[ index ].push( {

						id: i,
						weight: rawBone.weights[ j ],

					} );

				} );

			} );

		}

		return geoInfo;

	}

	genBuffers( geoInfo ) {

		const buffers = {
			vertex: [],
			normal: [],
			colors: [],
			uvs: [],
			materialIndex: [],
			vertexWeights: [],
			weightsIndices: [],
		};

		let polygonIndex = 0;
		let faceLength = 0;
		let displayedWeightsWarning = false;

		// these will hold data for a single face
		let facePositionIndexes = [];
		let faceNormals = [];
		let faceColors = [];
		let faceUVs = [];
		let faceWeights = [];
		let faceWeightIndices = [];

		const scope = this;
		geoInfo.vertexIndices.forEach( function ( vertexIndex, polygonVertexIndex ) {

			let materialIndex;
			let endOfFace = false;

			// Face index and vertex index arrays are combined in a single array
			// A cube with quad faces looks like this:
			// PolygonVertexIndex: *24 {
			//  a: 0, 1, 3, -3, 2, 3, 5, -5, 4, 5, 7, -7, 6, 7, 1, -1, 1, 7, 5, -4, 6, 0, 2, -5
			//  }
			// Negative numbers mark the end of a face - first face here is 0, 1, 3, -3
			// to find index of last vertex bit shift the index: ^ - 1
			if ( vertexIndex < 0 ) {

				vertexIndex = vertexIndex ^ - 1; // equivalent to ( x * -1 ) - 1
				endOfFace = true;

			}

			let weightIndices = [];
			let weights = [];

			facePositionIndexes.push( vertexIndex * 3, vertexIndex * 3 + 1, vertexIndex * 3 + 2 );

			if ( geoInfo.color ) {

				const data = getData( polygonVertexIndex, polygonIndex, vertexIndex, geoInfo.color );

				faceColors.push( data[ 0 ], data[ 1 ], data[ 2 ] );

			}

			if ( geoInfo.skeleton ) {

				if ( geoInfo.weightTable[ vertexIndex ] !== undefined ) {

					geoInfo.weightTable[ vertexIndex ].forEach( function ( wt ) {

						weights.push( wt.weight );
						weightIndices.push( wt.id );

					} );


				}

				if ( weights.length > 4 ) {

					if ( ! displayedWeightsWarning ) {

						console.warn( 'THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights.' );
						displayedWeightsWarning = true;

					}

					const wIndex = [ 0, 0, 0, 0 ];
					const Weight = [ 0, 0, 0, 0 ];

					weights.forEach( function ( weight, weightIndex ) {

						let currentWeight = weight;
						let currentIndex = weightIndices[ weightIndex ];

						Weight.forEach( function ( comparedWeight, comparedWeightIndex, comparedWeightArray ) {

							if ( currentWeight > comparedWeight ) {

								comparedWeightArray[ comparedWeightIndex ] = currentWeight;
								currentWeight = comparedWeight;

								const tmp = wIndex[ comparedWeightIndex ];
								wIndex[ comparedWeightIndex ] = currentIndex;
								currentIndex = tmp;

							}

						} );

					} );

					weightIndices = wIndex;
					weights = Weight;

				}

				// if the weight array is shorter than 4 pad with 0s
				while ( weights.length < 4 ) {

					weights.push( 0 );
					weightIndices.push( 0 );

				}

				for ( let i = 0; i < 4; ++ i ) {

					faceWeights.push( weights[ i ] );
					faceWeightIndices.push( weightIndices[ i ] );

				}

			}

			if ( geoInfo.normal ) {

				const data = getData( polygonVertexIndex, polygonIndex, vertexIndex, geoInfo.normal );

				faceNormals.push( data[ 0 ], data[ 1 ], data[ 2 ] );

			}

			if ( geoInfo.material && geoInfo.material.mappingType !== 'AllSame' ) {

				materialIndex = getData( polygonVertexIndex, polygonIndex, vertexIndex, geoInfo.material )[ 0 ];

				if ( materialIndex < 0 ) {

					scope.negativeMaterialIndices = true;
					materialIndex = 0; // fallback

				}

			}

			if ( geoInfo.uv ) {

				geoInfo.uv.forEach( function ( uv, i ) {

					const data = getData( polygonVertexIndex, polygonIndex, vertexIndex, uv );

					if ( faceUVs[ i ] === undefined ) {

						faceUVs[ i ] = [];

					}

					faceUVs[ i ].push( data[ 0 ] );
					faceUVs[ i ].push( data[ 1 ] );

				} );

			}

			faceLength ++;

			if ( endOfFace ) {

				scope.genFace( buffers, geoInfo, facePositionIndexes, materialIndex, faceNormals, faceColors, faceUVs, faceWeights, faceWeightIndices, faceLength );

				polygonIndex ++;
				faceLength = 0;

				// reset arrays for the next face
				facePositionIndexes = [];
				faceNormals = [];
				faceColors = [];
				faceUVs = [];
				faceWeights = [];
				faceWeightIndices = [];

			}

		} );

		return buffers;

	}

	// See https://www.khronos.org/opengl/wiki/Calculating_a_Surface_Normal
	getNormalNewell( vertices ) {

		const normal = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( 0.0, 0.0, 0.0 );

		for ( let i = 0; i < vertices.length; i ++ ) {

			const current = vertices[ i ];
			const next = vertices[ ( i + 1 ) % vertices.length ];

			normal.x += ( current.y - next.y ) * ( current.z + next.z );
			normal.y += ( current.z - next.z ) * ( current.x + next.x );
			normal.z += ( current.x - next.x ) * ( current.y + next.y );

		}

		normal.normalize();

		return normal;

	}

	getNormalTangentAndBitangent( vertices ) {

		const normalVector = this.getNormalNewell( vertices );
		// Avoid up being equal or almost equal to normalVector
		const up = Math.abs( normalVector.z ) > 0.5 ? new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( 0.0, 1.0, 0.0 ) : new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( 0.0, 0.0, 1.0 );
		const tangent = up.cross( normalVector ).normalize();
		const bitangent = normalVector.clone().cross( tangent ).normalize();

		return {
			normal: normalVector,
			tangent: tangent,
			bitangent: bitangent
		};

	}

	flattenVertex( vertex, normalTangent, normalBitangent ) {

		return new __WEBPACK_EXTERNAL_MODULE_three_Vector2__(
			vertex.dot( normalTangent ),
			vertex.dot( normalBitangent )
		);

	}

	// Generate data for a single face in a geometry. If the face is a quad then split it into 2 tris
	genFace( buffers, geoInfo, facePositionIndexes, materialIndex, faceNormals, faceColors, faceUVs, faceWeights, faceWeightIndices, faceLength ) {

		let triangles;

		if ( faceLength > 3 ) {

			// Triangulate n-gon using earcut

			const vertices = [];
			// in morphing scenario vertexPositions represent morphPositions
			// while baseVertexPositions represent the original geometry's positions
			const positions = geoInfo.baseVertexPositions || geoInfo.vertexPositions;
			for ( let i = 0; i < facePositionIndexes.length; i += 3 ) {

				vertices.push(
					new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(
						positions[ facePositionIndexes[ i ] ],
						positions[ facePositionIndexes[ i + 1 ] ],
						positions[ facePositionIndexes[ i + 2 ] ]
					)
				);

			}

			const { tangent, bitangent } = this.getNormalTangentAndBitangent( vertices );
			const triangulationInput = [];

			for ( const vertex of vertices ) {

				triangulationInput.push( this.flattenVertex( vertex, tangent, bitangent ) );

			}

			// When vertices is an array of [0,0,0] elements (which is the case for vertices not participating in morph)
			// the triangulationInput will be an array of [0,0] elements
			// resulting in an array of 0 triangles being returned from ShapeUtils.triangulateShape
			// leading to not pushing into buffers.vertex the redundant vertices (the vertices that are not morphed).
			// That's why, in order to support morphing scenario, "positions" is looking first for baseVertexPositions,
			// so that we don't end up with an array of 0 triangles for the faces not participating in morph.
			triangles = __WEBPACK_EXTERNAL_MODULE_three_ShapeUtils__.triangulateShape( triangulationInput, [] );

		} else {

			// Regular triangle, skip earcut triangulation step
			triangles = [[ 0, 1, 2 ]];

		}

		for ( const [ i0, i1, i2 ] of triangles ) {

			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i0 * 3 ] ] );
			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i0 * 3 + 1 ] ] );
			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i0 * 3 + 2 ] ] );

			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i1 * 3 ] ] );
			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i1 * 3 + 1 ] ] );
			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i1 * 3 + 2 ] ] );

			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i2 * 3 ] ] );
			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i2 * 3 + 1 ] ] );
			buffers.vertex.push( geoInfo.vertexPositions[ facePositionIndexes[ i2 * 3 + 2 ] ] );

			if ( geoInfo.skeleton ) {

				buffers.vertexWeights.push( faceWeights[ i0 * 4 ] );
				buffers.vertexWeights.push( faceWeights[ i0 * 4 + 1 ] );
				buffers.vertexWeights.push( faceWeights[ i0 * 4 + 2 ] );
				buffers.vertexWeights.push( faceWeights[ i0 * 4 + 3 ] );

				buffers.vertexWeights.push( faceWeights[ i1 * 4 ] );
				buffers.vertexWeights.push( faceWeights[ i1 * 4 + 1 ] );
				buffers.vertexWeights.push( faceWeights[ i1 * 4 + 2 ] );
				buffers.vertexWeights.push( faceWeights[ i1 * 4 + 3 ] );

				buffers.vertexWeights.push( faceWeights[ i2 * 4 ] );
				buffers.vertexWeights.push( faceWeights[ i2 * 4 + 1 ] );
				buffers.vertexWeights.push( faceWeights[ i2 * 4 + 2 ] );
				buffers.vertexWeights.push( faceWeights[ i2 * 4 + 3 ] );

				buffers.weightsIndices.push( faceWeightIndices[ i0 * 4 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i0 * 4 + 1 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i0 * 4 + 2 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i0 * 4 + 3 ] );

				buffers.weightsIndices.push( faceWeightIndices[ i1 * 4 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i1 * 4 + 1 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i1 * 4 + 2 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i1 * 4 + 3 ] );

				buffers.weightsIndices.push( faceWeightIndices[ i2 * 4 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i2 * 4 + 1 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i2 * 4 + 2 ] );
				buffers.weightsIndices.push( faceWeightIndices[ i2 * 4 + 3 ] );

			}

			if ( geoInfo.color ) {

				buffers.colors.push( faceColors[ i0 * 3 ] );
				buffers.colors.push( faceColors[ i0 * 3 + 1 ] );
				buffers.colors.push( faceColors[ i0 * 3 + 2 ] );

				buffers.colors.push( faceColors[ i1 * 3 ] );
				buffers.colors.push( faceColors[ i1 * 3 + 1 ] );
				buffers.colors.push( faceColors[ i1 * 3 + 2 ] );

				buffers.colors.push( faceColors[ i2 * 3 ] );
				buffers.colors.push( faceColors[ i2 * 3 + 1 ] );
				buffers.colors.push( faceColors[ i2 * 3 + 2 ] );

			}

			if ( geoInfo.material && geoInfo.material.mappingType !== 'AllSame' ) {

				buffers.materialIndex.push( materialIndex );
				buffers.materialIndex.push( materialIndex );
				buffers.materialIndex.push( materialIndex );

			}

			if ( geoInfo.normal ) {

				buffers.normal.push( faceNormals[ i0 * 3 ] );
				buffers.normal.push( faceNormals[ i0 * 3 + 1 ] );
				buffers.normal.push( faceNormals[ i0 * 3 + 2 ] );

				buffers.normal.push( faceNormals[ i1 * 3 ] );
				buffers.normal.push( faceNormals[ i1 * 3 + 1 ] );
				buffers.normal.push( faceNormals[ i1 * 3 + 2 ] );

				buffers.normal.push( faceNormals[ i2 * 3 ] );
				buffers.normal.push( faceNormals[ i2 * 3 + 1 ] );
				buffers.normal.push( faceNormals[ i2 * 3 + 2 ] );

			}

			if ( geoInfo.uv ) {

				geoInfo.uv.forEach( function ( uv, j ) {

					if ( buffers.uvs[ j ] === undefined ) buffers.uvs[ j ] = [];

					buffers.uvs[ j ].push( faceUVs[ j ][ i0 * 2 ] );
					buffers.uvs[ j ].push( faceUVs[ j ][ i0 * 2 + 1 ] );

					buffers.uvs[ j ].push( faceUVs[ j ][ i1 * 2 ] );
					buffers.uvs[ j ].push( faceUVs[ j ][ i1 * 2 + 1 ] );

					buffers.uvs[ j ].push( faceUVs[ j ][ i2 * 2 ] );
					buffers.uvs[ j ].push( faceUVs[ j ][ i2 * 2 + 1 ] );

				} );

			}

		}

	}

	addMorphTargets( parentGeo, parentGeoNode, morphTargets, preTransform ) {

		if ( morphTargets.length === 0 ) return;

		parentGeo.morphTargetsRelative = true;

		parentGeo.morphAttributes.position = [];
		// parentGeo.morphAttributes.normal = []; // not implemented

		// Morph attribute positions are stored as deltas (morphTargetsRelative = true), so the
		// translation component of the geometric transform must not be applied to them — only the
		// rotation/scale part. Otherwise every delta gets the geometric translation added, which
		// shifts morphed vertices away from their intended position by `weight * translation` as
		// the influence increases.
		const morphPreTransform = preTransform.clone().setPosition( 0, 0, 0 );

		const scope = this;
		morphTargets.forEach( function ( morphTarget ) {

			morphTarget.rawTargets.forEach( function ( rawTarget ) {

				const morphGeoNode = fbxTree.Objects.Geometry[ rawTarget.geoID ];

				if ( morphGeoNode !== undefined ) {

					scope.genMorphGeometry( parentGeo, parentGeoNode, morphGeoNode, morphPreTransform, rawTarget.name );

				}

			} );

		} );

	}

	// a morph geometry node is similar to a standard  node, and the node is also contained
	// in FBXTree.Objects.Geometry, however it can only have attributes for position, normal
	// and a special attribute Index defining which vertices of the original geometry are affected
	// Normal and position attributes only have data for the vertices that are affected by the morph
	genMorphGeometry( parentGeo, parentGeoNode, morphGeoNode, preTransform, name ) {

		const basePositions = parentGeoNode.Vertices !== undefined ? parentGeoNode.Vertices.a : [];
		const baseIndices = parentGeoNode.PolygonVertexIndex !== undefined ? parentGeoNode.PolygonVertexIndex.a : [];

		const morphPositionsSparse = morphGeoNode.Vertices !== undefined ? morphGeoNode.Vertices.a : [];
		const morphIndices = morphGeoNode.Indexes !== undefined ? morphGeoNode.Indexes.a : [];

		const length = parentGeo.attributes.position.count * 3;
		const morphPositions = new Float32Array( length );

		for ( let i = 0; i < morphIndices.length; i ++ ) {

			const morphIndex = morphIndices[ i ] * 3;

			morphPositions[ morphIndex ] = morphPositionsSparse[ i * 3 ];
			morphPositions[ morphIndex + 1 ] = morphPositionsSparse[ i * 3 + 1 ];
			morphPositions[ morphIndex + 2 ] = morphPositionsSparse[ i * 3 + 2 ];

		}

		// TODO: add morph normal support
		const morphGeoInfo = {
			vertexIndices: baseIndices,
			vertexPositions: morphPositions,
			baseVertexPositions: basePositions
		};

		const morphBuffers = this.genBuffers( morphGeoInfo );

		const positionAttribute = new __WEBPACK_EXTERNAL_MODULE_three_Float32BufferAttribute__( morphBuffers.vertex, 3 );
		positionAttribute.name = name || morphGeoNode.attrName;

		positionAttribute.applyMatrix4( preTransform );

		parentGeo.morphAttributes.position.push( positionAttribute );

	}

	// Parse normal from FBXTree.Objects.Geometry.LayerElementNormal if it exists
	parseNormals( NormalNode ) {

		const mappingType = NormalNode.MappingInformationType;
		const referenceType = NormalNode.ReferenceInformationType;
		const buffer = NormalNode.Normals.a;
		let indexBuffer = [];
		if ( referenceType === 'IndexToDirect' ) {

			if ( 'NormalIndex' in NormalNode ) {

				indexBuffer = NormalNode.NormalIndex.a;

			} else if ( 'NormalsIndex' in NormalNode ) {

				indexBuffer = NormalNode.NormalsIndex.a;

			}

		}

		return {
			dataSize: 3,
			buffer: buffer,
			indices: indexBuffer,
			mappingType: mappingType,
			referenceType: referenceType
		};

	}

	// Parse UVs from FBXTree.Objects.Geometry.LayerElementUV if it exists
	parseUVs( UVNode ) {

		const mappingType = UVNode.MappingInformationType;
		const referenceType = UVNode.ReferenceInformationType;
		const buffer = UVNode.UV.a;
		let indexBuffer = [];
		if ( referenceType === 'IndexToDirect' ) {

			indexBuffer = UVNode.UVIndex.a;

		}

		return {
			dataSize: 2,
			buffer: buffer,
			indices: indexBuffer,
			mappingType: mappingType,
			referenceType: referenceType
		};

	}

	// Parse Vertex Colors from FBXTree.Objects.Geometry.LayerElementColor if it exists
	parseVertexColors( ColorNode ) {

		const mappingType = ColorNode.MappingInformationType;
		const referenceType = ColorNode.ReferenceInformationType;
		const buffer = ColorNode.Colors.a;
		let indexBuffer = [];
		if ( referenceType === 'IndexToDirect' ) {

			indexBuffer = ColorNode.ColorIndex.a;

		}

		for ( let i = 0, c = new __WEBPACK_EXTERNAL_MODULE_three_Color__(); i < buffer.length; i += 4 ) {

			c.fromArray( buffer, i );
			__WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.colorSpaceToWorking( c, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ );
			c.toArray( buffer, i );

		}

		return {
			dataSize: 4,
			buffer: buffer,
			indices: indexBuffer,
			mappingType: mappingType,
			referenceType: referenceType
		};

	}

	// Parse mapping and material data in FBXTree.Objects.Geometry.LayerElementMaterial if it exists
	parseMaterialIndices( MaterialNode ) {

		const mappingType = MaterialNode.MappingInformationType;
		const referenceType = MaterialNode.ReferenceInformationType;

		if ( mappingType === 'NoMappingInformation' ) {

			return {
				dataSize: 1,
				buffer: [ 0 ],
				indices: [ 0 ],
				mappingType: 'AllSame',
				referenceType: referenceType
			};

		}

		const materialIndexBuffer = MaterialNode.Materials.a;

		// Since materials are stored as indices, there's a bit of a mismatch between FBX and what
		// we expect.So we create an intermediate buffer that points to the index in the buffer,
		// for conforming with the other functions we've written for other data.
		const materialIndices = [];

		for ( let i = 0; i < materialIndexBuffer.length; ++ i ) {

			materialIndices.push( i );

		}

		return {
			dataSize: 1,
			buffer: materialIndexBuffer,
			indices: materialIndices,
			mappingType: mappingType,
			referenceType: referenceType
		};

	}

	// Generate a NurbGeometry from a node in FBXTree.Objects.Geometry
	parseNurbsGeometry( geoNode ) {

		const order = parseInt( geoNode.Order );

		if ( isNaN( order ) ) {

			console.error( 'THREE.FBXLoader: Invalid Order %s given for geometry ID: %s', geoNode.Order, geoNode.id );
			return new __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__();

		}

		const degree = order - 1;

		const knots = geoNode.KnotVector.a;
		const controlPoints = [];
		const pointsValues = geoNode.Points.a;

		for ( let i = 0, l = pointsValues.length; i < l; i += 4 ) {

			controlPoints.push( new __WEBPACK_EXTERNAL_MODULE_three_Vector4__().fromArray( pointsValues, i ) );

		}

		let startKnot, endKnot;

		if ( geoNode.Form === 'Closed' ) {

			controlPoints.push( controlPoints[ 0 ] );

		} else if ( geoNode.Form === 'Periodic' ) {

			startKnot = degree;
			endKnot = knots.length - 1 - startKnot;

			for ( let i = 0; i < degree; ++ i ) {

				controlPoints.push( controlPoints[ i ] );

			}

		}

		const curve = new NURBSCurve( degree, knots, controlPoints, startKnot, endKnot );
		const points = curve.getPoints( controlPoints.length * 12 );

		return new __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__().setFromPoints( points );

	}

}

// parse animation data from FBXTree
class AnimationParser {

	constructor( trimAnimationClips ) {

		this.trimAnimationClips = trimAnimationClips;

	}

	// take raw animation clips and turn them into three.js animation clips
	parse() {

		const animationClips = [];

		const rawClips = this.parseClips();

		if ( rawClips !== undefined ) {

			for ( const key in rawClips ) {

				const rawClip = rawClips[ key ];

				const clip = this.addClip( rawClip );

				animationClips.push( clip );

			}

		}

		return animationClips;

	}

	parseClips() {

		// since the actual transformation data is stored in FBXTree.Objects.AnimationCurve,
		// if this is undefined we can safely assume there are no animations
		if ( fbxTree.Objects.AnimationCurve === undefined ) return undefined;

		const curveNodesMap = this.parseAnimationCurveNodes();

		this.parseAnimationCurves( curveNodesMap );

		const layersMap = this.parseAnimationLayers( curveNodesMap );
		const rawClips = this.parseAnimStacks( layersMap );

		return rawClips;

	}

	// parse nodes in FBXTree.Objects.AnimationCurveNode
	// each AnimationCurveNode holds data for an animation transform for a model (e.g. left arm rotation )
	// and is referenced by an AnimationLayer
	parseAnimationCurveNodes() {

		const rawCurveNodes = fbxTree.Objects.AnimationCurveNode;

		const curveNodesMap = new Map();

		for ( const nodeID in rawCurveNodes ) {

			const rawCurveNode = rawCurveNodes[ nodeID ];

			if ( rawCurveNode.attrName.match( /S|R|T|DeformPercent/ ) !== null ) {

				const curveNode = {

					id: rawCurveNode.id,
					attr: rawCurveNode.attrName,
					curves: {},

				};

				curveNodesMap.set( curveNode.id, curveNode );

			}

		}

		return curveNodesMap;

	}

	// parse nodes in FBXTree.Objects.AnimationCurve and connect them up to
	// previously parsed AnimationCurveNodes. Each AnimationCurve holds data for a single animated
	// axis ( e.g. times and values of x rotation)
	parseAnimationCurves( curveNodesMap ) {

		const rawCurves = fbxTree.Objects.AnimationCurve;

		// TODO: Many values are identical up to roundoff error, but won't be optimised
		// e.g. position times: [0, 0.4, 0. 8]
		// position values: [7.23538335023477e-7, 93.67518615722656, -0.9982695579528809, 7.23538335023477e-7, 93.67518615722656, -0.9982695579528809, 7.235384487103147e-7, 93.67520904541016, -0.9982695579528809]
		// clearly, this should be optimised to
		// times: [0], positions [7.23538335023477e-7, 93.67518615722656, -0.9982695579528809]
		// this shows up in nearly every FBX file, and generally time array is length > 100

		for ( const nodeID in rawCurves ) {

			const animationCurve = {

				id: rawCurves[ nodeID ].id,
				times: rawCurves[ nodeID ].KeyTime.a.map( convertFBXTimeToSeconds ),
				values: rawCurves[ nodeID ].KeyValueFloat.a,

			};

			const relationships = connections.get( animationCurve.id );

			if ( relationships !== undefined ) {

				const animationCurveID = relationships.parents[ 0 ].ID;
				const animationCurveRelationship = relationships.parents[ 0 ].relationship;

				if ( animationCurveRelationship.match( /X/ ) ) {

					curveNodesMap.get( animationCurveID ).curves[ 'x' ] = animationCurve;

				} else if ( animationCurveRelationship.match( /Y/ ) ) {

					curveNodesMap.get( animationCurveID ).curves[ 'y' ] = animationCurve;

				} else if ( animationCurveRelationship.match( /Z/ ) ) {

					curveNodesMap.get( animationCurveID ).curves[ 'z' ] = animationCurve;

				} else if ( animationCurveRelationship.match( /DeformPercent/ ) && curveNodesMap.has( animationCurveID ) ) {

					curveNodesMap.get( animationCurveID ).curves[ 'morph' ] = animationCurve;

				}

			}

		}

	}

	// parse nodes in FBXTree.Objects.AnimationLayer. Each layers holds references
	// to various AnimationCurveNodes and is referenced by an AnimationStack node
	// note: theoretically a stack can have multiple layers, however in practice there always seems to be one per stack
	parseAnimationLayers( curveNodesMap ) {

		const rawLayers = fbxTree.Objects.AnimationLayer;

		const layersMap = new Map();

		for ( const nodeID in rawLayers ) {

			const layerCurveNodes = [];

			const connection = connections.get( parseInt( nodeID ) );

			if ( connection !== undefined ) {

				// all the animationCurveNodes used in the layer
				const children = connection.children;

				children.forEach( function ( child, i ) {

					if ( curveNodesMap.has( child.ID ) ) {

						const curveNode = curveNodesMap.get( child.ID );

						// check that the curves are defined for at least one axis, otherwise ignore the curveNode
						if ( curveNode.curves.x !== undefined || curveNode.curves.y !== undefined || curveNode.curves.z !== undefined ) {

							if ( layerCurveNodes[ i ] === undefined ) {

								const filteredParents = connections.get( child.ID ).parents.filter( function ( parent ) {

									return parent.relationship !== undefined;

								} );

								if ( filteredParents.length === 0 ) return;

								const modelID = filteredParents[ 0 ].ID;

								if ( modelID !== undefined ) {

									const rawModel = fbxTree.Objects.Model[ modelID.toString() ];

									if ( rawModel === undefined ) {

										console.warn( 'THREE.FBXLoader: Encountered a unused curve.', child );
										return;

									}

									const node = {

										modelName: rawModel.attrName ? __WEBPACK_EXTERNAL_MODULE_three_PropertyBinding__.sanitizeNodeName( rawModel.attrName ) : '',
										ID: rawModel.id,
										initialPosition: [ 0, 0, 0 ],
										initialRotation: [ 0, 0, 0 ],
										initialScale: [ 1, 1, 1 ],

									};

									sceneGraph.traverse( function ( child ) {

										if ( child.ID === rawModel.id ) {

											node.transform = child.matrix;

											if ( child.userData.transformData ) {

												node.eulerOrder = child.userData.transformData.eulerOrder;

												if ( child.userData.transformData.rotation ) node.initialRotation = child.userData.transformData.rotation;

											}

										}

									} );

									if ( ! node.transform ) node.transform = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

									// if the animated model is pre rotated, we'll have to apply the pre rotations to every
									// animation value as well
									if ( 'PreRotation' in rawModel ) node.preRotation = rawModel.PreRotation.value;
									if ( 'PostRotation' in rawModel ) node.postRotation = rawModel.PostRotation.value;

									layerCurveNodes[ i ] = node;

								}

							}

							if ( layerCurveNodes[ i ] ) layerCurveNodes[ i ][ curveNode.attr ] = curveNode;

						} else if ( curveNode.curves.morph !== undefined ) {

							if ( layerCurveNodes[ i ] === undefined ) {

								const filteredParents = connections.get( child.ID ).parents.filter( function ( parent ) {

									return parent.relationship !== undefined;

								} );

								if ( filteredParents.length === 0 ) return;

								const deformerID = filteredParents[ 0 ].ID;

								const morpherID = connections.get( deformerID ).parents[ 0 ].ID;
								const geoID = connections.get( morpherID ).parents[ 0 ].ID;

								// assuming geometry is not used in more than one model
								const modelID = connections.get( geoID ).parents[ 0 ].ID;

								const rawModel = fbxTree.Objects.Model[ modelID ];

								const node = {

									modelName: rawModel.attrName ? __WEBPACK_EXTERNAL_MODULE_three_PropertyBinding__.sanitizeNodeName( rawModel.attrName ) : '',
									morphName: fbxTree.Objects.Deformer[ deformerID ].attrName,

								};

								layerCurveNodes[ i ] = node;

							}

							layerCurveNodes[ i ][ curveNode.attr ] = curveNode;

						}

					}

				} );

				layersMap.set( parseInt( nodeID ), layerCurveNodes );

			}

		}

		return layersMap;

	}

	// parse nodes in FBXTree.Objects.AnimationStack. These are the top level node in the animation
	// hierarchy. Each Stack node will be used to create an AnimationClip
	parseAnimStacks( layersMap ) {

		const rawStacks = fbxTree.Objects.AnimationStack;

		// connect the stacks (clips) up to the layers
		const rawClips = {};

		for ( const nodeID in rawStacks ) {

			const children = connections.get( parseInt( nodeID ) ).children;

			if ( children.length > 1 ) {

				// it seems like stacks will always be associated with a single layer. But just in case there are files
				// where there are multiple layers per stack, we'll display a warning
				console.warn( 'THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.' );

			}

			const layer = layersMap.get( children[ 0 ].ID );
			const rawStack = rawStacks[ nodeID ];

			rawClips[ nodeID ] = {

				name: rawStack.attrName,
				layer: layer,
				localStart: rawStack.LocalStart !== undefined ? convertFBXTimeToSeconds( Number( rawStack.LocalStart.value ) ) : 0,
				localStop: rawStack.LocalStop !== undefined ? convertFBXTimeToSeconds( Number( rawStack.LocalStop.value ) ) : 0,

			};

		}

		return rawClips;

	}

	addClip( rawClip ) {

		let tracks = [];

		const scope = this;
		rawClip.layer.forEach( function ( rawTracks ) {

			tracks = tracks.concat( scope.generateTracks( rawTracks ) );

		} );

		if ( this.trimAnimationClips === true && rawClip.localStop > rawClip.localStart ) {

			tracks = this.trimTracks( tracks, rawClip.localStart, rawClip.localStop );

		}

		return new __WEBPACK_EXTERNAL_MODULE_three_AnimationClip__( rawClip.name, - 1, tracks );

	}

	// trims the given tracks to the time range [ startTime, endTime ] and shifts
	// them so they start at time zero. tracks without keyframes in the range are discarded
	trimTracks( tracks, startTime, endTime ) {

		// track times are stored as float32 so compare against float32 boundaries
		// to keep keyframes lying exactly on the range limits

		const start = Math.fround( startTime );
		const end = Math.fround( endTime );

		const trimmedTracks = [];

		for ( let i = 0; i < tracks.length; i ++ ) {

			const track = tracks[ i ];
			const stride = track.getValueSize();

			const times = [];
			const values = [];

			for ( let j = 0; j < track.times.length; j ++ ) {

				const time = track.times[ j ];

				if ( time < start || time > end ) continue;

				times.push( time - start );

				for ( let k = 0; k < stride; k ++ ) {

					values.push( track.values[ j * stride + k ] );

				}

			}

			if ( times.length === 0 ) continue;

			track.times = new Float32Array( times );
			track.values = new Float32Array( values );

			trimmedTracks.push( track );

		}

		return trimmedTracks;

	}

	generateTracks( rawTracks ) {

		const tracks = [];

		let initialPosition = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
		let initialScale = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();

		if ( rawTracks.transform ) rawTracks.transform.decompose( initialPosition, new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__(), initialScale );

		initialPosition = initialPosition.toArray();
		initialScale = initialScale.toArray();

		if ( rawTracks.T !== undefined && Object.keys( rawTracks.T.curves ).length > 0 ) {

			const positionTrack = this.generateVectorTrack( rawTracks.modelName, rawTracks.T.curves, initialPosition, 'position' );
			if ( positionTrack !== undefined ) tracks.push( positionTrack );

		}

		if ( rawTracks.R !== undefined && Object.keys( rawTracks.R.curves ).length > 0 ) {

			const rotationTrack = this.generateRotationTrack( rawTracks.modelName, rawTracks.R.curves, rawTracks.preRotation, rawTracks.postRotation, rawTracks.eulerOrder, rawTracks.initialRotation );
			if ( rotationTrack !== undefined ) tracks.push( rotationTrack );

		}

		if ( rawTracks.S !== undefined && Object.keys( rawTracks.S.curves ).length > 0 ) {

			const scaleTrack = this.generateVectorTrack( rawTracks.modelName, rawTracks.S.curves, initialScale, 'scale' );
			if ( scaleTrack !== undefined ) tracks.push( scaleTrack );

		}

		if ( rawTracks.DeformPercent !== undefined ) {

			const morphTrack = this.generateMorphTrack( rawTracks );
			if ( morphTrack !== undefined ) tracks.push( morphTrack );

		}

		return tracks;

	}

	generateVectorTrack( modelName, curves, initialValue, type ) {

		const times = this.getTimesForAllAxes( curves );
		const values = this.getKeyframeTrackValues( times, curves, initialValue );

		return new __WEBPACK_EXTERNAL_MODULE_three_VectorKeyframeTrack__( modelName + '.' + type, times, values );

	}

	generateRotationTrack( modelName, curves, preRotation, postRotation, eulerOrder, initialRotation ) {

		let times;
		let values;

		if ( curves.x !== undefined || curves.y !== undefined || curves.z !== undefined ) {

			// Get merged, sorted, unique times from all available curves
			const mergedTimes = this.getTimesForAllAxes( curves );

			if ( mergedTimes.length > 0 ) {

				const initialRot = initialRotation || [ 0, 0, 0 ];

				// Synchronize all curves to the merged time array.
				// Missing axes are filled with constant values from the initial rotation (Lcl Rotation).
				// Existing curves at different times are linearly interpolated.
				const syncX = this.synchronizeCurve( curves.x, mergedTimes, initialRot[ 0 ] );
				const syncY = this.synchronizeCurve( curves.y, mergedTimes, initialRot[ 1 ] );
				const syncZ = this.synchronizeCurve( curves.z, mergedTimes, initialRot[ 2 ] );

				const result = this.interpolateRotations( syncX, syncY, syncZ, eulerOrder );

				times = result[ 0 ];
				values = result[ 1 ];

			}

		}

		// For Maya models using "Joint Orient", Euler order only applies to rotation, not pre/post-rotations
		const defaultEulerOrder = getEulerOrder( 0 );

		if ( preRotation !== undefined ) {

			preRotation = preRotation.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );
			preRotation.push( defaultEulerOrder );

			preRotation = new __WEBPACK_EXTERNAL_MODULE_three_Euler__().fromArray( preRotation );
			preRotation = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__().setFromEuler( preRotation );

		}

		if ( postRotation !== undefined ) {

			postRotation = postRotation.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );
			postRotation.push( defaultEulerOrder );

			postRotation = new __WEBPACK_EXTERNAL_MODULE_three_Euler__().fromArray( postRotation );
			postRotation = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__().setFromEuler( postRotation ).invert();

		}

		const quaternion = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__();
		const euler = new __WEBPACK_EXTERNAL_MODULE_three_Euler__();

		const quaternionValues = [];

		if ( ! values || ! times ) return undefined;

		for ( let i = 0; i < values.length; i += 3 ) {

			euler.set( values[ i ], values[ i + 1 ], values[ i + 2 ], eulerOrder );
			quaternion.setFromEuler( euler );

			if ( preRotation !== undefined ) quaternion.premultiply( preRotation );
			if ( postRotation !== undefined ) quaternion.multiply( postRotation );

			// Check unroll
			if ( i > 2 ) {

				const prevQuat = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__().fromArray(
					quaternionValues,
					( ( i - 3 ) / 3 ) * 4
				);

				if ( prevQuat.dot( quaternion ) < 0 ) {

					quaternion.set( - quaternion.x, - quaternion.y, - quaternion.z, - quaternion.w );

				}

			}

			quaternion.toArray( quaternionValues, ( i / 3 ) * 4 );

		}

		return new __WEBPACK_EXTERNAL_MODULE_three_QuaternionKeyframeTrack__( modelName + '.quaternion', times, quaternionValues );

	}

	generateMorphTrack( rawTracks ) {

		const curves = rawTracks.DeformPercent.curves.morph;
		const values = curves.values.map( function ( val ) {

			return val / 100;

		} );

		const morphNum = sceneGraph.getObjectByName( rawTracks.modelName ).morphTargetDictionary[ rawTracks.morphName ];

		return new __WEBPACK_EXTERNAL_MODULE_three_NumberKeyframeTrack__( rawTracks.modelName + '.morphTargetInfluences[' + morphNum + ']', curves.times, values );

	}

	// For all animated objects, times are defined separately for each axis
	// Here we'll combine the times into one sorted array without duplicates
	getTimesForAllAxes( curves ) {

		let times = [];

		// first join together the times for each axis, if defined
		if ( curves.x !== undefined ) times = times.concat( curves.x.times );
		if ( curves.y !== undefined ) times = times.concat( curves.y.times );
		if ( curves.z !== undefined ) times = times.concat( curves.z.times );

		// then sort them
		times = times.sort( function ( a, b ) {

			return a - b;

		} );

		// and remove duplicates
		if ( times.length > 1 ) {

			let targetIndex = 1;
			let lastValue = times[ 0 ];
			for ( let i = 1; i < times.length; i ++ ) {

				const currentValue = times[ i ];
				if ( currentValue !== lastValue ) {

					times[ targetIndex ] = currentValue;
					lastValue = currentValue;
					targetIndex ++;

				}

			}

			times = times.slice( 0, targetIndex );

		}

		return times;

	}

	getKeyframeTrackValues( times, curves, initialValue ) {

		const prevValue = initialValue;

		const values = [];

		let xIndex = - 1;
		let yIndex = - 1;
		let zIndex = - 1;

		times.forEach( function ( time ) {

			if ( curves.x ) xIndex = curves.x.times.indexOf( time );
			if ( curves.y ) yIndex = curves.y.times.indexOf( time );
			if ( curves.z ) zIndex = curves.z.times.indexOf( time );

			// if there is an x value defined for this frame, use that
			if ( xIndex !== - 1 ) {

				const xValue = curves.x.values[ xIndex ];
				values.push( xValue );
				prevValue[ 0 ] = xValue;

			} else {

				// otherwise use the x value from the previous frame
				values.push( prevValue[ 0 ] );

			}

			if ( yIndex !== - 1 ) {

				const yValue = curves.y.values[ yIndex ];
				values.push( yValue );
				prevValue[ 1 ] = yValue;

			} else {

				values.push( prevValue[ 1 ] );

			}

			if ( zIndex !== - 1 ) {

				const zValue = curves.z.values[ zIndex ];
				values.push( zValue );
				prevValue[ 2 ] = zValue;

			} else {

				values.push( prevValue[ 2 ] );

			}

		} );

		return values;

	}

	// Synchronize a curve to a target time array using linear interpolation.
	// If the curve is undefined (axis not animated), returns constant values from initialValue.
	synchronizeCurve( curve, targetTimes, initialValue ) {

		if ( curve === undefined ) {

			return { times: targetTimes, values: targetTimes.map( () => initialValue ) };

		}

		// If the curve already has the same number of keyframes as the target, assume times match
		if ( curve.times.length === targetTimes.length ) return curve;

		// Linearly interpolate curve values at each target time
		const values = [];

		for ( let i = 0; i < targetTimes.length; i ++ ) {

			values.push( this.sampleCurveValue( curve, targetTimes[ i ], initialValue ) );

		}

		return { times: targetTimes, values: values };

	}

	// Sample a single value from a curve at a given time using linear interpolation
	sampleCurveValue( curve, time, initialValue ) {

		const times = curve.times;
		const values = curve.values;

		// Before first keyframe
		if ( time <= times[ 0 ] ) return values[ 0 ];

		// After last keyframe
		if ( time >= times[ times.length - 1 ] ) return values[ values.length - 1 ];

		// Find surrounding keyframes and linearly interpolate
		for ( let i = 0; i < times.length - 1; i ++ ) {

			if ( time >= times[ i ] && time <= times[ i + 1 ] ) {

				if ( times[ i ] === time ) return values[ i ];

				const alpha = ( time - times[ i ] ) / ( times[ i + 1 ] - times[ i ] );
				return values[ i ] * ( 1 - alpha ) + values[ i + 1 ] * alpha;

			}

		}

		return initialValue;

	}

	// Rotations are defined as Euler angles which can have values  of any size
	// These will be converted to quaternions which don't support values greater than
	// PI, so we'll interpolate large rotations
	interpolateRotations( curvex, curvey, curvez, eulerOrder ) {

		const times = [];
		const values = [];

		// Add first frame
		times.push( curvex.times[ 0 ] );
		values.push( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( curvex.values[ 0 ] ) );
		values.push( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( curvey.values[ 0 ] ) );
		values.push( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( curvez.values[ 0 ] ) );

		for ( let i = 1; i < curvex.values.length; i ++ ) {

			const initialValue = [
				curvex.values[ i - 1 ],
				curvey.values[ i - 1 ],
				curvez.values[ i - 1 ],
			];

			if ( isNaN( initialValue[ 0 ] ) || isNaN( initialValue[ 1 ] ) || isNaN( initialValue[ 2 ] ) ) {

				continue;

			}

			const initialValueRad = initialValue.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );

			const currentValue = [
				curvex.values[ i ],
				curvey.values[ i ],
				curvez.values[ i ],
			];

			if ( isNaN( currentValue[ 0 ] ) || isNaN( currentValue[ 1 ] ) || isNaN( currentValue[ 2 ] ) ) {

				continue;

			}

			const currentValueRad = currentValue.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );

			const valuesSpan = [
				currentValue[ 0 ] - initialValue[ 0 ],
				currentValue[ 1 ] - initialValue[ 1 ],
				currentValue[ 2 ] - initialValue[ 2 ],
			];

			const absoluteSpan = [
				Math.abs( valuesSpan[ 0 ] ),
				Math.abs( valuesSpan[ 1 ] ),
				Math.abs( valuesSpan[ 2 ] ),
			];

			if ( absoluteSpan[ 0 ] >= 180 || absoluteSpan[ 1 ] >= 180 || absoluteSpan[ 2 ] >= 180 ) {

				const maxAbsSpan = Math.max( ...absoluteSpan );

				const numSubIntervals = maxAbsSpan / 180;

				const E1 = new __WEBPACK_EXTERNAL_MODULE_three_Euler__( ...initialValueRad, eulerOrder );
				const E2 = new __WEBPACK_EXTERNAL_MODULE_three_Euler__( ...currentValueRad, eulerOrder );

				const Q1 = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__().setFromEuler( E1 );
				const Q2 = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__().setFromEuler( E2 );

				// Check unroll
				if ( Q1.dot( Q2 ) < 0 ) {

					Q2.set( - Q2.x, - Q2.y, - Q2.z, - Q2.w );

				}

				// Interpolate
				const initialTime = curvex.times[ i - 1 ];
				const timeSpan = curvex.times[ i ] - initialTime;

				const Q = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__();
				const E = new __WEBPACK_EXTERNAL_MODULE_three_Euler__();
				for ( let t = 0; t < 1; t += 1 / numSubIntervals ) {

					Q.copy( Q1.clone().slerp( Q2.clone(), t ) );

					times.push( initialTime + t * timeSpan );
					E.setFromQuaternion( Q, eulerOrder );

					values.push( E.x );
					values.push( E.y );
					values.push( E.z );

				}

			} else {

				times.push( curvex.times[ i ] );
				values.push( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( curvex.values[ i ] ) );
				values.push( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( curvey.values[ i ] ) );
				values.push( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( curvez.values[ i ] ) );

			}

		}

		return [ times, values ];

	}

}

// parse an FBX file in ASCII format
class TextParser {

	getPrevNode() {

		return this.nodeStack[ this.currentIndent - 2 ];

	}

	getCurrentNode() {

		return this.nodeStack[ this.currentIndent - 1 ];

	}

	getCurrentProp() {

		return this.currentProp;

	}

	pushStack( node ) {

		this.nodeStack.push( node );
		this.currentIndent += 1;

	}

	popStack() {

		this.nodeStack.pop();
		this.currentIndent -= 1;

	}

	setCurrentProp( val, name ) {

		this.currentProp = val;
		this.currentPropName = name;

	}

	parse( text ) {

		this.currentIndent = 0;

		this.allNodes = new FBXTree();
		this.nodeStack = [];
		this.currentProp = [];
		this.currentPropName = '';

		const scope = this;

		const split = text.split( /[\r\n]+/ );

		split.forEach( function ( line, i ) {

			const matchComment = line.match( /^[\s\t]*;/ );
			const matchEmpty = line.match( /^[\s\t]*$/ );

			if ( matchComment || matchEmpty ) return;

			const matchBeginning = line.match( '^\\t{' + scope.currentIndent + '}(\\w+):(.*){', '' );
			const matchProperty = line.match( '^\\t{' + ( scope.currentIndent ) + '}(\\w+):[\\s\\t\\r\\n](.*)' );
			const matchEnd = line.match( '^\\t{' + ( scope.currentIndent - 1 ) + '}}' );

			if ( matchBeginning ) {

				scope.parseNodeBegin( line, matchBeginning );

			} else if ( matchProperty ) {

				scope.parseNodeProperty( line, matchProperty, split[ ++ i ] );

			} else if ( matchEnd ) {

				scope.popStack();

			} else if ( line.match( /^[^\s\t}]/ ) ) {

				// large arrays are split over multiple lines terminated with a ',' character
				// if this is encountered the line needs to be joined to the previous line
				scope.parseNodePropertyContinued( line );

			}

		} );

		return this.allNodes;

	}

	parseNodeBegin( line, property ) {

		const nodeName = property[ 1 ].trim().replace( /^"/, '' ).replace( /"$/, '' );

		const nodeAttrs = property[ 2 ].split( ',' ).map( function ( attr ) {

			return attr.trim().replace( /^"/, '' ).replace( /"$/, '' );

		} );

		const node = { name: nodeName };
		const attrs = this.parseNodeAttr( nodeAttrs );

		const currentNode = this.getCurrentNode();

		// a top node
		if ( this.currentIndent === 0 ) {

			this.allNodes.add( nodeName, node );

		} else { // a subnode

			// if the subnode already exists, append it
			if ( nodeName in currentNode ) {

				// special case Pose needs PoseNodes as an array
				if ( nodeName === 'PoseNode' ) {

					currentNode.PoseNode.push( node );

				} else if ( currentNode[ nodeName ].id !== undefined ) {

					currentNode[ nodeName ] = {};
					currentNode[ nodeName ][ currentNode[ nodeName ].id ] = currentNode[ nodeName ];

				}

				if ( attrs.id !== '' ) currentNode[ nodeName ][ attrs.id ] = node;

			} else if ( typeof attrs.id === 'number' ) {

				currentNode[ nodeName ] = {};
				currentNode[ nodeName ][ attrs.id ] = node;

			} else if ( nodeName !== 'Properties70' ) {

				if ( nodeName === 'PoseNode' )	currentNode[ nodeName ] = [ node ];
				else currentNode[ nodeName ] = node;

			}

		}

		if ( typeof attrs.id === 'number' ) node.id = attrs.id;
		if ( attrs.name !== '' ) node.attrName = attrs.name;
		if ( attrs.type !== '' ) node.attrType = attrs.type;

		this.pushStack( node );

	}

	parseNodeAttr( attrs ) {

		let id = attrs[ 0 ];

		if ( attrs[ 0 ] !== '' ) {

			id = parseInt( attrs[ 0 ] );

			if ( isNaN( id ) ) {

				id = attrs[ 0 ];

			}

		}

		let name = '', type = '';

		if ( attrs.length > 1 ) {

			name = attrs[ 1 ].replace( /^(\w+)::/, '' );
			type = attrs[ 2 ];

		}

		return { id: id, name: name, type: type };

	}

	parseNodeProperty( line, property, contentLine ) {

		let propName = property[ 1 ].replace( /^"/, '' ).replace( /"$/, '' ).trim();
		let propValue = property[ 2 ].replace( /^"/, '' ).replace( /"$/, '' ).trim();

		// for special case: base64 image data follows "Content: ," line
		//	Content: ,
		//	 "/9j/4RDaRXhpZgAATU0A..."
		if ( propName === 'Content' && propValue === ',' ) {

			propValue = contentLine.replace( /"/g, '' ).replace( /,$/, '' ).trim();

		}

		const currentNode = this.getCurrentNode();
		const parentName = currentNode.name;

		if ( parentName === 'Properties70' ) {

			this.parseNodeSpecialProperty( line, propName, propValue );
			return;

		}

		// Connections
		if ( propName === 'C' ) {

			const connProps = propValue.split( ',' ).slice( 1 );
			const from = parseInt( connProps[ 0 ] );
			const to = parseInt( connProps[ 1 ] );

			let rest = propValue.split( ',' ).slice( 3 );

			rest = rest.map( function ( elem ) {

				return elem.trim().replace( /^"/, '' );

			} );

			propName = 'connections';
			propValue = [ from, to ];
			append( propValue, rest );

			if ( currentNode[ propName ] === undefined ) {

				currentNode[ propName ] = [];

			}

		}

		// Node
		if ( propName === 'Node' ) currentNode.id = propValue;

		// connections
		if ( propName in currentNode && Array.isArray( currentNode[ propName ] ) ) {

			currentNode[ propName ].push( propValue );

		} else {

			if ( propName !== 'a' ) currentNode[ propName ] = propValue;
			else currentNode.a = propValue;

		}

		this.setCurrentProp( currentNode, propName );

		// convert string to array, unless it ends in ',' in which case more will be added to it
		if ( propName === 'a' && propValue.slice( - 1 ) !== ',' ) {

			currentNode.a = parseNumberArray( propValue );

		}

	}

	parseNodePropertyContinued( line ) {

		const currentNode = this.getCurrentNode();

		currentNode.a += line;

		// if the line doesn't end in ',' we have reached the end of the property value
		// so convert the string to an array
		if ( line.slice( - 1 ) !== ',' ) {

			currentNode.a = parseNumberArray( currentNode.a );

		}

	}

	// parse "Property70"
	parseNodeSpecialProperty( line, propName, propValue ) {

		// split this
		// P: "Lcl Scaling", "Lcl Scaling", "", "A",1,1,1
		// into array like below
		// ["Lcl Scaling", "Lcl Scaling", "", "A", "1,1,1" ]
		const props = propValue.split( '",' ).map( function ( prop ) {

			return prop.trim().replace( /^\"/, '' ).replace( /\s/, '_' );

		} );

		const innerPropName = props[ 0 ];
		const innerPropType1 = props[ 1 ];
		const innerPropType2 = props[ 2 ];
		const innerPropFlag = props[ 3 ];
		let innerPropValue = props[ 4 ];

		// cast values where needed, otherwise leave as strings
		switch ( innerPropType1 ) {

			case 'int':
			case 'enum':
			case 'bool':
			case 'ULongLong':
			case 'double':
			case 'Number':
			case 'FieldOfView':
				innerPropValue = parseFloat( innerPropValue );
				break;

			case 'Color':
			case 'ColorRGB':
			case 'Vector3D':
			case 'Lcl_Translation':
			case 'Lcl_Rotation':
			case 'Lcl_Scaling':
				innerPropValue = parseNumberArray( innerPropValue );
				break;

		}

		// CAUTION: these props must append to parent's parent
		this.getPrevNode()[ innerPropName ] = {

			'type': innerPropType1,
			'type2': innerPropType2,
			'flag': innerPropFlag,
			'value': innerPropValue

		};

		this.setCurrentProp( this.getPrevNode(), innerPropName );

	}

}

// Parse an FBX file in Binary format
class BinaryParser {

	parse( buffer ) {

		const reader = new BinaryReader( buffer );
		reader.skip( 23 ); // skip magic 23 bytes

		const version = reader.getUint32();

		if ( version < 6400 ) {

			throw new Error( 'THREE.FBXLoader: FBX version not supported, FileVersion: ' + version );

		}

		const allNodes = new FBXTree();

		while ( ! this.endOfContent( reader ) ) {

			const node = this.parseNode( reader, version );
			if ( node !== null ) allNodes.add( node.name, node );

		}

		return allNodes;

	}

	// Check if reader has reached the end of content.
	endOfContent( reader ) {

		// footer size: 160bytes + 16-byte alignment padding
		// - 16bytes: magic
		// - padding til 16-byte alignment (at least 1byte?)
		//	(seems like some exporters embed fixed 15 or 16bytes?)
		// - 4bytes: magic
		// - 4bytes: version
		// - 120bytes: zero
		// - 16bytes: magic
		if ( reader.size() % 16 === 0 ) {

			return ( ( reader.getOffset() + 160 + 16 ) & ~ 0xf ) >= reader.size();

		} else {

			return reader.getOffset() + 160 + 16 >= reader.size();

		}

	}

	// recursively parse nodes until the end of the file is reached
	parseNode( reader, version ) {

		const node = {};

		// The first three data sizes depends on version.
		const endOffset = ( version >= 7500 ) ? reader.getUint64() : reader.getUint32();
		const numProperties = ( version >= 7500 ) ? reader.getUint64() : reader.getUint32();

		( version >= 7500 ) ? reader.getUint64() : reader.getUint32(); // the returned propertyListLen is not used

		const nameLen = reader.getUint8();
		const name = reader.getString( nameLen );

		// Regards this node as NULL-record if endOffset is zero
		if ( endOffset === 0 ) return null;

		const propertyList = [];

		for ( let i = 0; i < numProperties; i ++ ) {

			propertyList.push( this.parseProperty( reader ) );

		}

		// Regards the first three elements in propertyList as id, attrName, and attrType
		const id = propertyList.length > 0 ? propertyList[ 0 ] : '';
		const attrName = propertyList.length > 1 ? propertyList[ 1 ] : '';
		const attrType = propertyList.length > 2 ? propertyList[ 2 ] : '';

		// check if this node represents just a single property
		// like (name, 0) set or (name2, [0, 1, 2]) set of {name: 0, name2: [0, 1, 2]}
		node.singleProperty = ( numProperties === 1 && reader.getOffset() === endOffset ) ? true : false;

		while ( endOffset > reader.getOffset() ) {

			const subNode = this.parseNode( reader, version );

			if ( subNode !== null ) this.parseSubNode( name, node, subNode );

		}

		node.propertyList = propertyList; // raw property list used by parent

		if ( typeof id === 'number' ) node.id = id;
		if ( attrName !== '' ) node.attrName = attrName;
		if ( attrType !== '' ) node.attrType = attrType;
		if ( name !== '' ) node.name = name;

		return node;

	}

	parseSubNode( name, node, subNode ) {

		// special case: child node is single property
		if ( subNode.singleProperty === true ) {

			const value = subNode.propertyList[ 0 ];

			if ( Array.isArray( value ) ) {

				node[ subNode.name ] = subNode;

				subNode.a = value;

			} else {

				node[ subNode.name ] = value;

			}

		} else if ( name === 'Connections' && subNode.name === 'C' ) {

			const array = [];

			subNode.propertyList.forEach( function ( property, i ) {

				// first Connection is FBX type (OO, OP, etc.). We'll discard these
				if ( i !== 0 ) array.push( property );

			} );

			if ( node.connections === undefined ) {

				node.connections = [];

			}

			node.connections.push( array );

		} else if ( subNode.name === 'Properties70' ) {

			const keys = Object.keys( subNode );

			keys.forEach( function ( key ) {

				node[ key ] = subNode[ key ];

			} );

		} else if ( name === 'Properties70' && subNode.name === 'P' ) {

			let innerPropName = subNode.propertyList[ 0 ];
			let innerPropType1 = subNode.propertyList[ 1 ];
			const innerPropType2 = subNode.propertyList[ 2 ];
			const innerPropFlag = subNode.propertyList[ 3 ];
			let innerPropValue;

			if ( innerPropName.indexOf( 'Lcl ' ) === 0 ) innerPropName = innerPropName.replace( 'Lcl ', 'Lcl_' );
			if ( innerPropType1.indexOf( 'Lcl ' ) === 0 ) innerPropType1 = innerPropType1.replace( 'Lcl ', 'Lcl_' );

			if ( innerPropType1 === 'Color' || innerPropType1 === 'ColorRGB' || innerPropType1 === 'Vector' || innerPropType1 === 'Vector3D' || innerPropType1.indexOf( 'Lcl_' ) === 0 ) {

				innerPropValue = [
					subNode.propertyList[ 4 ],
					subNode.propertyList[ 5 ],
					subNode.propertyList[ 6 ]
				];

			} else {

				innerPropValue = subNode.propertyList[ 4 ];

			}

			// this will be copied to parent, see above
			node[ innerPropName ] = {

				'type': innerPropType1,
				'type2': innerPropType2,
				'flag': innerPropFlag,
				'value': innerPropValue

			};

		} else if ( node[ subNode.name ] === undefined ) {

			if ( typeof subNode.id === 'number' ) {

				node[ subNode.name ] = {};
				node[ subNode.name ][ subNode.id ] = subNode;

			} else {

				node[ subNode.name ] = subNode;

			}

		} else {

			if ( subNode.name === 'PoseNode' ) {

				if ( ! Array.isArray( node[ subNode.name ] ) ) {

					node[ subNode.name ] = [ node[ subNode.name ] ];

				}

				node[ subNode.name ].push( subNode );

			} else if ( node[ subNode.name ][ subNode.id ] === undefined ) {

				node[ subNode.name ][ subNode.id ] = subNode;

			}

		}

	}

	parseProperty( reader ) {

		const type = reader.getString( 1 );
		let length;

		switch ( type ) {

			case 'C':
				return reader.getBoolean();

			case 'D':
				return reader.getFloat64();

			case 'F':
				return reader.getFloat32();

			case 'I':
				return reader.getInt32();

			case 'L':
				return reader.getInt64();

			case 'R':
				length = reader.getUint32();
				return reader.getArrayBuffer( length );

			case 'S':
				length = reader.getUint32();
				return reader.getString( length );

			case 'Y':
				return reader.getInt16();

			case 'b':
			case 'c':
			case 'd':
			case 'f':
			case 'i':
			case 'l':

				const arrayLength = reader.getUint32();
				const encoding = reader.getUint32(); // 0: non-compressed, 1: compressed
				const compressedLength = reader.getUint32();

				if ( encoding === 0 ) {

					switch ( type ) {

						case 'b':
						case 'c':
							return reader.getBooleanArray( arrayLength );

						case 'd':
							return reader.getFloat64Array( arrayLength );

						case 'f':
							return reader.getFloat32Array( arrayLength );

						case 'i':
							return reader.getInt32Array( arrayLength );

						case 'l':
							return reader.getInt64Array( arrayLength );

					}

				}

				const data = unzlibSync( new Uint8Array( reader.getArrayBuffer( compressedLength ) ) );
				const reader2 = new BinaryReader( data.buffer );

				switch ( type ) {

					case 'b':
					case 'c':
						return reader2.getBooleanArray( arrayLength );

					case 'd':
						return reader2.getFloat64Array( arrayLength );

					case 'f':
						return reader2.getFloat32Array( arrayLength );

					case 'i':
						return reader2.getInt32Array( arrayLength );

					case 'l':
						return reader2.getInt64Array( arrayLength );

				}

				break; // cannot happen but is required by the DeepScan

			default:
				throw new Error( 'THREE.FBXLoader: Unknown property type ' + type );

		}

	}

}

class BinaryReader {

	constructor( buffer, littleEndian ) {

		this.dv = new DataView( buffer );
		this.offset = 0;
		this.littleEndian = ( littleEndian !== undefined ) ? littleEndian : true;
		this._textDecoder = new TextDecoder();

	}

	getOffset() {

		return this.offset;

	}

	size() {

		return this.dv.buffer.byteLength;

	}

	skip( length ) {

		this.offset += length;

	}

	// seems like true/false representation depends on exporter.
	// true: 1 or 'Y'(=0x59), false: 0 or 'T'(=0x54)
	// then sees LSB.
	getBoolean() {

		return ( this.getUint8() & 1 ) === 1;

	}

	getBooleanArray( size ) {

		const a = [];

		for ( let i = 0; i < size; i ++ ) {

			a.push( this.getBoolean() );

		}

		return a;

	}

	getUint8() {

		const value = this.dv.getUint8( this.offset );
		this.offset += 1;
		return value;

	}

	getInt16() {

		const value = this.dv.getInt16( this.offset, this.littleEndian );
		this.offset += 2;
		return value;

	}

	getInt32() {

		const value = this.dv.getInt32( this.offset, this.littleEndian );
		this.offset += 4;
		return value;

	}

	getInt32Array( size ) {

		const a = [];

		for ( let i = 0; i < size; i ++ ) {

			a.push( this.getInt32() );

		}

		return a;

	}

	getUint32() {

		const value = this.dv.getUint32( this.offset, this.littleEndian );
		this.offset += 4;
		return value;

	}

	// JavaScript doesn't support 64-bit integer so calculate this here
	// 1 << 32 will return 1 so using multiply operation instead here.
	// There's a possibility that this method returns wrong value if the value
	// is out of the range between Number.MAX_SAFE_INTEGER and Number.MIN_SAFE_INTEGER.
	// TODO: safely handle 64-bit integer
	getInt64() {

		let low, high;

		if ( this.littleEndian ) {

			low = this.getUint32();
			high = this.getUint32();

		} else {

			high = this.getUint32();
			low = this.getUint32();

		}

		// calculate negative value
		if ( high & 0x80000000 ) {

			high = ~ high & 0xFFFFFFFF;
			low = ~ low & 0xFFFFFFFF;

			if ( low === 0xFFFFFFFF ) high = ( high + 1 ) & 0xFFFFFFFF;

			low = ( low + 1 ) & 0xFFFFFFFF;

			return - ( high * 0x100000000 + low );

		}

		return high * 0x100000000 + low;

	}

	getInt64Array( size ) {

		const a = [];

		for ( let i = 0; i < size; i ++ ) {

			a.push( this.getInt64() );

		}

		return a;

	}

	// Note: see getInt64() comment
	getUint64() {

		let low, high;

		if ( this.littleEndian ) {

			low = this.getUint32();
			high = this.getUint32();

		} else {

			high = this.getUint32();
			low = this.getUint32();

		}

		return high * 0x100000000 + low;

	}

	getFloat32() {

		const value = this.dv.getFloat32( this.offset, this.littleEndian );
		this.offset += 4;
		return value;

	}

	getFloat32Array( size ) {

		const a = [];

		for ( let i = 0; i < size; i ++ ) {

			a.push( this.getFloat32() );

		}

		return a;

	}

	getFloat64() {

		const value = this.dv.getFloat64( this.offset, this.littleEndian );
		this.offset += 8;
		return value;

	}

	getFloat64Array( size ) {

		const a = [];

		for ( let i = 0; i < size; i ++ ) {

			a.push( this.getFloat64() );

		}

		return a;

	}

	getArrayBuffer( size ) {

		const value = this.dv.buffer.slice( this.offset, this.offset + size );
		this.offset += size;
		return value;

	}

	getString( size ) {

		const start = this.offset;
		let a = new Uint8Array( this.dv.buffer, start, size );

		this.skip( size );

		const nullByte = a.indexOf( 0 );
		if ( nullByte >= 0 ) a = new Uint8Array( this.dv.buffer, start, nullByte );

		return this._textDecoder.decode( a );

	}

}

// FBXTree holds a representation of the FBX data, returned by the TextParser ( FBX ASCII format)
// and BinaryParser( FBX Binary format)
class FBXTree {

	add( key, val ) {

		this[ key ] = val;

	}

}

// ************** UTILITY FUNCTIONS **************

function isFbxFormatBinary( buffer ) {

	const CORRECT = 'Kaydara\u0020FBX\u0020Binary\u0020\u0020\0';

	return buffer.byteLength >= CORRECT.length && CORRECT === convertArrayBufferToString( buffer, 0, CORRECT.length );

}

function isFbxFormatASCII( text ) {

	const CORRECT = [ 'K', 'a', 'y', 'd', 'a', 'r', 'a', '\\', 'F', 'B', 'X', '\\', 'B', 'i', 'n', 'a', 'r', 'y', '\\', '\\' ];

	let cursor = 0;

	function read( offset ) {

		const result = text[ offset - 1 ];
		text = text.slice( cursor + offset );
		cursor ++;
		return result;

	}

	for ( let i = 0; i < CORRECT.length; ++ i ) {

		const num = read( 1 );
		if ( num === CORRECT[ i ] ) {

			return false;

		}

	}

	return true;

}

function getFbxVersion( text ) {

	const versionRegExp = /FBXVersion: (\d+)/;
	const match = text.match( versionRegExp );

	if ( match ) {

		const version = parseInt( match[ 1 ] );
		return version;

	}

	throw new Error( 'THREE.FBXLoader: Cannot find the version number for the file given.' );

}

// Converts FBX ticks into real time seconds.
function convertFBXTimeToSeconds( time ) {

	return time / 46186158000;

}

const dataArray = [];

// extracts the data from the correct position in the FBX array based on indexing type
function getData( polygonVertexIndex, polygonIndex, vertexIndex, infoObject ) {

	let index;

	switch ( infoObject.mappingType ) {

		case 'ByPolygonVertex' :
			index = polygonVertexIndex;
			break;
		case 'ByPolygon' :
			index = polygonIndex;
			break;
		case 'ByVertice' :
			index = vertexIndex;
			break;
		case 'AllSame' :
			index = infoObject.indices[ 0 ];
			break;
		default :
			console.warn( 'THREE.FBXLoader: unknown attribute mapping type ' + infoObject.mappingType );

	}

	if ( infoObject.referenceType === 'IndexToDirect' ) index = infoObject.indices[ index ];

	const from = index * infoObject.dataSize;
	const to = from + infoObject.dataSize;

	return slice( dataArray, infoObject.buffer, from, to );

}

const tempEuler = new __WEBPACK_EXTERNAL_MODULE_three_Euler__();
const tempVec = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();

// generate transformation from FBX transform data
// ref: https://help.autodesk.com/view/FBX/2017/ENU/?guid=__files_GUID_10CDD63C_79C1_4F2D_BB28_AD2BE65A02ED_htm
// ref: http://docs.autodesk.com/FBX/2014/ENU/FBX-SDK-Documentation/index.html?url=cpp_ref/_transformations_2main_8cxx-example.html,topicNumber=cpp_ref__transformations_2main_8cxx_example_htmlfc10a1e1-b18d-4e72-9dc0-70d0f1959f5e
function generateTransform( transformData ) {

	const lTranslationM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lPreRotationM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lRotationM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lPostRotationM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

	const lScalingM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lScalingPivotM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lScalingOffsetM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lRotationOffsetM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lRotationPivotM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

	const lParentGX = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lParentLX = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	const lGlobalT = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

	const inheritType = ( transformData.inheritType ) ? transformData.inheritType : 0;

	if ( transformData.translation ) lTranslationM.setPosition( tempVec.fromArray( transformData.translation ) );

	// For Maya models using "Joint Orient", Euler order only applies to rotation, not pre/post-rotations
	const defaultEulerOrder = getEulerOrder( 0 );

	if ( transformData.preRotation ) {

		const array = transformData.preRotation.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );
		array.push( defaultEulerOrder );
		lPreRotationM.makeRotationFromEuler( tempEuler.fromArray( array ) );

	}

	if ( transformData.rotation ) {

		const array = transformData.rotation.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );
		array.push( transformData.eulerOrder || defaultEulerOrder );
		lRotationM.makeRotationFromEuler( tempEuler.fromArray( array ) );

	}

	if ( transformData.postRotation ) {

		const array = transformData.postRotation.map( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad );
		array.push( defaultEulerOrder );
		lPostRotationM.makeRotationFromEuler( tempEuler.fromArray( array ) );
		lPostRotationM.invert();

	}

	if ( transformData.scale ) lScalingM.scale( tempVec.fromArray( transformData.scale ) );

	// Pivots and offsets
	if ( transformData.scalingOffset ) lScalingOffsetM.setPosition( tempVec.fromArray( transformData.scalingOffset ) );
	if ( transformData.scalingPivot ) lScalingPivotM.setPosition( tempVec.fromArray( transformData.scalingPivot ) );
	if ( transformData.rotationOffset ) lRotationOffsetM.setPosition( tempVec.fromArray( transformData.rotationOffset ) );
	if ( transformData.rotationPivot ) lRotationPivotM.setPosition( tempVec.fromArray( transformData.rotationPivot ) );

	// parent transform
	if ( transformData.parentMatrixWorld ) {

		lParentLX.copy( transformData.parentMatrix );
		lParentGX.copy( transformData.parentMatrixWorld );

	}

	const lLRM = lPreRotationM.clone().multiply( lRotationM ).multiply( lPostRotationM );
	// Global Rotation
	const lParentGRM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	lParentGRM.extractRotation( lParentGX );

	// Global Shear*Scaling
	const lParentTM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
	lParentTM.copyPosition( lParentGX );

	const lParentGRSM = lParentTM.clone().invert().multiply( lParentGX );
	const lParentGSM = lParentGRM.clone().invert().multiply( lParentGRSM );
	const lLSM = lScalingM;

	const lGlobalRS = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

	if ( inheritType === 0 ) {

		lGlobalRS.copy( lParentGRM ).multiply( lLRM ).multiply( lParentGSM ).multiply( lLSM );

	} else if ( inheritType === 1 ) {

		lGlobalRS.copy( lParentGRM ).multiply( lParentGSM ).multiply( lLRM ).multiply( lLSM );

	} else {

		const lParentLSM = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__().scale( new __WEBPACK_EXTERNAL_MODULE_three_Vector3__().setFromMatrixScale( lParentLX ) );
		const lParentLSM_inv = lParentLSM.clone().invert();
		const lParentGSM_noLocal = lParentGSM.clone().multiply( lParentLSM_inv );

		lGlobalRS.copy( lParentGRM ).multiply( lLRM ).multiply( lParentGSM_noLocal ).multiply( lLSM );

	}

	const lRotationPivotM_inv = lRotationPivotM.clone().invert();
	const lScalingPivotM_inv = lScalingPivotM.clone().invert();
	// Calculate the local transform matrix
	let lTransform = lTranslationM.clone().multiply( lRotationOffsetM ).multiply( lRotationPivotM ).multiply( lPreRotationM ).multiply( lRotationM ).multiply( lPostRotationM ).multiply( lRotationPivotM_inv ).multiply( lScalingOffsetM ).multiply( lScalingPivotM ).multiply( lScalingM ).multiply( lScalingPivotM_inv );

	const lLocalTWithAllPivotAndOffsetInfo = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__().copyPosition( lTransform );

	const lGlobalTranslation = lParentGX.clone().multiply( lLocalTWithAllPivotAndOffsetInfo );
	lGlobalT.copyPosition( lGlobalTranslation );

	lTransform = lGlobalT.clone().multiply( lGlobalRS );

	// from global to local
	lTransform.premultiply( lParentGX.invert() );

	return lTransform;

}

// Returns the three.js intrinsic Euler order corresponding to FBX extrinsic Euler order
// ref: http://help.autodesk.com/view/FBX/2017/ENU/?guid=__cpp_ref_class_fbx_euler_html
function getEulerOrder( order ) {

	order = order || 0;

	const enums = [
		'ZYX', // -> XYZ extrinsic
		'YZX', // -> XZY extrinsic
		'XZY', // -> YZX extrinsic
		'ZXY', // -> YXZ extrinsic
		'YXZ', // -> ZXY extrinsic
		'XYZ', // -> ZYX extrinsic
		//'SphericXYZ', // not possible to support
	];

	if ( order === 6 ) {

		console.warn( 'THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect.' );
		return enums[ 0 ];

	}

	return enums[ order ];

}

// Parses comma separated list of numbers and returns them an array.
// Used internally by the TextParser
function parseNumberArray( value ) {

	const array = value.split( ',' ).map( function ( val ) {

		return parseFloat( val );

	} );

	return array;

}

function convertArrayBufferToString( buffer, from, to ) {

	if ( from === undefined ) from = 0;
	if ( to === undefined ) to = buffer.byteLength;

	return new TextDecoder().decode( new Uint8Array( buffer, from, to ) );

}

function append( a, b ) {

	for ( let i = 0, j = a.length, l = b.length; i < l; i ++, j ++ ) {

		a[ j ] = b[ i ];

	}

}

function slice( a, b, from, to ) {

	for ( let i = from, j = 0; i < to; i ++, j ++ ) {

		a[ j ] = b[ i ];

	}

	return a;

}




;// ../../node_modules/three/examples/jsm/utils/BufferGeometryUtils.js
/* unused harmony import specifier */ var BufferAttribute;
/* unused harmony import specifier */ var BufferGeometry;
/* unused harmony import specifier */ var InstancedBufferAttribute;
/* unused harmony import specifier */ var InterleavedBuffer;
/* unused harmony import specifier */ var InterleavedBufferAttribute;
/* unused harmony import specifier */ var Vector3;
/* unused harmony import specifier */ var Float32BufferAttribute;


/**
 * @module BufferGeometryUtils
 * @three_import import * as BufferGeometryUtils from 'three/addons/utils/BufferGeometryUtils.js';
 */

/**
 * Computes vertex tangents using the MikkTSpace algorithm. MikkTSpace generates the same tangents consistently,
 * and is used in most modelling tools and normal map bakers. Use MikkTSpace for materials with normal maps,
 * because inconsistent tangents may lead to subtle visual issues in the normal map, particularly around mirrored
 * UV seams.
 *
 * In comparison to this method, {@link BufferGeometry#computeTangents} (a custom algorithm) generates tangents that
 * probably will not match the tangents in other software. The custom algorithm is sufficient for general use with a
 * custom material, and may be faster than MikkTSpace.
 *
 * Returns the original BufferGeometry. Indexed geometries will be de-indexed. Requires position, normal, and uv attributes.
 *
 * @param {BufferGeometry} geometry - The geometry to compute tangents for.
 * @param {Object} MikkTSpace - Instance of `examples/jsm/libs/mikktspace.module.js`, or `mikktspace` npm package.
 * Await `MikkTSpace.ready` before use.
 * @param {boolean} [negateSign=true] - Whether to negate the sign component (.w) of each tangent.
 * Required for normal map conventions in some formats, including glTF.
 * @return {BufferGeometry} The updated geometry.
 */
function computeMikkTSpaceTangents( geometry, MikkTSpace, negateSign = true ) {

	if ( ! MikkTSpace || ! MikkTSpace.isReady ) {

		throw new Error( 'THREE.BufferGeometryUtils: Initialized MikkTSpace library required.' );

	}

	if ( ! geometry.hasAttribute( 'position' ) || ! geometry.hasAttribute( 'normal' ) || ! geometry.hasAttribute( 'uv' ) ) {

		throw new Error( 'THREE.BufferGeometryUtils: Tangents require "position", "normal", and "uv" attributes.' );

	}

	function getAttributeArray( attribute ) {

		if ( attribute.normalized || attribute.isInterleavedBufferAttribute ) {

			const dstArray = new Float32Array( attribute.count * attribute.itemSize );

			for ( let i = 0, j = 0; i < attribute.count; i ++ ) {

				dstArray[ j ++ ] = attribute.getX( i );
				dstArray[ j ++ ] = attribute.getY( i );

				if ( attribute.itemSize > 2 ) {

					dstArray[ j ++ ] = attribute.getZ( i );

				}

			}

			return dstArray;

		}

		if ( attribute.array instanceof Float32Array ) {

			return attribute.array;

		}

		return new Float32Array( attribute.array );

	}

	// MikkTSpace algorithm requires non-indexed input.

	const _geometry = geometry.index ? geometry.toNonIndexed() : geometry;

	// Compute vertex tangents.

	const tangents = MikkTSpace.generateTangents(

		getAttributeArray( _geometry.attributes.position ),
		getAttributeArray( _geometry.attributes.normal ),
		getAttributeArray( _geometry.attributes.uv )

	);

	// Texture coordinate convention of glTF differs from the apparent
	// default of the MikkTSpace library; .w component must be flipped.

	if ( negateSign ) {

		for ( let i = 3; i < tangents.length; i += 4 ) {

			tangents[ i ] *= - 1;

		}

	}

	//

	_geometry.setAttribute( 'tangent', new BufferAttribute( tangents, 4 ) );

	if ( geometry !== _geometry ) {

		geometry.copy( _geometry );

	}

	return geometry;

}

/**
 * Merges a set of geometries into a single instance. All geometries must have compatible attributes.
 *
 * @param {Array<BufferGeometry>} geometries - The geometries to merge.
 * @param {boolean} [useGroups=false] - Whether to use groups or not.
 * @return {?BufferGeometry} The merged geometry. Returns `null` if the merge does not succeed.
 */
function mergeGeometries( geometries, useGroups = false ) {

	const isIndexed = geometries[ 0 ].index !== null;

	const attributesUsed = new Set( Object.keys( geometries[ 0 ].attributes ) );
	const morphAttributesUsed = new Set( Object.keys( geometries[ 0 ].morphAttributes ) );

	const attributes = {};
	const morphAttributes = {};

	const morphTargetsRelative = geometries[ 0 ].morphTargetsRelative;

	const mergedGeometry = new BufferGeometry();

	let offset = 0;

	for ( let i = 0; i < geometries.length; ++ i ) {

		const geometry = geometries[ i ];
		let attributesCount = 0;

		// ensure that all geometries are indexed, or none

		if ( isIndexed !== ( geometry.index !== null ) ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them.' );
			return null;

		}

		// gather attributes, exit early if they're different

		for ( const name in geometry.attributes ) {

			if ( ! attributesUsed.has( name ) ) {

				console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. All geometries must have compatible attributes; make sure "' + name + '" attribute exists among all geometries, or in none of them.' );
				return null;

			}

			if ( attributes[ name ] === undefined ) attributes[ name ] = [];

			attributes[ name ].push( geometry.attributes[ name ] );

			attributesCount ++;

		}

		// ensure geometries have the same number of attributes

		if ( attributesCount !== attributesUsed.size ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. Make sure all geometries have the same number of attributes.' );
			return null;

		}

		// gather morph attributes, exit early if they're different

		if ( morphTargetsRelative !== geometry.morphTargetsRelative ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. .morphTargetsRelative must be consistent throughout all geometries.' );
			return null;

		}

		for ( const name in geometry.morphAttributes ) {

			if ( ! morphAttributesUsed.has( name ) ) {

				console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '.  .morphAttributes must be consistent throughout all geometries.' );
				return null;

			}

			if ( morphAttributes[ name ] === undefined ) morphAttributes[ name ] = [];

			morphAttributes[ name ].push( geometry.morphAttributes[ name ] );

		}

		if ( useGroups ) {

			let count;

			if ( isIndexed ) {

				count = geometry.index.count;

			} else if ( geometry.attributes.position !== undefined ) {

				count = geometry.attributes.position.count;

			} else {

				console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. The geometry must have either an index or a position attribute' );
				return null;

			}

			mergedGeometry.addGroup( offset, count, i );

			offset += count;

		}

	}

	// merge indices

	if ( isIndexed ) {

		let indexOffset = 0;
		const mergedIndex = [];

		for ( let i = 0; i < geometries.length; ++ i ) {

			const index = geometries[ i ].index;

			for ( let j = 0; j < index.count; ++ j ) {

				mergedIndex.push( index.getX( j ) + indexOffset );

			}

			indexOffset += geometries[ i ].attributes.position.count;

		}

		mergedGeometry.setIndex( mergedIndex );

	}

	// merge attributes

	for ( const name in attributes ) {

		const mergedAttribute = mergeAttributes( attributes[ name ] );

		if ( ! mergedAttribute ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the ' + name + ' attribute.' );
			return null;

		}

		mergedGeometry.setAttribute( name, mergedAttribute );

	}

	// merge morph attributes

	for ( const name in morphAttributes ) {

		const numMorphTargets = morphAttributes[ name ][ 0 ].length;
		if ( numMorphTargets === 0 ) continue;

		mergedGeometry.morphAttributes = mergedGeometry.morphAttributes || {};
		mergedGeometry.morphAttributes[ name ] = [];

		for ( let i = 0; i < numMorphTargets; ++ i ) {

			const morphAttributesToMerge = [];

			for ( let j = 0; j < morphAttributes[ name ].length; ++ j ) {

				morphAttributesToMerge.push( morphAttributes[ name ][ j ][ i ] );

			}

			const mergedMorphAttribute = mergeAttributes( morphAttributesToMerge );

			if ( ! mergedMorphAttribute ) {

				console.error( 'THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the ' + name + ' morphAttribute.' );
				return null;

			}

			mergedGeometry.morphAttributes[ name ].push( mergedMorphAttribute );

		}

	}

	return mergedGeometry;

}

/**
 * Merges a set of attributes into a single instance. All attributes must have compatible properties and types.
 * Instances of {@link InterleavedBufferAttribute} are not supported.
 *
 * @param {Array<BufferAttribute>} attributes - The attributes to merge.
 * @return {?BufferAttribute} The merged attribute. Returns `null` if the merge does not succeed.
 */
function mergeAttributes( attributes ) {

	let TypedArray;
	let itemSize;
	let normalized;
	let gpuType = - 1;
	let arrayLength = 0;

	for ( let i = 0; i < attributes.length; ++ i ) {

		const attribute = attributes[ i ];

		if ( TypedArray === undefined ) TypedArray = attribute.array.constructor;
		if ( TypedArray !== attribute.array.constructor ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes.' );
			return null;

		}

		if ( itemSize === undefined ) itemSize = attribute.itemSize;
		if ( itemSize !== attribute.itemSize ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes.' );
			return null;

		}

		if ( normalized === undefined ) normalized = attribute.normalized;
		if ( normalized !== attribute.normalized ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes.' );
			return null;

		}

		if ( gpuType === - 1 ) gpuType = attribute.gpuType;
		if ( gpuType !== attribute.gpuType ) {

			console.error( 'THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes.' );
			return null;

		}

		arrayLength += attribute.count * itemSize;

	}

	const array = new TypedArray( arrayLength );
	const result = new BufferAttribute( array, itemSize, normalized );
	let offset = 0;

	for ( let i = 0; i < attributes.length; ++ i ) {

		const attribute = attributes[ i ];
		if ( attribute.isInterleavedBufferAttribute ) {

			const tupleOffset = offset / itemSize;
			for ( let j = 0, l = attribute.count; j < l; j ++ ) {

				for ( let c = 0; c < itemSize; c ++ ) {

					const value = attribute.getComponent( j, c );
					result.setComponent( j + tupleOffset, c, value );

				}

			}

		} else {

			array.set( attribute.array, offset );

		}

		offset += attribute.count * itemSize;

	}

	if ( gpuType !== undefined ) {

		result.gpuType = gpuType;

	}

	return result;

}

/**
 * Performs a deep clone of the given buffer attribute.
 *
 * @param {BufferAttribute} attribute - The attribute to clone.
 * @return {BufferAttribute} The cloned attribute.
 */
function deepCloneAttribute( attribute ) {

	if ( attribute.isInstancedInterleavedBufferAttribute || attribute.isInterleavedBufferAttribute ) {

		return deinterleaveAttribute( attribute );

	}

	if ( attribute.isInstancedBufferAttribute ) {

		return new InstancedBufferAttribute().copy( attribute );

	}

	return new BufferAttribute().copy( attribute );

}

/**
 * Interleaves a set of attributes and returns a new array of corresponding attributes that share a
 * single {@link InterleavedBuffer} instance. All attributes must have compatible types.
 *
 * @param {Array<BufferAttribute>} attributes - The attributes to interleave.
 * @return {?Array<InterleavedBufferAttribute>} An array of interleaved attributes. If interleave does not succeed, the method returns `null`.
 */
function interleaveAttributes( attributes ) {

	// Interleaves the provided attributes into an InterleavedBuffer and returns
	// a set of InterleavedBufferAttributes for each attribute
	let TypedArray;
	let arrayLength = 0;
	let stride = 0;

	// calculate the length and type of the interleavedBuffer
	for ( let i = 0, l = attributes.length; i < l; ++ i ) {

		const attribute = attributes[ i ];

		if ( TypedArray === undefined ) TypedArray = attribute.array.constructor;
		if ( TypedArray !== attribute.array.constructor ) {

			console.error( 'AttributeBuffers of different types cannot be interleaved' );
			return null;

		}

		arrayLength += attribute.array.length;
		stride += attribute.itemSize;

	}

	// Create the set of buffer attributes
	const interleavedBuffer = new InterleavedBuffer( new TypedArray( arrayLength ), stride );
	let offset = 0;
	const res = [];
	const getters = [ 'getX', 'getY', 'getZ', 'getW' ];
	const setters = [ 'setX', 'setY', 'setZ', 'setW' ];

	for ( let j = 0, l = attributes.length; j < l; j ++ ) {

		const attribute = attributes[ j ];
		const itemSize = attribute.itemSize;
		const count = attribute.count;
		const iba = new InterleavedBufferAttribute( interleavedBuffer, itemSize, offset, attribute.normalized );
		res.push( iba );

		offset += itemSize;

		// Move the data for each attribute into the new interleavedBuffer
		// at the appropriate offset
		for ( let c = 0; c < count; c ++ ) {

			for ( let k = 0; k < itemSize; k ++ ) {

				iba[ setters[ k ] ]( c, attribute[ getters[ k ] ]( c ) );

			}

		}

	}

	return res;

}

/**
 * Returns a new, non-interleaved version of the given attribute.
 *
 * @param {InterleavedBufferAttribute} attribute - The interleaved attribute.
 * @return {BufferAttribute} The non-interleaved attribute.
 */
function deinterleaveAttribute( attribute ) {

	const cons = attribute.data.array.constructor;
	const count = attribute.count;
	const itemSize = attribute.itemSize;
	const normalized = attribute.normalized;

	const array = new cons( count * itemSize );
	let newAttribute;
	if ( attribute.isInstancedInterleavedBufferAttribute ) {

		newAttribute = new InstancedBufferAttribute( array, itemSize, normalized, attribute.meshPerAttribute );

	} else {

		newAttribute = new BufferAttribute( array, itemSize, normalized );

	}

	for ( let i = 0; i < count; i ++ ) {

		newAttribute.setX( i, attribute.getX( i ) );

		if ( itemSize >= 2 ) {

			newAttribute.setY( i, attribute.getY( i ) );

		}

		if ( itemSize >= 3 ) {

			newAttribute.setZ( i, attribute.getZ( i ) );

		}

		if ( itemSize >= 4 ) {

			newAttribute.setW( i, attribute.getW( i ) );

		}

	}

	return newAttribute;

}

/**
 * Deinterleaves all attributes on the given geometry.
 *
 * @param {BufferGeometry} geometry - The geometry to deinterleave.
 */
function deinterleaveGeometry( geometry ) {

	const attributes = geometry.attributes;
	const morphTargets = geometry.morphTargets;
	const attrMap = new Map();

	for ( const key in attributes ) {

		const attr = attributes[ key ];
		if ( attr.isInterleavedBufferAttribute ) {

			if ( ! attrMap.has( attr ) ) {

				attrMap.set( attr, deinterleaveAttribute( attr ) );

			}

			attributes[ key ] = attrMap.get( attr );

		}

	}

	for ( const key in morphTargets ) {

		const attr = morphTargets[ key ];
		if ( attr.isInterleavedBufferAttribute ) {

			if ( ! attrMap.has( attr ) ) {

				attrMap.set( attr, deinterleaveAttribute( attr ) );

			}

			morphTargets[ key ] = attrMap.get( attr );

		}

	}

}

/**
 * Returns the amount of bytes used by all attributes to represent the geometry.
 *
 * @param {BufferGeometry} geometry - The geometry.
 * @return {number} The estimate bytes used.
 */
function estimateBytesUsed( geometry ) {

	// Return the estimated memory used by this geometry in bytes
	// Calculate using itemSize, count, and BYTES_PER_ELEMENT to account
	// for InterleavedBufferAttributes.
	let mem = 0;
	for ( const name in geometry.attributes ) {

		const attr = geometry.getAttribute( name );
		mem += attr.count * attr.itemSize * attr.array.BYTES_PER_ELEMENT;

	}

	const indices = geometry.getIndex();
	mem += indices ? indices.count * indices.itemSize * indices.array.BYTES_PER_ELEMENT : 0;
	return mem;

}

/**
 * Returns a new geometry with vertices for which all similar vertex attributes (within tolerance) are merged.
 *
 * @param {BufferGeometry} geometry - The geometry to merge vertices for.
 * @param {number} [tolerance=1e-4] - The tolerance value.
 * @return {BufferGeometry} - The new geometry with merged vertices.
 */
function mergeVertices( geometry, tolerance = 1e-4 ) {

	tolerance = Math.max( tolerance, Number.EPSILON );

	// Generate an index buffer if the geometry doesn't have one, or optimize it
	// if it's already available.
	const hashToIndex = {};
	const indices = geometry.getIndex();
	const positions = geometry.getAttribute( 'position' );
	const vertexCount = indices ? indices.count : positions.count;

	// next value for triangle indices
	let nextIndex = 0;

	// attributes and new attribute arrays
	const attributeNames = Object.keys( geometry.attributes );
	const tmpAttributes = {};
	const tmpMorphAttributes = {};
	const newIndices = [];
	const getters = [ 'getX', 'getY', 'getZ', 'getW' ];
	const setters = [ 'setX', 'setY', 'setZ', 'setW' ];

	// Initialize the arrays, allocating space conservatively. Extra
	// space will be trimmed in the last step.
	for ( let i = 0, l = attributeNames.length; i < l; i ++ ) {

		const name = attributeNames[ i ];
		const attr = geometry.attributes[ name ];

		tmpAttributes[ name ] = new attr.constructor(
			new attr.array.constructor( attr.count * attr.itemSize ),
			attr.itemSize,
			attr.normalized
		);

		const morphAttributes = geometry.morphAttributes[ name ];
		if ( morphAttributes ) {

			if ( ! tmpMorphAttributes[ name ] ) tmpMorphAttributes[ name ] = [];
			morphAttributes.forEach( ( morphAttr, i ) => {

				const array = new morphAttr.array.constructor( morphAttr.count * morphAttr.itemSize );
				tmpMorphAttributes[ name ][ i ] = new morphAttr.constructor( array, morphAttr.itemSize, morphAttr.normalized );

			} );

		}

	}

	// convert the error tolerance to an amount of decimal places to truncate to
	const halfTolerance = tolerance * 0.5;
	const exponent = Math.log10( 1 / tolerance );
	const hashMultiplier = Math.pow( 10, exponent );
	const hashAdditive = halfTolerance * hashMultiplier;
	for ( let i = 0; i < vertexCount; i ++ ) {

		const index = indices ? indices.getX( i ) : i;

		// Generate a hash for the vertex attributes at the current index 'i'
		let hash = '';
		for ( let j = 0, l = attributeNames.length; j < l; j ++ ) {

			const name = attributeNames[ j ];
			const attribute = geometry.getAttribute( name );
			const itemSize = attribute.itemSize;

			for ( let k = 0; k < itemSize; k ++ ) {

				// Math.trunc() preserves the full Number range, ~~ would wrap to int32
				hash += `${ Math.trunc( attribute[ getters[ k ] ]( index ) * hashMultiplier + hashAdditive ) },`;

			}

		}

		// Add another reference to the vertex if it's already
		// used by another index
		if ( hash in hashToIndex ) {

			newIndices.push( hashToIndex[ hash ] );

		} else {

			// copy data to the new index in the temporary attributes
			for ( let j = 0, l = attributeNames.length; j < l; j ++ ) {

				const name = attributeNames[ j ];
				const attribute = geometry.getAttribute( name );
				const morphAttributes = geometry.morphAttributes[ name ];
				const itemSize = attribute.itemSize;
				const newArray = tmpAttributes[ name ];
				const newMorphArrays = tmpMorphAttributes[ name ];

				for ( let k = 0; k < itemSize; k ++ ) {

					const getterFunc = getters[ k ];
					const setterFunc = setters[ k ];
					newArray[ setterFunc ]( nextIndex, attribute[ getterFunc ]( index ) );

					if ( morphAttributes ) {

						for ( let m = 0, ml = morphAttributes.length; m < ml; m ++ ) {

							newMorphArrays[ m ][ setterFunc ]( nextIndex, morphAttributes[ m ][ getterFunc ]( index ) );

						}

					}

				}

			}

			hashToIndex[ hash ] = nextIndex;
			newIndices.push( nextIndex );
			nextIndex ++;

		}

	}

	// generate result BufferGeometry
	const result = geometry.clone();
	for ( const name in geometry.attributes ) {

		const tmpAttribute = tmpAttributes[ name ];

		result.setAttribute( name, new tmpAttribute.constructor(
			tmpAttribute.array.slice( 0, nextIndex * tmpAttribute.itemSize ),
			tmpAttribute.itemSize,
			tmpAttribute.normalized,
		) );

		if ( ! ( name in tmpMorphAttributes ) ) continue;

		for ( let j = 0; j < tmpMorphAttributes[ name ].length; j ++ ) {

			const tmpMorphAttribute = tmpMorphAttributes[ name ][ j ];

			result.morphAttributes[ name ][ j ] = new tmpMorphAttribute.constructor(
				tmpMorphAttribute.array.slice( 0, nextIndex * tmpMorphAttribute.itemSize ),
				tmpMorphAttribute.itemSize,
				tmpMorphAttribute.normalized,
			);

		}

	}

	// indices

	result.setIndex( newIndices );

	return result;

}

/**
 * Converts the given geometry to the `TrianglesDrawMode` draw mode, which
 * corresponds to the `gl.TRIANGLES` primitive in WebGL. The conversion only
 * rewrites the index, so the geometry is modified in place and returned.
 *
 * @param {BufferGeometry} geometry - The geometry to convert.
 * @param {number} drawMode - The current draw mode.
 * @return {BufferGeometry} The converted geometry using `TrianglesDrawMode`.
 */
function toTrianglesDrawMode( geometry, drawMode ) {

	if ( drawMode === __WEBPACK_EXTERNAL_MODULE_three_TrianglesDrawMode__ ) {

		console.warn( 'THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles.' );
		return geometry;

	}

	if ( drawMode === __WEBPACK_EXTERNAL_MODULE_three_TriangleFanDrawMode__ || drawMode === __WEBPACK_EXTERNAL_MODULE_three_TriangleStripDrawMode__ ) {

		let index = geometry.getIndex();

		// generate index if not present

		if ( index === null ) {

			const indices = [];

			const position = geometry.getAttribute( 'position' );

			if ( position !== undefined ) {

				for ( let i = 0; i < position.count; i ++ ) {

					indices.push( i );

				}

				geometry.setIndex( indices );
				index = geometry.getIndex();

			} else {

				console.error( 'THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible.' );
				return geometry;

			}

		}

		//

		const numberOfTriangles = index.count - 2;
		const newIndices = [];

		if ( drawMode === __WEBPACK_EXTERNAL_MODULE_three_TriangleFanDrawMode__ ) {

			// gl.TRIANGLE_FAN

			for ( let i = 1; i <= numberOfTriangles; i ++ ) {

				newIndices.push( index.getX( 0 ) );
				newIndices.push( index.getX( i ) );
				newIndices.push( index.getX( i + 1 ) );

			}

		} else {

			// gl.TRIANGLE_STRIP

			for ( let i = 0; i < numberOfTriangles; i ++ ) {

				if ( i % 2 === 0 ) {

					newIndices.push( index.getX( i ) );
					newIndices.push( index.getX( i + 1 ) );
					newIndices.push( index.getX( i + 2 ) );

				} else {

					newIndices.push( index.getX( i + 2 ) );
					newIndices.push( index.getX( i + 1 ) );
					newIndices.push( index.getX( i ) );

				}

			}

		}

		if ( ( newIndices.length / 3 ) !== numberOfTriangles ) {

			console.error( 'THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.' );

		}

		// updated indices

		geometry.setIndex( newIndices );
		geometry.clearGroups();

		return geometry;

	} else {

		console.error( 'THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:', drawMode );
		return geometry;

	}

}

/**
 * Calculates the morphed attributes of a morphed/skinned BufferGeometry.
 *
 * Helpful for Raytracing or Decals (i.e. a `DecalGeometry` applied to a morphed Object with a `BufferGeometry`
 * will use the original `BufferGeometry`, not the morphed/skinned one, generating an incorrect result.
 * Using this function to create a shadow `Object3`D the `DecalGeometry` can be correctly generated).
 *
 * @param {Mesh|Line|Points} object - The 3D object to compute morph attributes for.
 * @return {Object} An object with original position/normal attributes and morphed ones.
 */
function computeMorphedAttributes( object ) {

	const _vA = new Vector3();
	const _vB = new Vector3();
	const _vC = new Vector3();

	const _tempA = new Vector3();
	const _tempB = new Vector3();
	const _tempC = new Vector3();

	const _morphA = new Vector3();
	const _morphB = new Vector3();
	const _morphC = new Vector3();

	function _calculateMorphedAttributeData(
		object,
		attribute,
		morphAttribute,
		morphTargetsRelative,
		a,
		b,
		c,
		modifiedAttributeArray
	) {

		_vA.fromBufferAttribute( attribute, a );
		_vB.fromBufferAttribute( attribute, b );
		_vC.fromBufferAttribute( attribute, c );

		const morphInfluences = object.morphTargetInfluences;

		if ( morphAttribute && morphInfluences ) {

			_morphA.set( 0, 0, 0 );
			_morphB.set( 0, 0, 0 );
			_morphC.set( 0, 0, 0 );

			for ( let i = 0, il = morphAttribute.length; i < il; i ++ ) {

				const influence = morphInfluences[ i ];
				const morph = morphAttribute[ i ];

				if ( influence === 0 ) continue;

				_tempA.fromBufferAttribute( morph, a );
				_tempB.fromBufferAttribute( morph, b );
				_tempC.fromBufferAttribute( morph, c );

				if ( morphTargetsRelative ) {

					_morphA.addScaledVector( _tempA, influence );
					_morphB.addScaledVector( _tempB, influence );
					_morphC.addScaledVector( _tempC, influence );

				} else {

					_morphA.addScaledVector( _tempA.sub( _vA ), influence );
					_morphB.addScaledVector( _tempB.sub( _vB ), influence );
					_morphC.addScaledVector( _tempC.sub( _vC ), influence );

				}

			}

			_vA.add( _morphA );
			_vB.add( _morphB );
			_vC.add( _morphC );

		}

		if ( object.isSkinnedMesh ) {

			object.applyBoneTransform( a, _vA );
			object.applyBoneTransform( b, _vB );
			object.applyBoneTransform( c, _vC );

		}

		modifiedAttributeArray[ a * 3 + 0 ] = _vA.x;
		modifiedAttributeArray[ a * 3 + 1 ] = _vA.y;
		modifiedAttributeArray[ a * 3 + 2 ] = _vA.z;
		modifiedAttributeArray[ b * 3 + 0 ] = _vB.x;
		modifiedAttributeArray[ b * 3 + 1 ] = _vB.y;
		modifiedAttributeArray[ b * 3 + 2 ] = _vB.z;
		modifiedAttributeArray[ c * 3 + 0 ] = _vC.x;
		modifiedAttributeArray[ c * 3 + 1 ] = _vC.y;
		modifiedAttributeArray[ c * 3 + 2 ] = _vC.z;

	}

	const geometry = object.geometry;
	const material = object.material;

	let a, b, c;
	const index = geometry.index;
	const positionAttribute = geometry.attributes.position;
	const morphPosition = geometry.morphAttributes.position;
	const morphTargetsRelative = geometry.morphTargetsRelative;
	const normalAttribute = geometry.attributes.normal;
	const morphNormal = geometry.morphAttributes.normal;

	const groups = geometry.groups;
	const drawRange = geometry.drawRange;
	let i, j, il, jl;
	let group;
	let start, end;

	const modifiedPosition = new Float32Array( positionAttribute.count * positionAttribute.itemSize );
	const modifiedNormal = new Float32Array( normalAttribute.count * normalAttribute.itemSize );

	if ( index !== null ) {

		// indexed buffer geometry

		if ( Array.isArray( material ) ) {

			for ( i = 0, il = groups.length; i < il; i ++ ) {

				group = groups[ i ];

				start = Math.max( group.start, drawRange.start );
				end = Math.min( ( group.start + group.count ), ( drawRange.start + drawRange.count ) );

				for ( j = start, jl = end; j < jl; j += 3 ) {

					a = index.getX( j );
					b = index.getX( j + 1 );
					c = index.getX( j + 2 );

					_calculateMorphedAttributeData(
						object,
						positionAttribute,
						morphPosition,
						morphTargetsRelative,
						a, b, c,
						modifiedPosition
					);

					_calculateMorphedAttributeData(
						object,
						normalAttribute,
						morphNormal,
						morphTargetsRelative,
						a, b, c,
						modifiedNormal
					);

				}

			}

		} else {

			start = Math.max( 0, drawRange.start );
			end = Math.min( index.count, ( drawRange.start + drawRange.count ) );

			for ( i = start, il = end; i < il; i += 3 ) {

				a = index.getX( i );
				b = index.getX( i + 1 );
				c = index.getX( i + 2 );

				_calculateMorphedAttributeData(
					object,
					positionAttribute,
					morphPosition,
					morphTargetsRelative,
					a, b, c,
					modifiedPosition
				);

				_calculateMorphedAttributeData(
					object,
					normalAttribute,
					morphNormal,
					morphTargetsRelative,
					a, b, c,
					modifiedNormal
				);

			}

		}

	} else {

		// non-indexed buffer geometry

		if ( Array.isArray( material ) ) {

			for ( i = 0, il = groups.length; i < il; i ++ ) {

				group = groups[ i ];

				start = Math.max( group.start, drawRange.start );
				end = Math.min( ( group.start + group.count ), ( drawRange.start + drawRange.count ) );

				for ( j = start, jl = end; j < jl; j += 3 ) {

					a = j;
					b = j + 1;
					c = j + 2;

					_calculateMorphedAttributeData(
						object,
						positionAttribute,
						morphPosition,
						morphTargetsRelative,
						a, b, c,
						modifiedPosition
					);

					_calculateMorphedAttributeData(
						object,
						normalAttribute,
						morphNormal,
						morphTargetsRelative,
						a, b, c,
						modifiedNormal
					);

				}

			}

		} else {

			start = Math.max( 0, drawRange.start );
			end = Math.min( positionAttribute.count, ( drawRange.start + drawRange.count ) );

			for ( i = start, il = end; i < il; i += 3 ) {

				a = i;
				b = i + 1;
				c = i + 2;

				_calculateMorphedAttributeData(
					object,
					positionAttribute,
					morphPosition,
					morphTargetsRelative,
					a, b, c,
					modifiedPosition
				);

				_calculateMorphedAttributeData(
					object,
					normalAttribute,
					morphNormal,
					morphTargetsRelative,
					a, b, c,
					modifiedNormal
				);

			}

		}

	}

	const morphedPositionAttribute = new Float32BufferAttribute( modifiedPosition, 3 );
	const morphedNormalAttribute = new Float32BufferAttribute( modifiedNormal, 3 );

	return {

		positionAttribute: positionAttribute,
		normalAttribute: normalAttribute,
		morphedPositionAttribute: morphedPositionAttribute,
		morphedNormalAttribute: morphedNormalAttribute

	};

}

/**
 * Merges the {@link BufferGeometry#groups} for the given geometry.
 *
 * @param {BufferGeometry} geometry - The geometry to modify.
 * @return {BufferGeometry} - The updated geometry
 */
function mergeGroups( geometry ) {

	if ( geometry.groups.length === 0 ) {

		console.warn( 'THREE.BufferGeometryUtils.mergeGroups(): No groups are defined. Nothing to merge.' );
		return geometry;

	}

	let groups = geometry.groups;

	// sort groups by material index

	groups = groups.sort( ( a, b ) => {

		if ( a.materialIndex !== b.materialIndex ) return a.materialIndex - b.materialIndex;

		return a.start - b.start;

	} );

	// create index for non-indexed geometries

	if ( geometry.getIndex() === null ) {

		const positionAttribute = geometry.getAttribute( 'position' );
		const indices = [];

		for ( let i = 0; i < positionAttribute.count; i += 3 ) {

			indices.push( i, i + 1, i + 2 );

		}

		geometry.setIndex( indices );

	}

	// sort index

	const index = geometry.getIndex();

	const newIndices = [];

	for ( let i = 0; i < groups.length; i ++ ) {

		const group = groups[ i ];

		const groupStart = group.start;
		const groupLength = groupStart + group.count;

		for ( let j = groupStart; j < groupLength; j ++ ) {

			newIndices.push( index.getX( j ) );

		}

	}

	geometry.dispose(); // Required to force buffer recreation
	geometry.setIndex( newIndices );

	// update groups indices

	let start = 0;

	for ( let i = 0; i < groups.length; i ++ ) {

		const group = groups[ i ];

		group.start = start;
		start += group.count;

	}

	// merge groups

	let currentGroup = groups[ 0 ];

	geometry.groups = [ currentGroup ];

	for ( let i = 1; i < groups.length; i ++ ) {

		const group = groups[ i ];

		if ( currentGroup.materialIndex === group.materialIndex ) {

			currentGroup.count += group.count;

		} else {

			currentGroup = group;
			geometry.groups.push( currentGroup );

		}

	}

	return geometry;

}

/**
 * Modifies the supplied geometry if it is non-indexed, otherwise creates a new,
 * non-indexed geometry. Returns the geometry with smooth normals everywhere except
 * faces that meet at an angle greater than the crease angle.
 *
 * @param {BufferGeometry} geometry - The geometry to modify.
 * @param {number} [creaseAngle=Math.PI/3] - The crease angle in radians.
 * @return {BufferGeometry} - The updated geometry
 */
function toCreasedNormals( geometry, creaseAngle = Math.PI / 3 /* 60 degrees */ ) {

	// BufferGeometry.toNonIndexed() warns if the geometry is non-indexed
	// and returns the original geometry
	const resultGeometry = geometry.index ? geometry.toNonIndexed() : geometry;
	const posAttr = resultGeometry.attributes.position;
	const vertexCount = posAttr.count;

	let positions;

	if ( posAttr.isBufferAttribute === true && posAttr.itemSize === 3 && posAttr.normalized === false ) {

		positions = posAttr.array;

	} else {

		// flatten the position buffer so the math below operates on plain numbers
		positions = new Float64Array( vertexCount * 3 );

		for ( let i = 0; i < vertexCount; i ++ ) {

			positions[ 3 * i + 0 ] = posAttr.getX( i );
			positions[ 3 * i + 1 ] = posAttr.getY( i );
			positions[ 3 * i + 2 ] = posAttr.getZ( i );

		}

	}

	const creaseDot = Math.cos( creaseAngle );
	const hashMultiplier = ( 1 + 1e-10 ) * 1e2;
	const faceCount = vertexCount / 3;

	// compute the normal of each face
	const faceNormals = new Float64Array( faceCount * 3 );
	for ( let f = 0; f < faceCount; f ++ ) {

		const f9 = 9 * f;
		const ax = positions[ f9 + 0 ], ay = positions[ f9 + 1 ], az = positions[ f9 + 2 ];
		const bx = positions[ f9 + 3 ], by = positions[ f9 + 4 ], bz = positions[ f9 + 5 ];
		const cx = positions[ f9 + 6 ], cy = positions[ f9 + 7 ], cz = positions[ f9 + 8 ];

		const v1x = cx - bx, v1y = cy - by, v1z = cz - bz;
		const v2x = ax - bx, v2y = ay - by, v2z = az - bz;

		const nx = v1y * v2z - v1z * v2y;
		const ny = v1z * v2x - v1x * v2z;
		const nz = v1x * v2y - v1y * v2x;

		const invLength = 1 / ( Math.sqrt( nx * nx + ny * ny + nz * nz ) || 1 );
		faceNormals[ 3 * f + 0 ] = nx * invLength;
		faceNormals[ 3 * f + 1 ] = ny * invLength;
		faceNormals[ 3 * f + 2 ] = nz * invLength;

	}

	// assign an id to each vertex, sharing the id between vertices with the same
	// quantized position via an open-addressed hash table (slots hold id + 1, 0 means empty)
	const vertexIds = new Int32Array( vertexCount );
	const quantized = new Float64Array( vertexCount * 3 );

	let tableSize = 1;
	while ( tableSize < vertexCount * 2 ) tableSize <<= 1;
	const tableMask = tableSize - 1;
	const table = new Int32Array( tableSize );

	let uniqueCount = 0;
	for ( let i = 0; i < vertexCount; i ++ ) {

		const i3 = 3 * i;
		const qx = Math.trunc( positions[ i3 + 0 ] * hashMultiplier );
		const qy = Math.trunc( positions[ i3 + 1 ] * hashMultiplier );
		const qz = Math.trunc( positions[ i3 + 2 ] * hashMultiplier );

		let slot = ( Math.imul( qx, 73856093 ) ^ Math.imul( qy, 19349663 ) ^ Math.imul( qz, 83492791 ) ) & tableMask;

		while ( true ) {

			const id = table[ slot ];

			if ( id === 0 ) {

				const q3 = 3 * uniqueCount;
				quantized[ q3 + 0 ] = qx;
				quantized[ q3 + 1 ] = qy;
				quantized[ q3 + 2 ] = qz;

				table[ slot ] = uniqueCount + 1;
				vertexIds[ i ] = uniqueCount ++;
				break;

			}

			const q3 = 3 * ( id - 1 );

			if ( quantized[ q3 + 0 ] === qx && quantized[ q3 + 1 ] === qy && quantized[ q3 + 2 ] === qz ) {

				vertexIds[ i ] = id - 1;
				break;

			}

			slot = ( slot + 1 ) & tableMask;

		}

	}

	// bucket the faces surrounding each unique vertex position
	const bucketOffsets = new Int32Array( uniqueCount + 1 );
	for ( let i = 0; i < vertexCount; i ++ ) bucketOffsets[ vertexIds[ i ] + 1 ] ++;
	for ( let i = 0; i < uniqueCount; i ++ ) bucketOffsets[ i + 1 ] += bucketOffsets[ i ];

	const bucketFaces = new Int32Array( vertexCount );
	const bucketCursors = bucketOffsets.slice( 0, uniqueCount );
	for ( let f = 0; f < faceCount; f ++ ) {

		const f3 = 3 * f;
		bucketFaces[ bucketCursors[ vertexIds[ f3 + 0 ] ] ++ ] = f;
		bucketFaces[ bucketCursors[ vertexIds[ f3 + 1 ] ] ++ ] = f;
		bucketFaces[ bucketCursors[ vertexIds[ f3 + 2 ] ] ++ ] = f;

	}

	// average the normals of the faces surrounding each vertex if they are within the
	// provided crease threshold
	const normalArray = new Float32Array( vertexCount * 3 );
	for ( let f = 0; f < faceCount; f ++ ) {

		const f3 = 3 * f;
		const nx = faceNormals[ f3 + 0 ];
		const ny = faceNormals[ f3 + 1 ];
		const nz = faceNormals[ f3 + 2 ];

		for ( let n = 0; n < 3; n ++ ) {

			const i = f3 + n;
			const id = vertexIds[ i ];

			let sumX = 0, sumY = 0, sumZ = 0;

			for ( let k = bucketOffsets[ id ], end = bucketOffsets[ id + 1 ]; k < end; k ++ ) {

				const o3 = 3 * bucketFaces[ k ];
				const ox = faceNormals[ o3 + 0 ];
				const oy = faceNormals[ o3 + 1 ];
				const oz = faceNormals[ o3 + 2 ];

				if ( nx * ox + ny * oy + nz * oz > creaseDot ) {

					sumX += ox;
					sumY += oy;
					sumZ += oz;

				}

			}

			const invLength = 1 / ( Math.sqrt( sumX * sumX + sumY * sumY + sumZ * sumZ ) || 1 );
			normalArray[ 3 * i + 0 ] = sumX * invLength;
			normalArray[ 3 * i + 1 ] = sumY * invLength;
			normalArray[ 3 * i + 2 ] = sumZ * invLength;

		}

	}

	resultGeometry.setAttribute( 'normal', new BufferAttribute( normalArray, 3, false ) );
	return resultGeometry;

}



;// ../../node_modules/three/examples/jsm/utils/SkeletonUtils.js
/* unused harmony import specifier */ var Quaternion;
/* unused harmony import specifier */ var SkeletonUtils_Vector3;
/* unused harmony import specifier */ var Matrix4;
/* unused harmony import specifier */ var AnimationMixer;
/* unused harmony import specifier */ var VectorKeyframeTrack;
/* unused harmony import specifier */ var QuaternionKeyframeTrack;
/* unused harmony import specifier */ var AnimationClip;
/* unused harmony import specifier */ var SkeletonHelper;


/**
 * @module SkeletonUtils
 * @three_import import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
 */

function getBoneName( bone, options ) {

	if ( options.getBoneName !== undefined ) {

		return options.getBoneName( bone );

	}

	return options.names[ bone.name ];

}

/**
 * Retargets the skeleton from the given source to the target.
 *
 * Both `target` and `source` can be a 3D object with a skeleton property (e.g. a skinned mesh)
 * or a {@link Skeleton} directly.
 *
 * @param {Object3D|Skeleton} target - The target object.
 * @param {Object3D|Skeleton} source - The source object.
 * @param {module:SkeletonUtils~RetargetOptions} options - The options.
 */
function retarget( target, source, options = {} ) {

	const quat = new Quaternion(),
		scale = new SkeletonUtils_Vector3(),
		relativeMatrix = new Matrix4(),
		globalMatrix = new Matrix4();

	options.preserveBoneMatrix = options.preserveBoneMatrix !== undefined ? options.preserveBoneMatrix : true;
	options.preserveBonePositions = options.preserveBonePositions !== undefined ? options.preserveBonePositions : true;
	options.useTargetMatrix = options.useTargetMatrix !== undefined ? options.useTargetMatrix : false;
	options.hip = options.hip !== undefined ? options.hip : 'hip';
	options.hipInfluence = options.hipInfluence !== undefined ? options.hipInfluence : new SkeletonUtils_Vector3( 1, 1, 1 );
	options.scale = options.scale !== undefined ? options.scale : 1;
	options.names = options.names || {};

	const sourceBones = source.isObject3D ? source.skeleton.bones : getBones( source ),
		bones = target.isObject3D ? target.skeleton.bones : getBones( target );

	let bone, name, boneTo,
		bonesPosition;

	// reset bones

	if ( target.isObject3D ) {

		target.skeleton.pose();

	} else {

		options.useTargetMatrix = true;
		options.preserveBoneMatrix = false;

	}

	if ( options.preserveBonePositions ) {

		bonesPosition = [];

		for ( let i = 0; i < bones.length; i ++ ) {

			bonesPosition.push( bones[ i ].position.clone() );

		}

	}

	if ( options.preserveBoneMatrix ) {

		// reset matrix

		target.updateMatrixWorld();

		target.matrixWorld.identity();

		// reset children matrix

		for ( let i = 0; i < target.children.length; ++ i ) {

			target.children[ i ].updateMatrixWorld( true );

		}

	}

	for ( let i = 0; i < bones.length; ++ i ) {

		bone = bones[ i ];
		name = getBoneName( bone, options );

		boneTo = getBoneByName( name, sourceBones );

		globalMatrix.copy( bone.matrixWorld );

		if ( boneTo ) {

			boneTo.updateMatrixWorld();

			if ( options.useTargetMatrix ) {

				relativeMatrix.copy( boneTo.matrixWorld );

			} else {

				relativeMatrix.copy( target.matrixWorld ).invert();
				relativeMatrix.multiply( boneTo.matrixWorld );

			}

			// ignore scale to extract rotation

			scale.setFromMatrixScale( relativeMatrix );
			relativeMatrix.scale( scale.set( 1 / scale.x, 1 / scale.y, 1 / scale.z ) );

			// apply to global matrix

			globalMatrix.makeRotationFromQuaternion( quat.setFromRotationMatrix( relativeMatrix ) );

			if ( target.isObject3D ) {

				if ( options.localOffsets ) {

					if ( options.localOffsets[ bone.name ] ) {

						globalMatrix.multiply( options.localOffsets[ bone.name ] );

					}

				}

			}

			globalMatrix.copyPosition( relativeMatrix );

		}

		if ( name === options.hip ) {

			globalMatrix.elements[ 12 ] *= options.scale * options.hipInfluence.x;
			globalMatrix.elements[ 13 ] *= options.scale * options.hipInfluence.y;
			globalMatrix.elements[ 14 ] *= options.scale * options.hipInfluence.z;

			if ( options.hipPosition !== undefined ) {

				globalMatrix.elements[ 12 ] += options.hipPosition.x * options.scale;
				globalMatrix.elements[ 13 ] += options.hipPosition.y * options.scale;
				globalMatrix.elements[ 14 ] += options.hipPosition.z * options.scale;

			}

		}

		if ( bone.parent ) {

			bone.matrix.copy( bone.parent.matrixWorld ).invert();
			bone.matrix.multiply( globalMatrix );

		} else {

			bone.matrix.copy( globalMatrix );

		}

		bone.matrix.decompose( bone.position, bone.quaternion, bone.scale );

		bone.updateMatrixWorld();

	}

	if ( options.preserveBonePositions ) {

		for ( let i = 0; i < bones.length; ++ i ) {

			bone = bones[ i ];
			name = getBoneName( bone, options ) || bone.name;

			if ( name !== options.hip ) {

				bone.position.copy( bonesPosition[ i ] );

			}

		}

	}

	if ( options.preserveBoneMatrix ) {

		// restore matrix

		target.updateMatrixWorld( true );

	}

}

/**
 * Retargets the animation clip of the source to the target 3D object.
 *
 * The `source` can be a 3D object with a skeleton property (e.g. a skinned mesh)
 * or a {@link Skeleton} directly.
 *
 * @param {Object3D} target - The target 3D object. Must have a `skeleton` property.
 * @param {Object3D|Skeleton} source - The source object.
 * @param {AnimationClip} clip - The animation clip.
 * @param {module:SkeletonUtils~RetargetOptions} options - The options.
 * @return {AnimationClip} The retargeted animation clip.
 */
function retargetClip( target, source, clip, options = {} ) {

	options.useFirstFramePosition = options.useFirstFramePosition !== undefined ? options.useFirstFramePosition : false;

	// Calculate the fps from the source clip based on the track with the most frames, unless fps is already provided.
	options.fps = options.fps !== undefined ? options.fps : ( Math.max( ...clip.tracks.map( track => track.times.length ) ) / clip.duration );
	options.names = options.names || [];

	if ( ! source.isObject3D ) {

		source = getHelperFromSkeleton( source );

	}

	const numFrames = Math.round( clip.duration * ( options.fps / 1000 ) * 1000 ),
		delta = clip.duration / ( numFrames - 1 ),
		convertedTracks = [],
		mixer = new AnimationMixer( source ),
		bones = getBones( target.skeleton ),
		boneDatas = [];

	let positionOffset,
		bone, boneTo, boneData,
		name;

	mixer.clipAction( clip ).play();

	// trim

	let start = 0, end = numFrames;

	if ( options.trim !== undefined ) {

		start = Math.round( options.trim[ 0 ] * options.fps );
		end = Math.min( Math.round( options.trim[ 1 ] * options.fps ), numFrames ) - start;

		mixer.update( options.trim[ 0 ] );

	} else {

		mixer.update( 0 );

	}

	source.updateMatrixWorld();

	//

	for ( let frame = 0; frame < end; ++ frame ) {

		const time = frame * delta;

		retarget( target, source, options );

		for ( let j = 0; j < bones.length; ++ j ) {

			bone = bones[ j ];
			name = getBoneName( bone, options ) || bone.name;
			boneTo = getBoneByName( name, source.skeleton );

			if ( boneTo ) {

				boneData = boneDatas[ j ] = boneDatas[ j ] || { bone: bone };

				if ( options.hip === name ) {

					if ( ! boneData.pos ) {

						boneData.pos = {
							times: new Float32Array( end ),
							values: new Float32Array( end * 3 )
						};

					}

					if ( options.useFirstFramePosition ) {

						if ( frame === 0 ) {

							positionOffset = bone.position.clone();

						}

						bone.position.sub( positionOffset );

					}

					boneData.pos.times[ frame ] = time;

					bone.position.toArray( boneData.pos.values, frame * 3 );

				}

				if ( ! boneData.quat ) {

					boneData.quat = {
						times: new Float32Array( end ),
						values: new Float32Array( end * 4 )
					};

				}

				boneData.quat.times[ frame ] = time;

				bone.quaternion.toArray( boneData.quat.values, frame * 4 );

			}

		}

		if ( frame === end - 2 ) {

			// last mixer update before final loop iteration
			// make sure we do not go over or equal to clip duration
			mixer.update( delta - 0.0000001 );

		} else {

			mixer.update( delta );

		}

		source.updateMatrixWorld();

	}

	for ( let i = 0; i < boneDatas.length; ++ i ) {

		boneData = boneDatas[ i ];

		if ( boneData ) {

			if ( boneData.pos ) {

				convertedTracks.push( new VectorKeyframeTrack(
					'.bones[' + boneData.bone.name + '].position',
					boneData.pos.times,
					boneData.pos.values
				) );

			}

			convertedTracks.push( new QuaternionKeyframeTrack(
				'.bones[' + boneData.bone.name + '].quaternion',
				boneData.quat.times,
				boneData.quat.values
			) );

		}

	}

	mixer.uncacheAction( clip );

	return new AnimationClip( clip.name, - 1, convertedTracks );

}

/**
 * Clones the given 3D object and its descendants, ensuring that any `SkinnedMesh` instances are
 * correctly associated with their bones. Bones are also cloned, and must be descendants of the
 * object passed to this method. Other data, like geometries and materials, are reused by reference.
 *
 * @param {Object3D} source - The 3D object to clone.
 * @return {Object3D} The cloned 3D object.
 */
function clone( source ) {

	const sourceLookup = new Map();
	const cloneLookup = new Map();

	const clone = source.clone();

	parallelTraverse( source, clone, function ( sourceNode, clonedNode ) {

		sourceLookup.set( clonedNode, sourceNode );
		cloneLookup.set( sourceNode, clonedNode );

	} );

	clone.traverse( function ( node ) {

		if ( ! node.isSkinnedMesh ) return;

		const clonedMesh = node;
		const sourceMesh = sourceLookup.get( node );
		const sourceBones = sourceMesh.skeleton.bones;

		clonedMesh.skeleton = sourceMesh.skeleton.clone();
		clonedMesh.bindMatrix.copy( sourceMesh.bindMatrix );

		clonedMesh.skeleton.bones = sourceBones.map( function ( bone ) {

			return cloneLookup.get( bone );

		} );

		clonedMesh.bind( clonedMesh.skeleton, clonedMesh.bindMatrix );

	} );

	return clone;

}

// internal helper

function getBoneByName( name, skeleton ) {

	for ( let i = 0, bones = getBones( skeleton ); i < bones.length; i ++ ) {

		if ( name === bones[ i ].name )

			return bones[ i ];

	}

}

function getBones( skeleton ) {

	return Array.isArray( skeleton ) ? skeleton : skeleton.bones;

}


function getHelperFromSkeleton( skeleton ) {

	const source = new SkeletonHelper( skeleton.bones[ 0 ] );
	source.skeleton = skeleton;

	return source;

}

function parallelTraverse( a, b, callback ) {

	callback( a, b );

	for ( let i = 0; i < a.children.length; i ++ ) {

		parallelTraverse( a.children[ i ], b.children[ i ], callback );

	}

}

/**
 * Retarget options of `SkeletonUtils`.
 *
 * @typedef {Object} module:SkeletonUtils~RetargetOptions
 * @property {boolean} [useFirstFramePosition=false] - Whether to use the position of the first frame or not.
 * @property {number} [fps] - The FPS of the clip.
 * @property {Object<string,string>} [names] - A dictionary for mapping target to source bone names.
 * @property {function(string):string} [getBoneName] - A function for mapping bone names. Alternative to `names`.
 * @property {Array<number>} [trim] - Whether to trim the clip or not. If set the array should hold two values for the start and end.
 * @property {boolean} [preserveBoneMatrix=true] - Whether to preserve bone matrices or not.
 * @property {boolean} [preserveBonePositions=true] - Whether to preserve bone positions or not.
 * @property {boolean} [useTargetMatrix=false] - Whether to use the target matrix or not.
 * @property {string} [hip='hip'] - The name of the source's hip bone.
 * @property {Vector3} [hipInfluence=(1,1,1)] - The hip influence.
 * @property {number} [scale=1] - The scale.
 * @property {Object<string,Matrix4>} [localOffsets] - Per-bone local offset matrices, keyed by bone name.
 * @property {Vector3} [hipPosition] - An additional position offset applied to the hip bone.
 **/



;// ../../node_modules/three/examples/jsm/loaders/GLTFLoader.js




/**
 * A loader for the glTF 2.0 format.
 *
 * [glTF](https://www.khronos.org/gltf/) (GL Transmission Format) is an [open format specification]{@link https://github.com/KhronosGroup/glTF/tree/main/specification/2.0)
 * for efficient delivery and loading of 3D content. Assets may be provided either in JSON (.gltf) or binary (.glb)
 * format. External files store textures (.jpg, .png) and additional binary data (.bin). A glTF asset may deliver
 * one or more scenes, including meshes, materials, textures, skins, skeletons, morph targets, animations, lights,
 * and/or cameras.
 *
 * `GLTFLoader` uses {@link ImageBitmapLoader} whenever possible. Be advised that image bitmaps are not
 * automatically GC-collected when they are no longer referenced, and they require special handling during
 * the disposal process.
 *
 * `GLTFLoader` supports the following glTF 2.0 extensions:
 * - KHR_draco_mesh_compression
 * - KHR_lights_punctual
 * - KHR_materials_anisotropy
 * - KHR_materials_clearcoat
 * - KHR_materials_dispersion
 * - KHR_materials_emissive_strength
 * - KHR_materials_ior
 * - KHR_materials_specular
 * - KHR_materials_transmission
 * - KHR_materials_iridescence
 * - KHR_materials_unlit
 * - KHR_materials_volume
 * - KHR_mesh_quantization
 * - KHR_meshopt_compression
 * - KHR_texture_basisu
 * - KHR_texture_transform
 * - EXT_materials_bump
 * - EXT_meshopt_compression
 * - EXT_mesh_gpu_instancing
 * - EXT_texture_avif
 * - EXT_texture_webp
 *
 * The following glTF 2.0 extensions are supported by separately registered plugins:
 * - KHR_gaussian_splatting
 * - [KHR_materials_variants](https://github.com/takahirox/three-gltf-extensions)
 * - [MSFT_texture_dds](https://github.com/takahirox/three-gltf-extensions)
 * - [KHR_animation_pointer](https://github.com/needle-tools/three-animation-pointer)
 * - [NEEDLE_progressive](https://github.com/needle-tools/gltf-progressive)
 *
 * ```js
 * const loader = new GLTFLoader();
 *
 * // Optional: Provide a DRACOLoader instance to decode compressed mesh data
 * const dracoLoader = new DRACOLoader();
 * dracoLoader.setDecoderPath( '/examples/jsm/libs/draco/' );
 * loader.setDRACOLoader( dracoLoader );
 *
 * const gltf = await loader.loadAsync( 'models/gltf/duck/duck.gltf' );
 * scene.add( gltf.scene );
 * ```
 *
 * @augments Loader
 * @three_import import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
 */
class GLTFLoader extends __WEBPACK_EXTERNAL_MODULE_three_Loader__ {

	/**
	 * Constructs a new glTF loader.
	 *
	 * @param {LoadingManager} [manager] - The loading manager.
	 */
	constructor( manager ) {

		super( manager );

		this.dracoLoader = null;
		this.ktx2Loader = null;
		this.meshoptDecoder = null;

		this.pluginCallbacks = [];

		this.register( function ( parser ) {

			return new GLTFMaterialsClearcoatExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsDispersionExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFTextureBasisUExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFTextureWebPExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFTextureAVIFExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsSheenExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsTransmissionExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsVolumeExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsIorExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsEmissiveStrengthExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsSpecularExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsIridescenceExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsAnisotropyExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMaterialsBumpExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFLightsExtension( parser );

		} );

		this.register( function ( parser ) {

			return new GLTFMeshoptCompression( parser, EXTENSIONS.EXT_MESHOPT_COMPRESSION );

		} );

		this.register( function ( parser ) {

			return new GLTFMeshoptCompression( parser, EXTENSIONS.KHR_MESHOPT_COMPRESSION );

		} );

		this.register( function ( parser ) {

			return new GLTFMeshGpuInstancing( parser );

		} );

	}

	/**
	 * Starts loading from the given URL and passes the loaded glTF asset
	 * to the `onLoad()` callback.
	 *
	 * @param {string} url - The path/URL of the file to be loaded. This can also be a data URI.
	 * @param {function(GLTFLoader~LoadObject)} onLoad - Executed when the loading process has been finished.
	 * @param {onProgressCallback} onProgress - Executed while the loading is in progress.
	 * @param {onErrorCallback} onError - Executed when errors occur.
	 */
	load( url, onLoad, onProgress, onError ) {

		const scope = this;

		let resourcePath;

		if ( this.resourcePath !== '' ) {

			resourcePath = this.resourcePath;

		} else if ( this.path !== '' ) {

			// If a base path is set, resources will be relative paths from that plus the relative path of the gltf file
			// Example  path = 'https://my-cnd-server.com/', url = 'assets/models/model.gltf'
			// resourcePath = 'https://my-cnd-server.com/assets/models/'
			// referenced resource 'model.bin' will be loaded from 'https://my-cnd-server.com/assets/models/model.bin'
			// referenced resource '../textures/texture.png' will be loaded from 'https://my-cnd-server.com/assets/textures/texture.png'
			const relativeUrl = __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__.extractUrlBase( url );
			resourcePath = __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__.resolveURL( relativeUrl, this.path );

		} else {

			resourcePath = __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__.extractUrlBase( url );

		}

		// Tells the LoadingManager to track an extra item, which resolves after
		// the model is fully loaded. This means the count of items loaded will
		// be incorrect, but ensures manager.onLoad() does not fire early.
		this.manager.itemStart( url );

		const _onError = function ( e ) {

			if ( onError ) {

				onError( e );

			} else {

				console.error( e );

			}

			scope.manager.itemError( url );
			scope.manager.itemEnd( url );

		};

		const loader = new __WEBPACK_EXTERNAL_MODULE_three_FileLoader__( this.manager );

		loader.setPath( this.path );
		loader.setResponseType( 'arraybuffer' );
		loader.setRequestHeader( this.requestHeader );
		loader.setWithCredentials( this.withCredentials );

		loader.load( url, function ( data ) {

			try {

				scope.parse( data, resourcePath, function ( gltf ) {

					onLoad( gltf );

					scope.manager.itemEnd( url );

				}, _onError );

			} catch ( e ) {

				_onError( e );

			}

		}, onProgress, _onError );

	}

	/**
	 * Sets the given Draco loader to this loader. Required for decoding assets
	 * compressed with the `KHR_draco_mesh_compression` extension.
	 *
	 * @param {DRACOLoader} dracoLoader - The Draco loader to set.
	 * @return {GLTFLoader} A reference to this loader.
	 */
	setDRACOLoader( dracoLoader ) {

		this.dracoLoader = dracoLoader;
		return this;

	}

	/**
	 * Sets the given KTX2 loader to this loader. Required for loading KTX2
	 * compressed textures.
	 *
	 * @param {KTX2Loader} ktx2Loader - The KTX2 loader to set.
	 * @return {GLTFLoader} A reference to this loader.
	 */
	setKTX2Loader( ktx2Loader ) {

		this.ktx2Loader = ktx2Loader;
		return this;

	}

	/**
	 * Sets the given meshopt decoder. Required for decoding assets
	 * compressed with the `EXT_meshopt_compression` extension.
	 *
	 * @param {Object} meshoptDecoder - The meshopt decoder to set.
	 * @return {GLTFLoader} A reference to this loader.
	 */
	setMeshoptDecoder( meshoptDecoder ) {

		this.meshoptDecoder = meshoptDecoder;
		return this;

	}

	/**
	 * Registers a plugin callback. This API is internally used to implement the various
	 * glTF extensions but can also used by third-party code to add additional logic
	 * to the loader.
	 *
	 * @param {function(parser:GLTFParser)} callback - The callback function to register.
	 * @return {GLTFLoader} A reference to this loader.
	 */
	register( callback ) {

		if ( this.pluginCallbacks.indexOf( callback ) === - 1 ) {

			this.pluginCallbacks.push( callback );

		}

		return this;

	}

	/**
	 * Unregisters a plugin callback.
	 *
	 * @param {Function} callback - The callback function to unregister.
	 * @return {GLTFLoader} A reference to this loader.
	 */
	unregister( callback ) {

		if ( this.pluginCallbacks.indexOf( callback ) !== - 1 ) {

			this.pluginCallbacks.splice( this.pluginCallbacks.indexOf( callback ), 1 );

		}

		return this;

	}

	/**
	 * Parses the given glTF data and returns the resulting group.
	 *
	 * @param {string|ArrayBuffer} data - The raw glTF data.
	 * @param {string} path - The URL base path.
	 * @param {function(GLTFLoader~LoadObject)} onLoad - Executed when the loading process has been finished.
	 * @param {onErrorCallback} onError - Executed when errors occur.
	 */
	parse( data, path, onLoad, onError ) {

		let json;
		const extensions = {};
		const plugins = {};
		const textDecoder = new TextDecoder();

		if ( typeof data === 'string' ) {

			json = JSON.parse( data );

		} else if ( data instanceof ArrayBuffer ) {

			const magic = textDecoder.decode( new Uint8Array( data, 0, 4 ) );

			if ( magic === BINARY_EXTENSION_HEADER_MAGIC ) {

				try {

					extensions[ EXTENSIONS.KHR_BINARY_GLTF ] = new GLTFBinaryExtension( data );

				} catch ( error ) {

					if ( onError ) onError( error );
					return;

				}

				json = JSON.parse( extensions[ EXTENSIONS.KHR_BINARY_GLTF ].content );

			} else {

				json = JSON.parse( textDecoder.decode( data ) );

			}

		} else {

			json = data;

		}

		if ( json.asset === undefined || json.asset.version[ 0 ] < 2 ) {

			if ( onError ) onError( new Error( 'THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported.' ) );
			return;

		}

		const parser = new GLTFParser( json, {

			path: path || this.resourcePath || '',
			crossOrigin: this.crossOrigin,
			requestHeader: this.requestHeader,
			manager: this.manager,
			ktx2Loader: this.ktx2Loader,
			meshoptDecoder: this.meshoptDecoder

		} );

		parser.fileLoader.setRequestHeader( this.requestHeader );

		for ( let i = 0; i < this.pluginCallbacks.length; i ++ ) {

			const plugin = this.pluginCallbacks[ i ]( parser );

			if ( ! plugin.name ) console.error( 'THREE.GLTFLoader: Invalid plugin found: missing name' );

			plugins[ plugin.name ] = plugin;

			// Workaround to avoid determining as unknown extension
			// in addUnknownExtensionsToUserData().
			// Remove this workaround if we move all the existing
			// extension handlers to plugin system
			extensions[ plugin.name ] = true;

		}

		if ( json.extensionsUsed ) {

			for ( let i = 0; i < json.extensionsUsed.length; ++ i ) {

				const extensionName = json.extensionsUsed[ i ];
				const extensionsRequired = json.extensionsRequired || [];

				switch ( extensionName ) {

					case EXTENSIONS.KHR_MATERIALS_UNLIT:
						extensions[ extensionName ] = new GLTFMaterialsUnlitExtension();
						break;

					case EXTENSIONS.KHR_DRACO_MESH_COMPRESSION:
						extensions[ extensionName ] = new GLTFDracoMeshCompressionExtension( json, this.dracoLoader );
						break;

					case EXTENSIONS.KHR_TEXTURE_TRANSFORM:
						extensions[ extensionName ] = new GLTFTextureTransformExtension();
						break;

					case EXTENSIONS.KHR_MESH_QUANTIZATION:
						extensions[ extensionName ] = new GLTFMeshQuantizationExtension();
						break;

					default:

						if ( extensionsRequired.indexOf( extensionName ) >= 0 && plugins[ extensionName ] === undefined ) {

							console.warn( 'THREE.GLTFLoader: Unknown extension "' + extensionName + '".' );

						}

				}

			}

		}

		parser.setExtensions( extensions );
		parser.setPlugins( plugins );
		parser.parse( onLoad, onError );

	}

	/**
	 * Async version of {@link GLTFLoader#parse}.
	 *
	 * @async
	 * @param {string|ArrayBuffer} data - The raw glTF data.
	 * @param {string} path - The URL base path.
	 * @return {Promise<GLTFLoader~LoadObject>} A Promise that resolves with the loaded glTF when the parsing has been finished.
	 */
	parseAsync( data, path ) {

		const scope = this;

		return new Promise( function ( resolve, reject ) {

			scope.parse( data, path, resolve, reject );

		} );

	}

}

/* GLTFREGISTRY */

function GLTFRegistry() {

	let objects = {};

	return	{

		get: function ( key ) {

			return objects[ key ];

		},

		add: function ( key, object ) {

			objects[ key ] = object;

		},

		remove: function ( key ) {

			delete objects[ key ];

		},

		removeAll: function () {

			objects = {};

		}

	};

}

/*********************************/
/********** EXTENSIONS ***********/
/*********************************/

function getMaterialExtension( parser, materialIndex, extensionName ) {

	const materialDef = parser.json.materials[ materialIndex ];

	if ( materialDef.extensions && materialDef.extensions[ extensionName ] ) {

		return materialDef.extensions[ extensionName ];

	}

	return null;

}

const EXTENSIONS = {
	KHR_BINARY_GLTF: 'KHR_binary_glTF',
	KHR_DRACO_MESH_COMPRESSION: 'KHR_draco_mesh_compression',
	KHR_LIGHTS_PUNCTUAL: 'KHR_lights_punctual',
	KHR_MATERIALS_CLEARCOAT: 'KHR_materials_clearcoat',
	KHR_MATERIALS_DISPERSION: 'KHR_materials_dispersion',
	KHR_MATERIALS_IOR: 'KHR_materials_ior',
	KHR_MATERIALS_SHEEN: 'KHR_materials_sheen',
	KHR_MATERIALS_SPECULAR: 'KHR_materials_specular',
	KHR_MATERIALS_TRANSMISSION: 'KHR_materials_transmission',
	KHR_MATERIALS_IRIDESCENCE: 'KHR_materials_iridescence',
	KHR_MATERIALS_ANISOTROPY: 'KHR_materials_anisotropy',
	KHR_MATERIALS_UNLIT: 'KHR_materials_unlit',
	KHR_MATERIALS_VOLUME: 'KHR_materials_volume',
	KHR_TEXTURE_BASISU: 'KHR_texture_basisu',
	KHR_TEXTURE_TRANSFORM: 'KHR_texture_transform',
	KHR_MESH_QUANTIZATION: 'KHR_mesh_quantization',
	KHR_MATERIALS_EMISSIVE_STRENGTH: 'KHR_materials_emissive_strength',
	EXT_MATERIALS_BUMP: 'EXT_materials_bump',
	EXT_TEXTURE_WEBP: 'EXT_texture_webp',
	EXT_TEXTURE_AVIF: 'EXT_texture_avif',
	EXT_MESHOPT_COMPRESSION: 'EXT_meshopt_compression',
	KHR_MESHOPT_COMPRESSION: 'KHR_meshopt_compression',
	EXT_MESH_GPU_INSTANCING: 'EXT_mesh_gpu_instancing'
};

/**
 * Punctual Lights Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_lights_punctual
 *
 * @private
 */
class GLTFLightsExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_LIGHTS_PUNCTUAL;

		// Object3D instance caches
		this.cache = { refs: {}, uses: {} };

	}

	_markDefs() {

		const parser = this.parser;
		const nodeDefs = this.parser.json.nodes || [];

		for ( let nodeIndex = 0, nodeLength = nodeDefs.length; nodeIndex < nodeLength; nodeIndex ++ ) {

			const nodeDef = nodeDefs[ nodeIndex ];

			if ( nodeDef.extensions
					&& nodeDef.extensions[ this.name ]
					&& nodeDef.extensions[ this.name ].light !== undefined ) {

				parser._addNodeRef( this.cache, nodeDef.extensions[ this.name ].light );

			}

		}

	}

	_loadLight( lightIndex ) {

		const parser = this.parser;
		const cacheKey = 'light:' + lightIndex;
		let dependency = parser.cache.get( cacheKey );

		if ( dependency ) return dependency;

		const json = parser.json;
		const extensions = ( json.extensions && json.extensions[ this.name ] ) || {};
		const lightDefs = extensions.lights || [];
		const lightDef = lightDefs[ lightIndex ];
		let lightNode;

		const color = new __WEBPACK_EXTERNAL_MODULE_three_Color__( 0xffffff );

		if ( lightDef.color !== undefined ) color.setRGB( lightDef.color[ 0 ], lightDef.color[ 1 ], lightDef.color[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );

		const range = lightDef.range !== undefined ? lightDef.range : 0;

		switch ( lightDef.type ) {

			case 'directional':
				lightNode = new __WEBPACK_EXTERNAL_MODULE_three_DirectionalLight__( color );
				lightNode.target.position.set( 0, 0, - 1 );
				lightNode.add( lightNode.target );
				break;

			case 'point':
				lightNode = new __WEBPACK_EXTERNAL_MODULE_three_PointLight__( color );
				lightNode.distance = range;
				break;

			case 'spot':
				lightNode = new __WEBPACK_EXTERNAL_MODULE_three_SpotLight__( color );
				lightNode.distance = range;
				// Handle spotlight properties.
				lightDef.spot = lightDef.spot || {};
				lightDef.spot.innerConeAngle = lightDef.spot.innerConeAngle !== undefined ? lightDef.spot.innerConeAngle : 0;
				lightDef.spot.outerConeAngle = lightDef.spot.outerConeAngle !== undefined ? lightDef.spot.outerConeAngle : Math.PI / 4.0;
				lightNode.angle = lightDef.spot.outerConeAngle;
				lightNode.penumbra = 1.0 - lightDef.spot.innerConeAngle / lightDef.spot.outerConeAngle;
				lightNode.target.position.set( 0, 0, - 1 );
				lightNode.add( lightNode.target );
				break;

			default:
				throw new Error( 'THREE.GLTFLoader: Unexpected light type: ' + lightDef.type );

		}

		// Some lights (e.g. spot) default to a position other than the origin. Reset the position
		// here, because node-level parsing will only override position if explicitly specified.
		lightNode.position.set( 0, 0, 0 );

		assignExtrasToUserData( lightNode, lightDef );

		if ( lightDef.intensity !== undefined ) lightNode.intensity = lightDef.intensity;

		lightNode.name = parser.createUniqueName( lightDef.name || ( 'light_' + lightIndex ) );

		dependency = Promise.resolve( lightNode );

		parser.cache.add( cacheKey, dependency );

		return dependency;

	}

	getDependency( type, index ) {

		if ( type !== 'light' ) return;

		return this._loadLight( index );

	}

	createNodeAttachment( nodeIndex ) {

		const self = this;
		const parser = this.parser;
		const json = parser.json;
		const nodeDef = json.nodes[ nodeIndex ];
		const lightDef = ( nodeDef.extensions && nodeDef.extensions[ this.name ] ) || {};
		const lightIndex = lightDef.light;

		if ( lightIndex === undefined ) return null;

		return this._loadLight( lightIndex ).then( function ( light ) {

			return parser._getNodeRef( self.cache, lightIndex, light );

		} );

	}

}

/**
 * Unlit Materials Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_unlit
 *
 * @private
 */
class GLTFMaterialsUnlitExtension {

	constructor() {

		this.name = EXTENSIONS.KHR_MATERIALS_UNLIT;

	}

	getMaterialType() {

		return __WEBPACK_EXTERNAL_MODULE_three_MeshBasicMaterial__;

	}

	extendParams( materialParams, materialDef, parser ) {

		const pending = [];

		materialParams.color = new __WEBPACK_EXTERNAL_MODULE_three_Color__( 1.0, 1.0, 1.0 );
		materialParams.opacity = 1.0;

		const metallicRoughness = materialDef.pbrMetallicRoughness;

		if ( metallicRoughness ) {

			if ( Array.isArray( metallicRoughness.baseColorFactor ) ) {

				const array = metallicRoughness.baseColorFactor;

				materialParams.color.setRGB( array[ 0 ], array[ 1 ], array[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );
				materialParams.opacity = array[ 3 ];

			}

			if ( metallicRoughness.baseColorTexture !== undefined ) {

				pending.push( parser.assignTexture( materialParams, 'map', metallicRoughness.baseColorTexture, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ ) );

			}

		}

		return Promise.all( pending );

	}

}

/**
 * Materials Emissive Strength Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/blob/5768b3ce0ef32bc39cdf1bef10b948586635ead3/extensions/2.0/Khronos/KHR_materials_emissive_strength/README.md
 *
 * @private
 */
class GLTFMaterialsEmissiveStrengthExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_EMISSIVE_STRENGTH;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		if ( extension.emissiveStrength !== undefined ) {

			materialParams.emissiveIntensity = extension.emissiveStrength;

		}

		return Promise.resolve();

	}

}

/**
 * Clearcoat Materials Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_clearcoat
 *
 * @private
 */
class GLTFMaterialsClearcoatExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_CLEARCOAT;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		if ( extension.clearcoatFactor !== undefined ) {

			materialParams.clearcoat = extension.clearcoatFactor;

		}

		if ( extension.clearcoatTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'clearcoatMap', extension.clearcoatTexture ) );

		}

		if ( extension.clearcoatRoughnessFactor !== undefined ) {

			materialParams.clearcoatRoughness = extension.clearcoatRoughnessFactor;

		}

		if ( extension.clearcoatRoughnessTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'clearcoatRoughnessMap', extension.clearcoatRoughnessTexture ) );

		}

		if ( extension.clearcoatNormalTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'clearcoatNormalMap', extension.clearcoatNormalTexture ) );

			if ( extension.clearcoatNormalTexture.scale !== undefined ) {

				const scale = extension.clearcoatNormalTexture.scale;

				materialParams.clearcoatNormalScale = new __WEBPACK_EXTERNAL_MODULE_three_Vector2__( scale, scale );

			}

		}

		return Promise.all( pending );

	}

}

/**
 * Materials dispersion Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_materials_dispersion
 *
 * @private
 */
class GLTFMaterialsDispersionExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_DISPERSION;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		materialParams.dispersion = extension.dispersion !== undefined ? extension.dispersion : 0;

		return Promise.resolve();

	}

}

/**
 * Iridescence Materials Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_iridescence
 *
 * @private
 */
class GLTFMaterialsIridescenceExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_IRIDESCENCE;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		if ( extension.iridescenceFactor !== undefined ) {

			materialParams.iridescence = extension.iridescenceFactor;

		}

		if ( extension.iridescenceTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'iridescenceMap', extension.iridescenceTexture ) );

		}

		if ( extension.iridescenceIor !== undefined ) {

			materialParams.iridescenceIOR = extension.iridescenceIor;

		}

		if ( materialParams.iridescenceThicknessRange === undefined ) {

			materialParams.iridescenceThicknessRange = [ 100, 400 ];

		}

		if ( extension.iridescenceThicknessMinimum !== undefined ) {

			materialParams.iridescenceThicknessRange[ 0 ] = extension.iridescenceThicknessMinimum;

		}

		if ( extension.iridescenceThicknessMaximum !== undefined ) {

			materialParams.iridescenceThicknessRange[ 1 ] = extension.iridescenceThicknessMaximum;

		}

		if ( extension.iridescenceThicknessTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'iridescenceThicknessMap', extension.iridescenceThicknessTexture ) );

		}

		return Promise.all( pending );

	}

}

/**
 * Sheen Materials Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_materials_sheen
 *
 * @private
 */
class GLTFMaterialsSheenExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_SHEEN;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		materialParams.sheenColor = new __WEBPACK_EXTERNAL_MODULE_three_Color__( 0, 0, 0 );
		materialParams.sheenRoughness = 0;
		materialParams.sheen = 1;

		if ( extension.sheenColorFactor !== undefined ) {

			const colorFactor = extension.sheenColorFactor;
			materialParams.sheenColor.setRGB( colorFactor[ 0 ], colorFactor[ 1 ], colorFactor[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );

		}

		if ( extension.sheenRoughnessFactor !== undefined ) {

			materialParams.sheenRoughness = extension.sheenRoughnessFactor;

		}

		if ( extension.sheenColorTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'sheenColorMap', extension.sheenColorTexture, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ ) );

		}

		if ( extension.sheenRoughnessTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'sheenRoughnessMap', extension.sheenRoughnessTexture ) );

		}

		return Promise.all( pending );

	}

}

/**
 * Transmission Materials Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_transmission
 * Draft: https://github.com/KhronosGroup/glTF/pull/1698
 *
 * @private
 */
class GLTFMaterialsTransmissionExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_TRANSMISSION;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		if ( extension.transmissionFactor !== undefined ) {

			materialParams.transmission = extension.transmissionFactor;

		}

		if ( extension.transmissionTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'transmissionMap', extension.transmissionTexture ) );

		}

		return Promise.all( pending );

	}

}

/**
 * Materials Volume Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_volume
 *
 * @private
 */
class GLTFMaterialsVolumeExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_VOLUME;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		materialParams.thickness = extension.thicknessFactor !== undefined ? extension.thicknessFactor : 0;

		if ( extension.thicknessTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'thicknessMap', extension.thicknessTexture ) );

		}

		materialParams.attenuationDistance = extension.attenuationDistance || Infinity;

		const colorArray = extension.attenuationColor || [ 1, 1, 1 ];
		materialParams.attenuationColor = new __WEBPACK_EXTERNAL_MODULE_three_Color__().setRGB( colorArray[ 0 ], colorArray[ 1 ], colorArray[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );

		return Promise.all( pending );

	}

}

/**
 * Materials ior Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_ior
 *
 * @private
 */
class GLTFMaterialsIorExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_IOR;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		materialParams.ior = extension.ior !== undefined ? extension.ior : 1.5;

		if ( materialParams.ior === 0 ) materialParams.ior = 1000; // see #26167

		return Promise.resolve();

	}

}

/**
 * Materials specular Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_specular
 *
 * @private
 */
class GLTFMaterialsSpecularExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_SPECULAR;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		materialParams.specularIntensity = extension.specularFactor !== undefined ? extension.specularFactor : 1.0;

		if ( extension.specularTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'specularIntensityMap', extension.specularTexture ) );

		}

		const colorArray = extension.specularColorFactor || [ 1, 1, 1 ];
		materialParams.specularColor = new __WEBPACK_EXTERNAL_MODULE_three_Color__().setRGB( colorArray[ 0 ], colorArray[ 1 ], colorArray[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );

		if ( extension.specularColorTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'specularColorMap', extension.specularColorTexture, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ ) );

		}

		return Promise.all( pending );

	}

}


/**
 * Materials bump Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/EXT_materials_bump
 *
 * @private
 */
class GLTFMaterialsBumpExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.EXT_MATERIALS_BUMP;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		materialParams.bumpScale = extension.bumpFactor !== undefined ? extension.bumpFactor : 1.0;

		if ( extension.bumpTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'bumpMap', extension.bumpTexture ) );

		}

		return Promise.all( pending );

	}

}

/**
 * Materials anisotropy Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_materials_anisotropy
 *
 * @private
 */
class GLTFMaterialsAnisotropyExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_MATERIALS_ANISOTROPY;

	}

	getMaterialType( materialIndex ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		return extension !== null ? __WEBPACK_EXTERNAL_MODULE_three_MeshPhysicalMaterial__ : null;

	}

	extendMaterialParams( materialIndex, materialParams ) {

		const extension = getMaterialExtension( this.parser, materialIndex, this.name );

		if ( extension === null ) return Promise.resolve();

		const pending = [];

		if ( extension.anisotropyStrength !== undefined ) {

			materialParams.anisotropy = extension.anisotropyStrength;

		}

		if ( extension.anisotropyRotation !== undefined ) {

			materialParams.anisotropyRotation = extension.anisotropyRotation;

		}

		if ( extension.anisotropyTexture !== undefined ) {

			pending.push( this.parser.assignTexture( materialParams, 'anisotropyMap', extension.anisotropyTexture ) );

		}

		return Promise.all( pending );

	}

}

/**
 * BasisU Texture Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_texture_basisu
 *
 * @private
 */
class GLTFTextureBasisUExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.KHR_TEXTURE_BASISU;

	}

	loadTexture( textureIndex ) {

		const parser = this.parser;
		const json = parser.json;

		const textureDef = json.textures[ textureIndex ];

		if ( ! textureDef.extensions || ! textureDef.extensions[ this.name ] ) {

			return null;

		}

		const extension = textureDef.extensions[ this.name ];
		const loader = parser.options.ktx2Loader;

		if ( ! loader ) {

			if ( json.extensionsRequired && json.extensionsRequired.indexOf( this.name ) >= 0 ) {

				throw new Error( 'THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures' );

			} else {

				// Assumes that the extension is optional and that a fallback texture is present
				return null;

			}

		}

		return parser.loadTextureImage( textureIndex, extension.source, loader );

	}

}

/**
 * WebP Texture Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/EXT_texture_webp
 *
 * @private
 */
class GLTFTextureWebPExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.EXT_TEXTURE_WEBP;

	}

	loadTexture( textureIndex ) {

		const name = this.name;
		const parser = this.parser;
		const json = parser.json;

		const textureDef = json.textures[ textureIndex ];

		if ( ! textureDef.extensions || ! textureDef.extensions[ name ] ) {

			return null;

		}

		const extension = textureDef.extensions[ name ];
		const source = json.images[ extension.source ];

		let loader = parser.textureLoader;
		if ( source.uri ) {

			const handler = parser.options.manager.getHandler( source.uri );
			if ( handler !== null ) loader = handler;

		}

		return parser.loadTextureImage( textureIndex, extension.source, loader );

	}

}

/**
 * AVIF Texture Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/EXT_texture_avif
 *
 * @private
 */
class GLTFTextureAVIFExtension {

	constructor( parser ) {

		this.parser = parser;
		this.name = EXTENSIONS.EXT_TEXTURE_AVIF;

	}

	loadTexture( textureIndex ) {

		const name = this.name;
		const parser = this.parser;
		const json = parser.json;

		const textureDef = json.textures[ textureIndex ];

		if ( ! textureDef.extensions || ! textureDef.extensions[ name ] ) {

			return null;

		}

		const extension = textureDef.extensions[ name ];
		const source = json.images[ extension.source ];

		let loader = parser.textureLoader;
		if ( source.uri ) {

			const handler = parser.options.manager.getHandler( source.uri );
			if ( handler !== null ) loader = handler;

		}

		return parser.loadTextureImage( textureIndex, extension.source, loader );

	}

}

/**
 * meshopt BufferView Compression Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/EXT_meshopt_compression
 *
 * @private
 */
class GLTFMeshoptCompression {

	constructor( parser, name ) {

		this.name = name;
		this.parser = parser;

	}

	loadBufferView( index ) {

		const json = this.parser.json;
		const bufferView = json.bufferViews[ index ];

		if ( bufferView.extensions && bufferView.extensions[ this.name ] ) {

			const extensionDef = bufferView.extensions[ this.name ];

			const buffer = this.parser.getDependency( 'buffer', extensionDef.buffer );
			const decoder = this.parser.options.meshoptDecoder;

			if ( ! decoder || ! decoder.supported ) {

				if ( json.extensionsRequired && json.extensionsRequired.indexOf( this.name ) >= 0 ) {

					throw new Error( 'THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files' );

				} else {

					// Assumes that the extension is optional and that fallback buffer data is present
					return null;

				}

			}

			return buffer.then( function ( res ) {

				const byteOffset = extensionDef.byteOffset || 0;
				const byteLength = extensionDef.byteLength || 0;

				const count = extensionDef.count;
				const stride = extensionDef.byteStride;

				const source = new Uint8Array( res, byteOffset, byteLength );

				if ( decoder.decodeGltfBufferAsync ) {

					return decoder.decodeGltfBufferAsync( count, stride, source, extensionDef.mode, extensionDef.filter ).then( function ( res ) {

						return res.buffer;

					} );

				} else {

					// Support for MeshoptDecoder 0.18 or earlier, without decodeGltfBufferAsync
					return decoder.ready.then( function () {

						const result = new ArrayBuffer( count * stride );
						decoder.decodeGltfBuffer( new Uint8Array( result ), count, stride, source, extensionDef.mode, extensionDef.filter );
						return result;

					} );

				}

			} );

		} else {

			return null;

		}

	}

}

/**
 * GPU Instancing Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/EXT_mesh_gpu_instancing
 *
 * @private
 */
class GLTFMeshGpuInstancing {

	constructor( parser ) {

		this.name = EXTENSIONS.EXT_MESH_GPU_INSTANCING;
		this.parser = parser;

	}

	createNodeMesh( nodeIndex ) {

		const json = this.parser.json;
		const nodeDef = json.nodes[ nodeIndex ];

		if ( ! nodeDef.extensions || ! nodeDef.extensions[ this.name ] ||
			nodeDef.mesh === undefined ) {

			return null;

		}

		const meshDef = json.meshes[ nodeDef.mesh ];

		// No Points or Lines + Instancing support yet

		for ( const primitive of meshDef.primitives ) {

			if ( primitive.mode !== WEBGL_CONSTANTS.TRIANGLES &&
				 primitive.mode !== WEBGL_CONSTANTS.TRIANGLE_STRIP &&
				 primitive.mode !== WEBGL_CONSTANTS.TRIANGLE_FAN &&
				 primitive.mode !== undefined ) {

				return null;

			}

		}

		const extensionDef = nodeDef.extensions[ this.name ];
		const attributesDef = extensionDef.attributes;

		// @TODO: Can we support InstancedMesh + SkinnedMesh?

		const pending = [];
		const attributes = {};

		for ( const key in attributesDef ) {

			pending.push( this.parser.getDependency( 'accessor', attributesDef[ key ] ).then( accessor => {

				attributes[ key ] = accessor;
				return attributes[ key ];

			} ) );

		}

		if ( pending.length < 1 ) {

			return null;

		}

		pending.push( this.parser.createNodeMesh( nodeIndex ) );

		return Promise.all( pending ).then( results => {

			const nodeObject = results.pop();
			const meshes = nodeObject.isGroup ? nodeObject.children : [ nodeObject ];
			const count = results[ 0 ].count; // All attribute counts should be same
			const instancedMeshes = [];

			for ( const mesh of meshes ) {

				// Temporal variables
				const m = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
				const p = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
				const q = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__();
				const s = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( 1, 1, 1 );

				const instancedMesh = new __WEBPACK_EXTERNAL_MODULE_three_InstancedMesh__( mesh.geometry, mesh.material, count );

				for ( let i = 0; i < count; i ++ ) {

					if ( attributes.TRANSLATION ) {

						p.fromBufferAttribute( attributes.TRANSLATION, i );

					}

					if ( attributes.ROTATION ) {

						q.fromBufferAttribute( attributes.ROTATION, i );

					}

					if ( attributes.SCALE ) {

						s.fromBufferAttribute( attributes.SCALE, i );

					}

					instancedMesh.setMatrixAt( i, m.compose( p, q, s ) );

				}

				// Add instance attributes to the geometry, excluding TRS.

				let instanceGeometry = null;

				for ( const attributeName in attributes ) {

					if ( attributeName === '_COLOR_0' ) {

						const attr = attributes[ attributeName ];
						instancedMesh.instanceColor = new __WEBPACK_EXTERNAL_MODULE_three_InstancedBufferAttribute__( attr.array, attr.itemSize, attr.normalized );

					} else if ( attributeName !== 'TRANSLATION' &&
						 attributeName !== 'ROTATION' &&
						 attributeName !== 'SCALE' ) {

						if ( instanceGeometry === null ) {

							// do a shallow clone of the goemetry so per-instance data are not shared

							const source = instancedMesh.geometry;
							instanceGeometry = new __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__();
							instanceGeometry.name = source.name;

							for ( const name in source.attributes ) instanceGeometry.setAttribute( name, source.attributes[ name ] );
							for ( const name in source.morphAttributes ) instanceGeometry.morphAttributes[ name ] = source.morphAttributes[ name ];
							if ( source.index !== null ) instanceGeometry.setIndex( source.index );

							instanceGeometry.morphTargetsRelative = source.morphTargetsRelative;

							for ( const group of source.groups ) instanceGeometry.addGroup( group.start, group.count, group.materialIndex );

							if ( source.boundingBox !== null ) instanceGeometry.boundingBox = source.boundingBox.clone();
							if ( source.boundingSphere !== null ) instanceGeometry.boundingSphere = source.boundingSphere.clone();

							instanceGeometry.drawRange.start = source.drawRange.start;
							instanceGeometry.drawRange.count = source.drawRange.count;

							instanceGeometry.userData = Object.assign( {}, source.userData );

							instancedMesh.geometry = instanceGeometry;

						}

						const attr = attributes[ attributeName ];
						instanceGeometry.setAttribute( attributeName, new __WEBPACK_EXTERNAL_MODULE_three_InstancedBufferAttribute__( attr.array, attr.itemSize, attr.normalized ) );

					}

				}

				// Just in case
				__WEBPACK_EXTERNAL_MODULE_three_Object3D__.prototype.copy.call( instancedMesh, mesh );

				this.parser.assignFinalMaterial( instancedMesh );

				instancedMeshes.push( instancedMesh );

			}

			if ( nodeObject.isGroup ) {

				nodeObject.clear();

				nodeObject.add( ... instancedMeshes );

				return nodeObject;

			}

			return instancedMeshes[ 0 ];

		} );

	}

}

/* BINARY EXTENSION */
const BINARY_EXTENSION_HEADER_MAGIC = 'glTF';
const BINARY_EXTENSION_HEADER_LENGTH = 12;
const BINARY_EXTENSION_CHUNK_TYPES = { JSON: 0x4E4F534A, BIN: 0x004E4942 };

class GLTFBinaryExtension {

	constructor( data ) {

		this.name = EXTENSIONS.KHR_BINARY_GLTF;
		this.content = null;
		this.body = null;

		const headerView = new DataView( data, 0, BINARY_EXTENSION_HEADER_LENGTH );
		const textDecoder = new TextDecoder();

		this.header = {
			magic: textDecoder.decode( new Uint8Array( data.slice( 0, 4 ) ) ),
			version: headerView.getUint32( 4, true ),
			length: headerView.getUint32( 8, true )
		};

		if ( this.header.magic !== BINARY_EXTENSION_HEADER_MAGIC ) {

			throw new Error( 'THREE.GLTFLoader: Unsupported glTF-Binary header.' );

		} else if ( this.header.version < 2.0 ) {

			throw new Error( 'THREE.GLTFLoader: Legacy binary file detected.' );

		}

		const chunkContentsLength = this.header.length - BINARY_EXTENSION_HEADER_LENGTH;
		const chunkView = new DataView( data, BINARY_EXTENSION_HEADER_LENGTH );
		let chunkIndex = 0;

		while ( chunkIndex < chunkContentsLength ) {

			const chunkLength = chunkView.getUint32( chunkIndex, true );
			chunkIndex += 4;

			const chunkType = chunkView.getUint32( chunkIndex, true );
			chunkIndex += 4;

			if ( chunkType === BINARY_EXTENSION_CHUNK_TYPES.JSON ) {

				const contentArray = new Uint8Array( data, BINARY_EXTENSION_HEADER_LENGTH + chunkIndex, chunkLength );
				this.content = textDecoder.decode( contentArray );

			} else if ( chunkType === BINARY_EXTENSION_CHUNK_TYPES.BIN ) {

				const byteOffset = BINARY_EXTENSION_HEADER_LENGTH + chunkIndex;
				this.body = data.slice( byteOffset, byteOffset + chunkLength );

			}

			// Clients must ignore chunks with unknown types.

			chunkIndex += chunkLength;

		}

		if ( this.content === null ) {

			throw new Error( 'THREE.GLTFLoader: JSON content not found.' );

		}

	}

}

/**
 * DRACO Mesh Compression Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_draco_mesh_compression
 *
 * @private
 */
class GLTFDracoMeshCompressionExtension {

	constructor( json, dracoLoader ) {

		if ( ! dracoLoader ) {

			throw new Error( 'THREE.GLTFLoader: No DRACOLoader instance provided.' );

		}

		this.name = EXTENSIONS.KHR_DRACO_MESH_COMPRESSION;
		this.json = json;
		this.dracoLoader = dracoLoader;
		this.dracoLoader.preload();

	}

	decodePrimitive( primitive, parser ) {

		const json = this.json;
		const dracoLoader = this.dracoLoader;
		const bufferViewIndex = primitive.extensions[ this.name ].bufferView;
		const gltfAttributeMap = primitive.extensions[ this.name ].attributes;
		const threeAttributeMap = {};
		const attributeNormalizedMap = {};
		const attributeTypeMap = {};

		for ( const attributeName in gltfAttributeMap ) {

			const threeAttributeName = ATTRIBUTES[ attributeName ] || attributeName.toLowerCase();

			threeAttributeMap[ threeAttributeName ] = gltfAttributeMap[ attributeName ];

		}

		for ( const attributeName in primitive.attributes ) {

			const threeAttributeName = ATTRIBUTES[ attributeName ] || attributeName.toLowerCase();

			if ( gltfAttributeMap[ attributeName ] !== undefined ) {

				const accessorDef = json.accessors[ primitive.attributes[ attributeName ] ];
				const componentType = WEBGL_COMPONENT_TYPES[ accessorDef.componentType ];

				attributeTypeMap[ threeAttributeName ] = componentType.name;
				attributeNormalizedMap[ threeAttributeName ] = accessorDef.normalized === true;

			}

		}

		return parser.getDependency( 'bufferView', bufferViewIndex ).then( function ( bufferView ) {

			return new Promise( function ( resolve, reject ) {

				dracoLoader.decodeDracoFile( bufferView, function ( geometry ) {

					for ( const attributeName in geometry.attributes ) {

						const attribute = geometry.attributes[ attributeName ];
						const normalized = attributeNormalizedMap[ attributeName ];

						if ( normalized !== undefined ) attribute.normalized = normalized;

					}

					resolve( geometry );

				}, threeAttributeMap, attributeTypeMap, __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__, reject );

			} );

		} );

	}

}

/**
 * Texture Transform Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_texture_transform
 *
 * @private
 */
class GLTFTextureTransformExtension {

	constructor() {

		this.name = EXTENSIONS.KHR_TEXTURE_TRANSFORM;

	}

	extendTexture( texture, transform ) {

		if ( ( transform.texCoord === undefined || transform.texCoord === texture.channel )
			&& transform.offset === undefined
			&& transform.rotation === undefined
			&& transform.scale === undefined ) {

			// See https://github.com/mrdoob/three.js/issues/21819.
			return texture;

		}

		texture = texture.clone();

		if ( transform.texCoord !== undefined ) {

			texture.channel = transform.texCoord;

		}

		if ( transform.offset !== undefined ) {

			texture.offset.fromArray( transform.offset );

		}

		if ( transform.rotation !== undefined ) {

			texture.rotation = transform.rotation;

		}

		if ( transform.scale !== undefined ) {

			texture.repeat.fromArray( transform.scale );

		}

		if ( transform.rotation !== undefined ) {

			// glTF's KHR_texture_transform order differs from three.js:
			// glTF defines the UV transform as T * R * S
			// three.js defines the UV transform as T * S * R
			//
			// To fix this, we need to override the matrix with the value computed per glTF spec
			// We still set the other fields so that you can inspect/export the resulting object.

			const c = Math.cos( texture.rotation );
			const s = Math.sin( texture.rotation );

			texture.matrix.set(
				texture.repeat.x * c, texture.repeat.y * s, texture.offset.x,
				- texture.repeat.x * s, texture.repeat.y * c, texture.offset.y,
				0, 0, 1
			);
			texture.matrixAutoUpdate = false;

		}

		texture.needsUpdate = true;

		return texture;

	}

}

/**
 * Mesh Quantization Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_mesh_quantization
 *
 * @private
 */
class GLTFMeshQuantizationExtension {

	constructor() {

		this.name = EXTENSIONS.KHR_MESH_QUANTIZATION;

	}

}

/*********************************/
/********** INTERPOLATION ********/
/*********************************/

// Spline Interpolation
// Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#appendix-c-spline-interpolation
class GLTFCubicSplineInterpolant extends __WEBPACK_EXTERNAL_MODULE_three_Interpolant__ {

	constructor( parameterPositions, sampleValues, sampleSize, resultBuffer ) {

		super( parameterPositions, sampleValues, sampleSize, resultBuffer );

	}

	copySampleValue_( index ) {

		// Copies a sample value to the result buffer. See description of glTF
		// CUBICSPLINE values layout in interpolate_() function below.

		const result = this.resultBuffer,
			values = this.sampleValues,
			valueSize = this.valueSize,
			offset = index * valueSize * 3 + valueSize;

		for ( let i = 0; i !== valueSize; i ++ ) {

			result[ i ] = values[ offset + i ];

		}

		return result;

	}

	interpolate_( i1, t0, t, t1 ) {

		const result = this.resultBuffer;
		const values = this.sampleValues;
		const stride = this.valueSize;

		const stride2 = stride * 2;
		const stride3 = stride * 3;

		const td = t1 - t0;

		const p = ( t - t0 ) / td;
		const pp = p * p;
		const ppp = pp * p;

		const offset1 = i1 * stride3;
		const offset0 = offset1 - stride3;

		const s2 = - 2 * ppp + 3 * pp;
		const s3 = ppp - pp;
		const s0 = 1 - s2;
		const s1 = s3 - pp + p;

		// Layout of keyframe output values for CUBICSPLINE animations:
		//   [ inTangent_1, splineVertex_1, outTangent_1, inTangent_2, splineVertex_2, ... ]
		for ( let i = 0; i !== stride; i ++ ) {

			const p0 = values[ offset0 + i + stride ]; // splineVertex_k
			const m0 = values[ offset0 + i + stride2 ] * td; // outTangent_k * (t_k+1 - t_k)
			const p1 = values[ offset1 + i + stride ]; // splineVertex_k+1
			const m1 = values[ offset1 + i ] * td; // inTangent_k+1 * (t_k+1 - t_k)

			result[ i ] = s0 * p0 + s1 * m0 + s2 * p1 + s3 * m1;

		}

		return result;

	}

}

const _quaternion = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__();

class GLTFCubicSplineQuaternionInterpolant extends GLTFCubicSplineInterpolant {

	interpolate_( i1, t0, t, t1 ) {

		const result = super.interpolate_( i1, t0, t, t1 );

		_quaternion.fromArray( result ).normalize().toArray( result );

		return result;

	}

}


/*********************************/
/********** INTERNALS ************/
/*********************************/

/* CONSTANTS */

const WEBGL_CONSTANTS = {
	FLOAT: 5126,
	//FLOAT_MAT2: 35674,
	FLOAT_MAT3: 35675,
	FLOAT_MAT4: 35676,
	FLOAT_VEC2: 35664,
	FLOAT_VEC3: 35665,
	FLOAT_VEC4: 35666,
	LINEAR: 9729,
	REPEAT: 10497,
	SAMPLER_2D: 35678,
	POINTS: 0,
	LINES: 1,
	LINE_LOOP: 2,
	LINE_STRIP: 3,
	TRIANGLES: 4,
	TRIANGLE_STRIP: 5,
	TRIANGLE_FAN: 6,
	UNSIGNED_BYTE: 5121,
	UNSIGNED_SHORT: 5123
};

const WEBGL_COMPONENT_TYPES = {
	5120: Int8Array,
	5121: Uint8Array,
	5122: Int16Array,
	5123: Uint16Array,
	5125: Uint32Array,
	5126: Float32Array
};

const WEBGL_FILTERS = {
	9728: __WEBPACK_EXTERNAL_MODULE_three_NearestFilter__,
	9729: __WEBPACK_EXTERNAL_MODULE_three_LinearFilter__,
	9984: __WEBPACK_EXTERNAL_MODULE_three_NearestMipmapNearestFilter__,
	9985: __WEBPACK_EXTERNAL_MODULE_three_LinearMipmapNearestFilter__,
	9986: __WEBPACK_EXTERNAL_MODULE_three_NearestMipmapLinearFilter__,
	9987: __WEBPACK_EXTERNAL_MODULE_three_LinearMipmapLinearFilter__
};

const WEBGL_WRAPPINGS = {
	33071: __WEBPACK_EXTERNAL_MODULE_three_ClampToEdgeWrapping__,
	33648: __WEBPACK_EXTERNAL_MODULE_three_MirroredRepeatWrapping__,
	10497: __WEBPACK_EXTERNAL_MODULE_three_RepeatWrapping__
};

const WEBGL_TYPE_SIZES = {
	'SCALAR': 1,
	'VEC2': 2,
	'VEC3': 3,
	'VEC4': 4,
	'MAT2': 4,
	'MAT3': 9,
	'MAT4': 16
};

const ATTRIBUTES = {
	POSITION: 'position',
	NORMAL: 'normal',
	TANGENT: 'tangent',
	TEXCOORD_0: 'uv',
	TEXCOORD_1: 'uv1',
	TEXCOORD_2: 'uv2',
	TEXCOORD_3: 'uv3',
	COLOR_0: 'color',
	WEIGHTS_0: 'skinWeight',
	JOINTS_0: 'skinIndex',
};

const PATH_PROPERTIES = {
	scale: 'scale',
	translation: 'position',
	rotation: 'quaternion',
	weights: 'morphTargetInfluences'
};

const INTERPOLATION = {
	CUBICSPLINE: undefined, // We use a custom interpolant (GLTFCubicSplineInterpolation) for CUBICSPLINE tracks. Each
		                        // keyframe track will be initialized with a default interpolation type, then modified.
	LINEAR: __WEBPACK_EXTERNAL_MODULE_three_InterpolateLinear__,
	STEP: __WEBPACK_EXTERNAL_MODULE_three_InterpolateDiscrete__
};

const ALPHA_MODES = {
	OPAQUE: 'OPAQUE',
	MASK: 'MASK',
	BLEND: 'BLEND'
};

/**
 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#default-material
 *
 * @private
 * @param {Object<string, Material>} cache
 * @return {Material}
 */
function createDefaultMaterial( cache ) {

	if ( cache[ 'DefaultMaterial' ] === undefined ) {

		cache[ 'DefaultMaterial' ] = new __WEBPACK_EXTERNAL_MODULE_three_MeshStandardMaterial__( {
			color: 0xFFFFFF,
			emissive: 0x000000,
			metalness: 1,
			roughness: 1,
			transparent: false,
			depthTest: true,
			side: __WEBPACK_EXTERNAL_MODULE_three_FrontSide__
		} );

	}

	return cache[ 'DefaultMaterial' ];

}

function addUnknownExtensionsToUserData( knownExtensions, object, objectDef ) {

	// Add unknown glTF extensions to an object's userData.

	for ( const name in objectDef.extensions ) {

		if ( knownExtensions[ name ] === undefined ) {

			object.userData.gltfExtensions = object.userData.gltfExtensions || {};
			object.userData.gltfExtensions[ name ] = objectDef.extensions[ name ];

		}

	}

}

/**
 *
 * @private
 * @param {Object3D|Material|BufferGeometry|Object|AnimationClip} object
 * @param {GLTF.definition} gltfDef
 */
function assignExtrasToUserData( object, gltfDef ) {

	if ( gltfDef.extras !== undefined ) {

		if ( typeof gltfDef.extras === 'object' ) {

			Object.assign( object.userData, gltfDef.extras );

		} else {

			console.warn( 'THREE.GLTFLoader: Ignoring primitive type .extras, ' + gltfDef.extras );

		}

	}

}

/**
 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#morph-targets
 *
 * @private
 * @param {BufferGeometry} geometry
 * @param {Array<GLTF.Target>} targets
 * @param {GLTFParser} parser
 * @return {Promise<BufferGeometry>}
 */
function addMorphTargets( geometry, targets, parser ) {

	let hasMorphPosition = false;
	let hasMorphNormal = false;
	let hasMorphColor = false;

	for ( let i = 0, il = targets.length; i < il; i ++ ) {

		const target = targets[ i ];

		if ( target.POSITION !== undefined ) hasMorphPosition = true;
		if ( target.NORMAL !== undefined ) hasMorphNormal = true;
		if ( target.COLOR_0 !== undefined ) hasMorphColor = true;

		if ( hasMorphPosition && hasMorphNormal && hasMorphColor ) break;

	}

	if ( ! hasMorphPosition && ! hasMorphNormal && ! hasMorphColor ) return Promise.resolve( geometry );

	const pendingPositionAccessors = [];
	const pendingNormalAccessors = [];
	const pendingColorAccessors = [];

	for ( let i = 0, il = targets.length; i < il; i ++ ) {

		const target = targets[ i ];

		if ( hasMorphPosition ) {

			const pendingAccessor = target.POSITION !== undefined
				? parser.getDependency( 'accessor', target.POSITION )
				: geometry.attributes.position;

			pendingPositionAccessors.push( pendingAccessor );

		}

		if ( hasMorphNormal ) {

			const pendingAccessor = target.NORMAL !== undefined
				? parser.getDependency( 'accessor', target.NORMAL )
				: geometry.attributes.normal;

			pendingNormalAccessors.push( pendingAccessor );

		}

		if ( hasMorphColor ) {

			const pendingAccessor = target.COLOR_0 !== undefined
				? parser.getDependency( 'accessor', target.COLOR_0 )
				: geometry.attributes.color;

			pendingColorAccessors.push( pendingAccessor );

		}

	}

	return Promise.all( [
		Promise.all( pendingPositionAccessors ),
		Promise.all( pendingNormalAccessors ),
		Promise.all( pendingColorAccessors )
	] ).then( function ( accessors ) {

		const morphPositions = accessors[ 0 ];
		const morphNormals = accessors[ 1 ];
		const morphColors = accessors[ 2 ];

		if ( hasMorphPosition ) geometry.morphAttributes.position = morphPositions;
		if ( hasMorphNormal ) geometry.morphAttributes.normal = morphNormals;
		if ( hasMorphColor ) geometry.morphAttributes.color = morphColors;
		geometry.morphTargetsRelative = true;

		return geometry;

	} );

}

/**
 *
 * @private
 * @param {Mesh} mesh
 * @param {GLTF.Mesh} meshDef
 */
function updateMorphTargets( mesh, meshDef ) {

	mesh.updateMorphTargets();

	if ( meshDef.weights !== undefined ) {

		for ( let i = 0, il = meshDef.weights.length; i < il; i ++ ) {

			mesh.morphTargetInfluences[ i ] = meshDef.weights[ i ];

		}

	}

	// .extras has user-defined data, so check that .extras.targetNames is an array.
	if ( meshDef.extras && Array.isArray( meshDef.extras.targetNames ) ) {

		const targetNames = meshDef.extras.targetNames;

		if ( mesh.morphTargetInfluences.length === targetNames.length ) {

			mesh.morphTargetDictionary = {};

			for ( let i = 0, il = targetNames.length; i < il; i ++ ) {

				mesh.morphTargetDictionary[ targetNames[ i ] ] = i;

			}

		} else {

			console.warn( 'THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.' );

		}

	}

}

function createPrimitiveKey( primitiveDef ) {

	let geometryKey;

	const dracoExtension = primitiveDef.extensions && primitiveDef.extensions[ EXTENSIONS.KHR_DRACO_MESH_COMPRESSION ];

	if ( dracoExtension ) {

		geometryKey = 'draco:' + dracoExtension.bufferView
				+ ':' + dracoExtension.indices
				+ ':' + createAttributesKey( dracoExtension.attributes );

	} else {

		geometryKey = primitiveDef.indices + ':' + createAttributesKey( primitiveDef.attributes ) + ':' + primitiveDef.mode;

	}

	if ( primitiveDef.targets !== undefined ) {

		for ( let i = 0, il = primitiveDef.targets.length; i < il; i ++ ) {

			geometryKey += ':' + createAttributesKey( primitiveDef.targets[ i ] );

		}

	}

	return geometryKey;

}

function createAttributesKey( attributes ) {

	let attributesKey = '';

	const keys = Object.keys( attributes ).sort();

	for ( let i = 0, il = keys.length; i < il; i ++ ) {

		attributesKey += keys[ i ] + ':' + attributes[ keys[ i ] ] + ';';

	}

	return attributesKey;

}

function getNormalizedComponentScale( constructor ) {

	// Reference:
	// https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_mesh_quantization#encoding-quantized-data

	switch ( constructor ) {

		case Int8Array:
			return 1 / 127;

		case Uint8Array:
			return 1 / 255;

		case Int16Array:
			return 1 / 32767;

		case Uint16Array:
			return 1 / 65535;

		default:
			throw new Error( 'THREE.GLTFLoader: Unsupported normalized accessor component type.' );

	}

}

function getImageURIMimeType( uri ) {

	if ( uri.search( /\.jpe?g($|\?)/i ) > 0 || uri.search( /^data\:image\/jpeg/ ) === 0 ) return 'image/jpeg';
	if ( uri.search( /\.webp($|\?)/i ) > 0 || uri.search( /^data\:image\/webp/ ) === 0 ) return 'image/webp';
	if ( uri.search( /\.ktx2($|\?)/i ) > 0 || uri.search( /^data\:image\/ktx2/ ) === 0 ) return 'image/ktx2';

	return 'image/png';

}

const _identityMatrix = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

/* GLTF PARSER */

class GLTFParser {

	constructor( json = {}, options = {} ) {

		this.json = json;
		this.extensions = {};
		this.plugins = {};
		this.options = options;

		// loader object cache
		this.cache = new GLTFRegistry();

		// associations between Three.js objects and glTF elements
		this.associations = new Map();

		// BufferGeometry caching
		this.primitiveCache = {};

		// Node cache
		this.nodeCache = {};

		// Object3D instance caches
		this.meshCache = { refs: {}, uses: {} };
		this.cameraCache = { refs: {}, uses: {} };
		this.lightCache = { refs: {}, uses: {} };

		this.sourceCache = {};
		this.textureCache = {};

		// Track node names, to ensure no duplicates
		this.nodeNamesUsed = {};

		// Use an ImageBitmapLoader if imageBitmaps are supported. Moves much of the
		// expensive work of uploading a texture to the GPU off the main thread.

		let isSafari = false;
		let safariVersion = - 1;
		let isFirefox = false;
		let firefoxVersion = - 1;

		if ( typeof navigator !== 'undefined' && typeof navigator.userAgent !== 'undefined' ) {

			const userAgent = navigator.userAgent;

			isSafari = /^((?!chrome|android).)*safari/i.test( userAgent ) === true;
			const safariMatch = userAgent.match( /Version\/(\d+)/ );
			safariVersion = isSafari && safariMatch ? parseInt( safariMatch[ 1 ], 10 ) : - 1;

			isFirefox = userAgent.indexOf( 'Firefox' ) > - 1;
			firefoxVersion = isFirefox ? userAgent.match( /Firefox\/([0-9]+)\./ )[ 1 ] : - 1;

		}

		if ( typeof createImageBitmap === 'undefined' || ( isSafari && safariVersion < 17 ) || ( isFirefox && firefoxVersion < 98 ) ) {

			this.textureLoader = new __WEBPACK_EXTERNAL_MODULE_three_TextureLoader__( this.options.manager );

		} else {

			this.textureLoader = new __WEBPACK_EXTERNAL_MODULE_three_ImageBitmapLoader__( this.options.manager );

		}

		this.textureLoader.setCrossOrigin( this.options.crossOrigin );
		this.textureLoader.setRequestHeader( this.options.requestHeader );

		this.fileLoader = new __WEBPACK_EXTERNAL_MODULE_three_FileLoader__( this.options.manager );
		this.fileLoader.setResponseType( 'arraybuffer' );

		if ( this.options.crossOrigin === 'use-credentials' ) {

			this.fileLoader.setWithCredentials( true );

		}

	}

	setExtensions( extensions ) {

		this.extensions = extensions;

	}

	setPlugins( plugins ) {

		this.plugins = plugins;

	}

	parse( onLoad, onError ) {

		const parser = this;
		const json = this.json;
		const extensions = this.extensions;

		// Clear the loader cache
		this.cache.removeAll();
		this.nodeCache = {};

		// Mark the special nodes/meshes in json for efficient parse
		this._invokeAll( function ( ext ) {

			return ext._markDefs && ext._markDefs();

		} );

		Promise.all( this._invokeAll( function ( ext ) {

			return ext.beforeRoot && ext.beforeRoot();

		} ) ).then( function () {

			return Promise.all( [

				parser.getDependencies( 'scene' ),
				parser.getDependencies( 'animation' ),
				parser.getDependencies( 'camera' ),

			] );

		} ).then( function ( dependencies ) {

			const result = {
				scene: dependencies[ 0 ][ json.scene || 0 ],
				scenes: dependencies[ 0 ],
				animations: dependencies[ 1 ],
				cameras: dependencies[ 2 ],
				asset: json.asset,
				parser: parser,
				userData: {}
			};

			addUnknownExtensionsToUserData( extensions, result, json );

			assignExtrasToUserData( result, json );

			return Promise.all( parser._invokeAll( function ( ext ) {

				return ext.afterRoot && ext.afterRoot( result );

			} ) ).then( function () {

				for ( const scene of result.scenes ) {

					scene.updateMatrixWorld();

				}

				onLoad( result );

			} );

		} ).catch( onError );

	}

	/**
	 * Marks the special nodes/meshes in json for efficient parse.
	 *
	 * @private
	 */
	_markDefs() {

		const nodeDefs = this.json.nodes || [];
		const skinDefs = this.json.skins || [];
		const meshDefs = this.json.meshes || [];

		// Nothing in the node definition indicates whether it is a Bone or an
		// Object3D. Use the skins' joint references to mark bones.
		for ( let skinIndex = 0, skinLength = skinDefs.length; skinIndex < skinLength; skinIndex ++ ) {

			const joints = skinDefs[ skinIndex ].joints;

			for ( let i = 0, il = joints.length; i < il; i ++ ) {

				nodeDefs[ joints[ i ] ].isBone = true;

			}

		}

		// Iterate over all nodes, marking references to shared resources,
		// as well as skeleton joints.
		for ( let nodeIndex = 0, nodeLength = nodeDefs.length; nodeIndex < nodeLength; nodeIndex ++ ) {

			const nodeDef = nodeDefs[ nodeIndex ];

			if ( nodeDef.mesh !== undefined ) {

				this._addNodeRef( this.meshCache, nodeDef.mesh );

				// Nothing in the mesh definition indicates whether it is
				// a SkinnedMesh or Mesh. Use the node's mesh reference
				// to mark SkinnedMesh if node has skin.
				if ( nodeDef.skin !== undefined ) {

					meshDefs[ nodeDef.mesh ].isSkinnedMesh = true;

				}

			}

			if ( nodeDef.camera !== undefined ) {

				this._addNodeRef( this.cameraCache, nodeDef.camera );

			}

		}

	}

	/**
	 * Counts references to shared node / Object3D resources. These resources
	 * can be reused, or "instantiated", at multiple nodes in the scene
	 * hierarchy. Mesh, Camera, and Light instances are instantiated and must
	 * be marked. Non-scenegraph resources (like Materials, Geometries, and
	 * Textures) can be reused directly and are not marked here.
	 *
	 * Example: CesiumMilkTruck sample model reuses "Wheel" meshes.
	 *
	 * @private
	 * @param {Object} cache
	 * @param {Object3D} index
	 */
	_addNodeRef( cache, index ) {

		if ( index === undefined ) return;

		if ( cache.refs[ index ] === undefined ) {

			cache.refs[ index ] = cache.uses[ index ] = 0;

		}

		cache.refs[ index ] ++;

	}

	/**
	 * Returns a reference to a shared resource, cloning it if necessary.
	 *
	 * @private
	 * @param {Object} cache
	 * @param {number} index
	 * @param {Object} object
	 * @return {Object}
	 */
	_getNodeRef( cache, index, object ) {

		if ( cache.refs[ index ] <= 1 ) return object;

		const ref = object.clone();

		// Propagates mappings to the cloned object, prevents mappings on the
		// original object from being lost.
		const updateMappings = ( original, clone ) => {

			const mappings = this.associations.get( original );
			if ( mappings != null ) {

				this.associations.set( clone, mappings );

			}

			for ( const [ i, child ] of original.children.entries() ) {

				updateMappings( child, clone.children[ i ] );

			}

		};

		updateMappings( object, ref );

		ref.name += '_instance_' + ( cache.uses[ index ] ++ );

		return ref;

	}

	_invokeOne( func ) {

		const extensions = Object.values( this.plugins );
		extensions.push( this );

		for ( let i = 0; i < extensions.length; i ++ ) {

			const result = func( extensions[ i ] );

			if ( result ) return result;

		}

		return null;

	}

	_invokeAll( func ) {

		const extensions = Object.values( this.plugins );
		extensions.unshift( this );

		const pending = [];

		for ( let i = 0; i < extensions.length; i ++ ) {

			const result = func( extensions[ i ] );

			if ( result ) pending.push( result );

		}

		return pending;

	}

	/**
	 * Requests the specified dependency asynchronously, with caching.
	 *
	 * @private
	 * @param {string} type
	 * @param {number} index
	 * @return {Promise<Object3D|Material|Texture|AnimationClip|ArrayBuffer|Object>}
	 */
	getDependency( type, index ) {

		const cacheKey = type + ':' + index;
		let dependency = this.cache.get( cacheKey );

		if ( ! dependency ) {

			switch ( type ) {

				case 'scene':
					dependency = this.loadScene( index );
					break;

				case 'node':
					dependency = this._invokeOne( function ( ext ) {

						return ext.loadNode && ext.loadNode( index );

					} );
					break;

				case 'mesh':
					dependency = this._invokeOne( function ( ext ) {

						return ext.loadMesh && ext.loadMesh( index );

					} );
					break;

				case 'accessor':
					dependency = this.loadAccessor( index );
					break;

				case 'bufferView':
					dependency = this._invokeOne( function ( ext ) {

						return ext.loadBufferView && ext.loadBufferView( index );

					} );
					break;

				case 'buffer':
					dependency = this.loadBuffer( index );
					break;

				case 'material':
					dependency = this._invokeOne( function ( ext ) {

						return ext.loadMaterial && ext.loadMaterial( index );

					} );
					break;

				case 'texture':
					dependency = this._invokeOne( function ( ext ) {

						return ext.loadTexture && ext.loadTexture( index );

					} );
					break;

				case 'skin':
					dependency = this.loadSkin( index );
					break;

				case 'animation':
					dependency = this._invokeOne( function ( ext ) {

						return ext.loadAnimation && ext.loadAnimation( index );

					} );
					break;

				case 'camera':
					dependency = this.loadCamera( index );
					break;

				default:
					dependency = this._invokeOne( function ( ext ) {

						return ext != this && ext.getDependency && ext.getDependency( type, index );

					} );

					if ( ! dependency ) {

						throw new Error( 'Unknown type: ' + type );

					}

					break;

			}

			this.cache.add( cacheKey, dependency );

		}

		return dependency;

	}

	/**
	 * Requests all dependencies of the specified type asynchronously, with caching.
	 *
	 * @private
	 * @param {string} type
	 * @return {Promise<Array<Object>>}
	 */
	getDependencies( type ) {

		let dependencies = this.cache.get( type );

		if ( ! dependencies ) {

			const parser = this;
			const defs = this.json[ type + ( type === 'mesh' ? 'es' : 's' ) ] || [];

			dependencies = Promise.all( defs.map( function ( def, index ) {

				return parser.getDependency( type, index );

			} ) );

			this.cache.add( type, dependencies );

		}

		return dependencies;

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#buffers-and-buffer-views
	 *
	 * @private
	 * @param {number} bufferIndex
	 * @return {Promise<ArrayBuffer>}
	 */
	loadBuffer( bufferIndex ) {

		const bufferDef = this.json.buffers[ bufferIndex ];
		const loader = this.fileLoader;

		if ( bufferDef.type && bufferDef.type !== 'arraybuffer' ) {

			throw new Error( 'THREE.GLTFLoader: ' + bufferDef.type + ' buffer type is not supported.' );

		}

		// If present, GLB container is required to be the first buffer.
		if ( bufferDef.uri === undefined && bufferIndex === 0 ) {

			return Promise.resolve( this.extensions[ EXTENSIONS.KHR_BINARY_GLTF ].body );

		}

		const options = this.options;

		return new Promise( function ( resolve, reject ) {

			loader.load( __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__.resolveURL( bufferDef.uri, options.path ), resolve, undefined, function () {

				reject( new Error( 'THREE.GLTFLoader: Failed to load buffer "' + bufferDef.uri + '".' ) );

			} );

		} );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#buffers-and-buffer-views
	 *
	 * @private
	 * @param {number} bufferViewIndex
	 * @return {Promise<ArrayBuffer>}
	 */
	loadBufferView( bufferViewIndex ) {

		const bufferViewDef = this.json.bufferViews[ bufferViewIndex ];

		return this.getDependency( 'buffer', bufferViewDef.buffer ).then( function ( buffer ) {

			const byteLength = bufferViewDef.byteLength || 0;
			const byteOffset = bufferViewDef.byteOffset || 0;
			return buffer.slice( byteOffset, byteOffset + byteLength );

		} );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#accessors
	 *
	 * @private
	 * @param {number} accessorIndex
	 * @return {Promise<BufferAttribute|InterleavedBufferAttribute>}
	 */
	loadAccessor( accessorIndex ) {

		const parser = this;
		const json = this.json;

		const accessorDef = this.json.accessors[ accessorIndex ];

		if ( accessorDef.bufferView === undefined && accessorDef.sparse === undefined ) {

			const itemSize = WEBGL_TYPE_SIZES[ accessorDef.type ];
			const TypedArray = WEBGL_COMPONENT_TYPES[ accessorDef.componentType ];
			const normalized = accessorDef.normalized === true;

			const array = new TypedArray( accessorDef.count * itemSize );
			return Promise.resolve( new __WEBPACK_EXTERNAL_MODULE_three_BufferAttribute__( array, itemSize, normalized ) );

		}

		const pendingBufferViews = [];

		if ( accessorDef.bufferView !== undefined ) {

			pendingBufferViews.push( this.getDependency( 'bufferView', accessorDef.bufferView ) );

		} else {

			pendingBufferViews.push( null );

		}

		if ( accessorDef.sparse !== undefined ) {

			pendingBufferViews.push( this.getDependency( 'bufferView', accessorDef.sparse.indices.bufferView ) );
			pendingBufferViews.push( this.getDependency( 'bufferView', accessorDef.sparse.values.bufferView ) );

		}

		return Promise.all( pendingBufferViews ).then( function ( bufferViews ) {

			const bufferView = bufferViews[ 0 ];

			const itemSize = WEBGL_TYPE_SIZES[ accessorDef.type ];
			const TypedArray = WEBGL_COMPONENT_TYPES[ accessorDef.componentType ];

			// For VEC3: itemSize is 3, elementBytes is 4, itemBytes is 12.
			const elementBytes = TypedArray.BYTES_PER_ELEMENT;
			const itemBytes = elementBytes * itemSize;
			const byteOffset = accessorDef.byteOffset || 0;
			const byteStride = accessorDef.bufferView !== undefined ? json.bufferViews[ accessorDef.bufferView ].byteStride : undefined;
			const normalized = accessorDef.normalized === true;
			let array, bufferAttribute;

			// The buffer is not interleaved if the stride is the item size in bytes.
			if ( byteStride && byteStride !== itemBytes ) {

				// Each "slice" of the buffer, as defined by 'count' elements of 'byteStride' bytes, gets its own InterleavedBuffer
				// This makes sure that IBA.count reflects accessor.count properly
				const ibSlice = Math.floor( byteOffset / byteStride );
				const ibCacheKey = 'InterleavedBuffer:' + accessorDef.bufferView + ':' + accessorDef.componentType + ':' + ibSlice + ':' + accessorDef.count;
				let ib = parser.cache.get( ibCacheKey );

				if ( ! ib ) {

					array = new TypedArray( bufferView, ibSlice * byteStride, accessorDef.count * byteStride / elementBytes );

					// Integer parameters to IB/IBA are in array elements, not bytes.
					ib = new __WEBPACK_EXTERNAL_MODULE_three_InterleavedBuffer__( array, byteStride / elementBytes );

					parser.cache.add( ibCacheKey, ib );

				}

				bufferAttribute = new __WEBPACK_EXTERNAL_MODULE_three_InterleavedBufferAttribute__( ib, itemSize, ( byteOffset % byteStride ) / elementBytes, normalized );

			} else {

				if ( bufferView === null ) {

					array = new TypedArray( accessorDef.count * itemSize );

				} else {

					array = new TypedArray( bufferView, byteOffset, accessorDef.count * itemSize );

				}

				bufferAttribute = new __WEBPACK_EXTERNAL_MODULE_three_BufferAttribute__( array, itemSize, normalized );

			}

			// https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#sparse-accessors
			if ( accessorDef.sparse !== undefined ) {

				const itemSizeIndices = WEBGL_TYPE_SIZES.SCALAR;
				const TypedArrayIndices = WEBGL_COMPONENT_TYPES[ accessorDef.sparse.indices.componentType ];

				const byteOffsetIndices = accessorDef.sparse.indices.byteOffset || 0;
				const byteOffsetValues = accessorDef.sparse.values.byteOffset || 0;

				const sparseIndices = new TypedArrayIndices( bufferViews[ 1 ], byteOffsetIndices, accessorDef.sparse.count * itemSizeIndices );
				const sparseValues = new TypedArray( bufferViews[ 2 ], byteOffsetValues, accessorDef.sparse.count * itemSize );

				if ( bufferView !== null ) {

					// Avoid modifying the original ArrayBuffer, if the bufferView wasn't initialized with zeroes.
					bufferAttribute = new __WEBPACK_EXTERNAL_MODULE_three_BufferAttribute__( bufferAttribute.array.slice(), bufferAttribute.itemSize, bufferAttribute.normalized );

				}

				// Ignore normalized since we copy from sparse
				bufferAttribute.normalized = false;

				for ( let i = 0, il = sparseIndices.length; i < il; i ++ ) {

					const index = sparseIndices[ i ];

					bufferAttribute.setX( index, sparseValues[ i * itemSize ] );
					if ( itemSize >= 2 ) bufferAttribute.setY( index, sparseValues[ i * itemSize + 1 ] );
					if ( itemSize >= 3 ) bufferAttribute.setZ( index, sparseValues[ i * itemSize + 2 ] );
					if ( itemSize >= 4 ) bufferAttribute.setW( index, sparseValues[ i * itemSize + 3 ] );
					if ( itemSize >= 5 ) throw new Error( 'THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.' );

				}

				bufferAttribute.normalized = normalized;

			}

			return bufferAttribute;

		} );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#textures
	 *
	 * @private
	 * @param {number} textureIndex
	 * @return {Promise<?Texture>}
	 */
	loadTexture( textureIndex ) {

		const json = this.json;
		const options = this.options;
		const textureDef = json.textures[ textureIndex ];
		const sourceIndex = textureDef.source;
		const sourceDef = json.images[ sourceIndex ];

		let loader = this.textureLoader;

		if ( sourceDef.uri ) {

			const handler = options.manager.getHandler( sourceDef.uri );
			if ( handler !== null ) loader = handler;

		}

		return this.loadTextureImage( textureIndex, sourceIndex, loader );

	}

	loadTextureImage( textureIndex, sourceIndex, loader ) {

		const parser = this;
		const json = this.json;

		const textureDef = json.textures[ textureIndex ];
		const sourceDef = json.images[ sourceIndex ];

		const cacheKey = ( sourceDef.uri || sourceDef.bufferView ) + ':' + textureDef.sampler;

		if ( this.textureCache[ cacheKey ] ) {

			// See https://github.com/mrdoob/three.js/issues/21559.
			return this.textureCache[ cacheKey ];

		}

		const promise = this.loadImageSource( sourceIndex, loader ).then( function ( texture ) {

			texture.flipY = false;

			texture.name = textureDef.name || sourceDef.name || '';

			if ( texture.name === '' && typeof sourceDef.uri === 'string' && sourceDef.uri.startsWith( 'data:image/' ) === false ) {

				texture.name = sourceDef.uri;

			}

			const samplers = json.samplers || {};
			const sampler = samplers[ textureDef.sampler ] || {};

			texture.magFilter = WEBGL_FILTERS[ sampler.magFilter ] || __WEBPACK_EXTERNAL_MODULE_three_LinearFilter__;
			texture.minFilter = WEBGL_FILTERS[ sampler.minFilter ] || __WEBPACK_EXTERNAL_MODULE_three_LinearMipmapLinearFilter__;
			texture.wrapS = WEBGL_WRAPPINGS[ sampler.wrapS ] || __WEBPACK_EXTERNAL_MODULE_three_RepeatWrapping__;
			texture.wrapT = WEBGL_WRAPPINGS[ sampler.wrapT ] || __WEBPACK_EXTERNAL_MODULE_three_RepeatWrapping__;
			texture.generateMipmaps = ! texture.isCompressedTexture && texture.minFilter !== __WEBPACK_EXTERNAL_MODULE_three_NearestFilter__ && texture.minFilter !== __WEBPACK_EXTERNAL_MODULE_three_LinearFilter__;

			parser.associations.set( texture, { textures: textureIndex } );

			return texture;

		} ).catch( function () {

			return null;

		} );

		this.textureCache[ cacheKey ] = promise;

		return promise;

	}

	loadImageSource( sourceIndex, loader ) {

		const parser = this;
		const json = this.json;
		const options = this.options;

		if ( this.sourceCache[ sourceIndex ] !== undefined ) {

			return this.sourceCache[ sourceIndex ].then( ( texture ) => texture.clone() );

		}

		const sourceDef = json.images[ sourceIndex ];

		const URL = self.URL || self.webkitURL;

		let sourceURI = sourceDef.uri || '';
		let isObjectURL = false;

		if ( sourceDef.bufferView !== undefined ) {

			// Load binary image data from bufferView, if provided.

			sourceURI = parser.getDependency( 'bufferView', sourceDef.bufferView ).then( function ( bufferView ) {

				isObjectURL = true;
				const blob = new Blob( [ bufferView ], { type: sourceDef.mimeType } );
				sourceURI = URL.createObjectURL( blob );
				return sourceURI;

			} );

		} else if ( sourceDef.uri === undefined ) {

			throw new Error( 'THREE.GLTFLoader: Image ' + sourceIndex + ' is missing URI and bufferView' );

		}

		const promise = Promise.resolve( sourceURI ).then( function ( sourceURI ) {

			return new Promise( function ( resolve, reject ) {

				let onLoad = resolve;

				if ( loader.isImageBitmapLoader === true ) {

					onLoad = function ( imageBitmap ) {

						const texture = new __WEBPACK_EXTERNAL_MODULE_three_Texture__( imageBitmap );
						texture.needsUpdate = true;

						resolve( texture );

					};

				}

				loader.load( __WEBPACK_EXTERNAL_MODULE_three_LoaderUtils__.resolveURL( sourceURI, options.path ), onLoad, undefined, reject );

			} );

		} ).then( function ( texture ) {

			// Clean up resources and configure Texture.

			if ( isObjectURL === true ) {

				URL.revokeObjectURL( sourceURI );

			}

			assignExtrasToUserData( texture, sourceDef );

			texture.userData.mimeType = sourceDef.mimeType || getImageURIMimeType( sourceDef.uri );

			return texture;

		} ).catch( function ( error ) {

			console.error( 'THREE.GLTFLoader: Couldn\'t load texture', sourceURI );
			throw error;

		} );

		this.sourceCache[ sourceIndex ] = promise;
		return promise;

	}

	/**
	 * Asynchronously assigns a texture to the given material parameters.
	 *
	 * @private
	 * @param {Object} materialParams
	 * @param {string} mapName
	 * @param {Object} mapDef
	 * @param {string} [colorSpace]
	 * @return {Promise<Texture>}
	 */
	assignTexture( materialParams, mapName, mapDef, colorSpace ) {

		const parser = this;

		return this.getDependency( 'texture', mapDef.index ).then( function ( texture ) {

			if ( ! texture ) return null;

			if ( mapDef.texCoord !== undefined && mapDef.texCoord > 0 ) {

				texture = texture.clone();
				texture.channel = mapDef.texCoord;

			}

			if ( parser.extensions[ EXTENSIONS.KHR_TEXTURE_TRANSFORM ] ) {

				const transform = mapDef.extensions !== undefined ? mapDef.extensions[ EXTENSIONS.KHR_TEXTURE_TRANSFORM ] : undefined;

				if ( transform ) {

					const gltfReference = parser.associations.get( texture );
					texture = parser.extensions[ EXTENSIONS.KHR_TEXTURE_TRANSFORM ].extendTexture( texture, transform );
					parser.associations.set( texture, gltfReference );

				}

			}

			if ( colorSpace !== undefined ) {

				texture.colorSpace = colorSpace;

			}

			materialParams[ mapName ] = texture;

			return texture;

		} );

	}

	/**
	 * Assigns final material to a Mesh, Line, or Points instance. The instance
	 * already has a material (generated from the glTF material options alone)
	 * but reuse of the same glTF material may require multiple threejs materials
	 * to accommodate different primitive types, defines, etc. New materials will
	 * be created if necessary, and reused from a cache.
	 *
	 * @private
	 * @param {Object3D} mesh Mesh, Line, or Points instance.
	 */
	assignFinalMaterial( mesh ) {

		const geometry = mesh.geometry;
		let material = mesh.material;

		const useDerivativeTangents = geometry.attributes.tangent === undefined;
		const useVertexColors = geometry.attributes.color !== undefined;
		const useFlatShading = geometry.attributes.normal === undefined;

		if ( mesh.isPoints ) {

			const cacheKey = 'PointsMaterial:' + material.uuid;

			let pointsMaterial = this.cache.get( cacheKey );

			if ( ! pointsMaterial ) {

				pointsMaterial = new __WEBPACK_EXTERNAL_MODULE_three_PointsMaterial__();
				__WEBPACK_EXTERNAL_MODULE_three_Material__.prototype.copy.call( pointsMaterial, material );
				pointsMaterial.color.copy( material.color );
				pointsMaterial.map = material.map;
				pointsMaterial.sizeAttenuation = false; // glTF spec says points should be 1px

				this.cache.add( cacheKey, pointsMaterial );

			}

			material = pointsMaterial;

		} else if ( mesh.isLine ) {

			const cacheKey = 'LineBasicMaterial:' + material.uuid;

			let lineMaterial = this.cache.get( cacheKey );

			if ( ! lineMaterial ) {

				lineMaterial = new __WEBPACK_EXTERNAL_MODULE_three_LineBasicMaterial__();
				__WEBPACK_EXTERNAL_MODULE_three_Material__.prototype.copy.call( lineMaterial, material );
				lineMaterial.color.copy( material.color );
				lineMaterial.map = material.map;

				this.cache.add( cacheKey, lineMaterial );

			}

			material = lineMaterial;

		}

		// Clone the material if it will be modified
		if ( useDerivativeTangents || useVertexColors || useFlatShading ) {

			let cacheKey = 'ClonedMaterial:' + material.uuid + ':';

			if ( useDerivativeTangents ) cacheKey += 'derivative-tangents:';
			if ( useVertexColors ) cacheKey += 'vertex-colors:';
			if ( useFlatShading ) cacheKey += 'flat-shading:';

			let cachedMaterial = this.cache.get( cacheKey );

			if ( ! cachedMaterial ) {

				cachedMaterial = material.clone();

				if ( useVertexColors ) cachedMaterial.vertexColors = true;
				if ( useFlatShading ) cachedMaterial.flatShading = true;

				if ( useDerivativeTangents ) {

					// https://github.com/mrdoob/three.js/issues/11438#issuecomment-507003995
					if ( cachedMaterial.normalScale ) cachedMaterial.normalScale.y *= - 1;
					if ( cachedMaterial.clearcoatNormalScale ) cachedMaterial.clearcoatNormalScale.y *= - 1;

				}

				this.cache.add( cacheKey, cachedMaterial );

				this.associations.set( cachedMaterial, this.associations.get( material ) );

			}

			material = cachedMaterial;

		}

		mesh.material = material;

	}

	getMaterialType( /* materialIndex */ ) {

		return __WEBPACK_EXTERNAL_MODULE_three_MeshStandardMaterial__;

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#materials
	 *
	 * @private
	 * @param {number} materialIndex
	 * @return {Promise<Material>}
	 */
	loadMaterial( materialIndex ) {

		const parser = this;
		const json = this.json;
		const extensions = this.extensions;
		const materialDef = json.materials[ materialIndex ];

		let materialType;
		const materialParams = {};
		const materialExtensions = materialDef.extensions || {};

		const pending = [];

		if ( materialExtensions[ EXTENSIONS.KHR_MATERIALS_UNLIT ] ) {

			const kmuExtension = extensions[ EXTENSIONS.KHR_MATERIALS_UNLIT ];
			materialType = kmuExtension.getMaterialType();
			pending.push( kmuExtension.extendParams( materialParams, materialDef, parser ) );

		} else {

			// Specification:
			// https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#metallic-roughness-material

			const metallicRoughness = materialDef.pbrMetallicRoughness || {};

			materialParams.color = new __WEBPACK_EXTERNAL_MODULE_three_Color__( 1.0, 1.0, 1.0 );
			materialParams.opacity = 1.0;

			if ( Array.isArray( metallicRoughness.baseColorFactor ) ) {

				const array = metallicRoughness.baseColorFactor;

				materialParams.color.setRGB( array[ 0 ], array[ 1 ], array[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );
				materialParams.opacity = array[ 3 ];

			}

			if ( metallicRoughness.baseColorTexture !== undefined ) {

				pending.push( parser.assignTexture( materialParams, 'map', metallicRoughness.baseColorTexture, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ ) );

			}

			materialParams.metalness = metallicRoughness.metallicFactor !== undefined ? metallicRoughness.metallicFactor : 1.0;
			materialParams.roughness = metallicRoughness.roughnessFactor !== undefined ? metallicRoughness.roughnessFactor : 1.0;

			if ( metallicRoughness.metallicRoughnessTexture !== undefined ) {

				pending.push( parser.assignTexture( materialParams, 'metalnessMap', metallicRoughness.metallicRoughnessTexture ) );
				pending.push( parser.assignTexture( materialParams, 'roughnessMap', metallicRoughness.metallicRoughnessTexture ) );

			}

			materialType = this._invokeOne( function ( ext ) {

				return ext.getMaterialType && ext.getMaterialType( materialIndex );

			} );

			pending.push( Promise.all( this._invokeAll( function ( ext ) {

				return ext.extendMaterialParams && ext.extendMaterialParams( materialIndex, materialParams );

			} ) ) );

		}

		if ( materialDef.doubleSided === true ) {

			materialParams.side = __WEBPACK_EXTERNAL_MODULE_three_DoubleSide__;

		}

		const alphaMode = materialDef.alphaMode || ALPHA_MODES.OPAQUE;

		if ( alphaMode === ALPHA_MODES.BLEND ) {

			materialParams.transparent = true;

			// See: https://github.com/mrdoob/three.js/issues/17706
			materialParams.depthWrite = false;

		} else {

			materialParams.transparent = false;

			if ( alphaMode === ALPHA_MODES.MASK ) {

				materialParams.alphaTest = materialDef.alphaCutoff !== undefined ? materialDef.alphaCutoff : 0.5;

			}

		}

		if ( materialDef.normalTexture !== undefined && materialType !== __WEBPACK_EXTERNAL_MODULE_three_MeshBasicMaterial__ ) {

			pending.push( parser.assignTexture( materialParams, 'normalMap', materialDef.normalTexture ) );

			materialParams.normalScale = new __WEBPACK_EXTERNAL_MODULE_three_Vector2__( 1, 1 );

			if ( materialDef.normalTexture.scale !== undefined ) {

				const scale = materialDef.normalTexture.scale;

				materialParams.normalScale.set( scale, scale );

			}

		}

		if ( materialDef.occlusionTexture !== undefined && materialType !== __WEBPACK_EXTERNAL_MODULE_three_MeshBasicMaterial__ ) {

			pending.push( parser.assignTexture( materialParams, 'aoMap', materialDef.occlusionTexture ) );

			if ( materialDef.occlusionTexture.strength !== undefined ) {

				materialParams.aoMapIntensity = materialDef.occlusionTexture.strength;

			}

		}

		if ( materialDef.emissiveFactor !== undefined && materialType !== __WEBPACK_EXTERNAL_MODULE_three_MeshBasicMaterial__ ) {

			const emissiveFactor = materialDef.emissiveFactor;
			materialParams.emissive = new __WEBPACK_EXTERNAL_MODULE_three_Color__().setRGB( emissiveFactor[ 0 ], emissiveFactor[ 1 ], emissiveFactor[ 2 ], __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ );

		}

		if ( materialDef.emissiveTexture !== undefined && materialType !== __WEBPACK_EXTERNAL_MODULE_three_MeshBasicMaterial__ ) {

			pending.push( parser.assignTexture( materialParams, 'emissiveMap', materialDef.emissiveTexture, __WEBPACK_EXTERNAL_MODULE_three_SRGBColorSpace__ ) );

		}

		return Promise.all( pending ).then( function () {

			const material = new materialType( materialParams );

			if ( materialDef.name ) material.name = materialDef.name;

			assignExtrasToUserData( material, materialDef );

			parser.associations.set( material, { materials: materialIndex } );

			if ( materialDef.extensions ) addUnknownExtensionsToUserData( extensions, material, materialDef );

			return material;

		} );

	}

	/**
	 * When Object3D instances are targeted by animation, they need unique names.
	 *
	 * @private
	 * @param {string} originalName
	 * @return {string}
	 */
	createUniqueName( originalName ) {

		const sanitizedName = __WEBPACK_EXTERNAL_MODULE_three_PropertyBinding__.sanitizeNodeName( originalName || '' );

		if ( sanitizedName in this.nodeNamesUsed ) {

			return sanitizedName + '_' + ( ++ this.nodeNamesUsed[ sanitizedName ] );

		} else {

			this.nodeNamesUsed[ sanitizedName ] = 0;

			return sanitizedName;

		}

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#geometry
	 *
	 * Creates BufferGeometries from primitives.
	 *
	 * @private
	 * @param {Array<GLTF.Primitive>} primitives
	 * @return {Promise<Array<BufferGeometry>>}
	 */
	loadGeometries( primitives ) {

		const parser = this;
		const extensions = this.extensions;
		const cache = this.primitiveCache;

		function createDracoPrimitive( primitive ) {

			return extensions[ EXTENSIONS.KHR_DRACO_MESH_COMPRESSION ]
				.decodePrimitive( primitive, parser )
				.then( function ( geometry ) {

					return addPrimitiveAttributes( geometry, primitive, parser );

				} );

		}

		const pending = [];

		for ( let i = 0, il = primitives.length; i < il; i ++ ) {

			const primitive = primitives[ i ];
			const cacheKey = createPrimitiveKey( primitive );

			// See if we've already created this geometry
			const cached = cache[ cacheKey ];

			if ( cached ) {

				// Use the cached geometry if it exists
				pending.push( cached.promise );

			} else {

				let geometryPromise;

				if ( primitive.extensions && primitive.extensions[ EXTENSIONS.KHR_DRACO_MESH_COMPRESSION ] ) {

					// Use DRACO geometry if available
					geometryPromise = createDracoPrimitive( primitive );

				} else {

					// Otherwise create a new geometry
					geometryPromise = addPrimitiveAttributes( new __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__(), primitive, parser );

				}

				// Convert strip/fan primitives to triangles

				if ( primitive.mode === WEBGL_CONSTANTS.TRIANGLE_STRIP ) {

					geometryPromise = geometryPromise.then( geometry => toTrianglesDrawMode( geometry, __WEBPACK_EXTERNAL_MODULE_three_TriangleStripDrawMode__ ) );

				} else if ( primitive.mode === WEBGL_CONSTANTS.TRIANGLE_FAN ) {

					geometryPromise = geometryPromise.then( geometry => toTrianglesDrawMode( geometry, __WEBPACK_EXTERNAL_MODULE_three_TriangleFanDrawMode__ ) );

				}

				// Cache this geometry
				cache[ cacheKey ] = { primitive: primitive, promise: geometryPromise };

				pending.push( geometryPromise );

			}

		}

		return Promise.all( pending );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#meshes
	 *
	 * @private
	 * @param {number} meshIndex
	 * @return {Promise<Group|Mesh|SkinnedMesh|Line|Points>}
	 */
	loadMesh( meshIndex ) {

		const parser = this;
		const json = this.json;
		const extensions = this.extensions;

		const meshDef = json.meshes[ meshIndex ];
		const primitives = meshDef.primitives;

		const pending = [];

		for ( let i = 0, il = primitives.length; i < il; i ++ ) {

			const material = primitives[ i ].material === undefined
				? createDefaultMaterial( this.cache )
				: this.getDependency( 'material', primitives[ i ].material );

			pending.push( material );

		}

		pending.push( parser.loadGeometries( primitives ) );

		return Promise.all( pending ).then( async function ( results ) {

			const materials = results.slice( 0, results.length - 1 );
			const geometries = results[ results.length - 1 ];

			const meshes = [];

			for ( let i = 0, il = geometries.length; i < il; i ++ ) {

				const geometry = geometries[ i ];
				const primitive = primitives[ i ];

				// 1. create Mesh

				let mesh;

				const material = materials[ i ];

				if ( primitive.mode === WEBGL_CONSTANTS.TRIANGLES ||
						primitive.mode === WEBGL_CONSTANTS.TRIANGLE_STRIP ||
						primitive.mode === WEBGL_CONSTANTS.TRIANGLE_FAN ||
						primitive.mode === undefined ) {

					const needsSkinning = meshDef.isSkinnedMesh === true;
					const hasSkinningAttributes = geometry.hasAttribute( 'skinIndex' ) && geometry.hasAttribute( 'skinWeight' );

					if ( needsSkinning && hasSkinningAttributes === false ) {

						console.warn( 'THREE.GLTFLoader: Missing skinIndex or skinWeight attributes. Skinning disabled.' );

					}

					// .isSkinnedMesh isn't in glTF spec. See ._markDefs()
					mesh = ( needsSkinning && hasSkinningAttributes )
						? new __WEBPACK_EXTERNAL_MODULE_three_SkinnedMesh__( geometry, material )
						: new __WEBPACK_EXTERNAL_MODULE_three_Mesh__( geometry, material );

					if ( mesh.isSkinnedMesh === true ) {

						// normalize skin weights to fix malformed assets (see #15319)
						mesh.normalizeSkinWeights();

					}

				} else if ( primitive.mode === WEBGL_CONSTANTS.LINES ) {

					mesh = new __WEBPACK_EXTERNAL_MODULE_three_LineSegments__( geometry, material );

				} else if ( primitive.mode === WEBGL_CONSTANTS.LINE_STRIP ) {

					mesh = new __WEBPACK_EXTERNAL_MODULE_three_Line__( geometry, material );

				} else if ( primitive.mode === WEBGL_CONSTANTS.LINE_LOOP ) {

					mesh = new __WEBPACK_EXTERNAL_MODULE_three_LineLoop__( geometry, material );

				} else if ( primitive.mode === WEBGL_CONSTANTS.POINTS ) {

					mesh = new __WEBPACK_EXTERNAL_MODULE_three_Points__( geometry, material );

				} else {

					throw new Error( 'THREE.GLTFLoader: Primitive mode unsupported: ' + primitive.mode );

				}

				if ( Object.keys( mesh.geometry.morphAttributes ).length > 0 ) {

					updateMorphTargets( mesh, meshDef );

				}

				mesh.name = parser.createUniqueName( meshDef.name || ( 'mesh_' + meshIndex ) );

				assignExtrasToUserData( mesh, meshDef );

				if ( primitive.extensions ) addUnknownExtensionsToUserData( extensions, mesh, primitive );

				parser.assignFinalMaterial( mesh );

				meshes.push( mesh );

			}

			for ( let i = 0, il = meshes.length; i < il; i ++ ) {

				parser.associations.set( meshes[ i ], {
					meshes: meshIndex,
					primitives: i
				} );

			}

			if ( meshes.length === 1 ) {

				if ( meshDef.extensions ) addUnknownExtensionsToUserData( extensions, meshes[ 0 ], meshDef );

				return meshes[ 0 ];

			}

			const group = new __WEBPACK_EXTERNAL_MODULE_three_Group__();

			if ( meshDef.extensions ) addUnknownExtensionsToUserData( extensions, group, meshDef );

			parser.associations.set( group, { meshes: meshIndex } );

			for ( let i = 0, il = meshes.length; i < il; i ++ ) {

				group.add( meshes[ i ] );

			}

			return group;

		} );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#cameras
	 *
	 * @private
	 * @param {number} cameraIndex
	 * @return {Promise<Camera>|undefined}
	 */
	loadCamera( cameraIndex ) {

		let camera;
		const cameraDef = this.json.cameras[ cameraIndex ];
		const params = cameraDef[ cameraDef.type ];

		if ( ! params ) {

			console.warn( 'THREE.GLTFLoader: Missing camera parameters.' );
			return;

		}

		if ( cameraDef.type === 'perspective' ) {

			camera = new __WEBPACK_EXTERNAL_MODULE_three_PerspectiveCamera__( __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.radToDeg( params.yfov ), params.aspectRatio || 1, params.znear || 1, params.zfar || 2e6 );

		} else if ( cameraDef.type === 'orthographic' ) {

			camera = new __WEBPACK_EXTERNAL_MODULE_three_OrthographicCamera__( - params.xmag, params.xmag, params.ymag, - params.ymag, params.znear, params.zfar );

		}

		if ( cameraDef.name ) camera.name = this.createUniqueName( cameraDef.name );

		assignExtrasToUserData( camera, cameraDef );

		return Promise.resolve( camera );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#skins
	 *
	 * @private
	 * @param {number} skinIndex
	 * @return {Promise<Skeleton>}
	 */
	loadSkin( skinIndex ) {

		const skinDef = this.json.skins[ skinIndex ];

		const pending = [];

		for ( let i = 0, il = skinDef.joints.length; i < il; i ++ ) {

			pending.push( this._loadNodeShallow( skinDef.joints[ i ] ) );

		}

		if ( skinDef.inverseBindMatrices !== undefined ) {

			pending.push( this.getDependency( 'accessor', skinDef.inverseBindMatrices ) );

		} else {

			pending.push( null );

		}

		return Promise.all( pending ).then( function ( results ) {

			const inverseBindMatrices = results.pop();
			const jointNodes = results;

			// Note that bones (joint nodes) may or may not be in the
			// scene graph at this time.

			const bones = [];
			const boneInverses = [];

			for ( let i = 0, il = jointNodes.length; i < il; i ++ ) {

				const jointNode = jointNodes[ i ];

				if ( jointNode ) {

					bones.push( jointNode );

					const mat = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();

					if ( inverseBindMatrices !== null ) {

						mat.fromArray( inverseBindMatrices.array, i * 16 );

					}

					boneInverses.push( mat );

				} else {

					console.warn( 'THREE.GLTFLoader: Joint "%s" could not be found.', skinDef.joints[ i ] );

				}

			}

			return new __WEBPACK_EXTERNAL_MODULE_three_Skeleton__( bones, boneInverses );

		} );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#animations
	 *
	 * @private
	 * @param {number} animationIndex
	 * @return {Promise<AnimationClip>}
	 */
	loadAnimation( animationIndex ) {

		const json = this.json;
		const parser = this;

		const animationDef = json.animations[ animationIndex ];
		const animationName = animationDef.name ? animationDef.name : 'animation_' + animationIndex;

		const pendingNodes = [];
		const pendingInputAccessors = [];
		const pendingOutputAccessors = [];
		const pendingSamplers = [];
		const pendingTargets = [];

		for ( let i = 0, il = animationDef.channels.length; i < il; i ++ ) {

			const channel = animationDef.channels[ i ];
			const sampler = animationDef.samplers[ channel.sampler ];
			const target = channel.target;
			const name = target.node;
			const input = animationDef.parameters !== undefined ? animationDef.parameters[ sampler.input ] : sampler.input;
			const output = animationDef.parameters !== undefined ? animationDef.parameters[ sampler.output ] : sampler.output;

			if ( target.node === undefined ) continue;

			pendingNodes.push( this.getDependency( 'node', name ) );
			pendingInputAccessors.push( this.getDependency( 'accessor', input ) );
			pendingOutputAccessors.push( this.getDependency( 'accessor', output ) );
			pendingSamplers.push( sampler );
			pendingTargets.push( target );

		}

		return Promise.all( [

			Promise.all( pendingNodes ),
			Promise.all( pendingInputAccessors ),
			Promise.all( pendingOutputAccessors ),
			Promise.all( pendingSamplers ),
			Promise.all( pendingTargets )

		] ).then( function ( dependencies ) {

			const nodes = dependencies[ 0 ];
			const inputAccessors = dependencies[ 1 ];
			const outputAccessors = dependencies[ 2 ];
			const samplers = dependencies[ 3 ];
			const targets = dependencies[ 4 ];

			const tracks = [];

			for ( let i = 0, il = nodes.length; i < il; i ++ ) {

				const node = nodes[ i ];
				const inputAccessor = inputAccessors[ i ];
				const outputAccessor = outputAccessors[ i ];
				const sampler = samplers[ i ];
				const target = targets[ i ];

				if ( node === undefined ) continue;

				if ( node.updateMatrix ) {

					node.updateMatrix();

				}

				const createdTracks = parser._createAnimationTracks( node, inputAccessor, outputAccessor, sampler, target );

				if ( createdTracks ) {

					for ( let k = 0; k < createdTracks.length; k ++ ) {

						tracks.push( createdTracks[ k ] );

					}

				}

			}

			const animation = new __WEBPACK_EXTERNAL_MODULE_three_AnimationClip__( animationName, undefined, tracks );

			assignExtrasToUserData( animation, animationDef );

			return animation;

		} );

	}

	createNodeMesh( nodeIndex ) {

		const json = this.json;
		const parser = this;
		const nodeDef = json.nodes[ nodeIndex ];

		if ( nodeDef.mesh === undefined ) return null;

		return parser.getDependency( 'mesh', nodeDef.mesh ).then( function ( mesh ) {

			const node = parser._getNodeRef( parser.meshCache, nodeDef.mesh, mesh );

			// if weights are provided on the node, override weights on the mesh.
			if ( nodeDef.weights !== undefined ) {

				node.traverse( function ( o ) {

					if ( ! o.isMesh ) return;

					for ( let i = 0, il = nodeDef.weights.length; i < il; i ++ ) {

						o.morphTargetInfluences[ i ] = nodeDef.weights[ i ];

					}

				} );

			}

			return node;

		} );

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#nodes-and-hierarchy
	 *
	 * @private
	 * @param {number} nodeIndex
	 * @return {Promise<Object3D>}
	 */
	loadNode( nodeIndex ) {

		const json = this.json;
		const parser = this;

		const nodeDef = json.nodes[ nodeIndex ];

		const nodePending = parser._loadNodeShallow( nodeIndex );

		const childPending = [];
		const childrenDef = nodeDef.children || [];

		for ( let i = 0, il = childrenDef.length; i < il; i ++ ) {

			childPending.push( parser.getDependency( 'node', childrenDef[ i ] ) );

		}

		const skeletonPending = nodeDef.skin === undefined
			? Promise.resolve( null )
			: parser.getDependency( 'skin', nodeDef.skin );

		return Promise.all( [
			nodePending,
			Promise.all( childPending ),
			skeletonPending
		] ).then( function ( results ) {

			const node = results[ 0 ];
			const children = results[ 1 ];
			const skeleton = results[ 2 ];

			if ( skeleton !== null ) {

				// This full traverse should be fine because
				// child glTF nodes have not been added to this node yet.
				node.traverse( function ( mesh ) {

					if ( ! mesh.isSkinnedMesh ) return;

					mesh.bind( skeleton, _identityMatrix );

				} );

			}

			for ( let i = 0, il = children.length; i < il; i ++ ) {

				node.add( children[ i ] );

			}

			// Reconstruct pivot from container pattern created by GLTFExporter
			// The container has position+pivot, rotation, scale; child has -pivot offset and mesh
			if ( node.userData.pivot !== undefined && children.length > 0 ) {

				const pivot = node.userData.pivot;
				const pivotChild = children[ 0 ];

				// Set pivot on container and adjust transforms
				node.pivot = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__().fromArray( pivot );

				// Adjust container position: stored as position + pivot, so subtract pivot
				node.position.x -= pivot[ 0 ];
				node.position.y -= pivot[ 1 ];
				node.position.z -= pivot[ 2 ];

				// Remove the child's -pivot offset since pivot now handles it
				pivotChild.position.set( 0, 0, 0 );

				delete node.userData.pivot;

			}

			return node;

		} );

	}

	// ._loadNodeShallow() parses a single node.
	// skin and child nodes are created and added in .loadNode() (no '_' prefix).
	_loadNodeShallow( nodeIndex ) {

		const json = this.json;
		const extensions = this.extensions;
		const parser = this;

		// This method is called from .loadNode() and .loadSkin().
		// Cache a node to avoid duplication.

		if ( this.nodeCache[ nodeIndex ] !== undefined ) {

			return this.nodeCache[ nodeIndex ];

		}

		const nodeDef = json.nodes[ nodeIndex ];

		// reserve node's name before its dependencies, so the root has the intended name.
		const nodeName = nodeDef.name ? parser.createUniqueName( nodeDef.name ) : '';

		const pending = [];

		const meshPromise = parser._invokeOne( function ( ext ) {

			return ext.createNodeMesh && ext.createNodeMesh( nodeIndex );

		} );

		if ( meshPromise ) {

			pending.push( meshPromise );

		}

		if ( nodeDef.camera !== undefined ) {

			pending.push( parser.getDependency( 'camera', nodeDef.camera ).then( function ( camera ) {

				return parser._getNodeRef( parser.cameraCache, nodeDef.camera, camera );

			} ) );

		}

		parser._invokeAll( function ( ext ) {

			return ext.createNodeAttachment && ext.createNodeAttachment( nodeIndex );

		} ).forEach( function ( promise ) {

			pending.push( promise );

		} );

		this.nodeCache[ nodeIndex ] = Promise.all( pending ).then( function ( objects ) {

			let node;

			// .isBone isn't in glTF spec. See ._markDefs
			if ( nodeDef.isBone === true ) {

				node = new __WEBPACK_EXTERNAL_MODULE_three_Bone__();

			} else if ( objects.length > 1 ) {

				node = new __WEBPACK_EXTERNAL_MODULE_three_Group__();

			} else if ( objects.length === 1 ) {

				node = objects[ 0 ];

			} else {

				node = new __WEBPACK_EXTERNAL_MODULE_three_Object3D__();

			}

			if ( node !== objects[ 0 ] ) {

				for ( let i = 0, il = objects.length; i < il; i ++ ) {

					node.add( objects[ i ] );

				}

			}

			if ( nodeDef.name ) {

				node.userData.name = nodeDef.name;
				node.name = nodeName;

			}

			assignExtrasToUserData( node, nodeDef );

			if ( nodeDef.extensions ) addUnknownExtensionsToUserData( extensions, node, nodeDef );

			if ( nodeDef.matrix !== undefined ) {

				const matrix = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
				matrix.fromArray( nodeDef.matrix );
				node.applyMatrix4( matrix );

			} else {

				if ( nodeDef.translation !== undefined ) {

					node.position.fromArray( nodeDef.translation );

				}

				if ( nodeDef.rotation !== undefined ) {

					node.quaternion.fromArray( nodeDef.rotation );

				}

				if ( nodeDef.scale !== undefined ) {

					node.scale.fromArray( nodeDef.scale );

				}

			}

			if ( ! parser.associations.has( node ) ) {

				parser.associations.set( node, {} );

			} else if ( nodeDef.mesh !== undefined && parser.meshCache.refs[ nodeDef.mesh ] > 1 ) {

				const mapping = parser.associations.get( node );
				parser.associations.set( node, { ...mapping } );

			}

			parser.associations.get( node ).nodes = nodeIndex;

			return node;

		} );

		return this.nodeCache[ nodeIndex ];

	}

	/**
	 * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#scenes
	 *
	 * @private
	 * @param {number} sceneIndex
	 * @return {Promise<Group>}
	 */
	loadScene( sceneIndex ) {

		const extensions = this.extensions;
		const sceneDef = this.json.scenes[ sceneIndex ];
		const parser = this;

		// Loader returns Group, not Scene.
		// See: https://github.com/mrdoob/three.js/issues/18342#issuecomment-578981172
		const scene = new __WEBPACK_EXTERNAL_MODULE_three_Group__();
		if ( sceneDef.name ) scene.name = parser.createUniqueName( sceneDef.name );

		assignExtrasToUserData( scene, sceneDef );

		if ( sceneDef.extensions ) addUnknownExtensionsToUserData( extensions, scene, sceneDef );

		const nodeIds = sceneDef.nodes || [];

		const pending = [];

		for ( let i = 0, il = nodeIds.length; i < il; i ++ ) {

			pending.push( parser.getDependency( 'node', nodeIds[ i ] ) );

		}

		return Promise.all( pending ).then( function ( nodes ) {

			for ( let i = 0, il = nodes.length; i < il; i ++ ) {

				const node = nodes[ i ];

				// If the node already has a parent, it means it's being reused across multiple scenes.
				// Clone it to avoid the second scene's add() removing it from the first scene.
				// See: https://github.com/mrdoob/three.js/issues/27993
				if ( node.parent !== null ) {

					scene.add( clone( node ) );

				} else {

					scene.add( node );

				}

			}

			// Removes dangling associations, associations that reference a node that
			// didn't make it into the scene.
			const reduceAssociations = ( node ) => {

				const reducedAssociations = new Map();

				for ( const [ key, value ] of parser.associations ) {

					if ( key instanceof __WEBPACK_EXTERNAL_MODULE_three_Material__ || key instanceof __WEBPACK_EXTERNAL_MODULE_three_Texture__ ) {

						reducedAssociations.set( key, value );

					}

				}

				node.traverse( ( node ) => {

					const mappings = parser.associations.get( node );

					if ( mappings != null ) {

						reducedAssociations.set( node, mappings );

					}

				} );

				return reducedAssociations;

			};

			parser.associations = reduceAssociations( scene );

			return scene;

		} );

	}

	_createAnimationTracks( node, inputAccessor, outputAccessor, sampler, target ) {

		const tracks = [];

		const targetName = node.name ? node.name : node.uuid;
		const targetNames = [];

		function collectMorphTargets( object ) {

			if ( object.morphTargetInfluences ) {

				targetNames.push( object.name ? object.name : object.uuid );

			}

		}


		if ( PATH_PROPERTIES[ target.path ] === PATH_PROPERTIES.weights ) {

			collectMorphTargets( node );

			// for multi-primitive meshes, the node is a Group containing the sub-meshes

			if ( node.isGroup ) {

				node.children.forEach( collectMorphTargets );

			}

		} else {

			targetNames.push( targetName );

		}

		let TypedKeyframeTrack;

		switch ( PATH_PROPERTIES[ target.path ] ) {

			case PATH_PROPERTIES.weights:

				TypedKeyframeTrack = __WEBPACK_EXTERNAL_MODULE_three_NumberKeyframeTrack__;
				break;

			case PATH_PROPERTIES.rotation:

				TypedKeyframeTrack = __WEBPACK_EXTERNAL_MODULE_three_QuaternionKeyframeTrack__;
				break;

			case PATH_PROPERTIES.translation:
			case PATH_PROPERTIES.scale:

				TypedKeyframeTrack = __WEBPACK_EXTERNAL_MODULE_three_VectorKeyframeTrack__;
				break;

			default:

				switch ( outputAccessor.itemSize ) {

					case 1:
						TypedKeyframeTrack = __WEBPACK_EXTERNAL_MODULE_three_NumberKeyframeTrack__;
						break;
					case 2:
					case 3:
					default:
						TypedKeyframeTrack = __WEBPACK_EXTERNAL_MODULE_three_VectorKeyframeTrack__;
						break;

				}

				break;

		}

		const interpolation = sampler.interpolation !== undefined ? INTERPOLATION[ sampler.interpolation ] : __WEBPACK_EXTERNAL_MODULE_three_InterpolateLinear__;


		const outputArray = this._getArrayFromAccessor( outputAccessor );

		for ( let j = 0, jl = targetNames.length; j < jl; j ++ ) {

			const track = new TypedKeyframeTrack(
				targetNames[ j ] + '.' + PATH_PROPERTIES[ target.path ],
				inputAccessor.array,
				outputArray,
				interpolation
			);

			// Override interpolation with custom factory method.
			if ( sampler.interpolation === 'CUBICSPLINE' ) {

				this._createCubicSplineTrackInterpolant( track );

			}

			tracks.push( track );

		}

		return tracks;

	}

	_getArrayFromAccessor( accessor ) {

		let outputArray = accessor.array;

		if ( accessor.normalized ) {

			const scale = getNormalizedComponentScale( outputArray.constructor );
			const scaled = new Float32Array( outputArray.length );

			for ( let j = 0, jl = outputArray.length; j < jl; j ++ ) {

				scaled[ j ] = outputArray[ j ] * scale;

			}

			outputArray = scaled;

		}

		return outputArray;

	}

	_createCubicSplineTrackInterpolant( track ) {

		track.createInterpolant = function InterpolantFactoryMethodGLTFCubicSpline( result ) {

			// A CUBICSPLINE keyframe in glTF has three output values for each input value,
			// representing inTangent, splineVertex, and outTangent. As a result, track.getValueSize()
			// must be divided by three to get the interpolant's sampleSize argument.

			const interpolantType = ( this instanceof __WEBPACK_EXTERNAL_MODULE_three_QuaternionKeyframeTrack__ ) ? GLTFCubicSplineQuaternionInterpolant : GLTFCubicSplineInterpolant;

			return new interpolantType( this.times, this.values, this.getValueSize() / 3, result );

		};

		// Mark as CUBICSPLINE. `track.getInterpolation()` doesn't support custom interpolants.
		track.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = true;

	}

}

/**
 *
 * @private
 * @param {BufferGeometry} geometry
 * @param {GLTF.Primitive} primitiveDef
 * @param {GLTFParser} parser
 */
function computeBounds( geometry, primitiveDef, parser ) {

	const attributes = primitiveDef.attributes;

	const box = new __WEBPACK_EXTERNAL_MODULE_three_Box3__();

	if ( attributes.POSITION !== undefined ) {

		const accessor = parser.json.accessors[ attributes.POSITION ];

		const min = accessor.min;
		const max = accessor.max;

		// glTF requires 'min' and 'max', but VRM (which extends glTF) currently ignores that requirement.

		if ( min !== undefined && max !== undefined ) {

			box.set(
				new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( min[ 0 ], min[ 1 ], min[ 2 ] ),
				new __WEBPACK_EXTERNAL_MODULE_three_Vector3__( max[ 0 ], max[ 1 ], max[ 2 ] )
			);

			if ( accessor.normalized ) {

				const boxScale = getNormalizedComponentScale( WEBGL_COMPONENT_TYPES[ accessor.componentType ] );
				box.min.multiplyScalar( boxScale );
				box.max.multiplyScalar( boxScale );

			}

		} else {

			console.warn( 'THREE.GLTFLoader: Missing min/max properties for accessor POSITION.' );

			return;

		}

	} else {

		return;

	}

	const targets = primitiveDef.targets;

	if ( targets !== undefined ) {

		const maxDisplacement = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
		const vector = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();

		for ( let i = 0, il = targets.length; i < il; i ++ ) {

			const target = targets[ i ];

			if ( target.POSITION !== undefined ) {

				const accessor = parser.json.accessors[ target.POSITION ];
				const min = accessor.min;
				const max = accessor.max;

				// glTF requires 'min' and 'max', but VRM (which extends glTF) currently ignores that requirement.

				if ( min !== undefined && max !== undefined ) {

					// we need to get max of absolute components because target weight is [-1,1]
					vector.setX( Math.max( Math.abs( min[ 0 ] ), Math.abs( max[ 0 ] ) ) );
					vector.setY( Math.max( Math.abs( min[ 1 ] ), Math.abs( max[ 1 ] ) ) );
					vector.setZ( Math.max( Math.abs( min[ 2 ] ), Math.abs( max[ 2 ] ) ) );


					if ( accessor.normalized ) {

						const boxScale = getNormalizedComponentScale( WEBGL_COMPONENT_TYPES[ accessor.componentType ] );
						vector.multiplyScalar( boxScale );

					}

					// Note: this assumes that the sum of all weights is at most 1. This isn't quite correct - it's more conservative
					// to assume that each target can have a max weight of 1. However, for some use cases - notably, when morph targets
					// are used to implement key-frame animations and as such only two are active at a time - this results in very large
					// boxes. So for now we make a box that's sometimes a touch too small but is hopefully mostly of reasonable size.
					maxDisplacement.max( vector );

				} else {

					console.warn( 'THREE.GLTFLoader: Missing min/max properties for accessor POSITION.' );

				}

			}

		}

		// As per comment above this box isn't conservative, but has a reasonable size for a very large number of morph targets.
		box.expandByVector( maxDisplacement );

	}

	geometry.boundingBox = box;

	const sphere = new __WEBPACK_EXTERNAL_MODULE_three_Sphere__();

	box.getCenter( sphere.center );
	sphere.radius = box.min.distanceTo( box.max ) / 2;

	geometry.boundingSphere = sphere;

}

/**
 *
 * @private
 * @param {BufferGeometry} geometry
 * @param {GLTF.Primitive} primitiveDef
 * @param {GLTFParser} parser
 * @return {Promise<BufferGeometry>}
 */
function addPrimitiveAttributes( geometry, primitiveDef, parser ) {

	const attributes = primitiveDef.attributes;

	const pending = [];

	function assignAttributeAccessor( accessorIndex, attributeName ) {

		return parser.getDependency( 'accessor', accessorIndex )
			.then( function ( accessor ) {

				geometry.setAttribute( attributeName, accessor );

			} );

	}

	for ( const gltfAttributeName in attributes ) {

		const threeAttributeName = ATTRIBUTES[ gltfAttributeName ] || gltfAttributeName.toLowerCase();

		// Skip attributes already provided by e.g. Draco extension.
		if ( threeAttributeName in geometry.attributes ) continue;

		pending.push( assignAttributeAccessor( attributes[ gltfAttributeName ], threeAttributeName ) );

	}

	if ( primitiveDef.indices !== undefined && ! geometry.index ) {

		const accessor = parser.getDependency( 'accessor', primitiveDef.indices ).then( function ( accessor ) {

			geometry.setIndex( accessor );

		} );

		pending.push( accessor );

	}

	if ( __WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.workingColorSpace !== __WEBPACK_EXTERNAL_MODULE_three_LinearSRGBColorSpace__ && 'COLOR_0' in attributes ) {

		console.warn( `THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${__WEBPACK_EXTERNAL_MODULE_three_ColorManagement__.workingColorSpace}" not supported.` );

	}

	assignExtrasToUserData( geometry, primitiveDef );

	computeBounds( geometry, primitiveDef, parser );

	return Promise.all( pending ).then( function () {

		return primitiveDef.targets !== undefined
			? addMorphTargets( geometry, primitiveDef.targets, parser )
			: geometry;

	} );

}

/**
 * Loader result of `GLTFLoader`.
 *
 * @typedef {Object} GLTFLoader~LoadObject
 * @property {Array<AnimationClip>} animations - An array of animation clips.
 * @property {Object} asset - Meta data about the loaded asset.
 * @property {Array<Camera>} cameras - An array of cameras.
 * @property {GLTFParser} parser - A reference to the internal parser.
 * @property {Group} scene - The default scene.
 * @property {Array<Group>} scenes - glTF assets might define multiple scenes.
 * @property {Object} userData - Additional data.
 **/



;// ./node_modules/@newkrok/three-utils/dist/assets/loaders.js
/* unused harmony import specifier */ var THREE;



// Loader instances
const gltfLoader = new GLTFLoader();
const fbxLoaders = Array.from({ length: 3 }, () => ({
    loader: new FBXLoader(),
    isUsed: false,
}));
let fbxLoaderQueue = (/* unused pure expression or super */ null && ([]));
const textureLoaders = Array.from({ length: 3 }, () => ({
    loader: new __WEBPACK_EXTERNAL_MODULE_three_TextureLoader__(),
    isUsed: false,
}));
let textureLoaderQueue = (/* unused pure expression or super */ null && ([]));
const audioLoaders = Array.from({ length: 3 }, () => ({
    loader: new __WEBPACK_EXTERNAL_MODULE_three_AudioLoader__(),
    isUsed: false,
}));
let audioLoaderQueue = (/* unused pure expression or super */ null && ([]));
// Loader getter functions
const getFBXLoader = (onComplete) => getLoader(onComplete, fbxLoaders, fbxLoaderQueue);
const getTextureLoader = (onComplete) => getLoader(onComplete, textureLoaders, textureLoaderQueue);
const getAudioLoader = (onComplete) => getLoader(onComplete, audioLoaders, audioLoaderQueue);
const getLoader = (onComplete, loaders, loaderQueue) => {
    const loader = loaders.find((entry) => !entry.isUsed);
    if (loader) {
        loader.isUsed = true;
        onComplete(loader.loader);
    }
    else {
        loaderQueue.push((availableLoader) => {
            onComplete(availableLoader.loader);
            availableLoader.isUsed = true;
        });
    }
};
// Loader release functions
const releaseFBXLoader = (loader) => releaseLoader(loader, fbxLoaders, fbxLoaderQueue);
const releaseTextureLoader = (loader) => releaseLoader(loader, textureLoaders, textureLoaderQueue);
const releaseAudioLoader = (loader) => releaseLoader(loader, audioLoaders, audioLoaderQueue);
const releaseLoader = (loader, loaders, loaderQueue) => {
    const loaderObject = loaders.find((entry) => entry.loader === loader);
    if (loaderObject) {
        if (loaderQueue.length > 0) {
            const callback = loaderQueue.shift();
            if (callback) {
                callback(loaderObject);
            }
        }
        else {
            loaderObject.isUsed = false;
        }
    }
};
// GLTF Model loading
const loadGLTFModelRoutine = ({ list, onElementLoaded, onComplete, onError, }) => {
    if (list.length > 0) {
        const { url } = list[0];
        gltfLoader.load(url, ({ scene, animations }) => {
            onElementLoaded({
                ...list[0],
                gltfModel: { scene, animations },
            });
            list.shift();
            loadGLTFModelRoutine({ list, onElementLoaded, onComplete, onError });
        }, undefined, (error) => onError(String(error)));
    }
    else {
        onComplete();
    }
};
const loadGLTFModels = (list, onProgress) => {
    const elements = [];
    const onElementLoaded = (element) => {
        elements.push(element);
        onProgress();
    };
    const promise = new Promise((resolve, reject) => {
        loadGLTFModelRoutine({
            list: [...list], // Create a copy to avoid modifying the original
            onElementLoaded,
            onComplete: () => resolve(elements),
            onError: (error) => reject(new Error(`Something wrong happened: ${error}`)),
        });
    });
    return promise;
};
const loadFBXModels = (list, onProgress) => {
    const elements = [];
    const onElementLoaded = (element) => {
        elements.push(element);
        onProgress();
    };
    const promise = new Promise((resolve, reject) => {
        if (list.length > 0) {
            const listCopy = [...list]; // Create a copy to avoid modifying the original
            while (listCopy.length > 0) {
                const { url, id } = listCopy[0];
                const current = listCopy[0];
                listCopy.shift();
                getFBXLoader((fbxLoader) => fbxLoader.load(url, (fbxModel) => {
                    onElementLoaded({ ...current, id, fbxModel });
                    releaseFBXLoader(fbxLoader);
                    if (!fbxLoaders.some((entry) => entry.isUsed)) {
                        resolve(elements);
                    }
                }, undefined, (error) => reject(new Error(`Something wrong happened with an FBX model: ${id}, url: ${url}, error: ${error}`))));
            }
        }
        else {
            resolve([]);
        }
    });
    return promise;
};
const loadTextures = (list, onProgress) => {
    const elements = [];
    const onElementLoaded = (element) => {
        elements.push(element);
        onProgress();
    };
    const promise = new Promise((resolve, reject) => {
        if (list.length > 0) {
            const listCopy = [...list]; // Create a copy to avoid modifying the original
            while (listCopy.length > 0) {
                const { url, id } = listCopy[0];
                listCopy.shift();
                getTextureLoader((textureLoader) => textureLoader.load(url, (texture) => {
                    texture.wrapS = THREE.RepeatWrapping;
                    texture.wrapT = THREE.RepeatWrapping;
                    onElementLoaded({ id, url, texture });
                    releaseTextureLoader(textureLoader);
                    if (!textureLoaders.some((entry) => entry.isUsed)) {
                        resolve(elements);
                    }
                }, undefined, (error) => reject(new Error(`Something wrong happened with a texture: ${id}, url: ${url}, error: ${error}`))));
            }
        }
        else {
            resolve([]);
        }
    });
    return promise;
};
const loadAudio = (list, onProgress) => {
    const elements = [];
    const onElementLoaded = (element) => {
        elements.push(element);
        onProgress();
    };
    const promise = new Promise((resolve, reject) => {
        if (list.length > 0) {
            const listCopy = [...list]; // Create a copy to avoid modifying the original
            while (listCopy.length > 0) {
                const { url, id } = listCopy[0];
                listCopy.shift();
                getAudioLoader((audioLoader) => audioLoader.load(url, (audioBuffer) => {
                    onElementLoaded({ id, url, audioBuffer });
                    releaseAudioLoader(audioLoader);
                    if (!audioLoaders.some((entry) => entry.isUsed)) {
                        resolve(elements);
                    }
                }, undefined, (error) => reject(new Error(`Something wrong happened with an audio: ${id}, url: ${url}, error: ${error}`))));
            }
        }
        else {
            resolve([]);
        }
    });
    return promise;
};

;// ./node_modules/@newkrok/three-utils/dist/assets/assets.js
/* unused harmony import specifier */ var assets_THREE;
/* unused harmony import specifier */ var assets_clone;
/* unused harmony import specifier */ var deepDispose;
/* unused harmony import specifier */ var assets_loadTextures;
/* unused harmony import specifier */ var assets_loadGLTFModels;
/* unused harmony import specifier */ var assets_loadFBXModels;
/* unused harmony import specifier */ var assets_loadAudio;




// Asset registries
const _fbxModels = {};
const _gltfModels = {};
const _textures = {};
const _audioBuffers = {};
const fbxSkeletonAnimations = {};
// FBX Model functions
const registerFBXModel = ({ id, fbxModel, }) => {
    _fbxModels[id] = fbxModel;
};
const getFBXModel = (id) => {
    const clonedModel = assets_clone(_fbxModels[id]);
    clonedModel.animations = [..._fbxModels[id].animations];
    return clonedModel;
};
// FBX Skeleton Animation functions
const registerFBXSkeletonAnimation = ({ id, fbxModel, }) => {
    fbxSkeletonAnimations[id] = fbxModel.animations[0];
};
const getFBXSkeletonAnimation = (id) => {
    return fbxSkeletonAnimations[id];
};
// GLTF Model functions
const registerGLTFModel = ({ id, gltfModel, }) => {
    _gltfModels[id] = gltfModel;
};
const getGLTFModel = (id) => {
    return _gltfModels[id];
};
// Texture functions
const registerTexture = ({ id, texture, }) => {
    _textures[id] = texture;
};
const getTexture = (id) => {
    return _textures[id] || null;
};
// Audio Buffer functions
const registerAudioBuffer = ({ id, audioBuffer, }) => {
    _audioBuffers[id] = audioBuffer;
};
const getAudioBuffer = (id) => {
    return _audioBuffers[id] || null;
};
// Material helper functions
const applyMaterialConfig = ({ material, materialConfig = { texture: { id: '' }, color: 0xffffff, alphaTest: 0.5 }, }) => {
    if ('map' in material) {
        material.map = materialConfig?.texture?.id
            ? getTexture(materialConfig.texture.id)
            : null;
    }
    if ('alphaTest' in material) {
        material.alphaTest = materialConfig?.alphaTest || 0.5;
    }
    if ('color' in material) {
        material.color = new assets_THREE.Color(materialConfig?.color || 0xffffff);
    }
};
const createMaterial = (materialConfig = {
    materialType: undefined,
    texture: { id: '', flipY: true },
    color: 0xffffff,
    alphaTest: 0.5,
}) => {
    let material = null;
    if (materialConfig instanceof Array) {
        material = materialConfig.map((config) => createMaterial(config));
    }
    else if (materialConfig.materialType) {
        const map = materialConfig?.texture?.id
            ? getTexture(materialConfig.texture.id)
            : null;
        if (map) {
            map.flipY = materialConfig?.texture?.flipY ?? true;
        }
        material = new materialConfig.materialType({
            map,
            alphaTest: materialConfig.alphaTest || 0.5,
            color: new assets_THREE.Color(materialConfig?.color || 0xffffff),
        });
    }
    return material;
};
// Asset disposal
const disposeAssets = () => {
    Object.entries(_textures).forEach(([key, texture]) => {
        texture.dispose();
        delete _textures[key];
    });
    Object.entries(_fbxModels).forEach(([key, fbxModel]) => {
        deepDispose(fbxModel);
        delete _fbxModels[key];
    });
    Object.entries(_gltfModels).forEach(([key, gltfModel]) => {
        deepDispose(gltfModel.scene);
        delete _gltfModels[key];
    });
};
// Main asset loading function
const loadAssets = ({ textures, gltfModels, fbxModels, fbxSkeletonAnimations, audio, onProgress, verbose = true, }) => new Promise((resolve) => {
    const result = { fbxModels: [] };
    const assetCount = textures.length +
        gltfModels.length +
        fbxModels.length +
        fbxSkeletonAnimations.length +
        audio.length;
    let loadedCount = 0;
    const updateProgress = () => {
        loadedCount++;
        onProgress && onProgress(loadedCount / assetCount);
    };
    assets_loadTextures(textures, updateProgress)
        .then((loadedTextures) => {
        loadedTextures.forEach((element) => {
            element.texture.colorSpace = assets_THREE.SRGBColorSpace;
            registerTexture(element);
        });
        if (verbose) {
            console.log(`Textures(${loadedTextures.length}) are loaded...`);
        }
        assets_loadGLTFModels(gltfModels, updateProgress).then((loadedModels) => {
            loadedModels.forEach((element) => {
                const createdMaterial = createMaterial(element.material);
                let textureIndex = 0;
                element.gltfModel.scene.traverse((child) => {
                    if (child.isMesh) {
                        const mesh = child;
                        mesh.castShadow = true;
                        mesh.receiveShadow = true;
                        if (mesh.material instanceof Array) {
                            mesh.material = createdMaterial;
                        }
                        else {
                            mesh.material =
                                createdMaterial instanceof Array
                                    ? createdMaterial[textureIndex]
                                    : createdMaterial || mesh.material;
                        }
                        if (!createdMaterial && element.material) {
                            applyMaterialConfig({
                                material: mesh.material,
                                materialConfig: element.material instanceof Array
                                    ? element.material[textureIndex]
                                    : element.material,
                            });
                        }
                        textureIndex++;
                    }
                });
                registerGLTFModel(element);
            });
            if (verbose) {
                console.log(`GLTF Models(${loadedModels.length}) are loaded...`);
            }
            assets_loadFBXModels(fbxSkeletonAnimations, updateProgress).then((loadedAnimations) => {
                loadedAnimations.forEach((element) => {
                    registerFBXSkeletonAnimation(element);
                });
                if (verbose) {
                    console.log(`FBX Skeleton Animations(${loadedAnimations.length}) are loaded...`);
                }
                assets_loadFBXModels(fbxModels, updateProgress)
                    .then((loadedModels) => {
                    loadedModels.forEach((element) => {
                        const createdMaterial = createMaterial(element.material);
                        let textureIndex = 0;
                        element.fbxModel.traverse((child) => {
                            if (child.isMesh) {
                                const mesh = child;
                                mesh.castShadow = true;
                                mesh.receiveShadow = true;
                                if (mesh.material instanceof Array) {
                                    mesh.material = createdMaterial;
                                }
                                else {
                                    mesh.material =
                                        createdMaterial instanceof Array
                                            ? createdMaterial[textureIndex]
                                            : createdMaterial ||
                                                mesh.material;
                                }
                                if (!createdMaterial && element.material) {
                                    applyMaterialConfig({
                                        material: mesh.material,
                                        materialConfig: element.material instanceof Array
                                            ? element.material[textureIndex]
                                            : element.material,
                                    });
                                }
                                textureIndex++;
                            }
                        });
                        registerFBXModel(element);
                    });
                    result.fbxModels = [...loadedModels];
                    if (verbose) {
                        console.log(`FBX Models(${loadedModels.length}) are loaded...`);
                    }
                    assets_loadAudio(audio, updateProgress)
                        .then((loadedAudio) => {
                        loadedAudio.forEach((element) => registerAudioBuffer(element));
                        if (verbose) {
                            console.log(`Audio files(${loadedAudio.length}) are loaded...`);
                        }
                        resolve(result);
                    })
                        .catch((error) => console.error(`Fatal error during Audio files preloader phase: ${error}`));
                })
                    .catch((error) => console.error(`Fatal error during FBX model preloader phase: ${error}`));
            });
        });
    })
        .catch((error) => console.error(`Fatal error during texture preloader phase: ${error}`));
});

;// ./node_modules/@newkrok/three-utils/dist/assets/index.js


;// ../../node_modules/three/examples/jsm/helpers/PositionalAudioHelper.js


/**
 * This helper displays the directional cone of a positional audio.
 *
 * `PositionalAudioHelper` must be added as a child of the positional audio.
 *
 * ```js
 * const positionalAudio = new THREE.PositionalAudio( listener );
 * positionalAudio.setDirectionalCone( 180, 230, 0.1 );
 * scene.add( positionalAudio );
 *
 * const helper = new PositionalAudioHelper( positionalAudio );
 * positionalAudio.add( helper );
 * ```
 *
 * @augments Line
 * @three_import import { PositionalAudioHelper } from 'three/addons/helpers/PositionalAudioHelper.js';
 */
class PositionalAudioHelper extends __WEBPACK_EXTERNAL_MODULE_three_Line__ {

	/**
	 * Constructs a new positional audio helper.
	 *
	 * @param {PositionalAudio} audio - The audio to visualize.
	 * @param {number} [range=1] - The range of the directional cone.
	 * @param {number} [divisionsInnerAngle=16] - The number of divisions of the inner part of the directional cone.
	 * @param {number} [divisionsOuterAngle=2] The number of divisions of the outer part of the directional cone.
	 */
	constructor( audio, range = 1, divisionsInnerAngle = 16, divisionsOuterAngle = 2 ) {

		const geometry = new __WEBPACK_EXTERNAL_MODULE_three_BufferGeometry__();
		const divisions = divisionsInnerAngle + divisionsOuterAngle * 2;
		const positions = new Float32Array( ( divisions * 3 + 3 ) * 3 );
		geometry.setAttribute( 'position', new __WEBPACK_EXTERNAL_MODULE_three_BufferAttribute__( positions, 3 ) );

		const materialInnerAngle = new __WEBPACK_EXTERNAL_MODULE_three_LineBasicMaterial__( { color: 0x00ff00 } );
		const materialOuterAngle = new __WEBPACK_EXTERNAL_MODULE_three_LineBasicMaterial__( { color: 0xffff00 } );

		super( geometry, [ materialOuterAngle, materialInnerAngle ] );

		/**
		 * The audio to visualize.
		 *
		 * @type {PositionalAudio}
		 */
		this.audio = audio;

		/**
		 * The range of the directional cone.
		 *
		 * @type {number}
		 * @default 1
		 */
		this.range = range;

		/**
		 * The number of divisions of the inner part of the directional cone.
		 *
		 * @type {number}
		 * @default 16
		 */
		this.divisionsInnerAngle = divisionsInnerAngle;

		/**
		 * The number of divisions of the outer part of the directional cone.
		 *
		 * @type {number}
		 * @default 2
		 */
		this.divisionsOuterAngle = divisionsOuterAngle;

		this.type = 'PositionalAudioHelper';

		this.update();

	}

	/**
	 * Updates the helper. This method must be called whenever the directional cone
	 * of the positional audio is changed.
	 */
	update() {

		const audio = this.audio;
		const range = this.range;
		const divisionsInnerAngle = this.divisionsInnerAngle;
		const divisionsOuterAngle = this.divisionsOuterAngle;

		const coneInnerAngle = __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( audio.panner.coneInnerAngle );
		const coneOuterAngle = __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.degToRad( audio.panner.coneOuterAngle );

		const halfConeInnerAngle = coneInnerAngle / 2;
		const halfConeOuterAngle = coneOuterAngle / 2;

		let start = 0;
		let count = 0;
		let i;
		let stride;

		const geometry = this.geometry;
		const positionAttribute = geometry.attributes.position;

		geometry.clearGroups();

		//

		function generateSegment( from, to, divisions, materialIndex ) {

			const step = ( to - from ) / divisions;

			positionAttribute.setXYZ( start, 0, 0, 0 );
			count ++;

			for ( i = from; i < to; i += step ) {

				stride = start + count;

				positionAttribute.setXYZ( stride, Math.sin( i ) * range, 0, Math.cos( i ) * range );
				positionAttribute.setXYZ( stride + 1, Math.sin( Math.min( i + step, to ) ) * range, 0, Math.cos( Math.min( i + step, to ) ) * range );
				positionAttribute.setXYZ( stride + 2, 0, 0, 0 );

				count += 3;

			}

			geometry.addGroup( start, count, materialIndex );

			start += count;
			count = 0;

		}

		//

		generateSegment( - halfConeOuterAngle, - halfConeInnerAngle, divisionsOuterAngle, 0 );
		generateSegment( - halfConeInnerAngle, halfConeInnerAngle, divisionsInnerAngle, 1 );
		generateSegment( halfConeInnerAngle, halfConeOuterAngle, divisionsOuterAngle, 0 );

		//

		positionAttribute.needsUpdate = true;

		if ( coneInnerAngle === coneOuterAngle ) this.material[ 0 ].visible = false;

	}

	/**
	 * Frees the GPU-related resources allocated by this instance. Call this
	 * method whenever this instance is no longer used in your app.
	 */
	dispose() {

		this.geometry.dispose();
		this.material[ 0 ].dispose();
		this.material[ 1 ].dispose();

	}

}




;// ./node_modules/@newkrok/three-utils/dist/audio/audio.js



const defaultConfig = { loop: false, volume: 1, isMusic: false };
let audioConfig = {};
const audioCache = {};
const coreConfig = {
    masterVolume: 1,
    musicVolume: 1,
    effectsVolume: 1,
};
const setAudioConfig = (config) => {
    audioConfig = config;
};
const playAudio = ({ audioId, position, radius = 1, scene, camera, cacheId, }) => {
    const now = Date.now();
    let audio;
    if (!cacheId || !audioCache[cacheId]) {
        const audioBuffer = getAudioBuffer(audioId);
        if (!audioBuffer) {
            console.warn(`Audio buffer not found for ID: ${audioId}`);
            return;
        }
        const { loop, volume, isMusic } = {
            ...defaultConfig,
            ...audioConfig[audioId],
        };
        const listener = new __WEBPACK_EXTERNAL_MODULE_three_AudioListener__();
        let container;
        if (position && scene && camera) {
            audio = new __WEBPACK_EXTERNAL_MODULE_three_PositionalAudio__(listener);
            audio.setRefDistance(radius);
            const sphere = new __WEBPACK_EXTERNAL_MODULE_three_SphereGeometry__(radius, 32, 32);
            container = new __WEBPACK_EXTERNAL_MODULE_three_Mesh__(sphere);
            container.visible = false;
            const helper = new PositionalAudioHelper(audio, radius);
            audio.add(helper);
            container.position.copy(position);
            container.add(audio);
            scene.add(container);
            camera.add(listener);
        }
        else {
            audio = new __WEBPACK_EXTERNAL_MODULE_three_Audio__(listener);
        }
        audio.setBuffer(audioBuffer);
        audio.setLoop(loop || false);
        audio.setVolume((volume || 1) *
            coreConfig.masterVolume *
            (isMusic ? coreConfig.musicVolume : coreConfig.effectsVolume));
        audioCache[cacheId || audioId] = {
            audio,
            audioId,
            container,
            lastPlayedTime: now,
        };
    }
    else {
        const { audio: cachedAudio, container } = audioCache[cacheId];
        audio = cachedAudio;
        if (audio.isPlaying)
            audio.stop();
        if (container && position)
            container.position.copy(position);
        audioCache[cacheId].lastPlayedTime = now;
    }
    audio.play();
};
const stopAudio = (cacheId) => {
    const audioEntry = getAudioCache(cacheId);
    if (audioEntry.audio && audioEntry.audio.isPlaying) {
        audioEntry.audio.stop();
    }
};
const getAudioCache = (cacheId) => {
    return (audioCache[cacheId] || {
        audio: null,
        audioId: '',
        container: undefined,
        lastPlayedTime: 0,
    });
};
const updateMusicVolumes = () => {
    Object.keys(audioCache).forEach((key) => {
        const { audio, audioId } = getAudioCache(key);
        if (audio) {
            const { volume, isMusic } = { ...defaultConfig, ...audioConfig[audioId] };
            audio.setVolume((volume || 1) *
                coreConfig.masterVolume *
                (isMusic ? coreConfig.musicVolume : coreConfig.effectsVolume));
        }
    });
};
const setMasterVolume = (masterVolume) => {
    coreConfig.masterVolume = masterVolume;
    updateMusicVolumes();
};
const setMusicVolume = (musicVolume) => {
    coreConfig.musicVolume = musicVolume;
    updateMusicVolumes();
};
const setEffectsVolume = (effectsVolume) => {
    coreConfig.effectsVolume = effectsVolume;
    updateMusicVolumes();
};
const AudioPlayer = {
    playAudio,
    stopAudio,
    setMasterVolume,
    setMusicVolume,
    setEffectsVolume,
};
/* harmony default export */ const audio = ((/* unused pure expression or super */ null && (AudioPlayer)));

;// ./node_modules/@newkrok/three-utils/dist/audio/index.js


;// ./node_modules/@newkrok/three-utils/dist/index.js










;// external "three/webgpu"

;// ./dist/index.js
/* unused harmony import specifier */ var THREE3;
/* unused harmony import specifier */ var ObjectUtils;
/* unused harmony import specifier */ var StorageBufferAttribute;





// src/js/effects/three-particles/version.ts
var REVISION = "4.0.0" ;
if (typeof globalThis !== "undefined") {
  const g = globalThis;
  if (g.__THREE_PARTICLES__ && g.__THREE_PARTICLES__ !== REVISION) {
    console.warn(
      "WARNING: Multiple instances of @cyberluke/three-particles being imported."
    );
  } else {
    g.__THREE_PARTICLES__ = REVISION;
  }
}

// src/js/effects/three-particles/color-utils.ts
var sRGBToLinear = (c) => c < 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
var linearToSRGB = (c) => c < 31308e-7 ? c * 12.92 : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
var rgbSRGBToLinear = (c) => ({
  r: sRGBToLinear(c.r ?? 0),
  g: sRGBToLinear(c.g ?? 0),
  b: sRGBToLinear(c.b ?? 0)
});

// src/js/effects/three-particles/three-particles-bezier.ts
var cache = (/* unused pure expression or super */ null && ([]));
var nCr = (n, k) => {
  let z = 1;
  for (let i = 1; i <= k; i++) z *= (n + 1 - i) / i;
  return z;
};
var createBezierCurveFunction = (particleSystemId, bezierPoints) => {
  const cacheEntry = cache.find((item) => item.bezierPoints === bezierPoints);
  if (cacheEntry) {
    if (!cacheEntry.referencedBy.includes(particleSystemId))
      cacheEntry.referencedBy.push(particleSystemId);
    return cacheEntry.curveFunction;
  }
  const entry = {
    referencedBy: [particleSystemId],
    bezierPoints,
    curveFunction: (percentage) => {
      if (percentage < 0) return bezierPoints[0].y;
      if (percentage > 1) return bezierPoints[bezierPoints.length - 1].y;
      let start = 0;
      let stop = bezierPoints.length - 1;
      for (let i = 0; i < bezierPoints.length; i++) {
        const point = bezierPoints[i];
        if (percentage < (point.percentage ?? 0)) {
          stop = i;
          break;
        }
        if (point.percentage !== void 0) start = i;
      }
      const n = stop - start;
      const calculatedPercentage = (percentage - (bezierPoints[start].percentage ?? 0)) / ((bezierPoints[stop].percentage ?? 1) - (bezierPoints[start].percentage ?? 0));
      let value = 0;
      for (let i = 0; i <= n; i++) {
        const p = bezierPoints[start + i];
        const c = nCr(n, i) * Math.pow(1 - calculatedPercentage, n - i) * Math.pow(calculatedPercentage, i);
        value += c * p.y;
      }
      return value;
    }
  };
  cache.push(entry);
  return entry.curveFunction;
};
var removeBezierCurveFunction = (particleSystemId) => {
  while (true) {
    const index = cache.findIndex(
      (item) => item.referencedBy.includes(particleSystemId)
    );
    if (index === -1) break;
    const entry = cache[index];
    entry.referencedBy = entry.referencedBy.filter(
      (id) => id !== particleSystemId
    );
    if (entry.referencedBy.length === 0) cache.splice(index, 1);
  }
};
var getBezierCacheSize = () => cache.length;
var CurveFunctionId = /* @__PURE__ */ ((CurveFunctionId3) => {
  CurveFunctionId3["BEZIER"] = "BEZIER";
  CurveFunctionId3["LINEAR"] = "LINEAR";
  CurveFunctionId3["QUADRATIC_IN"] = "QUADRATIC_IN";
  CurveFunctionId3["QUADRATIC_OUT"] = "QUADRATIC_OUT";
  CurveFunctionId3["QUADRATIC_IN_OUT"] = "QUADRATIC_IN_OUT";
  CurveFunctionId3["CUBIC_IN"] = "CUBIC_IN";
  CurveFunctionId3["CUBIC_OUT"] = "CUBIC_OUT";
  CurveFunctionId3["CUBIC_IN_OUT"] = "CUBIC_IN_OUT";
  CurveFunctionId3["QUARTIC_IN"] = "QUARTIC_IN";
  CurveFunctionId3["QUARTIC_OUT"] = "QUARTIC_OUT";
  CurveFunctionId3["QUARTIC_IN_OUT"] = "QUARTIC_IN_OUT";
  CurveFunctionId3["QUINTIC_IN"] = "QUINTIC_IN";
  CurveFunctionId3["QUINTIC_OUT"] = "QUINTIC_OUT";
  CurveFunctionId3["QUINTIC_IN_OUT"] = "QUINTIC_IN_OUT";
  CurveFunctionId3["SINUSOIDAL_IN"] = "SINUSOIDAL_IN";
  CurveFunctionId3["SINUSOIDAL_OUT"] = "SINUSOIDAL_OUT";
  CurveFunctionId3["SINUSOIDAL_IN_OUT"] = "SINUSOIDAL_IN_OUT";
  CurveFunctionId3["EXPONENTIAL_IN"] = "EXPONENTIAL_IN";
  CurveFunctionId3["EXPONENTIAL_OUT"] = "EXPONENTIAL_OUT";
  CurveFunctionId3["EXPONENTIAL_IN_OUT"] = "EXPONENTIAL_IN_OUT";
  CurveFunctionId3["CIRCULAR_IN"] = "CIRCULAR_IN";
  CurveFunctionId3["CIRCULAR_OUT"] = "CIRCULAR_OUT";
  CurveFunctionId3["CIRCULAR_IN_OUT"] = "CIRCULAR_IN_OUT";
  CurveFunctionId3["ELASTIC_IN"] = "ELASTIC_IN";
  CurveFunctionId3["ELASTIC_OUT"] = "ELASTIC_OUT";
  CurveFunctionId3["ELASTIC_IN_OUT"] = "ELASTIC_IN_OUT";
  CurveFunctionId3["BACK_IN"] = "BACK_IN";
  CurveFunctionId3["BACK_OUT"] = "BACK_OUT";
  CurveFunctionId3["BACK_IN_OUT"] = "BACK_IN_OUT";
  CurveFunctionId3["BOUNCE_IN"] = "BOUNCE_IN";
  CurveFunctionId3["BOUNCE_OUT"] = "BOUNCE_OUT";
  CurveFunctionId3["BOUNCE_IN_OUT"] = "BOUNCE_IN_OUT";
  return CurveFunctionId3;
})(CurveFunctionId || {});
var curveFunctionIdMap = {
  ["LINEAR" /* LINEAR */]: easing_functions.Linear.None,
  ["QUADRATIC_IN" /* QUADRATIC_IN */]: easing_functions.Quadratic.In,
  ["QUADRATIC_OUT" /* QUADRATIC_OUT */]: easing_functions.Quadratic.Out,
  ["QUADRATIC_IN_OUT" /* QUADRATIC_IN_OUT */]: easing_functions.Quadratic.InOut,
  ["CUBIC_IN" /* CUBIC_IN */]: easing_functions.Cubic.In,
  ["CUBIC_OUT" /* CUBIC_OUT */]: easing_functions.Cubic.Out,
  ["CUBIC_IN_OUT" /* CUBIC_IN_OUT */]: easing_functions.Cubic.InOut,
  ["QUARTIC_IN" /* QUARTIC_IN */]: easing_functions.Quartic.In,
  ["QUARTIC_OUT" /* QUARTIC_OUT */]: easing_functions.Quartic.Out,
  ["QUARTIC_IN_OUT" /* QUARTIC_IN_OUT */]: easing_functions.Quartic.InOut,
  ["QUINTIC_IN" /* QUINTIC_IN */]: easing_functions.Quintic.In,
  ["QUINTIC_OUT" /* QUINTIC_OUT */]: easing_functions.Quintic.Out,
  ["QUINTIC_IN_OUT" /* QUINTIC_IN_OUT */]: easing_functions.Quintic.InOut,
  ["SINUSOIDAL_IN" /* SINUSOIDAL_IN */]: easing_functions.Sinusoidal.In,
  ["SINUSOIDAL_OUT" /* SINUSOIDAL_OUT */]: easing_functions.Sinusoidal.Out,
  ["SINUSOIDAL_IN_OUT" /* SINUSOIDAL_IN_OUT */]: easing_functions.Sinusoidal.InOut,
  ["EXPONENTIAL_IN" /* EXPONENTIAL_IN */]: easing_functions.Exponential.In,
  ["EXPONENTIAL_OUT" /* EXPONENTIAL_OUT */]: easing_functions.Exponential.Out,
  ["EXPONENTIAL_IN_OUT" /* EXPONENTIAL_IN_OUT */]: easing_functions.Exponential.InOut,
  ["CIRCULAR_IN" /* CIRCULAR_IN */]: easing_functions.Circular.In,
  ["CIRCULAR_OUT" /* CIRCULAR_OUT */]: easing_functions.Circular.Out,
  ["CIRCULAR_IN_OUT" /* CIRCULAR_IN_OUT */]: easing_functions.Circular.InOut,
  ["ELASTIC_IN" /* ELASTIC_IN */]: easing_functions.Elastic.In,
  ["ELASTIC_OUT" /* ELASTIC_OUT */]: easing_functions.Elastic.Out,
  ["ELASTIC_IN_OUT" /* ELASTIC_IN_OUT */]: easing_functions.Elastic.InOut,
  ["BACK_IN" /* BACK_IN */]: easing_functions.Back.In,
  ["BACK_OUT" /* BACK_OUT */]: easing_functions.Back.Out,
  ["BACK_IN_OUT" /* BACK_IN_OUT */]: easing_functions.Back.InOut,
  ["BOUNCE_IN" /* BOUNCE_IN */]: easing_functions.Bounce.In,
  ["BOUNCE_OUT" /* BOUNCE_OUT */]: easing_functions.Bounce.Out,
  ["BOUNCE_IN_OUT" /* BOUNCE_IN_OUT */]: easing_functions.Bounce.InOut
};
var getCurveFunction = (curveFunctionId) => typeof curveFunctionId === "function" ? curveFunctionId : curveFunctionIdMap[curveFunctionId];

// src/js/effects/three-particles/three-particles-enums.ts
var SimulationSpace = /* @__PURE__ */ ((SimulationSpace2) => {
  SimulationSpace2["LOCAL"] = "LOCAL";
  SimulationSpace2["WORLD"] = "WORLD";
  return SimulationSpace2;
})(SimulationSpace || {});
var Shape = /* @__PURE__ */ ((Shape2) => {
  Shape2["SPHERE"] = "SPHERE";
  Shape2["CONE"] = "CONE";
  Shape2["BOX"] = "BOX";
  Shape2["CIRCLE"] = "CIRCLE";
  Shape2["RECTANGLE"] = "RECTANGLE";
  return Shape2;
})(Shape || {});
var EmitFrom = /* @__PURE__ */ ((EmitFrom2) => {
  EmitFrom2["VOLUME"] = "VOLUME";
  EmitFrom2["SHELL"] = "SHELL";
  EmitFrom2["EDGE"] = "EDGE";
  return EmitFrom2;
})(EmitFrom || {});
var TimeMode = /* @__PURE__ */ ((TimeMode2) => {
  TimeMode2["LIFETIME"] = "LIFETIME";
  TimeMode2["FPS"] = "FPS";
  return TimeMode2;
})(TimeMode || {});
var LifeTimeCurve = /* @__PURE__ */ ((LifeTimeCurve2) => {
  LifeTimeCurve2["BEZIER"] = "BEZIER";
  LifeTimeCurve2["EASING"] = "EASING";
  return LifeTimeCurve2;
})(LifeTimeCurve || {});
var SubEmitterTrigger = /* @__PURE__ */ ((SubEmitterTrigger3) => {
  SubEmitterTrigger3["BIRTH"] = "BIRTH";
  SubEmitterTrigger3["DEATH"] = "DEATH";
  return SubEmitterTrigger3;
})(SubEmitterTrigger || {});
var ForceFieldType = /* @__PURE__ */ ((ForceFieldType3) => {
  ForceFieldType3["POINT"] = "POINT";
  ForceFieldType3["DIRECTIONAL"] = "DIRECTIONAL";
  return ForceFieldType3;
})(ForceFieldType || {});
var RendererType = /* @__PURE__ */ ((RendererType2) => {
  RendererType2["POINTS"] = "POINTS";
  RendererType2["INSTANCED"] = "INSTANCED";
  RendererType2["TRAIL"] = "TRAIL";
  RendererType2["MESH"] = "MESH";
  return RendererType2;
})(RendererType || {});
var ForceFieldFalloff = /* @__PURE__ */ ((ForceFieldFalloff3) => {
  ForceFieldFalloff3["NONE"] = "NONE";
  ForceFieldFalloff3["LINEAR"] = "LINEAR";
  ForceFieldFalloff3["QUADRATIC"] = "QUADRATIC";
  return ForceFieldFalloff3;
})(ForceFieldFalloff || {});
var CollisionPlaneMode = /* @__PURE__ */ ((CollisionPlaneMode3) => {
  CollisionPlaneMode3["KILL"] = "KILL";
  CollisionPlaneMode3["CLAMP"] = "CLAMP";
  CollisionPlaneMode3["BOUNCE"] = "BOUNCE";
  return CollisionPlaneMode3;
})(CollisionPlaneMode || {});
var SimulationBackend = /* @__PURE__ */ ((SimulationBackend2) => {
  SimulationBackend2["AUTO"] = "AUTO";
  SimulationBackend2["CPU"] = "CPU";
  SimulationBackend2["GPU"] = "GPU";
  return SimulationBackend2;
})(SimulationBackend || {});

// src/js/effects/three-particles/three-particles-constants.ts
var SCALAR_STRIDE = 10;
var S_IS_ACTIVE = 0;
var S_LIFETIME = 1;
var S_START_LIFETIME = 2;
var S_START_FRAME = 3;
var S_SIZE = 4;
var S_ROTATION = 5;
var S_COLOR_R = 6;
var S_COLOR_G = 7;
var S_COLOR_B = 8;
var S_COLOR_A = 9;
var calculateRandomPositionAndVelocityOnSphere = (position, quaternion, velocity, speed, {
  radius,
  radiusThickness,
  arc
}) => {
  const u = Math.random() * (arc / 360);
  const v = Math.random();
  const randomizedDistanceRatio = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const sinPhi = Math.sin(phi);
  const xDirection = sinPhi * Math.cos(theta);
  const yDirection = sinPhi * Math.sin(theta);
  const zDirection = Math.cos(phi);
  const normalizedThickness = 1 - radiusThickness;
  position.x = radius * normalizedThickness * xDirection + radius * radiusThickness * randomizedDistanceRatio * xDirection;
  position.y = radius * normalizedThickness * yDirection + radius * radiusThickness * randomizedDistanceRatio * yDirection;
  position.z = radius * normalizedThickness * zDirection + radius * radiusThickness * randomizedDistanceRatio * zDirection;
  position.applyQuaternion(quaternion);
  const speedMultiplierByPosition = 1 / position.length();
  velocity.set(
    position.x * speedMultiplierByPosition * speed,
    position.y * speedMultiplierByPosition * speed,
    position.z * speedMultiplierByPosition * speed
  );
  velocity.applyQuaternion(quaternion);
};
var calculateRandomPositionAndVelocityOnCone = (position, quaternion, velocity, speed, {
  radius,
  radiusThickness,
  arc,
  angle = 90
}) => {
  const theta = 2 * Math.PI * Math.random() * (arc / 360);
  const randomizedDistanceRatio = Math.random();
  const xDirection = Math.cos(theta);
  const yDirection = Math.sin(theta);
  const normalizedThickness = 1 - radiusThickness;
  position.x = radius * normalizedThickness * xDirection + radius * radiusThickness * randomizedDistanceRatio * xDirection;
  position.y = radius * normalizedThickness * yDirection + radius * radiusThickness * randomizedDistanceRatio * yDirection;
  position.z = 0;
  position.applyQuaternion(quaternion);
  const positionLength = position.length();
  const normalizedAngle = Math.abs(
    positionLength / radius * THREE3.MathUtils.degToRad(angle)
  );
  const sinNormalizedAngle = Math.sin(normalizedAngle);
  const speedMultiplierByPosition = 1 / positionLength;
  velocity.set(
    position.x * sinNormalizedAngle * speedMultiplierByPosition * speed,
    position.y * sinNormalizedAngle * speedMultiplierByPosition * speed,
    Math.cos(normalizedAngle) * speed
  );
  velocity.applyQuaternion(quaternion);
};
var calculateRandomPositionAndVelocityOnBox = (position, quaternion, velocity, speed, { scale, emitFrom }) => {
  const _scale = scale;
  switch (emitFrom) {
    case "VOLUME" /* VOLUME */:
      position.x = Math.random() * _scale.x - _scale.x / 2;
      position.y = Math.random() * _scale.y - _scale.y / 2;
      position.z = Math.random() * _scale.z - _scale.z / 2;
      break;
    case "SHELL" /* SHELL */:
      const side = Math.floor(Math.random() * 6);
      const perpendicularAxis = side % 3;
      const shellResult = [];
      shellResult[perpendicularAxis] = side > 2 ? 1 : 0;
      shellResult[(perpendicularAxis + 1) % 3] = Math.random();
      shellResult[(perpendicularAxis + 2) % 3] = Math.random();
      position.x = shellResult[0] * _scale.x - _scale.x / 2;
      position.y = shellResult[1] * _scale.y - _scale.y / 2;
      position.z = shellResult[2] * _scale.z - _scale.z / 2;
      break;
    case "EDGE" /* EDGE */:
      const side2 = Math.floor(Math.random() * 6);
      const perpendicularAxis2 = side2 % 3;
      const edge = Math.floor(Math.random() * 4);
      const edgeResult = [];
      edgeResult[perpendicularAxis2] = side2 > 2 ? 1 : 0;
      edgeResult[(perpendicularAxis2 + 1) % 3] = edge < 2 ? Math.random() : edge - 2;
      edgeResult[(perpendicularAxis2 + 2) % 3] = edge < 2 ? edge : Math.random();
      position.x = edgeResult[0] * _scale.x - _scale.x / 2;
      position.y = edgeResult[1] * _scale.y - _scale.y / 2;
      position.z = edgeResult[2] * _scale.z - _scale.z / 2;
      break;
  }
  position.applyQuaternion(quaternion);
  velocity.set(0, 0, speed);
  velocity.applyQuaternion(quaternion);
};
var calculateRandomPositionAndVelocityOnCircle = (position, quaternion, velocity, speed, {
  radius,
  radiusThickness,
  arc
}) => {
  const theta = 2 * Math.PI * Math.random() * (arc / 360);
  const randomizedDistanceRatio = Math.random();
  const xDirection = Math.cos(theta);
  const yDirection = Math.sin(theta);
  const normalizedThickness = 1 - radiusThickness;
  position.x = radius * normalizedThickness * xDirection + radius * radiusThickness * randomizedDistanceRatio * xDirection;
  position.y = radius * normalizedThickness * yDirection + radius * radiusThickness * randomizedDistanceRatio * yDirection;
  position.z = 0;
  position.applyQuaternion(quaternion);
  const positionLength = position.length();
  const speedMultiplierByPosition = 1 / positionLength;
  velocity.set(
    position.x * speedMultiplierByPosition * speed,
    position.y * speedMultiplierByPosition * speed,
    0
  );
  velocity.applyQuaternion(quaternion);
};
var calculateRandomPositionAndVelocityOnRectangle = (position, quaternion, velocity, speed, { rotation, scale }) => {
  const _scale = scale;
  const _rotation = rotation;
  const xOffset = Math.random() * _scale.x - _scale.x / 2;
  const yOffset = Math.random() * _scale.y - _scale.y / 2;
  const rotationX = THREE3.MathUtils.degToRad(_rotation.x);
  const rotationY = THREE3.MathUtils.degToRad(_rotation.y);
  position.x = xOffset * Math.cos(rotationY);
  position.y = yOffset * Math.cos(rotationX);
  position.z = xOffset * Math.sin(rotationY) - yOffset * Math.sin(rotationX);
  position.applyQuaternion(quaternion);
  velocity.set(0, 0, speed);
  velocity.applyQuaternion(quaternion);
};
var createDefaultMeshTexture = () => {
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 1;
    canvas.height = 1;
    const context = canvas.getContext("2d");
    if (context) {
      context.fillStyle = "white";
      context.fillRect(0, 0, 1, 1);
      const texture = new THREE3.CanvasTexture(canvas);
      texture.needsUpdate = true;
      return texture;
    }
    return null;
  } catch {
    return null;
  }
};
var createDefaultParticleTexture = () => {
  try {
    const canvas = document.createElement("canvas");
    const size = 64;
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext("2d");
    if (context) {
      const centerX = size / 2;
      const centerY = size / 2;
      const radius = size / 2 - 2;
      context.beginPath();
      context.arc(centerX, centerY, radius, 0, 2 * Math.PI, false);
      context.fillStyle = "white";
      context.fill();
      const texture = new THREE3.CanvasTexture(canvas);
      texture.needsUpdate = true;
      return texture;
    } else {
      console.warn(
        "Could not get 2D context to generate default particle texture."
      );
      return null;
    }
  } catch (error) {
    console.warn("Error creating default particle texture:", error);
    return null;
  }
};
var isLifeTimeCurve = (value) => {
  return typeof value !== "number" && "type" in value;
};
var getCurveFunctionFromConfig = (particleSystemId, lifetimeCurve) => {
  if (lifetimeCurve.type === "BEZIER" /* BEZIER */) {
    return createBezierCurveFunction(
      particleSystemId,
      lifetimeCurve.bezierPoints
    );
  }
  if (lifetimeCurve.type === "EASING" /* EASING */) {
    return lifetimeCurve.curveFunction;
  }
  const raw = lifetimeCurve;
  if (Array.isArray(raw.bezierPoints)) {
    return createBezierCurveFunction(
      particleSystemId,
      raw.bezierPoints
    );
  }
  if (typeof raw.curveFunction === "function") {
    return raw.curveFunction;
  }
  throw new Error(`Unsupported value type: ${lifetimeCurve}`);
};
var calculateValue = (particleSystemId, value, time = 0) => {
  if (typeof value === "number") {
    return value;
  }
  if ("min" in value && "max" in value) {
    if (value.min === value.max) {
      return value.min ?? 0;
    }
    return THREE3.MathUtils.randFloat(value.min ?? 0, value.max ?? 1);
  }
  const lifetimeCurve = value;
  return getCurveFunctionFromConfig(particleSystemId, lifetimeCurve)(time) * (lifetimeCurve.scale ?? 1);
};

// src/js/effects/three-particles/three-particles-modifiers.ts
var noiseInput = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(0, 0, 0);
var orbitalEuler = new __WEBPACK_EXTERNAL_MODULE_three_Euler__();
var applyModifiers = ({
  delta,
  generalData,
  normalizedConfig,
  attributes,
  scalarArray,
  particleLifetimePercentage,
  particleIndex,
  updateFlags
}) => {
  const {
    particleSystemId,
    startValues,
    lifetimeValues,
    linearVelocityData,
    orbitalVelocityData,
    noise,
    modifierCurves
  } = generalData;
  const positionIndex = particleIndex * 3;
  const positionArr = attributes.position.array;
  const base = particleIndex * SCALAR_STRIDE;
  if (linearVelocityData) {
    const { speed, valueModifiers } = linearVelocityData[particleIndex];
    const normalizedXSpeed = valueModifiers.x ? valueModifiers.x(particleLifetimePercentage) : speed.x;
    const normalizedYSpeed = valueModifiers.y ? valueModifiers.y(particleLifetimePercentage) : speed.y;
    const normalizedZSpeed = valueModifiers.z ? valueModifiers.z(particleLifetimePercentage) : speed.z;
    positionArr[positionIndex] += normalizedXSpeed * delta;
    positionArr[positionIndex + 1] += normalizedYSpeed * delta;
    positionArr[positionIndex + 2] += normalizedZSpeed * delta;
    if (updateFlags) updateFlags.position = true;
    else attributes.position.needsUpdate = true;
  }
  if (orbitalVelocityData) {
    const { speed, positionOffset, valueModifiers } = orbitalVelocityData[particleIndex];
    positionArr[positionIndex] -= positionOffset.x;
    positionArr[positionIndex + 1] -= positionOffset.y;
    positionArr[positionIndex + 2] -= positionOffset.z;
    const normalizedXSpeed = valueModifiers.x ? valueModifiers.x(particleLifetimePercentage) : speed.x;
    const normalizedYSpeed = valueModifiers.y ? valueModifiers.y(particleLifetimePercentage) : speed.y;
    const normalizedZSpeed = valueModifiers.z ? valueModifiers.z(particleLifetimePercentage) : speed.z;
    orbitalEuler.set(
      normalizedXSpeed * delta,
      normalizedZSpeed * delta,
      normalizedYSpeed * delta
    );
    positionOffset.applyEuler(orbitalEuler);
    positionArr[positionIndex] += positionOffset.x;
    positionArr[positionIndex + 1] += positionOffset.y;
    positionArr[positionIndex + 2] += positionOffset.z;
    if (updateFlags) updateFlags.position = true;
    else attributes.position.needsUpdate = true;
  }
  if (normalizedConfig.sizeOverLifetime.isActive) {
    const multiplier = modifierCurves?.size ? modifierCurves.size(particleLifetimePercentage) : calculateValue(
      particleSystemId,
      normalizedConfig.sizeOverLifetime.lifetimeCurve,
      particleLifetimePercentage
    );
    scalarArray[base + S_SIZE] = startValues.startSize[particleIndex] * multiplier;
  }
  if (normalizedConfig.opacityOverLifetime.isActive) {
    const multiplier = modifierCurves?.opacity ? modifierCurves.opacity(particleLifetimePercentage) : calculateValue(
      particleSystemId,
      normalizedConfig.opacityOverLifetime.lifetimeCurve,
      particleLifetimePercentage
    );
    scalarArray[base + S_COLOR_A] = startValues.startOpacity[particleIndex] * multiplier;
  }
  if (normalizedConfig.colorOverLifetime.isActive) {
    const rMultiplier = modifierCurves?.colorR ? modifierCurves.colorR(particleLifetimePercentage) : calculateValue(
      particleSystemId,
      normalizedConfig.colorOverLifetime.r,
      particleLifetimePercentage
    );
    const gMultiplier = modifierCurves?.colorG ? modifierCurves.colorG(particleLifetimePercentage) : calculateValue(
      particleSystemId,
      normalizedConfig.colorOverLifetime.g,
      particleLifetimePercentage
    );
    const bMultiplier = modifierCurves?.colorB ? modifierCurves.colorB(particleLifetimePercentage) : calculateValue(
      particleSystemId,
      normalizedConfig.colorOverLifetime.b,
      particleLifetimePercentage
    );
    scalarArray[base + S_COLOR_R] = startValues.startColorR[particleIndex] * rMultiplier;
    scalarArray[base + S_COLOR_G] = startValues.startColorG[particleIndex] * gMultiplier;
    scalarArray[base + S_COLOR_B] = startValues.startColorB[particleIndex] * bMultiplier;
  }
  if (lifetimeValues.rotationOverLifetime) {
    scalarArray[base + S_ROTATION] += lifetimeValues.rotationOverLifetime[particleIndex] * delta * 0.02;
  }
  if (noise.isActive) {
    const {
      sampler,
      strength,
      noisePower,
      offsets,
      positionAmount,
      rotationAmount,
      sizeAmount
    } = noise;
    let noiseOnPosition;
    const noisePosition = (particleLifetimePercentage + (offsets ? offsets[particleIndex] : 0)) * 10 * strength;
    noiseInput.set(noisePosition, 0, 0);
    noiseOnPosition = sampler.get3(noiseInput);
    positionArr[positionIndex] += noiseOnPosition * noisePower * positionAmount;
    if (rotationAmount !== 0) {
      scalarArray[base + S_ROTATION] += noiseOnPosition * noisePower * rotationAmount;
    }
    if (sizeAmount !== 0) {
      scalarArray[base + S_SIZE] += noiseOnPosition * noisePower * sizeAmount;
    }
    noiseInput.set(noisePosition, noisePosition, 0);
    noiseOnPosition = sampler.get3(noiseInput);
    positionArr[positionIndex + 1] += noiseOnPosition * noisePower * positionAmount;
    noiseInput.set(noisePosition, noisePosition, noisePosition);
    noiseOnPosition = sampler.get3(noiseInput);
    positionArr[positionIndex + 2] += noiseOnPosition * noisePower * positionAmount;
    if (updateFlags) updateFlags.position = true;
    else attributes.position.needsUpdate = true;
  }
  if (attributes.quat) {
    const rotZ = scalarArray[base + S_ROTATION];
    const halfZ = rotZ * 0.5;
    const qi = particleIndex * 4;
    attributes.quat.array[qi] = 0;
    attributes.quat.array[qi + 1] = 0;
    attributes.quat.array[qi + 2] = Math.sin(halfZ);
    attributes.quat.array[qi + 3] = Math.cos(halfZ);
    if (updateFlags) updateFlags.quat = true;
    else attributes.quat.needsUpdate = true;
  }
};

// src/js/effects/three-particles/three-particles-renderer-detect.ts
function isComputeCapableRenderer(renderer) {
  return renderer !== null && renderer !== void 0 && typeof renderer === "object" && "compute" in renderer && typeof renderer.compute === "function" && "hasFeature" in renderer && typeof renderer.hasFeature === "function";
}
function resolveSimulationBackend(renderer, preference = "AUTO" /* AUTO */) {
  const gpuCapable = isComputeCapableRenderer(renderer);
  if (preference === "CPU" /* CPU */) {
    return "CPU" /* CPU */;
  }
  if (preference === "GPU" /* GPU */) {
    return gpuCapable ? "GPU" /* GPU */ : "CPU" /* CPU */;
  }
  return gpuCapable ? "GPU" /* GPU */ : "CPU" /* CPU */;
}
function resolveWebGPUEffectiveRendererType(requested) {
  switch (requested) {
    case "INSTANCED" /* INSTANCED */:
      return "INSTANCED" /* INSTANCED */;
    case "TRAIL" /* TRAIL */:
      return "TRAIL" /* TRAIL */;
    case "MESH" /* MESH */:
      return "MESH" /* MESH */;
    case "POINTS" /* POINTS */:
    default:
      return "POINTS" /* POINTS */;
  }
}
var _particleSystemId = 0;
var createdParticleSystems = (/* unused pure expression or super */ null && ([]));
var _tslMaterialFactory = null;
var _rendererBackendIsGPU = true;
var _cpuPreferenceWarned = false;
var _cpuPreferencePreferenceWarn = () => {
  _cpuPreferenceWarned = true;
  console.warn(
    "three-particles: simulationBackend 'CPU' maps to the GPU kernel in 4.0.0 (GPU-only build)."
  );
};
var registerTSLMaterialFactory = (factory, options) => {
  if (options && "renderer" in options && !isComputeCapableRenderer(options.renderer)) {
    console.warn(
      "three-particles: registerTSLMaterialFactory skipped ??? the provided renderer does not support compute dispatches (expected THREE.WebGPURenderer). Particle systems will use the CPU/GLSL path."
    );
    return false;
  }
  _tslMaterialFactory = factory;
  if (options && "renderer" in options) {
    _rendererBackendIsGPU = !!options.renderer?.backend?.isWebGPUBackend;
  } else {
    _rendererBackendIsGPU = true;
  }
  return true;
};
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Euler__(0, 0, 0, "XYZ");
var _lastWorldPositionSnapshot = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__();
var assertNamed = (cond, message) => {
  if (!cond) {
    throw new Error(`three-particles: ${message}`);
  }
};
var normalizeVector2Value = (raw, fallback, label) => {
  if (raw === void 0 || raw === null) {
    return new __WEBPACK_EXTERNAL_MODULE_three_Vector2__(fallback[0], fallback[1]);
  }
  if (raw instanceof __WEBPACK_EXTERNAL_MODULE_three_Vector2__) return raw;
  let n1;
  let n2;
  if (Array.isArray(raw)) {
    n1 = Number(raw[0]);
    n2 = Number(raw[1]);
  } else if (typeof raw === "object") {
    const o = raw;
    n1 = o.x !== void 0 ? Number(o.x) : o.u !== void 0 ? Number(o.u) : void 0;
    n2 = o.y !== void 0 ? Number(o.y) : o.v !== void 0 ? Number(o.v) : void 0;
  }
  assertNamed(
    n1 !== void 0 && n2 !== void 0 && Number.isFinite(n1) && Number.isFinite(n2),
    `${label} must be one of: Vector2, [x,y], [u,v], {x,y} or {u,v}`
  );
  return new __WEBPACK_EXTERNAL_MODULE_three_Vector2__(n1, n2);
};
var normalizeTextureValue = (raw, label) => {
  if (raw === void 0 || raw === null) return null;
  assertNamed(
    typeof raw === "object" && "image" in raw,
    `${label} must be null or a texture object with .image (got ${String(raw)})`
  );
  return raw;
};
var normalizeDepthTextureValue = (raw, label) => {
  if (raw === void 0 || raw === null) return null;
  assertNamed(
    typeof raw === "object" && "image" in raw,
    `${label} must be a texture object with .image when set (got ${String(raw)})`
  );
  return raw;
};
var normalizeBackgroundToVector3 = (raw, label) => {
  if (raw === void 0 || raw === null) return new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(1, 1, 1);
  if (typeof raw === "number") {
    const c = new __WEBPACK_EXTERNAL_MODULE_three_Color__(raw);
    return new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(c.r, c.g, c.b);
  }
  if (typeof raw === "string") {
    const s = raw.trim();
    const c = new __WEBPACK_EXTERNAL_MODULE_three_Color__(s.startsWith("#") ? s : `#${s}`);
    assertNamed(
      Number.isFinite(c.r) && Number.isFinite(c.g) && Number.isFinite(c.b),
      `${label} is not a valid hex color string`
    );
    return new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(c.r, c.g, c.b);
  }
  if (Array.isArray(raw)) {
    const [r, g, b] = raw;
    assertNamed(
      Number.isFinite(r) && Number.isFinite(g) && Number.isFinite(b),
      `${label} array must contain three finite numbers`
    );
    return new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(r, g, b);
  }
  const o = raw;
  assertNamed(
    Number.isFinite(Number(o.r)) && Number.isFinite(Number(o.g)) && Number.isFinite(Number(o.b)),
    `${label} object must provide finite r/g/b`
  );
  return new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(Number(o.r), Number(o.g), Number(o.b));
};
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
new __WEBPACK_EXTERNAL_MODULE_three_Vector2__();
var toVector3 = (v, fallback) => v ? new THREE3.Vector3(v.x ?? 0, v.y ?? 0, v.z ?? 0) : fallback.clone();
var normalizeForceFields = (rawForceFields) => (rawForceFields ?? []).map((ff) => ({
  isActive: ff.isActive ?? true,
  type: ff.type ?? "POINT" /* POINT */,
  position: toVector3(ff.position, new THREE3.Vector3(0, 0, 0)),
  direction: toVector3(ff.direction, new THREE3.Vector3(0, 1, 0)).normalize(),
  strength: ff.strength ?? 1,
  range: Math.max(0, ff.range ?? Infinity),
  falloff: ff.falloff ?? "LINEAR" /* LINEAR */
}));
var normalizeCollisionPlanes = (rawPlanes) => (rawPlanes ?? []).map((cp) => ({
  isActive: cp.isActive ?? true,
  position: toVector3(cp.position, new THREE3.Vector3(0, 0, 0)),
  normal: toVector3(cp.normal, new THREE3.Vector3(0, 1, 0)).normalize(),
  mode: cp.mode ?? "KILL" /* KILL */,
  dampen: Math.max(0, Math.min(1, cp.dampen ?? 0.5)),
  lifetimeLoss: Math.max(0, Math.min(1, cp.lifetimeLoss ?? 0))
}));
var blendingMap = {
  "THREE.NoBlending": __WEBPACK_EXTERNAL_MODULE_three_NoBlending__,
  "THREE.NormalBlending": __WEBPACK_EXTERNAL_MODULE_three_NormalBlending__,
  "THREE.AdditiveBlending": __WEBPACK_EXTERNAL_MODULE_three_AdditiveBlending__,
  "THREE.SubtractiveBlending": __WEBPACK_EXTERNAL_MODULE_three_SubtractiveBlending__,
  "THREE.MultiplyBlending": __WEBPACK_EXTERNAL_MODULE_three_MultiplyBlending__
};
var toBlendingConstant = (v) => {
  if (typeof v === "number") return v;
  if (typeof v === "string") {
    const key = v.startsWith("THREE.") ? v : `THREE.${v}`;
    const mapped = blendingMap[key];
    if (mapped !== void 0) return mapped;
  }
  return THREE3.NormalBlending;
};
var getDefaultParticleSystemConfig = () => JSON.parse(JSON.stringify(DEFAULT_PARTICLE_SYSTEM_CONFIG));
var DEFAULT_PARTICLE_SYSTEM_CONFIG = {
  transform: {
    position: new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(),
    rotation: new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(),
    scale: new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(1, 1, 1)
  },
  duration: 5,
  looping: true,
  startDelay: 0,
  startLifetime: 5,
  startSpeed: 1,
  startSize: 1,
  startOpacity: 1,
  startRotation: 0,
  startColor: {
    min: { r: 1, g: 1, b: 1 },
    max: { r: 1, g: 1, b: 1 }
  },
  gravity: 0,
  simulationSpace: "LOCAL" /* LOCAL */,
  simulationBackend: "AUTO" /* AUTO */,
  maxParticles: 100,
  emission: {
    rateOverTime: 10,
    rateOverDistance: 0,
    bursts: []
  },
  shape: {
    shape: "SPHERE" /* SPHERE */,
    sphere: {
      radius: 1,
      radiusThickness: 1,
      arc: 360
    },
    cone: {
      angle: 25,
      radius: 1,
      radiusThickness: 1,
      arc: 360
    },
    circle: {
      radius: 1,
      radiusThickness: 1,
      arc: 360
    },
    rectangle: {
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1 }
    },
    box: {
      scale: { x: 1, y: 1, z: 1 },
      emitFrom: "VOLUME" /* VOLUME */
    }
  },
  map: void 0,
  renderer: {
    blending: __WEBPACK_EXTERNAL_MODULE_three_NormalBlending__,
    discardBackgroundColor: false,
    backgroundColorTolerance: 1,
    backgroundColor: { r: 1, g: 1, b: 1 },
    transparent: true,
    depthTest: true,
    depthWrite: false,
    softParticles: {
      enabled: false,
      intensity: 1
    }
  },
  velocityOverLifetime: {
    isActive: false,
    linear: {
      x: 0,
      y: 0,
      z: 0
    },
    orbital: {
      x: 0,
      y: 0,
      z: 0
    }
  },
  sizeOverLifetime: {
    isActive: false,
    lifetimeCurve: {
      type: "BEZIER" /* BEZIER */,
      scale: 1,
      bezierPoints: [
        { x: 0, y: 0, percentage: 0 },
        { x: 1, y: 1, percentage: 1 }
      ]
    }
  },
  colorOverLifetime: {
    isActive: false,
    r: {
      type: "BEZIER" /* BEZIER */,
      scale: 1,
      bezierPoints: [
        { x: 0, y: 1, percentage: 0 },
        { x: 1, y: 1, percentage: 1 }
      ]
    },
    g: {
      type: "BEZIER" /* BEZIER */,
      scale: 1,
      bezierPoints: [
        { x: 0, y: 1, percentage: 0 },
        { x: 1, y: 1, percentage: 1 }
      ]
    },
    b: {
      type: "BEZIER" /* BEZIER */,
      scale: 1,
      bezierPoints: [
        { x: 0, y: 1, percentage: 0 },
        { x: 1, y: 1, percentage: 1 }
      ]
    }
  },
  opacityOverLifetime: {
    isActive: false,
    lifetimeCurve: {
      type: "BEZIER" /* BEZIER */,
      scale: 1,
      bezierPoints: [
        { x: 0, y: 0, percentage: 0 },
        { x: 1, y: 1, percentage: 1 }
      ]
    }
  },
  rotationOverLifetime: {
    isActive: false,
    min: 0,
    max: 0
  },
  noise: {
    isActive: false,
    useRandomOffset: false,
    strength: 1,
    frequency: 0.5,
    octaves: 1,
    positionAmount: 1,
    rotationAmount: 0,
    sizeAmount: 0
  },
  textureSheetAnimation: {
    tiles: new __WEBPACK_EXTERNAL_MODULE_three_Vector2__(1, 1),
    timeMode: "LIFETIME" /* LIFETIME */,
    fps: 30,
    startFrame: 0
  },
  forceFields: [],
  collisionPlanes: []
};
var destroyParticleSystem = (particleSystem) => {
  createdParticleSystems = createdParticleSystems.filter(
    ({
      particleSystem: savedParticleSystem,
      trailMesh,
      generalData: { particleSystemId }
    }) => {
      if (savedParticleSystem !== particleSystem) {
        return true;
      }
      removeBezierCurveFunction(particleSystemId);
      if (trailMesh) {
        trailMesh.geometry.dispose();
        if (Array.isArray(trailMesh.material))
          trailMesh.material.forEach((m) => m.dispose());
        else trailMesh.material.dispose();
        if (trailMesh.parent) trailMesh.parent.remove(trailMesh);
      }
      savedParticleSystem.geometry.dispose();
      if (Array.isArray(savedParticleSystem.material))
        savedParticleSystem.material.forEach((material) => material.dispose());
      else savedParticleSystem.material.dispose();
      if (savedParticleSystem.parent)
        savedParticleSystem.parent.remove(savedParticleSystem);
      return false;
    }
  );
};
var _defaultTexture = null;
var getDefaultTexture = () => {
  if (_defaultTexture) return _defaultTexture;
  if (typeof document === "undefined") return null;
  const canvas = document.createElement("canvas");
  canvas.width = 1;
  canvas.height = 1;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, 1, 1);
  }
  _defaultTexture = new THREE3.Texture(canvas);
  _defaultTexture.needsUpdate = true;
  return _defaultTexture;
};
var createParticleSystem = (config = DEFAULT_PARTICLE_SYSTEM_CONFIG, externalNow) => {
  const now = externalNow || Date.now();
  const useTSL = _tslMaterialFactory !== null;
  if (!useTSL) {
    throw new Error(
      "three-particles: WebGPU TSL material factory not registered. Call enableWebGPU(renderer) immediately after creating a WebGPURenderer. @cyberluke/three-particles 4.0.0 is GPU-only - no CPU fallback path exists."
    );
  }
  if (!_rendererBackendIsGPU) {
    throw new Error(
      "three-particles: renderer is not a native WebGPU backend. This build has no WebGL2 fallback. Use a new THREE.WebGPURenderer()."
    );
  }
  const factory = _tslMaterialFactory;
  if (!factory.createComputePipeline) {
    throw new Error(
      "three-particles: active WebGPU renderer does not provide a complete TSL compute pipeline (createComputePipeline missing). No CPU fallback exists; install a WebGPU-capable backend."
    );
  }
  const maxParticles = config.maxParticles || DEFAULT_PARTICLE_SYSTEM_CONFIG.maxParticles;
  const normalizedConfig = ObjectUtils.deepMerge(
    DEFAULT_PARTICLE_SYSTEM_CONFIG,
    config,
    { applyToFirstObject: false, skippedProperties: [] }
  );
  if (normalizedConfig.simulationBackend === "CPU") {
    if (!_cpuPreferenceWarned) {
      _cpuPreferencePreferenceWarn();
    }
    normalizedConfig.simulationBackend = "GPU" /* GPU */;
  }
  const requestedRendererType = normalizedConfig.renderer.rendererType || "POINTS" /* POINTS */;
  const effectiveRendererType = resolveWebGPUEffectiveRendererType(
    requestedRendererType
  );
  const rrType = effectiveRendererType;
  const useInstancing = effectiveRendererType === "INSTANCED" /* INSTANCED */ || effectiveRendererType === "MESH" /* MESH */;
  const trailConfig = normalizedConfig.renderer.trail;
  const trailLength = Math.max(2, Math.round(trailConfig?.length ?? 20));
  const trailHistoryAttribute = rrType === "TRAIL" /* TRAIL */ ? new StorageBufferAttribute(
    new Float32Array(maxParticles * (trailLength + 1) * 4),
    4
  ) : null;
  const trailDesc = trailHistoryAttribute ? {
    attribute: trailHistoryAttribute,
    meta: null,
    length: trailLength,
    minVertexDistance: trailConfig?.minVertexDistance ?? 0,
    maxTime: (trailConfig?.maxTime ?? 0) * 1e3
  } : null;
  const subEmitterConfigs = normalizedConfig.subEmitters ?? [];
  const fifos = subEmitterConfigs.map((se) => {
    const capacity = Math.max(1, Math.round(se.maxInstances ?? 32));
    const f = factory.createSubEmitterFifoAttribute(capacity);
    f.trigger = se.trigger === "BIRTH" ? 0 : 1;
    return f;
  });
  const fifoBaseStride = fifos.reduce((m, f) => Math.max(m, f.windowSize), 0);
  const forceFields = normalizeForceFields(normalizedConfig.forceFields);
  const collisionPlanes = normalizeCollisionPlanes(normalizedConfig.collisionPlanes);
  const pipeline = factory.createComputePipeline(
    maxParticles,
    useInstancing,
    normalizedConfig,
    _particleSystemId,
    // pre-increment inside generalData below would be off by 1; use the raw next id
    forceFields.length,
    collisionPlanes.length,
    fifos,
    trailDesc ?? void 0
  );
  const ribbonPipeline = trailDesc ? factory.createTrailRibbonUpdate({
    position: new StorageBufferAttribute(
      new Float32Array(maxParticles * trailLength * 2 * 4),
      4
    ),
    next: new StorageBufferAttribute(
      new Float32Array(maxParticles * trailLength * 2 * 4),
      4
    ),
    uvColorA: new StorageBufferAttribute(
      new Float32Array(maxParticles * trailLength * 2 * 4),
      4
    ),
    colorB: new StorageBufferAttribute(
      new Float32Array(maxParticles * trailLength * 2 * 4),
      4
    ),
    history: trailDesc.attribute,
    meta: trailDesc.meta,
    particleColor: pipeline.buffers.color,
    curveFns: {
      width: trailConfig?.widthOverTrail ? getCurveFunctionFromConfig(_particleSystemId, trailConfig.widthOverTrail) : void 0,
      opacity: trailConfig?.opacityOverTrail ? getCurveFunctionFromConfig(_particleSystemId, trailConfig.opacityOverTrail) : void 0,
      colorR: trailConfig?.colorOverTrail?.isActive ? getCurveFunctionFromConfig(_particleSystemId, trailConfig.colorOverTrail.r) : void 0,
      colorG: trailConfig?.colorOverTrail?.isActive ? getCurveFunctionFromConfig(_particleSystemId, trailConfig.colorOverTrail.g) : void 0,
      colorB: trailConfig?.colorOverTrail?.isActive ? getCurveFunctionFromConfig(_particleSystemId, trailConfig.colorOverTrail.b) : void 0
    },
    width: trailConfig?.width ?? 1,
    length: trailLength,
    maxTime: trailDesc.maxTime,
    maxParticles
  }) : null;
  const subEntries = [];
  for (let fi = 0; fi < subEmitterConfigs.length; fi++) {
    const se = subEmitterConfigs[fi];
    const fifo = fifos[fi];
    const childCfg = ObjectUtils.deepMerge(
      getDefaultParticleSystemConfig(),
      se.config ?? {},
      { applyToFirstObject: false, skippedProperties: [] }
    );
    const firstBurst = childCfg.emission?.bursts?.[0];
    const burstCount = firstBurst ? Math.max(
      1,
      Math.ceil(
        calculateValue(
          _particleSystemId + 1 + fi,
          firstBurst.count,
          0
        ) * (firstBurst.cycles ?? 1)
      )
    ) : 1;
    const perEvent = Math.min(burstCount, fifo.capacity);
    const childMax = Math.max(2, Math.min(perEvent * fifo.capacity, 65536));
    const childRequestedRendererType = childCfg.renderer?.rendererType;
    const childEffectiveRendererType = resolveWebGPUEffectiveRendererType(
      childRequestedRendererType
    );
    const childInstanced = childEffectiveRendererType === "INSTANCED" /* INSTANCED */ || childEffectiveRendererType === "MESH" /* MESH */;
    const childPipeline = factory.createComputePipeline(
      childMax,
      childInstanced,
      childCfg,
      _particleSystemId + 1 + fi,
      0,
      0,
      [],
      void 0
    );
    const childShapeParams = factory.encodeShapeEmitParams(
      childCfg,
      _particleSystemId + 1 + fi
    );
    const childVel = childCfg.velocityOverLifetime;
    const init = factory.createSubEmitterInitUpdate(
      childPipeline.buffers,
      childMax,
      childShapeParams,
      pipeline.buffers,
      maxParticles,
      fifo,
      se.inheritVelocity ?? 0,
      perEvent,
      {
        linear: [childVel?.linear?.x, childVel?.linear?.y, childVel?.linear?.z],
        orbital: [childVel?.orbital?.x, childVel?.orbital?.y, childVel?.orbital?.z]
      }
    );
    subEntries.push({
      fifo,
      pipeline: childPipeline,
      init,
      instanced: childInstanced,
      requestedRendererType: childRequestedRendererType,
      effectiveRendererType: childEffectiveRendererType,
      cfg: childCfg,
      object: null,
      perEvent,
      gravity: childCfg.gravity,
      noise: childCfg.noise?.isActive ? {
        isActive: true,
        strength: childCfg.noise.strength,
        noisePower: 0.15 * childCfg.noise.strength,
        frequency: childCfg.noise.frequency,
        positionAmount: childCfg.noise.positionAmount,
        rotationAmount: childCfg.noise.rotationAmount,
        sizeAmount: childCfg.noise.sizeAmount,
        fbmMax: 2 - Math.pow(2, -childCfg.noise.octaves)
      } : null,
      rate: childCfg.emission?.rateOverTime ? calculateValue(_particleSystemId + 1 + fi, childCfg.emission.rateOverTime, 0) : 0,
      acc: 0,
      lastEmit: 0,
      poseFrom: "self",
      selfPose: { x: 0, y: 0, z: 0, qx: 0, qy: 0, qz: 0, qw: 1, sx: 1, sy: 1, sz: 1, isWorld: childCfg.simulationSpace === "WORLD" /* WORLD */ ? 1 : 0 }
    });
  }
  const cameraNearFarSource = normalizedConfig.renderer.cameraNearFar;
  const tilesSource = normalizedConfig.textureSheetAnimation?.tiles;
  const elapsedUniform = { value: 0 };
  const sharedUniforms = {
    elapsed: elapsedUniform,
    viewportHeight: { value: 720 },
    cameraNearFar: {
      value: normalizeVector2Value(
        cameraNearFarSource,
        [0.1, 1e3],
        "renderer.cameraNearFar"
      )
    },
    useInstancing: { value: useInstancing },
    softParticlesEnabled: { value: !!normalizedConfig.renderer.softParticles?.enabled },
    softParticlesIntensity: {
      value: Math.max(normalizedConfig.renderer.softParticles?.intensity ?? 1, 1e-3)
    },
    sceneDepthTexture: {
      value: normalizeDepthTextureValue(
        normalizedConfig.renderer.softParticles?.depthTexture,
        "renderer.softParticles.depthTexture"
      )
    },
    discardBackgroundColor: { value: !!normalizedConfig.renderer.discardBackgroundColor },
    backgroundColor: { value: new THREE3.Color(16777215) },
    backgroundColorTolerance: { value: normalizedConfig.renderer.backgroundColorTolerance ?? 0 },
    map: {
      value: normalizeTextureValue(
        normalizedConfig.map ?? getDefaultTexture(),
        "map"
      )
    },
    startLifetime: { value: 0 },
    startSize: { value: 1 },
    startRotation: { value: 0 },
    startOpacity: { value: 1 },
    startColor: { value: new THREE3.Color(1, 1, 1) },
    lifetime: { value: 0 },
    color: { value: new THREE3.Color(1, 1, 1) },
    // Sprite-sheet animation fields consumed by tsl-shared.createParticleUniforms.
    fps: { value: normalizedConfig.textureSheetAnimation?.fps || 30 },
    useFPSForFrameIndex: {
      value: normalizedConfig.textureSheetAnimation?.timeMode === "FPS" /* FPS */
    },
    tiles: {
      // The ONLY normalizer: `tiles` reaches the TSL factory as a Vector2
      // (also {u,v} pairs are accepted per §10). The engine's own default is
      // already (1,1) via the merged default config.
      value: normalizeVector2Value(
        tilesSource,
        [1, 1],
        "textureSheetAnimation.tiles"
      )
    }
  };
  const bgVec = normalizeBackgroundToVector3(
    normalizedConfig.renderer.backgroundColor,
    "renderer.backgroundColor"
  );
  sharedUniforms.backgroundColor.value.setRGB(bgVec.x, bgVec.y, bgVec.z);
  const rendererConfig = {
    transparent: !!normalizedConfig.renderer.transparent,
    blending: toBlendingConstant(normalizedConfig.renderer.blending),
    depthTest: normalizedConfig.renderer.depthTest !== false,
    depthWrite: normalizedConfig.renderer.depthWrite !== false
  };
  const material = factory.createTSLParticleMaterial(
    rrType,
    sharedUniforms,
    rendererConfig,
    true
  );
  const buffers = pipeline.buffers;
  let geometry;
  if (useInstancing) {
    const g = new THREE3.InstancedBufferGeometry();
    const meshGeometry = normalizedConfig.renderer.mesh?.geometry;
    const baseGeometry = rrType === "MESH" /* MESH */ && meshGeometry ? meshGeometry : new THREE3.BufferGeometry();
    if (rrType !== "MESH" /* MESH */ || !meshGeometry) {
      const quad = new Float32Array([-0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0]);
      const quadUV = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]);
      const quadNormal = new Float32Array([0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1]);
      const idx = new Uint16Array([0, 1, 2, 0, 2, 3]);
      baseGeometry.setAttribute("position", new THREE3.BufferAttribute(quad, 3));
      baseGeometry.setAttribute("uv", new THREE3.BufferAttribute(quadUV, 2));
      baseGeometry.setAttribute("normal", new THREE3.BufferAttribute(quadNormal, 3));
      baseGeometry.setIndex(new THREE3.BufferAttribute(idx, 1));
    }
    g.setAttribute("position", baseGeometry.getAttribute("position"));
    if (baseGeometry.index !== null) g.setIndex(baseGeometry.index);
    g.instanceCount = maxParticles;
    g.setAttribute("instanceOffset", buffers.position);
    g.setAttribute("instanceColor", buffers.color);
    g.setAttribute("instanceParticleState", buffers.particleState);
    g.setAttribute("instanceStartValues", buffers.startValues);
    geometry = g;
  } else {
    const g = new THREE3.BufferGeometry();
    g.setAttribute("position", buffers.position);
    g.setAttribute("color", buffers.color);
    g.setAttribute("particleState", buffers.particleState);
    g.setAttribute("startValues", buffers.startValues);
    g.setDrawRange(0, maxParticles);
    geometry = g;
    g.instanceCount = maxParticles;
  }
  let trailGeometry = null;
  if (ribbonPipeline && trailDesc) {
    const rb = ribbonPipeline.buffers;
    const g = new THREE3.BufferGeometry();
    g.setAttribute("position", rb.position);
    g.setAttribute("trailNext", rb.next);
    g.setAttribute("trailUVColor", rb.uvColorA);
    g.setAttribute("trailColorBA", rb.colorB);
    const idx = new Uint32Array(maxParticles * (trailLength - 1) * 6);
    let o = 0;
    for (let pIdx = 0; pIdx < maxParticles; pIdx++) {
      for (let s = 0; s < trailLength - 1; s++) {
        const b = pIdx * trailLength * 2 + s * 2;
        idx[o++] = b;
        idx[o++] = b + 1;
        idx[o++] = b + 2;
        idx[o++] = b + 1;
        idx[o++] = b + 3;
        idx[o++] = b + 2;
      }
    }
    g.setIndex(new THREE3.BufferAttribute(idx, 1));
    g.setDrawRange(0, maxParticles * trailLength * 2);
    trailGeometry = g;
  }
  const trailMaterial = trailGeometry ? factory.createTSLTrailMaterial(
    {
      map: { value: normalizedConfig.map ?? getDefaultTexture() },
      useMap: { value: !!normalizedConfig.map },
      discardBackgroundColor: { value: !!normalizedConfig.renderer.discardBackgroundColor },
      backgroundColor: { value: normalizedConfig.renderer.backgroundColor ?? { r: 1, g: 1, b: 1 } },
      backgroundColorTolerance: { value: normalizedConfig.renderer.backgroundColorTolerance ?? 0 },
      softParticlesEnabled: { value: !!normalizedConfig.renderer.softParticles?.enabled },
      softParticlesIntensity: {
        value: Math.max(normalizedConfig.renderer.softParticles?.intensity ?? 1, 1e-3)
      },
      sceneDepthTexture: {
        value: normalizedConfig.renderer.softParticles?.depthTexture ?? null
      },
      cameraNearFar: { value: new THREE3.Vector2(0.1, 1e3) }
    },
    {
      transparent: !!normalizedConfig.renderer.transparent,
      blending: toBlendingConstant(normalizedConfig.renderer.blending),
      depthTest: normalizedConfig.renderer.depthTest !== false,
      depthWrite: normalizedConfig.renderer.depthWrite !== false
    }
  ) : null;
  const particleSystem = trailGeometry ? new THREE3.Mesh(trailGeometry, trailMaterial) : useInstancing ? new THREE3.Mesh(geometry, material) : new THREE3.Points(geometry, material);
  particleSystem.frustumCulled = false;
  for (const e of subEntries) {
    const cb = e.pipeline.buffers;
    const childMax = e.pipeline.allocatorCount - 1;
    const childGeometry = e.instanced ? (() => {
      const g = new THREE3.InstancedBufferGeometry();
      const quad = new Float32Array([-0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0]);
      const idx = new Uint16Array([0, 1, 2, 0, 2, 3]);
      g.setAttribute("position", new THREE3.BufferAttribute(quad, 3));
      g.setIndex(new THREE3.BufferAttribute(idx, 1));
      g.instanceCount = childMax;
      g.setAttribute("instanceOffset", cb.position);
      g.setAttribute("instanceColor", cb.color);
      g.setAttribute("instanceParticleState", cb.particleState);
      g.setAttribute("instanceStartValues", cb.startValues);
      return g;
    })() : (() => {
      const g = new THREE3.BufferGeometry();
      g.setAttribute("position", cb.position);
      g.setAttribute("color", cb.color);
      g.setAttribute("particleState", cb.particleState);
      g.setAttribute("startValues", cb.startValues);
      g.setDrawRange(0, childMax);
      return g;
    })();
    const childUniforms = {
      ...sharedUniforms,
      useInstancing: { value: e.instanced }
    };
    const childMaterial = factory.createTSLParticleMaterial(
      e.effectiveRendererType,
      childUniforms,
      rendererConfig,
      true
    );
    const childObject = e.instanced ? new THREE3.Mesh(childGeometry, childMaterial) : new THREE3.Points(childGeometry, childMaterial);
    childObject.frustumCulled = false;
    particleSystem.add(childObject);
    e.object = childObject;
  }
  if (undefined !== false) {
    const required = useInstancing ? [
      "position",
      // quad / mesh vertex positions
      "instanceOffset",
      // GPU particle position
      "instanceColor",
      // GPU particle RGBA
      "instanceParticleState",
      // GPU packed state vec4
      "instanceStartValues"
      // GPU packed initial-state vec4
    ] : ["position", "color", "particleState", "startValues"];
    for (const name of required) {
      if (!geometry.getAttribute(name)) {
        throw new Error(
          "three-particles: " + (useInstancing ? "instanced" : "POINTS") + " geometry " + name + " is missing its required contract attribute."
        );
      }
    }
    const contractIdentity = useInstancing ? [
      ["instanceOffset", buffers.position],
      ["instanceColor", buffers.color],
      ["instanceParticleState", buffers.particleState],
      ["instanceStartValues", buffers.startValues]
    ] : [
      ["position", buffers.position],
      ["color", buffers.color],
      ["particleState", buffers.particleState],
      ["startValues", buffers.startValues]
    ];
    for (const [name, buf] of contractIdentity) {
      if (geometry.getAttribute(name) !== buf) {
        throw new Error(
          `three-particles: attribute "${name}" is not the compute-owned storage buffer.`
        );
      }
    }
    const kind = pipeline.shapeUniforms.shapeKind.value;
    if (!(kind >= 0 && kind <= 4)) {
      throw new Error(
        `three-particles: gpuShapeKind ${kind} outside 0..4 (SPHERE..BOX).`
      );
    }
    if (!(maxParticles > 0)) {
      throw new Error("three-particles: maxParticles must be > 0.");
    }
    if (pipeline.allocatorCount !== maxParticles + 1) {
      throw new Error(
        "three-particles: allocator capacity must equal maxParticles + 1."
      );
    }
    const passLayouts = [
      ...pipeline.passLayouts ?? [],
      ...ribbonPipeline?.passLayouts ?? [],
      ...subEntries.flatMap((e) => [
        ...e.init.passLayouts ?? [],
        ...(e.pipeline.passLayouts ?? []).map(
          (p) => ({ ...p, name: `child:${p.name}` })
        )
      ])
    ];
    for (const pass of passLayouts) {
      if (pass.storageBindings > 8) {
        throw new Error(
          `${pass.name}: ${pass.storageBindings} storage buffers > guaranteed limit 8`
        );
      }
    }
    if (trailDesc && trailDesc.meta !== pipeline.trailMeta) {
      throw new Error("three-particles: trail ring meta buffer mismatch.");
    }
    for (const f of fifos) {
      const n = f.counter.array.length;
      if (n !== 2) {
        throw new Error(
          "three-particles: sub-emitter FIFO must expose exactly 2 ping-pong counter slots."
        );
      }
      const p = f.payload.array.length;
      if (p !== 2 * 6 * f.capacity) {
        throw new Error(
          "three-particles: sub-emitter FIFO payload length must be 2 * 6 * capacity."
        );
      }
    }
  }
  const _numOr = (v, d) => typeof v === "number" && Number.isFinite(v) ? v : d;
  const xform = normalizedConfig.transform;
  if (xform?.position) {
    particleSystem.position.set(
      _numOr(xform.position.x, 0),
      _numOr(xform.position.y, 0),
      _numOr(xform.position.z, 0)
    );
  }
  if (xform?.rotation) {
    particleSystem.rotation.set(
      THREE3.MathUtils.degToRad(_numOr(xform.rotation.x, 0)),
      THREE3.MathUtils.degToRad(_numOr(xform.rotation.y, 0)),
      THREE3.MathUtils.degToRad(_numOr(xform.rotation.z, 0))
    );
  }
  if (xform?.scale) {
    particleSystem.scale.set(
      _numOr(xform.scale.x, 1),
      _numOr(xform.scale.y, 1),
      _numOr(xform.scale.z, 1)
    );
  }
  particleSystem.updateMatrix();
  particleSystem.updateMatrixWorld(true);
  if (normalizedConfig.simulationSpace === "WORLD" /* WORLD */) {
    particleSystem.matrixWorldAutoUpdate = false;
    particleSystem.matrixWorld.identity();
  }
  const generalData = {
    particleSystemId: _particleSystemId++,
    normalizedLifetimePercentage: 0,
    distanceFromLastEmitByDistance: 0,
    lastWorldPosition: new THREE3.Vector3(-99999),
    currentWorldPosition: new THREE3.Vector3(-99999),
    worldPositionChange: new THREE3.Vector3(),
    sourceWorldMatrix: new THREE3.Matrix4(),
    worldQuaternion: new THREE3.Quaternion(),
    wrapperQuaternion: new THREE3.Quaternion(),
    worldScale: new THREE3.Vector3(1, 1, 1),
    worldEuler: new THREE3.Euler(),
    gravityVelocity: new THREE3.Vector3(0, 0, 0),
    startValues: {},
    linearVelocityData: void 0,
    orbitalVelocityData: void 0,
    lifetimeValues: {},
    creationTimes: new Float32Array(0),
    cpuDirtyParticleWatermark: -1,
    highWaterIndex: 0,
    noise: {
      isActive: normalizedConfig.noise.isActive,
      strength: normalizedConfig.noise.strength,
      // Oracle `0.15 * strength`; the single fbmMax division lives inside the
      // FBM sum (CPU: FBM.get3; GPU: the octave loop amp / fbmMax).
      noisePower: 0.15 * normalizedConfig.noise.strength,
      frequency: normalizedConfig.noise.frequency,
      positionAmount: normalizedConfig.noise.positionAmount,
      rotationAmount: normalizedConfig.noise.rotationAmount,
      sizeAmount: normalizedConfig.noise.sizeAmount,
      fbmMax: 2 - Math.pow(2, -normalizedConfig.noise.octaves)
    },
    isEnabled: true,
    burstStates: normalizedConfig.emission.bursts?.length ? normalizedConfig.emission.bursts.map(() => ({
      cyclesExecuted: 0,
      lastCycleTime: 0,
      probabilityPassed: false
    })) : void 0
  };
  const props = {
    particleSystem,
    mappedAttributes: {
      position: buffers.position,
      isActive: buffers.orbitalIsActive,
      lifetime: buffers.particleState,
      startLifetime: buffers.startValues,
      startFrame: buffers.particleState,
      size: buffers.particleState,
      rotation: buffers.particleState,
      color: buffers.color
    },
    // ?? Deprecated zero-size sentinels (GPU-only v4) ????
    // These legacy CPU particle-state fields are not authoritative anymore: the
    // compute kernels own the state in GPU storage. Only the TRAIL path (which
    // throws in v4) consumed them, so they are 0-length placeholders.
    scalarArray: new Float32Array(0),
    scalarInterleavedBuffer: new THREE3.InterleavedBuffer(
      new Float32Array(0),
      SCALAR_STRIDE
    ),
    elapsedUniform,
    generalData,
    onUpdate: () => {
    },
    onComplete: () => {
    },
    creationTime: now + (normalizedConfig.startDelay || 0),
    lastEmissionTime: now,
    emissionAccumulator: 0,
    duration: normalizedConfig.duration,
    looping: normalizedConfig.looping,
    simulationSpace: normalizedConfig.simulationSpace,
    gravity: normalizedConfig.gravity,
    normalizedForceFields: forceFields,
    normalizedCollisionPlanes: collisionPlanes,
    emission: normalizedConfig.emission,
    normalizedConfig,
    iterationCount: 0,
    velocities: [],
    freeList: [],
    deactivateParticle: () => {
    },
    killParticle: () => {
    },
    activateParticle: () => {
    },
    computePipeline: pipeline,
    useGPUCompute: true,
    computeDispatchReady: false,
    maxParticles,
    material,
    geometry,
    rrType,
    requestedRendererType,
    effectiveRendererType: rrType,
    sharedUniforms,
    allComputeNodes: [
      ...pipeline.computeNodes ?? [],
      ...ribbonPipeline ? [ribbonPipeline.ribbonNode] : [],
      ...subEntries.flatMap((e) => [
        e.init.commandBuildNode,
        e.init.childInitNode,
        ...e.init.counterClearNode != null ? [e.init.counterClearNode] : [],
        ...e.pipeline.computeNodes ?? []
      ])
    ],
    passNames: [
      ...pipeline.passNames ?? ["emit", "simulate"],
      ...ribbonPipeline ? ["trail-ribbon"] : [],
      ...subEntries.flatMap((e, ei) => [
        `sub${ei}:command-build`,
        `sub${ei}:child-init`,
        `sub${ei}:counter-clear`,
        `sub${ei}:child-emit`,
        `sub${ei}:child-sim`
      ])
    ],
    fifoBaseStride,
    ribbonUniforms: ribbonPipeline ? ribbonPipeline.uniforms : void 0,
    ribbonBuffers: ribbonPipeline ? ribbonPipeline.buffers : void 0,
    frameParity: 0,
    subEntries: subEntries.map((e) => ({
      fifo: { capacity: e.fifo.capacity, windowSize: e.fifo.windowSize },
      requestedRendererType: e.requestedRendererType,
      effectiveRendererType: e.effectiveRendererType,
      pipeline: e.pipeline,
      init: e.init,
      gravity: e.gravity,
      noise: e.noise,
      rate: e.rate,
      acc: 0,
      isWorld: e.selfPose.isWorld,
      quat: [e.selfPose.qx, e.selfPose.qy, e.selfPose.qz, e.selfPose.qw],
      scale: [e.selfPose.sx, e.selfPose.sy, e.selfPose.sz],
      position: [
        _numOr(e.cfg.transform?.position?.x, 0),
        _numOr(e.cfg.transform?.position?.y, 0),
        _numOr(e.cfg.transform?.position?.z, 0)
      ]
    }))
  };
  for (const e of subEntries) {
    if (!e.object) continue;
    const tf = e.cfg.transform;
    if (tf?.position) {
      e.object.position.set(
        _numOr(tf.position.x, 0),
        _numOr(tf.position.y, 0),
        _numOr(tf.position.z, 0)
      );
    }
    if (tf?.rotation) {
      e.object.rotation.set(
        THREE3.MathUtils.degToRad(_numOr(tf.rotation.x, 0)),
        THREE3.MathUtils.degToRad(_numOr(tf.rotation.y, 0)),
        THREE3.MathUtils.degToRad(_numOr(tf.rotation.z, 0))
      );
    }
    if (tf?.scale) {
      e.object.scale.set(
        _numOr(tf.scale.x, 1),
        _numOr(tf.scale.y, 1),
        _numOr(tf.scale.z, 1)
      );
    }
    e.object.updateMatrix();
    const q = new THREE3.Quaternion().setFromEuler(
      new THREE3.Euler(
        THREE3.MathUtils.degToRad(_numOr(tf?.rotation?.x, 0)),
        THREE3.MathUtils.degToRad(_numOr(tf?.rotation?.y, 0)),
        THREE3.MathUtils.degToRad(_numOr(tf?.rotation?.z, 0)),
        "XYZ"
      )
    );
    const entry = props.subEntries?.[subEntries.indexOf(e)];
    if (entry) {
      entry.quat = [q.x, q.y, q.z, q.w];
      entry.scale = [
        _numOr(tf?.scale?.x, 1),
        _numOr(tf?.scale?.y, 1),
        _numOr(tf?.scale?.z, 1)
      ];
    }
  }
  createdParticleSystems.push(props);
  const _dbgPassCounts = [
    ...(pipeline.passLayouts ?? []).map(
      (p) => [p.name, p.storageBindings]
    ),
    ...(ribbonPipeline?.passLayouts ?? []).map(
      (p) => [p.name, p.storageBindings]
    ),
    ...subEntries.flatMap((e, ei) => [
      ...(e.init.passLayouts ?? []).map(
        (p) => [`sub${ei}:${p.name}`, p.storageBindings]
      ),
      ...(e.pipeline.passLayouts ?? []).map(
        (p) => [`sub${ei}:${p.name}`, p.storageBindings]
      )
    ])
  ];
  const _dbgMaxPass = _dbgPassCounts.reduce((m, p) => Math.max(m, p[1]), 0);
  if (typeof console !== "undefined" && console.log) {
    const logCfg = normalizedConfig;
    const shpU = pipeline.shapeUniforms;
    const sv = logCfg.startValues;
    const u = pipeline.uniforms;
    console.log(`[PS:create] system #${generalData.particleSystemId}`, {
      rendererType: rrType,
      requestedRendererType,
      effectiveRendererType: rrType,
      simulationSpace: normalizedConfig.simulationSpace,
      maxParticles,
      useInstancing
    });
    console.log(`[PS:config] system #${generalData.particleSystemId}`, {
      shape: {
        publicKind: logCfg.shape?.shape ?? null,
        gpuShapeKind: shpU.shapeKind?.value ?? 0,
        radius: shpU.radius?.value ?? logCfg.shape?.radius ?? null,
        radiusThickness: shpU.radiusThickness?.value ?? null,
        arcDeg: shpU.arcDeg?.value ?? null,
        coneAngleDeg: shpU.coneAngleDeg?.value ?? null,
        rectScale: [shpU.rectScaleX?.value, shpU.rectScaleY?.value],
        rectRotationDeg: [shpU.rectRotXDeg?.value, shpU.rectRotYDeg?.value],
        boxScale: [shpU.boxSX?.value, shpU.boxSY?.value, shpU.boxSZ?.value],
        boxEmitFrom: shpU.boxEmitFrom?.value ?? null
      },
      transform: {
        position: xform?.position ?? null,
        rotation: xform?.rotation ?? null,
        scale: xform?.scale ?? null
      },
      emission: {
        rateOverTime: logCfg.emission?.rateOverTime ?? 0,
        rateOverDistance: logCfg.emission?.rateOverDistance ?? 0,
        bursts: logCfg.emission?.bursts?.length ?? 0
      },
      startValues: {
        lifetime: sv?.startLifetime ?? null,
        speed: sv?.startSpeed ?? null,
        size: sv?.startSize ?? null,
        rotation: sv?.startRotation ?? null,
        color: sv?.startColor ?? null,
        opacity: sv?.startOpacity ?? null
      },
      textureId: config.textureId ?? config._editorData?.textureId ?? null,
      textureResolved: !!normalizedConfig.map,
      forceFieldCount: forceFields.length,
      collisionPlaneCount: collisionPlanes.length,
      subEmitterCount: (normalizedConfig.subEmitters ?? []).length,
      trailEnabled: !!trailDesc,
      modifiers: {
        linearVelocity: !!logCfg.velocityOverLifetime?.isActive && (u.linearVelX !== void 0 || u.axisLinXMin !== void 0 || !!(logCfg.velocityOverLifetime?.linear && Object.values(logCfg.velocityOverLifetime.linear).some(
          (value) => value !== void 0 && value !== 0
        ))),
        orbitalVelocity: !!logCfg.velocityOverLifetime?.isActive && !!(logCfg.velocityOverLifetime?.orbital && Object.values(logCfg.velocityOverLifetime.orbital).some(
          (value) => value !== void 0 && value !== 0
        )),
        sizeOverLifetime: !!normalizedConfig.sizeOverLifetime?.isActive,
        opacityOverLifetime: !!normalizedConfig.opacityOverLifetime?.isActive,
        colorOverLifetime: !!normalizedConfig.colorOverLifetime?.isActive,
        rotationOverLifetime: !!normalizedConfig.rotationOverLifetime?.isActive,
        noise: !!normalizedConfig.noise?.isActive
      }
    });
    console.log(
      `[PS:pipeline] system #${generalData.particleSystemId}: ${(props.passNames ?? []).join(" -> ") || "emit -> simulate"} | storageBindings=${_dbgPassCounts.map((p) => `${p[0]}=${p[1]}\u22648`).join(" ")} | packedFloats=${pipeline.buffers.packedData?.length ?? 0}`
    );
  }
  const update = (cycleData) => {
    updateParticleSystemInstance(props, cycleData);
  };
  const resumeEmitter = () => {
    generalData.isEnabled = true;
  };
  const pauseEmitter = () => {
    generalData.isEnabled = false;
  };
  const dispose = () => {
    destroyParticleSystem(particleSystem);
  };
  const updateConfig = (partial) => {
    ObjectUtils.deepMerge(normalizedConfig, partial, {
      applyToFirstObject: true,
      skippedProperties: []
    });
  };
  return {
    instance: particleSystem,
    resumeEmitter,
    pauseEmitter,
    dispose,
    update,
    updateConfig,
    /**
     * ?? Deprecated synchronous active count ????
     * Returns -1 (= unsupported) in the GPU-only engine: the authoritative count
     * is `maxParticles - allocator[0]` which lives in GPU storage and is only
     * available through an explicit (throttled) `getArrayBufferAsync` read-back.
     */
    getActiveParticleCount: () => -1,
    computeNode: props.allComputeNodes && props.allComputeNodes.length > 0 ? props.allComputeNodes : pipeline.computeNodes ?? pipeline.computeNode,
    /**
         * ?? Temporary one-shot GPU debug handle (deprecated, no per-frame cost) ????
         * getActiveParticleCount() stays -1; this object is the raw material for an
         * explicit 
    enderer.getArrayBufferAsync(...) read-back (bytes, multiples of 4).
         * lastEmitCount() mirrors uEmitCount, the u32 count written per frame.
         */
    gpuDebug: {
      maxParticles,
      allocatorCount: pipeline.allocatorCount,
      /** Canonical requested vs effective GPU renderer classes (§2). */
      requestedRendererType,
      effectiveRendererType: rrType,
      /** u32 birth system seed for this pipeline (written ONCE at create). */
      systemSeed: pipeline.uniforms.seed.value,
      buffers: pipeline.buffers,
      emitNode: pipeline.emitNode,
      simNode: pipeline.simNode,
      passNames: pipeline.passNames ?? ["emit", "simulate"],
      allPassNames: props.passNames ?? [],
      storageBindingCount: _dbgMaxPass,
      passBindingCounts: _dbgPassCounts,
      lastEmitCount: () => pipeline.uniforms.emitCount.value,
      /**
       * Per-sub-emitter-child canonical pairs (§2/§21): each child pool's own
       * requested vs effective renderer class + its events-per-frame.
       */
      subEmitters: (subEntries ?? []).map((e) => ({
        requestedRendererType: e.requestedRendererType ?? null,
        effectiveRendererType: e.effectiveRendererType,
        perEvent: e.perEvent
      })),
      /** Decode summary for the `[PS:config]` / `[PS:pipeline]` logs. */
      snapshot: () => {
        const shp = normalizedConfig.shape;
        const branch = shp.shape === "CONE" ? shp.cone : shp.shape === "CIRCLE" ? shp.circle : shp.sphere;
        const tex = normalizedConfig.map;
        return {
          systemId: generalData.particleSystemId,
          // Canonical effective + original requested renderer classes (§2).
          effectiveRendererType: rrType,
          requestedRendererType,
          rendererType: rrType,
          simulationSpace: normalizedConfig.simulationSpace,
          maxParticles,
          shape: {
            publicShape: shp.shape,
            gpuShapeKind: pipeline.shapeUniforms?.shapeKind?.value ?? 0,
            radius: branch?.radius ?? null,
            radiusThickness: branch?.radiusThickness ?? null,
            arcDeg: branch?.arc ?? null,
            coneAngleDeg: shp.shape === "CONE" ? shp.cone?.angle ?? null : null,
            rectScale: shp.rectangle?.scale ?? null,
            rectRotation: shp.rectangle?.rotation ?? null,
            boxScale: shp.box?.scale ?? null,
            boxEmitFrom: shp.box?.emitFrom ?? null
          },
          textureId: config.textureId ?? config._editorData?.textureId ?? null,
          textureResolved: !!normalizedConfig.map,
          textureDimensions: tex?.image ? [tex.image.width ?? 0, tex.image.height ?? 0] : null,
          forceFieldCount: (normalizedConfig.forceFields ?? []).length,
          collisionPlaneCount: (normalizedConfig.collisionPlanes ?? []).length,
          subEmitterCount: (normalizedConfig.subEmitters ?? []).length,
          trailEnabled: !!normalizedConfig.renderer.trail
        };
      }
    }
  };
};
var _lastUploadStampMap = /* @__PURE__ */ new WeakMap();
var _cmdUploadSeen = /* @__PURE__ */ new WeakSet();
var updateParticleSystemInstance = (props, { now, delta, elapsed }) => {
  const {
    generalData,
    normalizedConfig,
    particleSystem,
    elapsedUniform,
    creationTime,
    normalizedForceFields,
    normalizedCollisionPlanes,
    emission,
    computePipeline: pipeline,
    maxParticles = 0,
    allComputeNodes,
    subEntries,
    fifoBaseStride = 0,
    ribbonUniforms
  } = props;
  if (!pipeline) return;
  const u = pipeline.uniforms;
  const dur = normalizedConfig.duration;
  const lifetime = now - creationTime;
  const loop = normalizedConfig.looping;
  const iterationTimeMs = loop ? lifetime % (dur * 1e3) : lifetime;
  generalData.normalizedLifetimePercentage = Math.max(Math.min(iterationTimeMs / 1e3 / dur, 1), 0);
  elapsedUniform.value = elapsed;
  const gv = generalData.gravityVelocity;
  gv.set(0, normalizedConfig.gravity, 0);
  if (normalizedConfig.simulationSpace === "WORLD" /* WORLD */) {
    particleSystem.updateMatrix();
    _tmpM1.copy(particleSystem.matrix);
    if (particleSystem.parent) {
      particleSystem.parent.updateMatrixWorld();
      _tmpM1.premultiply(particleSystem.parent.matrixWorld);
    }
    _tmpM1.decompose(
      generalData.currentWorldPosition,
      generalData.worldQuaternion,
      generalData.worldScale
    );
  } else {
    particleSystem.updateMatrixWorld();
    particleSystem.getWorldPosition(generalData.currentWorldPosition);
    particleSystem.getWorldQuaternion(generalData.worldQuaternion);
    particleSystem.getWorldScale(generalData.worldScale);
    _tmpQ1.copy(generalData.worldQuaternion).invert();
    gv.applyQuaternion(_tmpQ1);
    gv.x /= generalData.worldScale.x || 1;
    gv.y /= generalData.worldScale.y || 1;
    gv.z /= generalData.worldScale.z || 1;
  }
  if (generalData.lastWorldPosition.x !== -99999) {
    _lastWorldPositionSnapshot.copy(generalData.lastWorldPosition);
    generalData.distanceFromLastEmitByDistance += _lastWorldPositionSnapshot.distanceTo(generalData.currentWorldPosition);
  }
  generalData.lastWorldPosition.copy(generalData.currentWorldPosition);
  let emitCount = 0;
  if (generalData.isEnabled && (loop || iterationTimeMs < dur * 1e3)) {
    const lastEmit = props.lastEmissionTime;
    const emissionDelta = now - lastEmit;
    if (emissionDelta > 0) {
      props.lastEmissionTime = now;
      if (emission.rateOverTime) {
        props.emissionAccumulator += calculateValue(
          generalData.particleSystemId,
          emission.rateOverTime,
          generalData.normalizedLifetimePercentage
        ) * (emissionDelta / 1e3);
      }
    }
    emitCount += Math.floor(props.emissionAccumulator);
    if (emitCount > 0) props.emissionAccumulator -= emitCount;
    if (emission.rateOverDistance && generalData.distanceFromLastEmitByDistance > 0) {
      const r = calculateValue(
        generalData.particleSystemId,
        emission.rateOverDistance,
        generalData.normalizedLifetimePercentage
      );
      if (r > 0) {
        const n2 = Math.floor(generalData.distanceFromLastEmitByDistance * r);
        emitCount += n2;
        generalData.distanceFromLastEmitByDistance = Math.max(
          generalData.distanceFromLastEmitByDistance - n2 / r,
          0
        );
      }
    }
    if (emission.bursts && generalData.burstStates) {
      const bursts = emission.bursts;
      const states = generalData.burstStates;
      const tSec = iterationTimeMs / 1e3;
      for (let i = 0; i < bursts.length; i++) {
        const b = bursts[i];
        const s = states[i];
        const cyc = b.cycles ?? 1;
        const iv = b.interval ?? 0;
        const prob = b.probability ?? 1;
        if (loop && tSec < (b.time ?? 0) && s.cyclesExecuted > 0) {
          s.cyclesExecuted = 0;
          s.lastCycleTime = 0;
          s.probabilityPassed = false;
        }
        if (s.cyclesExecuted >= cyc) continue;
        const next = (b.time ?? 0) + s.cyclesExecuted * iv;
        if (tSec >= next) {
          if (s.cyclesExecuted === 0) s.probabilityPassed = Math.random() < prob;
          if (s.probabilityPassed) {
            emitCount += Math.floor(
              calculateValue(generalData.particleSystemId, b.count, generalData.normalizedLifetimePercentage)
            );
          }
          s.cyclesExecuted++;
          s.lastCycleTime = tSec;
        }
      }
    }
    if (emitCount > maxParticles) emitCount = maxParticles;
  }
  u.delta.value = delta;
  u.deltaMs.value = delta * 1e3;
  u.gravityVelocity.value.copy(gv);
  u.emitCount.value = emitCount;
  pipeline.emitNode.count = Math.max(1, emitCount);
  if (pipeline.subBirthEventsNode) {
    pipeline.subBirthEventsNode.count = Math.max(1, emitCount);
  }
  const n = generalData.noise;
  if (u.noiseStrength) u.noiseStrength.value = n.strength;
  if (u.noisePower) u.noisePower.value = n.noisePower;
  if (u.noiseFrequency) u.noiseFrequency.value = n.frequency;
  if (u.noisePositionAmount) u.noisePositionAmount.value = n.positionAmount;
  if (u.noiseRotationAmount) u.noiseRotationAmount.value = n.rotationAmount;
  if (u.noiseSizeAmount) u.noiseSizeAmount.value = n.sizeAmount;
  const pose = pipeline.emitterPose;
  if (pose) {
    if (normalizedConfig.simulationSpace === "WORLD" /* WORLD */) {
      particleSystem.updateMatrix();
      _tmpM1.copy(particleSystem.matrix);
      if (particleSystem.parent) {
        particleSystem.parent.updateMatrixWorld();
        _tmpM1.premultiply(particleSystem.parent.matrixWorld);
      }
      _tmpM1.decompose(_tmpV1, _tmpQ1, _tmpV2);
      pose.positionW.value.set(_tmpV1.x, _tmpV1.y, _tmpV1.z, 1);
      pose.wrapperQuat.value.set(_tmpQ1.x, _tmpQ1.y, _tmpQ1.z, _tmpQ1.w);
      pose.worldScale.value.set(_tmpV2.x || 1, _tmpV2.y || 1, _tmpV2.z || 1);
    } else {
      pose.positionW.value.set(0, 0, 0, 0);
      pose.wrapperQuat.value.set(0, 0, 0, 1);
      pose.worldScale.value.set(1, 1, 1);
    }
  }
  const parity = (props.frameParity ?? 0) % 2;
  const fifoBase = parity;
  if (u.fifoBase) u.fifoBase.value = fifoBase;
  if (u.nowMs) u.nowMs.value = now;
  if (ribbonUniforms?.nowMs) ribbonUniforms.nowMs.value = now;
  for (const e of subEntries ?? []) {
    const cp = e.pipeline;
    if (!cp) continue;
    const cu = cp.uniforms;
    if (cu.delta) cu.delta.value = delta;
    if (cu.deltaMs) cu.deltaMs.value = delta * 1e3;
    if (cu.nowMs) cu.nowMs.value = now;
    if (cu.gravityVelocity) {
      cu.gravityVelocity.value.set(
        0,
        e.gravity,
        0
      );
    }
    if (e.noise) {
      if (cu.noiseStrength) cu.noiseStrength.value = e.noise.strength;
      if (cu.noisePower) cu.noisePower.value = e.noise.noisePower;
      if (cu.noiseFrequency) cu.noiseFrequency.value = e.noise.frequency;
      if (cu.noisePositionAmount) cu.noisePositionAmount.value = e.noise.positionAmount;
      if (cu.noiseRotationAmount) cu.noiseRotationAmount.value = e.noise.rotationAmount;
      if (cu.noiseSizeAmount) cu.noiseSizeAmount.value = e.noise.sizeAmount;
    }
    if (cu.fifoBase) cu.fifoBase.value = fifoBase;
    if (e.init.uniforms.fifoBase) e.init.uniforms.fifoBase.value = fifoBase;
    let childEmit = 0;
    if (e.rate > 0) {
      e.acc += e.rate * delta / 1;
      childEmit = Math.floor(e.acc);
      if (childEmit > 0) e.acc -= childEmit;
    }
    const childCapacity = Math.max(2, (cp.allocatorCount ?? 2) - 1);
    if (childEmit > childCapacity) childEmit = childCapacity;
    if (cp.emitNode) cp.emitNode.count = Math.max(1, childEmit);
    if (cu.emitCount) cu.emitCount.value = childEmit;
    const cpose = cp.emitterPose;
    if (cpose) {
      if (e.isWorld === 1) {
        cpose.positionW.value.set(e.position[0], e.position[1], e.position[2], 1);
        cpose.wrapperQuat.value.set(e.quat[0], e.quat[1], e.quat[2], e.quat[3]);
        cpose.worldScale.value.set(e.scale[0], e.scale[1], e.scale[2]);
      } else {
        cpose.positionW.value.set(0, 0, 0, 0);
        cpose.wrapperQuat.value.set(0, 0, 0, 1);
        cpose.worldScale.value.set(1, 1, 1);
      }
    }
    const ip = e.init.uniforms;
    if (ip.positionW && ip.wrapperQuat) {
      if (e.isWorld === 1) {
        ip.positionW.value.set(e.position[0], e.position[1], e.position[2], 1);
        ip.wrapperQuat.value.set(e.quat[0], e.quat[1], e.quat[2], e.quat[3]);
      } else {
        ip.positionW.value.set(0, 0, 0, 0);
        ip.wrapperQuat.value.set(0, 0, 0, 1);
      }
    }
  }
  const ffInfo = pipeline.forceFieldInfo;
  const cInfo = pipeline.collisionPlaneInfo ?? null;
  if ((ffInfo || cInfo) && _tslMaterialFactory) {
    const cdArr = pipeline.buffers.packedData;
    const cdNode = pipeline.packedDataNode;
    if (ffInfo && normalizedForceFields.length > 0) {
      const encFF = _tslMaterialFactory.encodeForceFieldsForGPU(normalizedForceFields, generalData.particleSystemId, generalData.normalizedLifetimePercentage);
      let changedFF = false;
      for (let k = 0; k < encFF.length; k++) if (cdArr[ffInfo.offset + k] !== encFF[k]) {
        changedFF = true;
        break;
      }
      if (changedFF) {
        cdArr.set(encFF, ffInfo.offset);
        cdNode.addUpdateRange(ffInfo.offset, encFF.length);
        cdNode.needsUpdate = true;
      }
      ffInfo.countUniform.value = normalizedForceFields.length;
    }
    if (cInfo && normalizedCollisionPlanes.length > 0) {
      const encCP = _tslMaterialFactory.encodeCollisionPlanesForGPU(normalizedCollisionPlanes);
      let changedCP = false;
      for (let k = 0; k < encCP.length; k++) if (cdArr[cInfo.offset + k] !== encCP[k]) {
        changedCP = true;
        break;
      }
      if (changedCP) {
        cdArr.set(encCP, cInfo.offset);
        cdNode.addUpdateRange(cInfo.offset, encCP.length);
        cdNode.needsUpdate = true;
      }
      cInfo.countUniform.value = normalizedCollisionPlanes.length;
    }
  }
  const bufs = pipeline.buffers;
  let stamp = _lastUploadStampMap.get(bufs);
  if (stamp === void 0 || stamp === 0) {
    for (const key of Object.keys(bufs)) {
      const a = bufs[key];
      if (a && "needsUpdate" in a) a.needsUpdate = true;
    }
    _lastUploadStampMap.set(bufs, 1);
  } else {
    _lastUploadStampMap.set(bufs, stamp + 1);
  }
  for (const e of subEntries ?? []) {
    const cb = e.pipeline?.buffers;
    if (cb && !_lastUploadStampMap.has(cb)) {
      for (const key of Object.keys(cb)) {
        const a = cb[key];
        if (a && "needsUpdate" in a) a.needsUpdate = true;
      }
      _lastUploadStampMap.set(cb, 1);
    }
    const cmd = e.init.commandBuffer;
    if (cmd && "needsUpdate" in cmd && !_cmdUploadSeen.has(cmd)) {
      cmd.needsUpdate = true;
      _cmdUploadSeen.add(cmd);
    }
  }
  const rb = props.ribbonBuffers;
  if (rb && !_lastUploadStampMap.has(rb)) {
    for (const key of Object.keys(rb)) {
      const a = rb[key];
      if (a && "needsUpdate" in a) a.needsUpdate = true;
    }
    _lastUploadStampMap.set(rb, 1);
  }
  props.computeDispatchReady = true;
  props.iterationCount++;
  props.frameParity = (props.frameParity ?? 0) ^ 1;
  if (props.trailMesh) updateTrailGeometry(props, now);
};
var _tmpQ1 = new __WEBPACK_EXTERNAL_MODULE_three_Quaternion__();
var _tmpV1 = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
var _tmpV2 = new __WEBPACK_EXTERNAL_MODULE_three_Vector3__();
var _tmpM1 = new __WEBPACK_EXTERNAL_MODULE_three_Matrix4__();
var catmullRom = (out, outIdx, p0x, p0y, p0z, p1x, p1y, p1z, p2x, p2y, p2z, p3x, p3y, p3z, t) => {
  const t2 = t * t;
  const t3 = t2 * t;
  out[outIdx] = 0.5 * (2 * p1x + (-p0x + p2x) * t + (2 * p0x - 5 * p1x + 4 * p2x - p3x) * t2 + (-p0x + 3 * p1x - 3 * p2x + p3x) * t3);
  out[outIdx + 1] = 0.5 * (2 * p1y + (-p0y + p2y) * t + (2 * p0y - 5 * p1y + 4 * p2y - p3y) * t2 + (-p0y + 3 * p1y - 3 * p2y + p3y) * t3);
  out[outIdx + 2] = 0.5 * (2 * p1z + (-p0z + p2z) * t + (2 * p0z - 5 * p1z + 4 * p2z - p3z) * t2 + (-p0z + 3 * p1z - 3 * p2z + p3z) * t3);
};
var clearTrailVertex = (vIdx, cIdx, aIdx, uvIdx, trailPosArr, trailNextArr, trailHalfWidthArr, trailUVArr, trailAlphaArr, trailColorArr, fallbackX, fallbackY, fallbackZ) => {
  trailPosArr[vIdx] = fallbackX;
  trailPosArr[vIdx + 1] = fallbackY;
  trailPosArr[vIdx + 2] = fallbackZ;
  trailPosArr[vIdx + 3] = fallbackX;
  trailPosArr[vIdx + 4] = fallbackY;
  trailPosArr[vIdx + 5] = fallbackZ;
  trailNextArr[vIdx] = fallbackX;
  trailNextArr[vIdx + 1] = fallbackY;
  trailNextArr[vIdx + 2] = fallbackZ;
  trailNextArr[vIdx + 3] = fallbackX;
  trailNextArr[vIdx + 4] = fallbackY;
  trailNextArr[vIdx + 5] = fallbackZ;
  trailHalfWidthArr[aIdx] = 0;
  trailHalfWidthArr[aIdx + 1] = 0;
  trailUVArr[uvIdx] = 0;
  trailUVArr[uvIdx + 1] = 0;
  trailUVArr[uvIdx + 2] = 0;
  trailUVArr[uvIdx + 3] = 0;
  trailAlphaArr[aIdx] = 0;
  trailAlphaArr[aIdx + 1] = 0;
  trailColorArr[cIdx] = 0;
  trailColorArr[cIdx + 1] = 0;
  trailColorArr[cIdx + 2] = 0;
  trailColorArr[cIdx + 3] = 0;
  trailColorArr[cIdx + 4] = 0;
  trailColorArr[cIdx + 5] = 0;
  trailColorArr[cIdx + 6] = 0;
  trailColorArr[cIdx + 7] = 0;
};
var writeTrailVertex = (vIdx, cIdx, aIdx, uvIdx, hx, hy, hz, nx, ny, nz, halfWidth, t, alpha, fr, fg, fb, ca, trailPosArr, trailNextArr, trailHalfWidthArr, trailUVArr, trailAlphaArr, trailColorArr) => {
  trailPosArr[vIdx] = hx;
  trailPosArr[vIdx + 1] = hy;
  trailPosArr[vIdx + 2] = hz;
  trailPosArr[vIdx + 3] = hx;
  trailPosArr[vIdx + 4] = hy;
  trailPosArr[vIdx + 5] = hz;
  trailNextArr[vIdx] = nx;
  trailNextArr[vIdx + 1] = ny;
  trailNextArr[vIdx + 2] = nz;
  trailNextArr[vIdx + 3] = nx;
  trailNextArr[vIdx + 4] = ny;
  trailNextArr[vIdx + 5] = nz;
  trailHalfWidthArr[aIdx] = halfWidth;
  trailHalfWidthArr[aIdx + 1] = halfWidth;
  trailUVArr[uvIdx] = 0;
  trailUVArr[uvIdx + 1] = t;
  trailUVArr[uvIdx + 2] = 1;
  trailUVArr[uvIdx + 3] = t;
  trailAlphaArr[aIdx] = alpha;
  trailAlphaArr[aIdx + 1] = alpha;
  trailColorArr[cIdx] = fr;
  trailColorArr[cIdx + 1] = fg;
  trailColorArr[cIdx + 2] = fb;
  trailColorArr[cIdx + 3] = ca;
  trailColorArr[cIdx + 4] = fr;
  trailColorArr[cIdx + 5] = fg;
  trailColorArr[cIdx + 6] = fb;
  trailColorArr[cIdx + 7] = ca;
};
var _rawPoints = null;
var _rawPointsSize = 0;
var _smoothedPoints = null;
var _smoothedPointsSize = 0;
var _ribbonIndices = null;
var _ribbonIndicesSize = 0;
var _ribbonCount = 0;
var updateTrailGeometry = (props, now) => {
  const {
    generalData,
    trailPositionAttr,
    trailAlphaAttr,
    trailColorAttr,
    trailNextAttr: trailNextAttrCached,
    trailHalfWidthAttr: trailHalfWidthAttrCached,
    trailUVAttr: trailUVAttrCached,
    trailWidthCurveFn,
    trailOpacityCurveFn,
    trailColorOverTrailFns,
    trailConfig,
    mappedAttributes: ma
  } = props;
  if (!trailPositionAttr || !trailAlphaAttr || !trailColorAttr || !trailNextAttrCached || !trailHalfWidthAttrCached || !trailUVAttrCached || !trailWidthCurveFn || !trailOpacityCurveFn || !trailConfig || !generalData.positionHistory || !generalData.positionHistoryIndex || !generalData.positionHistoryCount)
    return;
  const trailLength = trailConfig.length;
  const positionHistory = generalData.positionHistory;
  const historyIndex = generalData.positionHistoryIndex;
  const historyCount = generalData.positionHistoryCount;
  const sampleTimes = generalData.trailSampleTimes;
  const lastSampledPos = generalData.trailLastSampledPosition;
  const prevNormal = generalData.trailPrevNormal;
  const minVertexDist = trailConfig.minVertexDistance;
  const minVertexDistSq = minVertexDist * minVertexDist;
  const maxTime = trailConfig.maxTime;
  const maxTimeMs = maxTime * 1e3;
  const useSmoothing = trailConfig.smoothing;
  const subdivisions = trailConfig.smoothingSubdivisions;
  const useTwistPrevention = trailConfig.twistPrevention;
  const ribbonId = trailConfig.ribbonId;
  const trailScalarArr = props.scalarArray;
  const positionArr = ma.position.array;
  const prevFilled = generalData.trailPrevFilledCount;
  const trailPosArr = trailPositionAttr.array;
  const trailAlphaArr = trailAlphaAttr.array;
  const trailColorArr = trailColorAttr.array;
  const trailNextArr = trailNextAttrCached.array;
  const trailUVArr = trailUVAttrCached.array;
  const trailHalfWidthArr = trailHalfWidthAttrCached.array;
  const verticesPerParticle = trailLength * 2;
  const hwm = generalData.highWaterIndex;
  const creationTimesLength = hwm > 0 ? hwm : generalData.creationTimes.length;
  let hasUpdates = false;
  const useRibbon = ribbonId !== void 0;
  let ribbonLeader = -1;
  if (useRibbon) {
    if (!_ribbonIndices || _ribbonIndicesSize < creationTimesLength) {
      _ribbonIndices = new Uint32Array(creationTimesLength);
      _ribbonIndicesSize = creationTimesLength;
    }
    _ribbonCount = 0;
    for (let i = 0; i < creationTimesLength; i++) {
      if (trailScalarArr[i * SCALAR_STRIDE + S_IS_ACTIVE])
        _ribbonIndices[_ribbonCount++] = i;
    }
    for (let i = 1; i < _ribbonCount; i++) {
      const key = _ribbonIndices[i];
      const keyTime = generalData.creationTimes[key];
      let j = i - 1;
      while (j >= 0 && generalData.creationTimes[_ribbonIndices[j]] > keyTime) {
        _ribbonIndices[j + 1] = _ribbonIndices[j];
        j--;
      }
      _ribbonIndices[j + 1] = key;
    }
    if (_ribbonCount > 0) ribbonLeader = _ribbonIndices[0];
  }
  for (let index = 0; index < creationTimesLength; index++) {
    const vertBase = index * verticesPerParticle;
    if (trailScalarArr[index * SCALAR_STRIDE + S_IS_ACTIVE]) {
      if (useRibbon && _ribbonCount >= 2 && index !== ribbonLeader) {
        const posIdx2 = index * 3;
        const px2 = positionArr[posIdx2];
        const py2 = positionArr[posIdx2 + 1];
        const pz2 = positionArr[posIdx2 + 2];
        const histBase = (index * trailLength + historyIndex[index]) * 3;
        positionHistory[histBase] = px2;
        positionHistory[histBase + 1] = py2;
        positionHistory[histBase + 2] = pz2;
        if (sampleTimes) {
          sampleTimes[index * trailLength + historyIndex[index]] = now;
        }
        historyIndex[index] = (historyIndex[index] + 1) % trailLength;
        if (historyCount[index] < trailLength) historyCount[index]++;
        continue;
      }
      hasUpdates = true;
      const posIdx = index * 3;
      const px = positionArr[posIdx];
      const py = positionArr[posIdx + 1];
      const pz = positionArr[posIdx + 2];
      let shouldSample = true;
      if (minVertexDist > 0 && lastSampledPos && historyCount[index] > 0) {
        const lsIdx = index * 3;
        const dx = px - lastSampledPos[lsIdx];
        const dy = py - lastSampledPos[lsIdx + 1];
        const dz = pz - lastSampledPos[lsIdx + 2];
        if (dx * dx + dy * dy + dz * dz < minVertexDistSq) {
          shouldSample = false;
        }
      }
      if (shouldSample) {
        const histBase = (index * trailLength + historyIndex[index]) * 3;
        positionHistory[histBase] = px;
        positionHistory[histBase + 1] = py;
        positionHistory[histBase + 2] = pz;
        if (sampleTimes) {
          sampleTimes[index * trailLength + historyIndex[index]] = now;
        }
        historyIndex[index] = (historyIndex[index] + 1) % trailLength;
        if (historyCount[index] < trailLength) historyCount[index]++;
        if (lastSampledPos) {
          const lsIdx = index * 3;
          lastSampledPos[lsIdx] = px;
          lastSampledPos[lsIdx + 1] = py;
          lastSampledPos[lsIdx + 2] = pz;
        }
      }
      let rawCount = historyCount[index];
      let effectiveCount = rawCount;
      if (maxTime > 0 && sampleTimes && rawCount > 0) {
        const sampleBase = index * trailLength;
        effectiveCount = 0;
        for (let s = 0; s < rawCount; s++) {
          const sampleSlot = (historyIndex[index] - 1 - s + trailLength * 2) % trailLength;
          const age = now - sampleTimes[sampleBase + sampleSlot];
          if (age <= maxTimeMs) {
            effectiveCount++;
          } else {
            break;
          }
        }
      }
      const count = effectiveCount;
      const ribbonWidth = trailConfig.width;
      const trailBase = index * SCALAR_STRIDE;
      const cr = trailScalarArr[trailBase + S_COLOR_R];
      const cg = trailScalarArr[trailBase + S_COLOR_G];
      const cb = trailScalarArr[trailBase + S_COLOR_B];
      const ca = trailScalarArr[trailBase + S_COLOR_A];
      const ringOff = index * trailLength * 3;
      const rawPtsSize = count * 3;
      if (!_rawPoints || _rawPointsSize < rawPtsSize) {
        _rawPoints = new Float32Array(rawPtsSize);
        _rawPointsSize = rawPtsSize;
      }
      const rawPts = _rawPoints;
      for (let s = 0; s < count; s++) {
        const histSlot = (historyIndex[index] - 1 - s + trailLength * 2) % trailLength * 3 + ringOff;
        rawPts[s * 3] = positionHistory[histSlot];
        rawPts[s * 3 + 1] = positionHistory[histSlot + 1];
        rawPts[s * 3 + 2] = positionHistory[histSlot + 2];
      }
      let finalPts;
      let finalCount;
      if (useSmoothing && count >= 3) {
        const segmentCount = count - 1;
        finalCount = segmentCount * subdivisions + 1;
        const neededSize = finalCount * 3;
        if (!_smoothedPoints || _smoothedPointsSize < neededSize) {
          _smoothedPoints = new Float32Array(neededSize);
          _smoothedPointsSize = neededSize;
        }
        finalPts = _smoothedPoints;
        for (let seg = 0; seg < segmentCount; seg++) {
          const i0 = Math.max(0, seg - 1);
          const i1 = seg;
          const i2 = Math.min(count - 1, seg + 1);
          const i3 = Math.min(count - 1, seg + 2);
          const p0x = rawPts[i0 * 3], p0y = rawPts[i0 * 3 + 1], p0z = rawPts[i0 * 3 + 2];
          const p1x = rawPts[i1 * 3], p1y = rawPts[i1 * 3 + 1], p1z = rawPts[i1 * 3 + 2];
          const p2x = rawPts[i2 * 3], p2y = rawPts[i2 * 3 + 1], p2z = rawPts[i2 * 3 + 2];
          const p3x = rawPts[i3 * 3], p3y = rawPts[i3 * 3 + 1], p3z = rawPts[i3 * 3 + 2];
          for (let sub = 0; sub < subdivisions; sub++) {
            const t = sub / subdivisions;
            const outIdx = (seg * subdivisions + sub) * 3;
            catmullRom(
              finalPts,
              outIdx,
              p0x,
              p0y,
              p0z,
              p1x,
              p1y,
              p1z,
              p2x,
              p2y,
              p2z,
              p3x,
              p3y,
              p3z,
              t
            );
          }
        }
        const lastOutIdx = (finalCount - 1) * 3;
        finalPts[lastOutIdx] = rawPts[(count - 1) * 3];
        finalPts[lastOutIdx + 1] = rawPts[(count - 1) * 3 + 1];
        finalPts[lastOutIdx + 2] = rawPts[(count - 1) * 3 + 2];
      } else {
        finalPts = rawPts;
        finalCount = count;
      }
      if (finalCount > trailLength) finalCount = trailLength;
      if (useSmoothing && finalCount >= 2) {
        const MIN_SEG_DIST_SQ = 1e-4 * 1e-4;
        for (let d = 1; d < finalCount; d++) {
          const pi = (d - 1) * 3;
          const ci = d * 3;
          const dx = finalPts[ci] - finalPts[pi];
          const dy = finalPts[ci + 1] - finalPts[pi + 1];
          const dz = finalPts[ci + 2] - finalPts[pi + 2];
          if (dx * dx + dy * dy + dz * dz < MIN_SEG_DIST_SQ) {
            finalPts[ci] = finalPts[pi];
            finalPts[ci + 1] = finalPts[pi + 1];
            finalPts[ci + 2] = finalPts[pi + 2];
          }
        }
      }
      const prevFilledSlots = prevFilled ? prevFilled[index] : trailLength;
      if (prevFilled) prevFilled[index] = finalCount;
      for (let s = 0; s < trailLength; s++) {
        const vIdx = (vertBase + s * 2) * 3;
        const cIdx = (vertBase + s * 2) * 4;
        const aIdx = vertBase + s * 2;
        const uvIdxBase = (vertBase + s * 2) * 2;
        if (s >= finalCount) {
          if (s >= prevFilledSlots) break;
          clearTrailVertex(
            vIdx,
            cIdx,
            aIdx,
            uvIdxBase,
            trailPosArr,
            trailNextArr,
            trailHalfWidthArr,
            trailUVArr,
            trailAlphaArr,
            trailColorArr,
            px,
            py,
            pz
          );
          continue;
        }
        const hx = finalPts[s * 3];
        const hy = finalPts[s * 3 + 1];
        const hz = finalPts[s * 3 + 2];
        let nx, ny, nz;
        if (s > 0 && s < finalCount - 1) {
          const px2 = finalPts[(s - 1) * 3];
          const py2 = finalPts[(s - 1) * 3 + 1];
          const pz2 = finalPts[(s - 1) * 3 + 2];
          const nx2 = finalPts[(s + 1) * 3];
          const ny2 = finalPts[(s + 1) * 3 + 1];
          const nz2 = finalPts[(s + 1) * 3 + 2];
          const atx = nx2 - px2;
          const aty = ny2 - py2;
          const atz = nz2 - pz2;
          const atLen = Math.sqrt(atx * atx + aty * aty + atz * atz);
          if (atLen > 1e-4) {
            nx = hx + atx / atLen;
            ny = hy + aty / atLen;
            nz = hz + atz / atLen;
          } else {
            nx = finalPts[(s + 1) * 3];
            ny = finalPts[(s + 1) * 3 + 1];
            nz = finalPts[(s + 1) * 3 + 2];
          }
        } else if (s < finalCount - 1) {
          nx = finalPts[(s + 1) * 3];
          ny = finalPts[(s + 1) * 3 + 1];
          nz = finalPts[(s + 1) * 3 + 2];
        } else if (finalCount >= 2) {
          const prevX = finalPts[(s - 1) * 3];
          const prevY = finalPts[(s - 1) * 3 + 1];
          const prevZ = finalPts[(s - 1) * 3 + 2];
          nx = hx + (hx - prevX);
          ny = hy + (hy - prevY);
          nz = hz + (hz - prevZ);
        } else {
          nx = hx;
          ny = hy + 1e-3;
          nz = hz;
        }
        const t = finalCount > 1 ? s / (finalCount - 1) : 0;
        let timeFade = 1;
        if (maxTime > 0 && sampleTimes && effectiveCount > 0) {
          const sampleBase = index * trailLength;
          if (useSmoothing && rawCount >= 2) {
            const rawF = s / Math.max(finalCount - 1, 1) * (rawCount - 1);
            const rawLo = Math.min(Math.floor(rawF), rawCount - 1);
            const rawHi = Math.min(rawLo + 1, rawCount - 1);
            const frac = rawF - rawLo;
            const slotLo = (historyIndex[index] - 1 - rawLo + trailLength * 2) % trailLength;
            const slotHi = (historyIndex[index] - 1 - rawHi + trailLength * 2) % trailLength;
            const ageLo = now - sampleTimes[sampleBase + slotLo];
            const ageHi = now - sampleTimes[sampleBase + slotHi];
            const age = ageLo + (ageHi - ageLo) * frac;
            timeFade = 1 - Math.min(age / maxTimeMs, 1);
          } else {
            const rawS = Math.min(s, rawCount - 1);
            const sampleSlot = (historyIndex[index] - 1 - rawS + trailLength * 2) % trailLength;
            const age = now - sampleTimes[sampleBase + sampleSlot];
            timeFade = 1 - Math.min(age / maxTimeMs, 1);
          }
        }
        const widthScale = trailWidthCurveFn(t);
        const opacityScale = trailOpacityCurveFn(t);
        const halfWidth = ribbonWidth * widthScale * 0.5;
        const alpha = ca * opacityScale * timeFade;
        const fr = trailColorOverTrailFns ? cr * trailColorOverTrailFns.r(t) : cr;
        const fg = trailColorOverTrailFns ? cg * trailColorOverTrailFns.g(t) : cg;
        const fb = trailColorOverTrailFns ? cb * trailColorOverTrailFns.b(t) : cb;
        writeTrailVertex(
          vIdx,
          cIdx,
          aIdx,
          uvIdxBase,
          hx,
          hy,
          hz,
          nx,
          ny,
          nz,
          halfWidth,
          t,
          alpha,
          fr,
          fg,
          fb,
          ca,
          trailPosArr,
          trailNextArr,
          trailHalfWidthArr,
          trailUVArr,
          trailAlphaArr,
          trailColorArr
        );
      }
      if (useTwistPrevention && prevNormal && finalCount >= 2) {
        const nIdx = index * 3;
        const tx = finalPts[3] - finalPts[0];
        const ty = finalPts[4] - finalPts[1];
        const tz = finalPts[5] - finalPts[2];
        const tLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (tLen > 1e-4) {
          const ntx = tx / tLen;
          const nty = ty / tLen;
          const ntz = tz / tLen;
          let upx = 0, upy = 1, upz = 0;
          const dot = ntx * upx + nty * upy + ntz * upz;
          if (Math.abs(dot) > 0.999) {
            upx = 1;
            upy = 0;
            upz = 0;
          }
          let cnx = nty * upz - ntz * upy;
          let cny = ntz * upx - ntx * upz;
          let cnz = ntx * upy - nty * upx;
          const cnLen = Math.sqrt(cnx * cnx + cny * cny + cnz * cnz);
          if (cnLen > 1e-4) {
            cnx /= cnLen;
            cny /= cnLen;
            cnz /= cnLen;
          }
          const prevNx = prevNormal[nIdx];
          const prevNy = prevNormal[nIdx + 1];
          const prevNz = prevNormal[nIdx + 2];
          const hasPrev = prevNx !== 0 || prevNy !== 0 || prevNz !== 0;
          if (hasPrev) {
            const normalDot = cnx * prevNx + cny * prevNy + cnz * prevNz;
            if (normalDot < 0) {
              for (let s = 0; s < Math.min(finalCount, trailLength); s++) {
                const aIdx = vertBase + s * 2;
                const hw = trailHalfWidthArr[aIdx];
                trailHalfWidthArr[aIdx] = -hw;
                trailHalfWidthArr[aIdx + 1] = -hw;
              }
              cnx = -cnx;
              cny = -cny;
              cnz = -cnz;
            }
          }
          prevNormal[nIdx] = cnx;
          prevNormal[nIdx + 1] = cny;
          prevNormal[nIdx + 2] = cnz;
        }
      }
    } else if (historyCount[index] > 0 || prevFilled && prevFilled[index] > 0) {
      hasUpdates = true;
      historyCount[index] = 0;
      historyIndex[index] = 0;
      const clearSlots = prevFilled ? prevFilled[index] : trailLength;
      if (prevFilled) prevFilled[index] = 0;
      for (let s = 0; s < clearSlots; s++) {
        const vIdx = (vertBase + s * 2) * 3;
        const cIdx = (vertBase + s * 2) * 4;
        const aIdx = vertBase + s * 2;
        const uvIdxBase = (vertBase + s * 2) * 2;
        clearTrailVertex(
          vIdx,
          cIdx,
          aIdx,
          uvIdxBase,
          trailPosArr,
          trailNextArr,
          trailHalfWidthArr,
          trailUVArr,
          trailAlphaArr,
          trailColorArr,
          0,
          0,
          0
        );
      }
    }
  }
  if (useRibbon && _ribbonCount >= 2 && _ribbonIndices) {
    hasUpdates = true;
    const leader = _ribbonIndices[0];
    const leaderVertBase = leader * verticesPerParticle;
    const controlCount = _ribbonCount;
    const filledCount = Math.min(
      trailLength,
      Math.max(controlCount * 4, controlCount)
    );
    const chainSize = filledCount * 3;
    if (!_rawPoints || _rawPointsSize < chainSize) {
      _rawPoints = new Float32Array(chainSize);
      _rawPointsSize = chainSize;
    }
    if (controlCount === 2) {
      const p0Idx = _ribbonIndices[0] * 3;
      const p1Idx = _ribbonIndices[1] * 3;
      for (let i = 0; i < filledCount; i++) {
        const t = i / (filledCount - 1);
        _rawPoints[i * 3] = positionArr[p0Idx] + t * (positionArr[p1Idx] - positionArr[p0Idx]);
        _rawPoints[i * 3 + 1] = positionArr[p0Idx + 1] + t * (positionArr[p1Idx + 1] - positionArr[p0Idx + 1]);
        _rawPoints[i * 3 + 2] = positionArr[p0Idx + 2] + t * (positionArr[p1Idx + 2] - positionArr[p0Idx + 2]);
      }
    } else {
      const segments = controlCount - 1;
      const ptsPerSeg = Math.max(1, Math.floor((filledCount - 1) / segments));
      let wi = 0;
      for (let seg = 0; seg < segments && wi < filledCount; seg++) {
        const i0 = Math.max(0, seg - 1);
        const i1 = seg;
        const i2 = Math.min(controlCount - 1, seg + 1);
        const i3 = Math.min(controlCount - 1, seg + 2);
        const p0i = _ribbonIndices[i0] * 3;
        const p1i = _ribbonIndices[i1] * 3;
        const p2i = _ribbonIndices[i2] * 3;
        const p3i = _ribbonIndices[i3] * 3;
        const subCount = seg === segments - 1 ? filledCount - wi : ptsPerSeg;
        for (let sub = 0; sub < subCount && wi < filledCount; sub++) {
          const t = sub / subCount;
          catmullRom(
            _rawPoints,
            wi * 3,
            positionArr[p0i],
            positionArr[p0i + 1],
            positionArr[p0i + 2],
            positionArr[p1i],
            positionArr[p1i + 1],
            positionArr[p1i + 2],
            positionArr[p2i],
            positionArr[p2i + 1],
            positionArr[p2i + 2],
            positionArr[p3i],
            positionArr[p3i + 1],
            positionArr[p3i + 2],
            t
          );
          wi++;
        }
      }
      if (wi > 0) {
        const lastPIdx = _ribbonIndices[controlCount - 1] * 3;
        _rawPoints[(wi - 1) * 3] = positionArr[lastPIdx];
        _rawPoints[(wi - 1) * 3 + 1] = positionArr[lastPIdx + 1];
        _rawPoints[(wi - 1) * 3 + 2] = positionArr[lastPIdx + 2];
      }
    }
    const leaderBase = leader * SCALAR_STRIDE;
    const leaderCr = trailScalarArr[leaderBase + S_COLOR_R];
    const leaderCg = trailScalarArr[leaderBase + S_COLOR_G];
    const leaderCb = trailScalarArr[leaderBase + S_COLOR_B];
    const leaderCa = trailScalarArr[leaderBase + S_COLOR_A];
    const leaderPrevFilled = prevFilled ? prevFilled[leader] : trailLength;
    if (prevFilled) prevFilled[leader] = filledCount;
    for (let s = 0; s < trailLength; s++) {
      const vIdx = (leaderVertBase + s * 2) * 3;
      const cIdx = (leaderVertBase + s * 2) * 4;
      const aIdx = leaderVertBase + s * 2;
      const uvIdxBase = (leaderVertBase + s * 2) * 2;
      if (s >= filledCount) {
        if (s >= leaderPrevFilled) break;
        clearTrailVertex(
          vIdx,
          cIdx,
          aIdx,
          uvIdxBase,
          trailPosArr,
          trailNextArr,
          trailHalfWidthArr,
          trailUVArr,
          trailAlphaArr,
          trailColorArr,
          0,
          0,
          0
        );
        continue;
      }
      const ptIdx = s * 3;
      const ptx = _rawPoints[ptIdx];
      const pty = _rawPoints[ptIdx + 1];
      const ptz = _rawPoints[ptIdx + 2];
      let nx, ny, nz;
      if (s > 0 && s < filledCount - 1) {
        const px2 = _rawPoints[(s - 1) * 3];
        const py2 = _rawPoints[(s - 1) * 3 + 1];
        const pz2 = _rawPoints[(s - 1) * 3 + 2];
        const nx2 = _rawPoints[(s + 1) * 3];
        const ny2 = _rawPoints[(s + 1) * 3 + 1];
        const nz2 = _rawPoints[(s + 1) * 3 + 2];
        const atx = nx2 - px2;
        const aty = ny2 - py2;
        const atz = nz2 - pz2;
        const atLen = Math.sqrt(atx * atx + aty * aty + atz * atz);
        if (atLen > 1e-4) {
          nx = ptx + atx / atLen;
          ny = pty + aty / atLen;
          nz = ptz + atz / atLen;
        } else {
          nx = _rawPoints[(s + 1) * 3];
          ny = _rawPoints[(s + 1) * 3 + 1];
          nz = _rawPoints[(s + 1) * 3 + 2];
        }
      } else if (s < filledCount - 1) {
        nx = _rawPoints[(s + 1) * 3];
        ny = _rawPoints[(s + 1) * 3 + 1];
        nz = _rawPoints[(s + 1) * 3 + 2];
      } else if (filledCount >= 2) {
        const prevX = _rawPoints[(s - 1) * 3];
        const prevY = _rawPoints[(s - 1) * 3 + 1];
        const prevZ = _rawPoints[(s - 1) * 3 + 2];
        nx = ptx + (ptx - prevX);
        ny = pty + (pty - prevY);
        nz = ptz + (ptz - prevZ);
      } else {
        nx = ptx;
        ny = pty + 1e-3;
        nz = ptz;
      }
      const t = filledCount > 1 ? s / (filledCount - 1) : 0;
      let ribbonTimeFade = 1;
      if (maxTime > 0 && controlCount >= 2) {
        const ctrlF = t * (controlCount - 1);
        const ctrlLo = Math.min(Math.floor(ctrlF), controlCount - 1);
        const ctrlHi = Math.min(ctrlLo + 1, controlCount - 1);
        const frac = ctrlF - ctrlLo;
        const ageLo = now - generalData.creationTimes[_ribbonIndices[ctrlLo]];
        const ageHi = now - generalData.creationTimes[_ribbonIndices[ctrlHi]];
        const age = ageLo + (ageHi - ageLo) * frac;
        ribbonTimeFade = 1 - Math.min(age / maxTimeMs, 1);
      }
      const widthScale = trailWidthCurveFn(t);
      const opacityScale = trailOpacityCurveFn(t);
      const halfWidth = trailConfig.width * widthScale * 0.5;
      const alpha = leaderCa * opacityScale * ribbonTimeFade;
      const fr = trailColorOverTrailFns ? leaderCr * trailColorOverTrailFns.r(t) : leaderCr;
      const fg = trailColorOverTrailFns ? leaderCg * trailColorOverTrailFns.g(t) : leaderCg;
      const fb = trailColorOverTrailFns ? leaderCb * trailColorOverTrailFns.b(t) : leaderCb;
      writeTrailVertex(
        vIdx,
        cIdx,
        aIdx,
        uvIdxBase,
        ptx,
        pty,
        ptz,
        nx,
        ny,
        nz,
        halfWidth,
        t,
        alpha,
        fr,
        fg,
        fb,
        leaderCa,
        trailPosArr,
        trailNextArr,
        trailHalfWidthArr,
        trailUVArr,
        trailAlphaArr,
        trailColorArr
      );
    }
    if (useTwistPrevention && prevNormal && filledCount >= 2) {
      const nIdx = leader * 3;
      const tx = _rawPoints[3] - _rawPoints[0];
      const ty = _rawPoints[4] - _rawPoints[1];
      const tz = _rawPoints[5] - _rawPoints[2];
      const tLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
      if (tLen > 1e-4) {
        const ntx = tx / tLen;
        const nty = ty / tLen;
        const ntz = tz / tLen;
        let upx = 0, upy = 1, upz = 0;
        const dot = ntx * upx + nty * upy + ntz * upz;
        if (Math.abs(dot) > 0.999) {
          upx = 1;
          upy = 0;
          upz = 0;
        }
        let cnx = nty * upz - ntz * upy;
        let cny = ntz * upx - ntx * upz;
        let cnz = ntx * upy - nty * upx;
        const cnLen = Math.sqrt(cnx * cnx + cny * cny + cnz * cnz);
        if (cnLen > 1e-4) {
          cnx /= cnLen;
          cny /= cnLen;
          cnz /= cnLen;
        }
        const prevNx = prevNormal[nIdx];
        const prevNy = prevNormal[nIdx + 1];
        const prevNz = prevNormal[nIdx + 2];
        const hasPrev = prevNx !== 0 || prevNy !== 0 || prevNz !== 0;
        if (hasPrev) {
          const normalDot = cnx * prevNx + cny * prevNy + cnz * prevNz;
          if (normalDot < 0) {
            for (let s = 0; s < Math.min(filledCount, trailLength); s++) {
              const aIdx = leaderVertBase + s * 2;
              const hw = trailHalfWidthArr[aIdx];
              trailHalfWidthArr[aIdx] = -hw;
              trailHalfWidthArr[aIdx + 1] = -hw;
            }
            cnx = -cnx;
            cny = -cny;
            cnz = -cnz;
          }
        }
        prevNormal[nIdx] = cnx;
        prevNormal[nIdx + 1] = cny;
        prevNormal[nIdx + 2] = cnz;
      }
    }
    for (let ri = 1; ri < _ribbonCount; ri++) {
      const pIdx = _ribbonIndices[ri];
      const pVertBase = pIdx * verticesPerParticle;
      const pClearSlots = prevFilled ? prevFilled[pIdx] : trailLength;
      if (prevFilled) prevFilled[pIdx] = 0;
      for (let s = 0; s < pClearSlots; s++) {
        const vIdx = (pVertBase + s * 2) * 3;
        const cIdx = (pVertBase + s * 2) * 4;
        const aIdx = pVertBase + s * 2;
        const uvIdxBase = (pVertBase + s * 2) * 2;
        clearTrailVertex(
          vIdx,
          cIdx,
          aIdx,
          uvIdxBase,
          trailPosArr,
          trailNextArr,
          trailHalfWidthArr,
          trailUVArr,
          trailAlphaArr,
          trailColorArr,
          0,
          0,
          0
        );
      }
    }
  }
  if (hasUpdates) {
    trailPositionAttr.needsUpdate = true;
    trailAlphaAttr.needsUpdate = true;
    trailColorAttr.needsUpdate = true;
    trailNextAttrCached.needsUpdate = true;
    trailHalfWidthAttrCached.needsUpdate = true;
    trailUVAttrCached.needsUpdate = true;
  }
};
var updateParticleSystems = (cycleData) => {
  createdParticleSystems.forEach(
    (props) => updateParticleSystemInstance(props, cycleData)
  );
};

// src/js/effects/three-particles/three-particles-serialization.ts
var SERIALIZATION_VERSION = 1;
var reverseBlendingMap = new Map(
  Object.entries(blendingMap).map(([k, v]) => [
    v,
    k
  ])
);
var reverseCurveFunctionMap = /* @__PURE__ */ new Map();
for (const [id, fn] of Object.entries(curveFunctionIdMap)) {
  if (fn) reverseCurveFunctionMap.set(fn, id);
}
function serializeAny(value, key) {
  if (value === null || value === void 0) return value;
  if (value instanceof THREE3.Vector3)
    return { x: value.x, y: value.y, z: value.z };
  if (value instanceof THREE3.Vector2) return { x: value.x, y: value.y };
  if (value instanceof THREE3.Texture) return void 0;
  if (typeof value === "function") return void 0;
  if (Array.isArray(value)) return value.map((item) => serializeAny(item));
  if (typeof value === "object") {
    const obj = value;
    if (obj["type"] === "EASING" /* EASING */ && typeof obj["curveFunction"] === "function") {
      const id = reverseCurveFunctionMap.get(
        obj["curveFunction"]
      );
      if (!id) {
        throw new Error(
          "Cannot serialize a custom curveFunction. Use a predefined CurveFunctionId instead."
        );
      }
      return {
        type: "EASING" /* EASING */,
        curveFunctionId: id,
        ...obj["scale"] !== void 0 ? { scale: obj["scale"] } : {}
      };
    }
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      if (k === "onUpdate" || k === "onComplete") continue;
      if (k === "blending" && typeof v === "number") {
        result[k] = reverseBlendingMap.get(v) ?? v;
        continue;
      }
      const serialized = serializeAny(v);
      if (serialized !== void 0) result[k] = serialized;
    }
    return result;
  }
  return value;
}
function serializeParticleSystem(config) {
  const serialized = serializeAny(config);
  return JSON.stringify({ _version: SERIALIZATION_VERSION, ...serialized });
}
function deserializeCurve(raw) {
  const obj = raw;
  if (Array.isArray(obj["bezierPoints"]) && !obj["type"]) {
    return { type: "BEZIER" /* BEZIER */, ...obj };
  }
  if (obj["type"] === "EASING" /* EASING */) {
    const id = obj["curveFunctionId"];
    const fn = getCurveFunction(id);
    if (!fn) {
      throw new Error(
        `Unknown curveFunctionId: "${id}". Use a value from CurveFunctionId.`
      );
    }
    const curve = {
      type: "EASING" /* EASING */,
      curveFunction: fn
    };
    if (obj["scale"] !== void 0) curve.scale = obj["scale"];
    return curve;
  }
  return obj;
}
function deserializeCurveOrValue(value) {
  if (typeof value === "number") return value;
  if (!value || typeof value !== "object") return value;
  const obj = value;
  const looksLikeCurve = Array.isArray(obj["bezierPoints"]) || obj["type"] === "BEZIER" /* BEZIER */ || obj["type"] === "EASING" /* EASING */ || typeof obj["curveFunctionId"] === "string";
  if (looksLikeCurve) return deserializeCurve(obj);
  return obj;
}
function deserializeVector3(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const { x = 0, y = 0, z = 0 } = raw;
  return new THREE3.Vector3(x, y, z);
}
function deserializeVector2(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const { x = 1, y = 1 } = raw;
  return new THREE3.Vector2(x, y);
}
function deserializeConfig(raw) {
  const config = {};
  if (raw["transform"] && typeof raw["transform"] === "object") {
    const t = raw["transform"];
    config.transform = {
      position: deserializeVector3(t["position"]),
      rotation: deserializeVector3(t["rotation"]),
      scale: deserializeVector3(t["scale"])
    };
  }
  for (const field of [
    "duration",
    "looping",
    "gravity",
    "simulationSpace",
    "simulationBackend",
    "maxParticles"
  ]) {
    if (field in raw) config[field] = raw[field];
  }
  for (const field of [
    "startDelay",
    "startLifetime",
    "startSpeed",
    "startSize",
    "startOpacity",
    "startRotation"
  ]) {
    if (field in raw)
      config[field] = deserializeCurveOrValue(raw[field]);
  }
  if ("startColor" in raw)
    config.startColor = raw["startColor"];
  if (raw["emission"] && typeof raw["emission"] === "object") {
    const e = raw["emission"];
    config.emission = {
      rateOverTime: deserializeCurveOrValue(e["rateOverTime"]),
      rateOverDistance: deserializeCurveOrValue(
        e["rateOverDistance"]
      ),
      bursts: Array.isArray(e["bursts"]) ? e["bursts"] : []
    };
  }
  if ("shape" in raw)
    config.shape = raw["shape"];
  if (raw["renderer"] && typeof raw["renderer"] === "object") {
    const r = raw["renderer"];
    const blending = typeof r["blending"] === "string" ? blendingMap[r["blending"]] ?? THREE3.NormalBlending : r["blending"] ?? THREE3.NormalBlending;
    config.renderer = { ...r, blending };
  }
  if (raw["velocityOverLifetime"] && typeof raw["velocityOverLifetime"] === "object") {
    const vol = raw["velocityOverLifetime"];
    const deserializeAxis = (axis) => {
      if (!axis || typeof axis !== "object") return {};
      const a = axis;
      return {
        ...a["x"] !== void 0 ? { x: deserializeCurveOrValue(a["x"]) } : {},
        ...a["y"] !== void 0 ? { y: deserializeCurveOrValue(a["y"]) } : {},
        ...a["z"] !== void 0 ? { z: deserializeCurveOrValue(a["z"]) } : {}
      };
    };
    config.velocityOverLifetime = {
      isActive: vol["isActive"] ?? false,
      linear: deserializeAxis(vol["linear"]),
      orbital: deserializeAxis(vol["orbital"])
    };
  }
  for (const field of ["sizeOverLifetime", "opacityOverLifetime"]) {
    if (raw[field] && typeof raw[field] === "object") {
      const m = raw[field];
      config[field] = {
        isActive: m["isActive"] ?? false,
        lifetimeCurve: deserializeCurve(m["lifetimeCurve"])
      };
    }
  }
  if (raw["colorOverLifetime"] && typeof raw["colorOverLifetime"] === "object") {
    const col = raw["colorOverLifetime"];
    config.colorOverLifetime = {
      isActive: col["isActive"] ?? true,
      r: deserializeCurve(col["r"]),
      g: deserializeCurve(col["g"]),
      b: deserializeCurve(col["b"])
    };
  }
  if (raw["rotationOverLifetime"] && typeof raw["rotationOverLifetime"] === "object") {
    config.rotationOverLifetime = raw["rotationOverLifetime"];
  }
  if (raw["noise"] && typeof raw["noise"] === "object") {
    config.noise = raw["noise"];
  }
  if (raw["textureSheetAnimation"] && typeof raw["textureSheetAnimation"] === "object") {
    const tsa = raw["textureSheetAnimation"];
    config.textureSheetAnimation = {
      ...tsa,
      tiles: deserializeVector2(tsa["tiles"]),
      startFrame: deserializeCurveOrValue(tsa["startFrame"])
    };
  }
  if (Array.isArray(raw["subEmitters"])) {
    config.subEmitters = raw["subEmitters"].map((se) => ({
      ...se,
      config: deserializeConfig(se["config"])
    }));
  }
  if (Array.isArray(raw["forceFields"])) {
    config.forceFields = raw["forceFields"].map((ff) => {
      const result = {};
      if ("isActive" in ff) result.isActive = ff["isActive"];
      if ("type" in ff) result.type = ff["type"];
      if (ff["position"]) result.position = deserializeVector3(ff["position"]);
      if (ff["direction"])
        result.direction = deserializeVector3(ff["direction"]);
      if ("strength" in ff)
        result.strength = deserializeCurveOrValue(
          ff["strength"]
        );
      if ("range" in ff)
        result.range = ff["range"] === null ? Infinity : ff["range"];
      if ("falloff" in ff) result.falloff = ff["falloff"];
      return result;
    });
  }
  if (Array.isArray(raw["collisionPlanes"])) {
    config.collisionPlanes = raw["collisionPlanes"].map(
      (cp) => {
        const result = {};
        if ("isActive" in cp) result.isActive = cp["isActive"];
        if ("mode" in cp) result.mode = cp["mode"];
        if (cp["position"])
          result.position = deserializeVector3(cp["position"]);
        if (cp["normal"]) result.normal = deserializeVector3(cp["normal"]);
        if ("dampen" in cp) result.dampen = cp["dampen"];
        if ("lifetimeLoss" in cp)
          result.lifetimeLoss = cp["lifetimeLoss"];
        return result;
      }
    );
  }
  for (const key of Object.keys(raw)) {
    if (!(key in config) && key !== "_version" && raw[key] !== null) {
      config[key] = raw[key];
    }
  }
  return config;
}
function deserializeParticleSystem(json) {
  const parsed = JSON.parse(json);
  const { _version: _, ...raw } = parsed;
  return deserializeConfig(raw);
}


//# sourceMappingURL=index.js.map
//# sourceMappingURL=index.js.map
;// external "three/tsl"

;// ./dist/webgpu.js







// src/webgpu.ts
var PLANE_STRIDE = 12;
var MAX_COLLISION_PLANES = 16;
var COLLISION_PLANE_DATA_SIZE = MAX_COLLISION_PLANES * PLANE_STRIDE;
var _encodeBuf = null;
function encodeCollisionPlanesForGPU(planes) {
  if (!_encodeBuf || _encodeBuf.length !== COLLISION_PLANE_DATA_SIZE) {
    _encodeBuf = new Float32Array(COLLISION_PLANE_DATA_SIZE);
  }
  const data = _encodeBuf;
  data.fill(0);
  const count = Math.min(planes.length, MAX_COLLISION_PLANES);
  for (let i = 0; i < count; i++) {
    const cp = planes[i];
    const base = i * PLANE_STRIDE;
    data[base] = cp.isActive ? 1 : 0;
    let modeCode = 0;
    if (cp.mode === "CLAMP" /* CLAMP */) modeCode = 1;
    else if (cp.mode === "BOUNCE" /* BOUNCE */) modeCode = 2;
    data[base + 1] = modeCode;
    data[base + 2] = cp.position.x;
    data[base + 3] = cp.position.y;
    data[base + 4] = cp.position.z;
    data[base + 5] = cp.normal.x;
    data[base + 6] = cp.normal.y;
    data[base + 7] = cp.normal.z;
    data[base + 8] = cp.dampen;
    data[base + 9] = cp.lifetimeLoss;
    data[base + 10] = 0;
    data[base + 11] = 0;
  }
  return data;
}
function createCollisionPlaneTSL(sCurveData, collisionPlaneOffset, collisionPlaneCount) {
  const count = Math.min(collisionPlaneCount, MAX_COLLISION_PLANES);
  const uCollisionPlaneCount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(count));
  const cpBase = collisionPlaneOffset;
  const applyCollisionPlanesTSL = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
    ({
      pos,
      vel,
      oiaVec,
      sColorNode,
      ps,
      startLife,
      particleIdx,
      sOrbitalIsActiveNode
    }) => {
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Loop__(uCollisionPlaneCount, ({ i }) => {
        const base = i.mul(PLANE_STRIDE).add(cpBase);
        const isActive = sCurveData.element(base);
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(isActive.lessThan(0.5), () => {
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Continue__();
        });
        const mode = sCurveData.element(base.add(1));
        const planePos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
          sCurveData.element(base.add(2)),
          sCurveData.element(base.add(3)),
          sCurveData.element(base.add(4))
        );
        const planeNormal = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
          sCurveData.element(base.add(5)),
          sCurveData.element(base.add(6)),
          sCurveData.element(base.add(7))
        );
        const dampen = sCurveData.element(base.add(8));
        const lifetimeLoss = sCurveData.element(base.add(9));
        const toParticle = pos.sub(planePos);
        const signedDist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(toParticle, planeNormal);
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(signedDist.lessThan(0), () => {
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(mode.lessThan(0.5), () => {
            ps.x.assign(startLife.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)));
          }).ElseIf(mode.lessThan(1.5), () => {
            pos.assign(pos.sub(planeNormal.mul(signedDist)));
            const velDotN = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(vel, planeNormal);
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(velDotN.lessThan(0), () => {
              vel.assign(vel.sub(planeNormal.mul(velDotN)));
            });
          }).Else(() => {
            pos.assign(pos.sub(planeNormal.mul(signedDist)));
            const vDotN = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(vel, planeNormal);
            const reflected = vel.sub(planeNormal.mul(vDotN.mul(2)));
            vel.assign(reflected.mul(dampen));
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(lifetimeLoss.greaterThan(0), () => {
              ps.x.assign(ps.x.add(lifetimeLoss.mul(startLife).mul(1e3)));
            });
          });
        });
      });
    },
    "void"
  );
  return {
    /** Uniform for the active collision plane count. */
    countUniform: uCollisionPlaneCount,
    /** TSL function to call in the compute kernel: apply({ pos, vel, ... }) */
    apply: applyCollisionPlanesTSL
  };
}

// src/js/effects/three-particles/three-particles-bezier.ts
var webgpu_cache = [];
var webgpu_nCr = (n, k) => {
  let z = 1;
  for (let i = 1; i <= k; i++) z *= (n + 1 - i) / i;
  return z;
};
var webgpu_createBezierCurveFunction = (particleSystemId, bezierPoints) => {
  const cacheEntry = webgpu_cache.find((item) => item.bezierPoints === bezierPoints);
  if (cacheEntry) {
    if (!cacheEntry.referencedBy.includes(particleSystemId))
      cacheEntry.referencedBy.push(particleSystemId);
    return cacheEntry.curveFunction;
  }
  const entry = {
    referencedBy: [particleSystemId],
    bezierPoints,
    curveFunction: (percentage) => {
      if (percentage < 0) return bezierPoints[0].y;
      if (percentage > 1) return bezierPoints[bezierPoints.length - 1].y;
      let start = 0;
      let stop = bezierPoints.length - 1;
      for (let i = 0; i < bezierPoints.length; i++) {
        const point = bezierPoints[i];
        if (percentage < (point.percentage ?? 0)) {
          stop = i;
          break;
        }
        if (point.percentage !== void 0) start = i;
      }
      const n = stop - start;
      const calculatedPercentage = (percentage - (bezierPoints[start].percentage ?? 0)) / ((bezierPoints[stop].percentage ?? 1) - (bezierPoints[start].percentage ?? 0));
      let value = 0;
      for (let i = 0; i <= n; i++) {
        const p = bezierPoints[start + i];
        const c = webgpu_nCr(n, i) * Math.pow(1 - calculatedPercentage, n - i) * Math.pow(calculatedPercentage, i);
        value += c * p.y;
      }
      return value;
    }
  };
  webgpu_cache.push(entry);
  return entry.curveFunction;
};

// src/js/effects/three-particles/three-particles-utils.ts
var webgpu_isLifeTimeCurve = (value) => {
  return typeof value !== "number" && "type" in value;
};
var webgpu_getCurveFunctionFromConfig = (particleSystemId, lifetimeCurve) => {
  if (lifetimeCurve.type === "BEZIER" /* BEZIER */) {
    return webgpu_createBezierCurveFunction(
      particleSystemId,
      lifetimeCurve.bezierPoints
    );
  }
  if (lifetimeCurve.type === "EASING" /* EASING */) {
    return lifetimeCurve.curveFunction;
  }
  const raw = lifetimeCurve;
  if (Array.isArray(raw.bezierPoints)) {
    return webgpu_createBezierCurveFunction(
      particleSystemId,
      raw.bezierPoints
    );
  }
  if (typeof raw.curveFunction === "function") {
    return raw.curveFunction;
  }
  throw new Error(`Unsupported value type: ${lifetimeCurve}`);
};
var webgpu_calculateValue = (particleSystemId, value, time = 0) => {
  if (typeof value === "number") {
    return value;
  }
  if ("min" in value && "max" in value) {
    if (value.min === value.max) {
      return value.min ?? 0;
    }
    return __WEBPACK_EXTERNAL_MODULE_three_MathUtils__.randFloat(value.min ?? 0, value.max ?? 1);
  }
  const lifetimeCurve = value;
  return webgpu_getCurveFunctionFromConfig(particleSystemId, lifetimeCurve)(time) * (lifetimeCurve.scale ?? 1);
};

// src/js/effects/three-particles/webgpu/compute-force-fields.ts
var FIELD_STRIDE = 12;
var MAX_FORCE_FIELDS = 16;
var FORCE_FIELD_DATA_SIZE = MAX_FORCE_FIELDS * FIELD_STRIDE;
var GPU_INFINITY = 1e10;
var _encodeBuf2 = null;
function encodeForceFieldsForGPU(forceFields, particleSystemId, systemLifetimePercentage) {
  if (!_encodeBuf2 || _encodeBuf2.length !== FORCE_FIELD_DATA_SIZE) {
    _encodeBuf2 = new Float32Array(FORCE_FIELD_DATA_SIZE);
  }
  const data = _encodeBuf2;
  data.fill(0);
  const count = Math.min(forceFields.length, MAX_FORCE_FIELDS);
  for (let i = 0; i < count; i++) {
    const ff = forceFields[i];
    const base = i * FIELD_STRIDE;
    data[base] = ff.isActive ? 1 : 0;
    data[base + 1] = ff.type === "POINT" /* POINT */ ? 0 : 1;
    data[base + 2] = ff.position.x;
    data[base + 3] = ff.position.y;
    data[base + 4] = ff.position.z;
    data[base + 5] = ff.direction.x;
    data[base + 6] = ff.direction.y;
    data[base + 7] = ff.direction.z;
    data[base + 8] = webgpu_calculateValue(
      particleSystemId,
      ff.strength,
      systemLifetimePercentage
    );
    data[base + 9] = ff.range === Infinity ? GPU_INFINITY : ff.range;
    let falloffCode = 0;
    if (ff.falloff === "LINEAR" /* LINEAR */) falloffCode = 1;
    else if (ff.falloff === "QUADRATIC" /* QUADRATIC */) falloffCode = 2;
    data[base + 10] = falloffCode;
    data[base + 11] = 0;
  }
  return data;
}
function createForceFieldTSL(sCurveData, forceFieldOffset, forceFieldCount) {
  const count = Math.min(forceFieldCount, MAX_FORCE_FIELDS);
  const uForceFieldCount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(count));
  const ffBase = forceFieldOffset;
  const applyForceFieldsTSL = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
    ({
      pos,
      vel,
      delta
    }) => {
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Loop__(uForceFieldCount, ({ i }) => {
        const base = i.mul(FIELD_STRIDE).add(ffBase);
        const isActive = sCurveData.element(base);
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(isActive.lessThan(0.5), () => {
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Continue__();
        });
        const fieldType = sCurveData.element(base.add(1));
        const fieldPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
          sCurveData.element(base.add(2)),
          sCurveData.element(base.add(3)),
          sCurveData.element(base.add(4))
        );
        const fieldDir = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
          sCurveData.element(base.add(5)),
          sCurveData.element(base.add(6)),
          sCurveData.element(base.add(7))
        );
        const strength = sCurveData.element(base.add(8));
        const range = sCurveData.element(base.add(9));
        const falloffType = sCurveData.element(base.add(10));
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(strength.equal(0), () => {
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Continue__();
        });
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(fieldType.greaterThan(0.5), () => {
          const force = strength.mul(delta);
          vel.assign(vel.add(fieldDir.mul(force)));
        });
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(fieldType.lessThan(0.5), () => {
          const toField = fieldPos.sub(pos);
          const dist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(toField);
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(dist.greaterThan(1e-4), () => {
            const inRange = dist.lessThan(range);
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(inRange, () => {
              const dir = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(toField);
              const normDist = dist.div(range);
              const falloffNone = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1);
              const falloffLinear = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(normDist);
              const falloffQuadratic = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(normDist.mul(normDist));
              const useLinear = falloffType.greaterThan(0.5);
              const useQuadratic = falloffType.greaterThan(1.5);
              const falloff = useQuadratic.select(
                falloffQuadratic,
                useLinear.select(falloffLinear, falloffNone)
              );
              const force = strength.mul(falloff).mul(delta);
              vel.assign(vel.add(dir.mul(force)));
            });
          });
        });
      });
    },
    "void"
  );
  return {
    /** Uniform for the active force field count. */
    countUniform: uForceFieldCount,
    /** TSL function to call in the compute kernel: apply({ pos, vel, delta }) */
    apply: applyForceFieldsTSL
  };
}

// src/js/effects/three-particles/webgpu/curve-bake.ts
var CURVE_RESOLUTION = 256;
function bakeCurve(curveFn, resolution = CURVE_RESOLUTION) {
  const samples = new Float32Array(resolution);
  const lastIndex = resolution - 1;
  for (let i = 0; i < resolution; i++) {
    const t = lastIndex === 0 ? 0 : i / lastIndex;
    samples[i] = curveFn(t);
  }
  return samples;
}
function bakeCurveIntoBuffer(buffer2, writeOffset, particleSystemId, curve) {
  const curveFn = webgpu_getCurveFunctionFromConfig(particleSystemId, curve);
  const lastIndex = CURVE_RESOLUTION - 1;
  for (let i = 0; i < CURVE_RESOLUTION; i++) {
    const t = i / lastIndex;
    buffer2[writeOffset + i] = curveFn(t);
  }
  return writeOffset + CURVE_RESOLUTION;
}
function bakeVelocityAxisIntoBuffer(buffer2, writeOffset, particleSystemId, value) {
  if (webgpu_isLifeTimeCurve(value)) {
    return bakeCurveIntoBuffer(buffer2, writeOffset, particleSystemId, value);
  }
  return writeOffset;
}
function bakeParticleSystemCurves(normalizedConfig, particleSystemId) {
  let curveCount = 0;
  const {
    sizeOverLifetime,
    opacityOverLifetime,
    colorOverLifetime,
    velocityOverLifetime
  } = normalizedConfig;
  const hasSizeOverLifetime = sizeOverLifetime.isActive;
  const hasOpacityOverLifetime = opacityOverLifetime.isActive;
  const hasColorOverLifetime = colorOverLifetime.isActive;
  const isVelActive = velocityOverLifetime.isActive;
  const isCurveAxis = (v) => isVelActive && v !== void 0 && webgpu_isLifeTimeCurve(v);
  const hasLinearVelX = isCurveAxis(velocityOverLifetime.linear.x);
  const hasLinearVelY = isCurveAxis(velocityOverLifetime.linear.y);
  const hasLinearVelZ = isCurveAxis(velocityOverLifetime.linear.z);
  const hasOrbitalVelX = isCurveAxis(velocityOverLifetime.orbital.x);
  const hasOrbitalVelY = isCurveAxis(velocityOverLifetime.orbital.y);
  const hasOrbitalVelZ = isCurveAxis(velocityOverLifetime.orbital.z);
  if (hasSizeOverLifetime) curveCount++;
  if (hasOpacityOverLifetime) curveCount++;
  if (hasColorOverLifetime) curveCount += 3;
  if (hasLinearVelX) curveCount++;
  if (hasLinearVelY) curveCount++;
  if (hasLinearVelZ) curveCount++;
  if (hasOrbitalVelX) curveCount++;
  if (hasOrbitalVelY) curveCount++;
  if (hasOrbitalVelZ) curveCount++;
  const data = new Float32Array(curveCount * CURVE_RESOLUTION);
  let writeOffset = 0;
  let nextIndex = 0;
  let sizeOverLifetimeIdx = -1;
  let opacityOverLifetimeIdx = -1;
  let colorRIdx = -1;
  let colorGIdx = -1;
  let colorBIdx = -1;
  let linearVelXIdx = -1;
  let linearVelYIdx = -1;
  let linearVelZIdx = -1;
  let orbitalVelXIdx = -1;
  let orbitalVelYIdx = -1;
  let orbitalVelZIdx = -1;
  if (hasSizeOverLifetime) {
    sizeOverLifetimeIdx = nextIndex++;
    writeOffset = bakeCurveIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      sizeOverLifetime.lifetimeCurve
    );
  }
  if (hasOpacityOverLifetime) {
    opacityOverLifetimeIdx = nextIndex++;
    writeOffset = bakeCurveIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      opacityOverLifetime.lifetimeCurve
    );
  }
  if (hasColorOverLifetime) {
    colorRIdx = nextIndex++;
    writeOffset = bakeCurveIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      colorOverLifetime.r
    );
    colorGIdx = nextIndex++;
    writeOffset = bakeCurveIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      colorOverLifetime.g
    );
    colorBIdx = nextIndex++;
    writeOffset = bakeCurveIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      colorOverLifetime.b
    );
  }
  if (hasLinearVelX) {
    linearVelXIdx = nextIndex++;
    writeOffset = bakeVelocityAxisIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      velocityOverLifetime.linear.x
    );
  }
  if (hasLinearVelY) {
    linearVelYIdx = nextIndex++;
    writeOffset = bakeVelocityAxisIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      velocityOverLifetime.linear.y
    );
  }
  if (hasLinearVelZ) {
    linearVelZIdx = nextIndex++;
    writeOffset = bakeVelocityAxisIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      velocityOverLifetime.linear.z
    );
  }
  if (hasOrbitalVelX) {
    orbitalVelXIdx = nextIndex++;
    writeOffset = bakeVelocityAxisIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      velocityOverLifetime.orbital.x
    );
  }
  if (hasOrbitalVelY) {
    orbitalVelYIdx = nextIndex++;
    writeOffset = bakeVelocityAxisIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      velocityOverLifetime.orbital.y
    );
  }
  if (hasOrbitalVelZ) {
    orbitalVelZIdx = nextIndex++;
    writeOffset = bakeVelocityAxisIntoBuffer(
      data,
      writeOffset,
      particleSystemId,
      velocityOverLifetime.orbital.z
    );
  }
  return {
    data,
    curveCount,
    sizeOverLifetime: sizeOverLifetimeIdx,
    opacityOverLifetime: opacityOverLifetimeIdx,
    colorR: colorRIdx,
    colorG: colorGIdx,
    colorB: colorBIdx,
    linearVelX: linearVelXIdx,
    linearVelY: linearVelYIdx,
    linearVelZ: linearVelZIdx,
    orbitalVelX: orbitalVelXIdx,
    orbitalVelY: orbitalVelYIdx,
    orbitalVelZ: orbitalVelZIdx
  };
}
var permute = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(({ x }) => {
  return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mod__(x.mul(34).add(10).mul(x), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(289));
});
var taylorInvSqrt = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(({ r }) => {
  return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1.79284291400159).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.85373472095314).mul(r));
});
var snoise3D = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({ v }) => {
    const ONE_THIRD = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1 / 3);
    const ONE_SIXTH = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1 / 6);
    const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(
      v.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(v, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(ONE_THIRD, ONE_THIRD, ONE_THIRD)))
    ).toVar();
    const x0 = v.sub(i).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(i, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(ONE_SIXTH, ONE_SIXTH, ONE_SIXTH))).toVar();
    const g = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_step__(x0.yzx, x0.xyz).toVar();
    const l = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(g).toVar();
    const i1 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(g.xyz, l.zxy).toVar();
    const i2 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__(g.xyz, l.zxy).toVar();
    const x1 = x0.sub(i1).add(ONE_SIXTH).toVar();
    const x2 = x0.sub(i2).add(ONE_SIXTH.mul(2)).toVar();
    const x3 = x0.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)).add(ONE_SIXTH.mul(3)).toVar();
    const iw = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mod__(i, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(289)).toVar();
    const p0_yz = permute({
      x: permute({
        x: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(iw.z, iw.z.add(i1.z)),
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(iw.z.add(i2.z), iw.z.add(1))
        )
      }).add(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(iw.y, iw.y.add(i1.y)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(iw.y.add(i2.y), iw.y.add(1)))
      )
    });
    const p = permute({
      x: p0_yz.add(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(iw.x, iw.x.add(i1.x)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(iw.x.add(i2.x), iw.x.add(1)))
      )
    });
    const n_ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.142857142857142);
    const j = p.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(49).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(p.mul(n_).mul(n_)))).toVar();
    const x_ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(j.mul(n_)).toVar();
    const y_ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(j.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(7).mul(x_))).toVar();
    const NS_X = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.285714285714286);
    const NS_Y = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(-0.928571428571429);
    const gx = x_.mul(NS_X).add(NS_Y);
    const gy = y_.mul(NS_X).add(NS_Y);
    const gz = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_abs__(gx)).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_abs__(gy)).toVar();
    const gz_neg = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_step__(gz, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(0));
    const ox = gz_neg.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(gx).add(0.5));
    const oy = gz_neg.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(gy).add(0.5));
    const gx_final = gx.sub(ox);
    const gy_final = gy.sub(oy);
    const g0 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(gx_final.x, gy_final.x, gz.x).toVar();
    const g1 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(gx_final.y, gy_final.y, gz.y).toVar();
    const g2 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(gx_final.z, gy_final.z, gz.z).toVar();
    const g3 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(gx_final.w, gy_final.w, gz.w).toVar();
    const norm = taylorInvSqrt({
      r: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g0, g0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g1, g1)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g2, g2), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g3, g3)))
    });
    g0.assign(g0.mul(norm.x));
    g1.assign(g1.mul(norm.y));
    g2.assign(g2.mul(norm.z));
    g3.assign(g3.mul(norm.w));
    const m = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(x0, x0)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(x1, x1))),
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(x2, x2)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(x3, x3)))
      ),
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)
    ).toVar();
    const m2 = m.mul(m).toVar();
    const m4 = m2.mul(m2).toVar();
    const gdot = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g0, x0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g1, x1)),
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g2, x2), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(g3, x3))
    );
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(42).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(m4, gdot));
  }
);
__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({ t }) => {
    const noiseX = snoise3D({ v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(t, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)) });
    const noiseY = snoise3D({ v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(t, t, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)) });
    const noiseZ = snoise3D({ v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(t, t, t) });
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(noiseX, noiseY, noiseZ);
  }
);

// src/js/effects/three-particles/color-utils.ts
var webgpu_sRGBToLinear = (c) => c < 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);

// src/js/effects/three-particles/webgpu/compute-modifiers.ts
var SUB_EMITTER_EVENT_STRIDE = 6;
var subEmitterWindowSize = (capacity) => SUB_EMITTER_EVENT_STRIDE * Math.max(1, capacity);
var asU32 = (n) => n.nodeType === "uint" ? n : n.toUint();
var pcgRawU32 = (seedU) => {
  const stateU = asU32(seedU).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(747796405)).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2891336453));
  const wordU = stateU.shiftRight(stateU.shiftRight(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(28)).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(4))).bitXor(stateU).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(277803737));
  return wordU.shiftRight(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(22)).bitXor(wordU);
};
var pcg01 = (seedU) => pcgRawU32(seedU).toFloat().mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1 / 4294967296));
var mixBirthSeed = (birthNoU, systemSeedU, channelU) => asU32(birthNoU).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(asU32(systemSeedU)).bitXor(asU32(channelU));
var randomChannel = (birthNoU, systemSeedU, channelU) => pcg01(mixBirthSeed(birthNoU, systemSeedU, channelU));
var stableSeedU32 = (birthNoU, systemSeedU) => pcgRawU32(mixBirthSeed(birthNoU, systemSeedU, CH.STABLE_SEED)).bitAnd(
  __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(16777215)
);
var stableSeedFromExt = (extW) => extW.toUint();
var nextSystemSeed = () => Math.floor(Math.random() * 4294967296) >>> 0;
var CH = {
  SHAPE_A: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1),
  SHAPE_B: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2),
  SHAPE_C: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(3),
  START_FRAME: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(4),
  SPEED: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(5),
  SIZE: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(6),
  ROTATION: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(7),
  OPACITY: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(8),
  LIFETIME: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(9),
  COLOR: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(10),
  ROTOL: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(11),
  STABLE_SEED: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(12),
  LIN_X: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(13),
  LIN_Y: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(14),
  LIN_Z: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(15),
  ORB_X: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(16),
  ORB_Y: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(17),
  ORB_Z: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(18),
  NOISE_PHASE: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(19)
};
var createSubEmitterFifoAttribute = (capacity) => ({
  counter: new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(new Uint32Array(2), 1),
  payload: new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(
    new Float32Array(
      2 * SUB_EMITTER_EVENT_STRIDE * Math.max(1, capacity)
    ),
    1
  ),
  trigger: 1,
  capacity: Math.max(1, capacity),
  windowSize: subEmitterWindowSize(capacity)
});
function createModifierStorageBuffers(maxParticles, instanced, curveData, hasForceFields = false, hasCollisionPlanes = false, trailLength = 0) {
  const Cls = instanced ? __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageInstancedBufferAttribute__ : __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__;
  const curveLen = Math.max(curveData.length, 1);
  const ffSize = hasForceFields ? FORCE_FIELD_DATA_SIZE : 0;
  const cpSize = hasCollisionPlanes ? COLLISION_PLANE_DATA_SIZE : 0;
  const packedData = new Float32Array(curveLen + ffSize + cpSize);
  packedData.set(curveData, 0);
  const allocatorCount = maxParticles + 1;
  const allocatorData = new Uint32Array(allocatorCount);
  allocatorData[0] = 0;
  for (let i = 0; i < maxParticles; i++) allocatorData[i + 1] = i;
  const trailMeta = trailLength > 0 ? new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(
    new Uint32Array(Math.max(1, maxParticles) * 2),
    1
  ) : null;
  return {
    buffers: {
      position: new Cls(new Float32Array(maxParticles * 4), 4),
      velocity: new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(new Float32Array(maxParticles * 4), 4),
      color: new Cls(new Float32Array(maxParticles * 4), 4),
      particleState: new Cls(new Float32Array(maxParticles * 4), 4),
      startValues: new Cls(new Float32Array(maxParticles * 4), 4),
      startColorsExt: new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(new Float32Array(maxParticles * 4), 4),
      orbitalIsActive: new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(new Float32Array(maxParticles * 4), 4),
      allocator: new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(allocatorData, 1),
      trailMeta,
      packedData
    },
    allocatorCount
  };
}
function createCurveLookup(sCurveData) {
  return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(({ curveIndex, t }) => {
    const clamped = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(t, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
    const pos = clamped.mul(CURVE_RESOLUTION - 1);
    const idx0 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(pos);
    const f = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_fract__(pos);
    const base = curveIndex.mul(CURVE_RESOLUTION);
    const v0 = sCurveData.element(base.add(idx0));
    const v1 = sCurveData.element(base.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(idx0.add(1), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(CURVE_RESOLUTION - 1))));
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(v0, v1, f);
  });
}
function shapeEmitNodes(u, rA, rB, rC, rSpeed) {
  const DEG = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.01745329);
  const uRadius = u.radius;
  const uRadiusThickness = u.thickness;
  const thetaS = rA.mul(u.arcDeg).mul(DEG);
  const cosPhi = rB.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
  const sinPhi = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sqrt__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(cosPhi.mul(cosPhi)));
  const dirSx = sinPhi.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(thetaS));
  const dirSy = sinPhi.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(thetaS));
  const dirSz = cosPhi;
  const distS = uRadius.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(uRadiusThickness)).add(uRadius.mul(uRadiusThickness).mul(rC));
  const pSx = dirSx.mul(distS);
  const pSy = dirSy.mul(distS);
  const pSz = dirSz.mul(distS);
  const spS = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(u.speedMin, u.speedMax, rSpeed);
  const vSx = dirSx.mul(spS);
  const vSy = dirSy.mul(spS);
  const vSz = dirSz.mul(spS);
  const thetaB = rA.mul(u.arcDeg).mul(DEG);
  const dirBx = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(thetaB);
  const dirBy = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(thetaB);
  const distB = uRadius.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(uRadiusThickness)).add(uRadius.mul(uRadiusThickness).mul(rB));
  const pBx = dirBx.mul(distB);
  const pBy = dirBy.mul(distB);
  const pBz = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0);
  const nAngle = distB.div(uRadius.max(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1e-6))).mul(u.coneAngleDeg.mul(DEG));
  const spB = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(u.speedMin, u.speedMax, rSpeed);
  const sinNA = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(nAngle);
  const vCx = dirBx.mul(sinNA).mul(spB);
  const vCy = dirBy.mul(sinNA).mul(spB);
  const vCz = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(nAngle).mul(spB);
  const vIx = dirBx.mul(spB);
  const vIy = dirBy.mul(spB);
  const vIz = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0);
  const rxOff = rA.mul(u.rectSX).sub(u.rectSX.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5)));
  const ryOff = rB.mul(u.rectSY).sub(u.rectSY.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5)));
  const rotXr = u.rectRX.mul(DEG);
  const rotYr = u.rectRY.mul(DEG);
  const pRx = rxOff.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(rotYr));
  const pRy = ryOff.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(rotXr));
  const pRz = rxOff.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(rotYr)).sub(ryOff.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(rotXr)));
  const halfX = u.boxSX.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5));
  const halfY = u.boxSY.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5));
  const halfZ = u.boxSZ.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5));
  const pVx = rA.mul(u.boxSX).sub(halfX);
  const pVy = rB.mul(u.boxSY).sub(halfY);
  const pVz = rC.mul(u.boxSZ).sub(halfZ);
  const side = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(rA.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(6))).min(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(5));
  const pa = side.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(side.div(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(3))).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(3)));
  const a0 = side.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)).select(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const isPa0 = pa.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const isPa1 = pa.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
  const shX = isPa0.select(a0, isPa1.select(rC, rB));
  const shY = isPa0.select(rB, isPa1.select(a0, rC));
  const shZ = isPa0.select(rC, isPa1.select(rB, a0));
  const pShx = shX.mul(u.boxSX).sub(halfX);
  const pShy = shY.mul(u.boxSY).sub(halfY);
  const pShz = shZ.mul(u.boxSZ).sub(halfZ);
  const edge = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(rB.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(4))).min(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(3));
  const lowEdge = edge.lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2));
  const e1 = lowEdge.select(rC, edge.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)));
  const e2 = lowEdge.select(edge, rC);
  const edX = isPa0.select(a0, isPa1.select(e2, e1));
  const edY = isPa0.select(e1, isPa1.select(a0, e2));
  const edZ = isPa0.select(e2, isPa1.select(e1, a0));
  const pEdx = edX.mul(u.boxSX).sub(halfX);
  const pEdy = edY.mul(u.boxSY).sub(halfY);
  const pEdz = edZ.mul(u.boxSZ).sub(halfZ);
  const boxFrom = u.boxFrom;
  const pBX = boxFrom.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)).select(pVx, boxFrom.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)).select(pShx, pEdx));
  const pBY = boxFrom.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)).select(pVy, boxFrom.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)).select(pShy, pEdy));
  const pBZ = boxFrom.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)).select(pVz, boxFrom.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)).select(pShz, pEdz));
  const vPlaneZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(u.speedMin, u.speedMax, rSpeed);
  const kind = u.kind;
  const isSphereKind = kind.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const isConeKind = kind.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
  const isCircleKind = kind.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2));
  const isRectKind = kind.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(3));
  const planeX = isRectKind.select(pRx, pBX);
  const planeY = isRectKind.select(pRy, pBY);
  const planeZ = isRectKind.select(pRz, pBZ);
  const isDiscKind = isConeKind.or(isCircleKind);
  const discX = isDiscKind.select(pBx, planeX);
  const discY = isDiscKind.select(pBy, planeY);
  const discZ = isDiscKind.select(pBz, planeZ);
  const px = isSphereKind.select(pSx, discX);
  const py = isSphereKind.select(pSy, discY);
  const pz = isSphereKind.select(pSz, discZ);
  const cOrI_X = isConeKind.select(vCx, vIx);
  const cOrI_Y = isConeKind.select(vCy, vIy);
  const cOrI_Z = isConeKind.select(vCz, vIz);
  const isDisc = isConeKind.or(isCircleKind);
  const nonSphereVX = isDisc.select(cOrI_X, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const nonSphereVY = isDisc.select(cOrI_Y, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const nonSphereVZ = isDisc.select(cOrI_Z, vPlaneZ);
  const vx = isSphereKind.select(vSx, nonSphereVX);
  const vy = isSphereKind.select(vSy, nonSphereVY);
  const vz = isSphereKind.select(vSz, nonSphereVZ);
  return { px, py, pz, vx, vy, vz };
}
function quatRotateNodes(x, y, z, q) {
  const qx = q.x;
  const qy = q.y;
  const qz = q.z;
  const qw = q.w;
  const projD = qx.mul(x).add(qy.mul(y)).add(qz.mul(z)).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2));
  const scaleV = qw.mul(qw).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
  const twoW = qw.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2));
  return [
    x.mul(scaleV).add(qx.mul(projD)).add(qy.mul(z).sub(qz.mul(y)).mul(twoW)),
    y.mul(scaleV).add(qy.mul(projD)).add(qz.mul(x).sub(qx.mul(z)).mul(twoW)),
    z.mul(scaleV).add(qz.mul(projD)).add(qx.mul(y).sub(qy.mul(x)).mul(twoW))
  ];
}
function createModifierComputeUpdate(buffers, maxParticles, curveMap, flags, shapeParams, forceFieldCount = 0, collisionPlaneCount = 0, subFifos = [], trailDesc, velocityValues) {
  const uDelta = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uDeltaMs = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uNowMs = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uGravityVelocity = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(0, 0, 0));
  const uSystemSeed = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(nextSystemSeed(), "uint");
  const uSeed = uSystemSeed;
  const uEmitCount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(0, "uint");
  const uNoiseStrength = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uNoisePower = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uNoiseFrequency = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
  const uNoisePosAmount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uNoiseRotAmount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const uNoiseSizeAmount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const shapeUniforms = {};
  const sh = (name, v) => {
    const u = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(v));
    shapeUniforms[name] = u;
    return u;
  };
  const uShape = sh("shapeKind", shapeParams.shapeKind);
  const uRadius = sh("radius", shapeParams.radius);
  const uRadiusThickness = sh("radiusThickness", shapeParams.radiusThickness);
  const uArcDeg = sh("arcDeg", shapeParams.arcDeg);
  const uConeAngleDeg = sh("coneAngleDeg", shapeParams.coneAngleDeg);
  const uRectRX = sh("rectangleRotXDeg", shapeParams.rectangleRotXDeg);
  const uRectRY = sh("rectangleRotYDeg", shapeParams.rectangleRotYDeg);
  const uRectSX = sh("rectangleScaleX", shapeParams.rectangleScaleX);
  const uRectSY = sh("rectangleScaleY", shapeParams.rectangleScaleY);
  const uBoxSX = sh("boxScaleX", shapeParams.boxScaleX);
  const uBoxSY = sh("boxScaleY", shapeParams.boxScaleY);
  const uBoxSZ = sh("boxScaleZ", shapeParams.boxScaleZ);
  const uBoxEmitFrom = sh("boxEmitFrom", shapeParams.boxEmitFrom);
  const uEmitterPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector4__(0, 0, 0, 0));
  const uWrapperQuat = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector4__(0, 0, 0, 1));
  const uWorldScale = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(1, 1, 1));
  const uSpeedMin = sh("speedMin", shapeParams.speedMin);
  const uSpeedMax = sh("speedMax", shapeParams.speedMax);
  const uSizeMin = sh("sizeMin", shapeParams.sizeMin);
  const uSizeMax = sh("sizeMax", shapeParams.sizeMax);
  const uRotMin = sh("rotMin", shapeParams.rotMin);
  const uRotMax = sh("rotMax", shapeParams.rotMax);
  const uRotOLMin = sh("rotOverLifeMin", shapeParams.rotOverLifeMin);
  const uRotOLMax = sh("rotOverLifeMax", shapeParams.rotOverLifeMax);
  const uOpMin = sh("opacityMin", shapeParams.opacityMin);
  const uOpMax = sh("opacityMax", shapeParams.opacityMax);
  const uLifeMin = sh("lifeMin", shapeParams.lifeMin);
  const uLifeMax = sh("lifeMax", shapeParams.lifeMax);
  const uCRR = sh("colorRMin", webgpu_sRGBToLinear(shapeParams.colorRMin));
  const uCRX = sh("colorRMax", webgpu_sRGBToLinear(shapeParams.colorRMax));
  const uCGR = sh("colorGMin", webgpu_sRGBToLinear(shapeParams.colorGMin));
  const uCGX = sh("colorGMax", webgpu_sRGBToLinear(shapeParams.colorGMax));
  const uCBR = sh("colorBMin", webgpu_sRGBToLinear(shapeParams.colorBMin));
  const uCBX = sh("colorBMax", webgpu_sRGBToLinear(shapeParams.colorBMax));
  const uFrMin = sh("startFrameMin", shapeParams.startFrameMin);
  const uFrMax = sh("startFrameMax", shapeParams.startFrameMax);
  const sPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.position, "vec4", maxParticles);
  const sVel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.velocity, "vec4", maxParticles);
  const sCol = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.color, "vec4", maxParticles);
  const sPS = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.particleState, "vec4", maxParticles);
  const sSV = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.startValues, "vec4", maxParticles);
  const sEx = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.startColorsExt, "vec4", maxParticles);
  const sOIA = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.orbitalIsActive, "vec4", maxParticles);
  const allocatorCount = maxParticles + 1;
  __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(maxParticles);
  const ringModU = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(maxParticles);
  const sAllocator = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.allocator, "uint", Math.max(1, allocatorCount)).toAtomic();
  const sCD = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_buffer__(buffers.packedData, "float", buffers.packedData.length);
  const lookupCurve = createCurveLookup(sCD);
  const uFifoBase = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), "uint");
  const fifoNodes = subFifos.map((f) => ({
    trigger: f.trigger,
    capacity: Math.max(1, f.capacity),
    windowSize: subEmitterWindowSize(Math.max(1, f.capacity)),
    count: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(
      f.counter,
      "uint",
      Math.max(1, f.counter.array.length)
    ).toAtomic(),
    payload: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(
      f.payload,
      "float",
      Math.max(1, f.payload.array.length)
    )
  }));
  const birthFifos = fifoNodes.filter((f) => f.trigger === 0);
  const deathFifos = fifoNodes.filter((f) => f.trigger === 1);
  const hasDeathFifo = deathFifos.length > 0;
  const writeFifoEvent = (f, x, y, z, vx, vy, vz) => {
    const winBase = uFifoBase.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(f.windowSize)).toVar();
    const oldCount = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicAdd__(f.count.element(uFifoBase), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1))
    ).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(oldCount.lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(f.capacity)), () => {
      const b = winBase.add(oldCount.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(SUB_EMITTER_EVENT_STRIDE)));
      f.payload.element(b).assign(x);
      f.payload.element(b.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1))).assign(y);
      f.payload.element(b.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2))).assign(z);
      f.payload.element(b.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(3))).assign(vx);
      f.payload.element(b.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(4))).assign(vy);
      f.payload.element(b.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(5))).assign(vz);
    });
  };
  const trailRows = trailDesc ? trailDesc.length + 1 : 0;
  const sTrail = trailDesc ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(trailDesc.attribute, "vec4", trailRows * maxParticles) : null;
  const sTrailMeta = trailDesc && buffers.trailMeta ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(buffers.trailMeta, "uint", maxParticles * 2).toAtomic() : null;
  const curveLen = Math.max(curveMap.data.length, 1);
  const forceFieldOffset = curveLen;
  const collisionOffset = forceFieldOffset + (flags.forceFields ? FORCE_FIELD_DATA_SIZE : 0);
  const ffNodes = flags.forceFields ? createForceFieldTSL(sCD, forceFieldOffset, forceFieldCount) : null;
  const cpNodes = flags.collisionPlanes ? createCollisionPlaneTSL(sCD, collisionOffset, collisionPlaneCount) : null;
  const parseAxis = (rawAxis, curveIdx) => {
    if (curveIdx >= 0) {
      return { ci: curveIdx, min: 0, max: 0, isRange: false };
    }
    if (rawAxis && typeof rawAxis === "object" && "min" in rawAxis && "max" in rawAxis) {
      const mn = Number(rawAxis.min) || 0;
      const mx = Number(rawAxis.max) || 0;
      return { ci: -1, min: mn, max: mx, isRange: mn !== mx };
    }
    const c = typeof rawAxis === "number" ? rawAxis : 0;
    return { ci: -1, min: c, max: c, isRange: false };
  };
  const vv = velocityValues ?? {
    linear: [void 0, void 0, void 0],
    orbital: [void 0, void 0, void 0]
  };
  const linAxes = [
    parseAxis(vv.linear[0], curveMap.linearVelX),
    parseAxis(vv.linear[1], curveMap.linearVelY),
    parseAxis(vv.linear[2], curveMap.linearVelZ)
  ];
  const orbAxes = [
    parseAxis(vv.orbital[0], curveMap.orbitalVelX),
    parseAxis(vv.orbital[1], curveMap.orbitalVelY),
    parseAxis(vv.orbital[2], curveMap.orbitalVelZ)
  ];
  const axisUniforms = /* @__PURE__ */ new Map();
  for (const a of [...linAxes, ...orbAxes]) {
    if (a.isRange) {
      axisUniforms.set(a, [__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(a.min)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(a.max))]);
    }
  }
  const simAxis = (a, lifePct, particleSeed, salt) => {
    if (a.ci >= 0) {
      return lookupCurve({
        curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(a.ci),
        t: lifePct
      });
    }
    if (a.isRange) {
      const [mn, mx] = axisUniforms.get(a);
      return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(
        mn,
        mx,
        pcg01(particleSeed.toUint().mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(salt))
      );
    }
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(a.min);
  };
  const emitKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(i.lessThan(uEmitCount), () => {
      const birthNo = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicAdd__(sAllocator.element(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1)).toVar();
      const slotIdx = birthNo.mod(ringModU).toVar();
      const rcA = randomChannel(birthNo, uSystemSeed, CH.SHAPE_A);
      const rcB = randomChannel(birthNo, uSystemSeed, CH.SHAPE_B);
      const rcC = randomChannel(birthNo, uSystemSeed, CH.SHAPE_C);
      const rcSpeed = randomChannel(birthNo, uSystemSeed, CH.SPEED);
      const rcSize = randomChannel(birthNo, uSystemSeed, CH.SIZE);
      const rcRot = randomChannel(birthNo, uSystemSeed, CH.ROTATION);
      const rcOpacity = randomChannel(birthNo, uSystemSeed, CH.OPACITY);
      const rcSheet = randomChannel(birthNo, uSystemSeed, CH.START_FRAME);
      const rcLife = randomChannel(birthNo, uSystemSeed, CH.LIFETIME);
      const rcColor = randomChannel(birthNo, uSystemSeed, CH.COLOR);
      const rcRotOl = randomChannel(birthNo, uSystemSeed, CH.ROTOL);
      const shE = shapeEmitNodes(
        {
          kind: uShape,
          radius: uRadius,
          thickness: uRadiusThickness,
          arcDeg: uArcDeg,
          coneAngleDeg: uConeAngleDeg,
          rectRX: uRectRX,
          rectRY: uRectRY,
          rectSX: uRectSX,
          rectSY: uRectSY,
          boxSX: uBoxSX,
          boxSY: uBoxSY,
          boxSZ: uBoxSZ,
          boxFrom: uBoxEmitFrom,
          speedMin: uSpeedMin,
          speedMax: uSpeedMax
        },
        rcA,
        rcB,
        rcC,
        rcSpeed
      );
      const pxL = shE.px;
      const pyL = shE.py;
      const pzL = shE.pz;
      const vxL = shE.vx;
      const vyL = shE.vy;
      const vzL = shE.vz;
      const [rotPX, rotPY, rotPZ] = quatRotateNodes(pxL, pyL, pzL, uWrapperQuat);
      const [rotVX, rotVY, rotVZ] = quatRotateNodes(vxL, vyL, vzL, uWrapperQuat);
      const isWorld = uEmitterPos.w.greaterThan(0.5);
      const sxf = isWorld.select(uWorldScale.x, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
      const syf = isWorld.select(uWorldScale.y, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
      const szf = isWorld.select(uWorldScale.z, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
      const ox = rotPX.mul(sxf).add(uEmitterPos.x);
      const oy = rotPY.mul(syf).add(uEmitterPos.y);
      const oz = rotPZ.mul(szf).add(uEmitterPos.z);
      const opac = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uOpMin, uOpMax, rcOpacity);
      const clR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uCRR, uCRX, rcColor);
      const clG = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uCGR, uCGX, rcColor);
      const clB = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uCBR, uCBX, rcColor);
      const slife = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uLifeMin, uLifeMax, rcLife).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1e3));
      const ssize = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uSizeMin, uSizeMax, rcSize);
      const srot = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uRotMin, uRotMax, rcRot);
      const startFrame = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uFrMin, uFrMax, rcSheet)).toVar();
      const rotSpeed = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(uRotOLMin, uRotOLMax, rcRotOl);
      const stableSeedU = stableSeedU32(birthNo, uSystemSeed);
      sPos.element(slotIdx).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(ox, oy, oz, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
      sVel.element(slotIdx).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(rotVX, rotVY, rotVZ, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
      sCol.element(slotIdx).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(clR, clG, clB, opac));
      sPS.element(slotIdx).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), ssize, srot, startFrame));
      sSV.element(slotIdx).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(slife, ssize, opac, clR));
      sEx.element(slotIdx).assign(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(clG, clB, rotSpeed, stableSeedU.toFloat())
      );
      sOIA.element(slotIdx).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(rotPX, rotPY, rotPZ, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)));
    });
  });
  const emitNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(emitKernel(), maxParticles);
  const noiseOctavesCount = Math.max(1, Math.round(shapeParams.noiseOctaves || 1));
  const noiseFbmMax = 2 - Math.pow(2, -noiseOctavesCount);
  if (!Number.isFinite(noiseFbmMax) || noiseFbmMax <= 0) {
    throw new Error(
      `three-particles: invalid FBM normalization ${noiseFbmMax}`
    );
  }
  const simKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(maxParticles)), () => {
      const oiaVec = sOIA.element(i).toVar();
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(oiaVec.w.greaterThanEqual(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5)), () => {
        const pos = sPos.element(i).xyz.toVar();
        const vel = sVel.element(i).xyz.toVar();
        const ps = sPS.element(i).toVar();
        const sv = sSV.element(i);
        const ex = sEx.element(i);
        const startLife = sv.x;
        const life = ps.x;
        const lifePct = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(life.div(startLife), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
        vel.assign(vel.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(uGravityVelocity).mul(uDelta)));
        if (ffNodes) ffNodes.apply({ pos, vel, delta: uDelta });
        pos.assign(pos.add(vel.mul(uDelta)));
        if (cpNodes) cpNodes.apply({
          pos,
          vel,
          oiaVec,
          sColorNode: sCol,
          ps,
          startLife,
          particleIdx: i,
          sOrbitalIsActiveNode: sOIA
        });
        if (flags.linearVelocity) {
          const lvx = simAxis(linAxes[0], lifePct, stableSeedFromExt(ex.w), CH.LIN_X);
          const lvy = simAxis(linAxes[1], lifePct, stableSeedFromExt(ex.w), CH.LIN_Y);
          const lvz = simAxis(linAxes[2], lifePct, stableSeedFromExt(ex.w), CH.LIN_Z);
          pos.assign(pos.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(lvx, lvy, lvz).mul(uDelta)));
        }
        if (flags.orbitalVelocity) {
          const offset = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(oiaVec.x, oiaVec.y, oiaVec.z).toVar();
          pos.assign(pos.sub(offset));
          const oX = simAxis(orbAxes[0], lifePct, stableSeedFromExt(ex.w), CH.ORB_X);
          const oY = simAxis(orbAxes[1], lifePct, stableSeedFromExt(ex.w), CH.ORB_Y);
          const oZ = simAxis(orbAxes[2], lifePct, stableSeedFromExt(ex.w), CH.ORB_Z);
          const angX = oX.mul(uDelta);
          const angY = oZ.mul(uDelta);
          const angZ = oY.mul(uDelta);
          const c3 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(angZ), s3 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(angZ);
          const zx = offset.x.mul(c3).sub(offset.y.mul(s3));
          const zy = offset.x.mul(s3).add(offset.y.mul(c3));
          const zz = offset.z;
          const c2 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(angY), s2 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(angY);
          const yx = zx.mul(c2).add(zz.mul(s2));
          const yz = zx.mul(s2).negate().add(zz.mul(c2));
          const yy = zy;
          const c1 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(angX), s1 = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(angX);
          const fx = yx;
          const fy = yy.mul(c1).sub(yz.mul(s1));
          const fz = yy.mul(s1).add(yz.mul(c1));
          pos.assign(pos.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(fx, fy, fz)));
          oiaVec.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(fx, fy, fz, oiaVec.w));
        }
        if (flags.sizeOverLifetime) {
          const s = lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(curveMap.sizeOverLifetime), t: lifePct });
          ps.y.assign(s.mul(sv.y));
        }
        if (flags.opacityOverLifetime) {
          const op = lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(curveMap.opacityOverLifetime), t: lifePct });
          const col = sCol.element(i).toVar();
          col.w.assign(op.mul(sv.z));
          sCol.element(i).assign(col);
        }
        if (flags.colorOverLifetime) {
          const col = sCol.element(i).toVar();
          const sce = sEx.element(i);
          if (curveMap.colorR >= 0) {
            col.x.assign(sv.w.mul(lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(curveMap.colorR), t: lifePct })));
          }
          if (curveMap.colorG >= 0) {
            col.y.assign(sce.x.mul(lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(curveMap.colorG), t: lifePct })));
          }
          if (curveMap.colorB >= 0) {
            col.z.assign(sce.y.mul(lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(curveMap.colorB), t: lifePct })));
          }
          sCol.element(i).assign(col);
        }
        if (flags.rotationOverLifetime) {
          ps.z.assign(ps.z.add(ex.z.mul(uDelta).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.02))));
        }
        if (flags.noise) {
          const noiseOffset = shapeParams.noiseUseRandomOffset ? pcg01(
            stableSeedFromExt(ex.w).toUint().mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(CH.NOISE_PHASE)
          ).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(100)) : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0);
          const np = lifePct.add(noiseOffset).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(10)).mul(uNoiseStrength).mul(uNoiseFrequency);
          let noiseX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0).toVar();
          let noiseY = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0).toVar();
          let noiseZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0).toVar();
          let amp = 1;
          let lac = 1;
          for (let o = 0; o < noiseOctavesCount; o++) {
            const t = np.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(lac));
            const sc = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(amp / noiseFbmMax);
            noiseX.assign(noiseX.add(snoise3D({ v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(t, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)) }).mul(sc)));
            noiseY.assign(noiseY.add(snoise3D({ v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(t, t, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)) }).mul(sc)));
            noiseZ.assign(noiseZ.add(snoise3D({ v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(t, t, t) }).mul(sc)));
            amp *= 0.5;
            lac *= 2;
          }
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(uNoisePosAmount.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1e-3)), () => {
            pos.assign(
              pos.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(noiseX, noiseY, noiseZ).mul(uNoisePower).mul(uNoisePosAmount))
            );
          });
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(uNoiseRotAmount.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1e-3)), () => {
            ps.z.assign(ps.z.add(noiseX.mul(uNoisePower).mul(uNoiseRotAmount)));
          });
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(uNoiseSizeAmount.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1e-3)), () => {
            ps.y.assign(ps.y.add(noiseX.mul(uNoisePower).mul(uNoiseSizeAmount)));
          });
        }
        ps.x.assign(ps.x.add(uDeltaMs));
        sPos.element(i).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(pos, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
        sVel.element(i).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(vel, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
        sPS.element(i).assign(ps);
        sOIA.element(i).assign(oiaVec);
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(ps.x.greaterThan(startLife), () => {
          const inactive = sOIA.element(i).toVar();
          sOIA.element(i).assign(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(
              inactive.x,
              inactive.y,
              inactive.z,
              hasDeathFifo ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(-1) : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)
            )
          );
          sCol.element(i).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
        });
      });
    });
  });
  const simNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(simKernel(), maxParticles);
  let trailHistoryNode = null;
  if (sTrail && sTrailMeta && trailDesc) {
    const trailHistoryKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
      const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(maxParticles)), () => {
        const oiaVec = sOIA.element(i).toVar();
        const activeNow = oiaVec.w.greaterThanEqual(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5));
        const pendingDeath = oiaVec.w.lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(-0.5));
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(activeNow.or(pendingDeath), () => {
          const pos = sPos.element(i).toVar();
          const L = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailDesc.length);
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailRows);
          const curIdx = i.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2));
          const cursor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__(sTrailMeta.element(curIdx))).toVar();
          const count = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__(sTrailMeta.element(curIdx.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1))))
          ).toVar();
          const baseI = i.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailRows));
          const prev = sTrail.element(baseI.add(cursor)).toVar();
          const ddx = pos.x.sub(prev.x);
          const ddy = pos.y.sub(prev.y);
          const ddz = pos.z.sub(prev.z);
          const dist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sqrt__(
            ddx.mul(ddx).add(ddy.mul(ddy)).add(ddz.mul(ddz))
          );
          const firstSample = count.lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5));
          const farEnough = dist.greaterThanEqual(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(Math.max(1e-6, trailDesc.minVertexDistance))
          );
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(firstSample.or(farEnough), () => {
            const newCursor = cursor.greaterThanEqual(L.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1))).select(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), cursor.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)));
            sTrail.element(baseI.add(newCursor)).assign(
              __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(pos.x, pos.y, pos.z, uNowMs)
            );
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicStore__(
              sTrailMeta.element(curIdx),
              newCursor.toUint()
            );
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicStore__(
              sTrailMeta.element(curIdx.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1))),
              __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(count.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailDesc.length)).toUint()
            );
          });
        });
      });
    });
    trailHistoryNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(trailHistoryKernel(), maxParticles);
  }
  let subBirthEventsNode = null;
  if (birthFifos.length > 0) {
    const subBirthKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
      const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(i.lessThan(uEmitCount), () => {
        const counterAfter = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__(sAllocator.element(0)).toVar();
        const birthNo = counterAfter.sub(uEmitCount).add(i).toVar();
        const slot = birthNo.mod(ringModU).toVar();
        const p = sPos.element(slot).toVar();
        const v = sVel.element(slot).toVar();
        for (const f of birthFifos) {
          writeFifoEvent(f, p.x, p.y, p.z, v.x, v.y, v.z);
        }
      });
    });
    subBirthEventsNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(subBirthKernel(), maxParticles);
  }
  let subDeathEventsNode = null;
  if (deathFifos.length > 0) {
    const subDeathKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
      const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(maxParticles)), () => {
        const oiaVec = sOIA.element(i).toVar();
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(oiaVec.w.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(-1)), () => {
          const p = sPos.element(i).toVar();
          const v = sVel.element(i).toVar();
          for (const f of deathFifos) {
            writeFifoEvent(f, p.x, p.y, p.z, v.x, v.y, v.z);
          }
          sOIA.element(i).assign(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(oiaVec.x, oiaVec.y, oiaVec.z, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0))
          );
        });
      });
    });
    subDeathEventsNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(subDeathKernel(), maxParticles);
  }
  const layout = (name, storageNodes, uniformNodes) => ({
    name,
    storageBindings: new Set(storageNodes.filter((n) => n != null)).size,
    uniformBindings: new Set(uniformNodes.filter((n) => n != null)).size
  });
  const basePool = [sPos, sVel, sCol, sPS, sSV, sEx, sOIA, sAllocator];
  const emitUniforms = [
    uEmitCount,
    uSeed,
    uShape,
    uRadius,
    uRadiusThickness,
    uArcDeg,
    uConeAngleDeg,
    uRectRX,
    uRectRY,
    uRectSX,
    uRectSY,
    uBoxSX,
    uBoxSY,
    uBoxSZ,
    uBoxEmitFrom,
    uSpeedMin,
    uSpeedMax,
    uSizeMin,
    uSizeMax,
    uRotMin,
    uRotMax,
    uOpMin,
    uOpMax,
    uLifeMin,
    uLifeMax,
    uCRR,
    uCRX,
    uCGR,
    uCGX,
    uCBR,
    uCBX,
    uFrMin,
    uFrMax,
    uRotOLMin,
    uRotOLMax,
    uWrapperQuat,
    uEmitterPos,
    uWorldScale
  ];
  const simUniforms = [
    uDelta,
    uDeltaMs,
    uGravityVelocity,
    uNoiseStrength,
    uNoisePower,
    uNoiseFrequency,
    uNoisePosAmount,
    uNoiseRotAmount,
    uNoiseSizeAmount,
    sCD,
    ...Array.from(axisUniforms.values()).flat()
  ];
  const passLayouts = [
    layout("emit", basePool, emitUniforms),
    layout("simulate", basePool, simUniforms)
  ];
  if (trailHistoryNode) {
    passLayouts.push(
      layout("trail-history", [sPos, sOIA, sTrail, sTrailMeta], [uNowMs])
    );
  }
  if (subBirthEventsNode) {
    passLayouts.push(
      layout(
        "sub-birth-events",
        [
          sAllocator,
          sPos,
          sVel,
          ...birthFifos.flatMap((f) => [f.count, f.payload])
        ],
        [uEmitCount, uFifoBase]
      )
    );
  }
  if (subDeathEventsNode) {
    passLayouts.push(
      layout(
        "sub-death-events",
        [
          sPos,
          sVel,
          sOIA,
          ...deathFifos.flatMap((f) => [f.count, f.payload])
        ],
        [uFifoBase]
      )
    );
  }
  return {
    emitNode,
    simNode,
    trailHistoryNode,
    subBirthEventsNode,
    subDeathEventsNode,
    computeNodes: [
      emitNode,
      ...subBirthEventsNode ? [subBirthEventsNode] : [],
      simNode,
      ...subDeathEventsNode ? [subDeathEventsNode] : [],
      ...trailHistoryNode ? [trailHistoryNode] : []
    ],
    passLayouts,
    uniforms: {
      delta: uDelta,
      deltaMs: uDeltaMs,
      nowMs: uNowMs,
      gravityVelocity: uGravityVelocity,
      noiseStrength: uNoiseStrength,
      noisePower: uNoisePower,
      noiseFrequency: uNoiseFrequency,
      noisePositionAmount: uNoisePosAmount,
      noiseRotationAmount: uNoiseRotAmount,
      noiseSizeAmount: uNoiseSizeAmount,
      emitCount: uEmitCount,
      seed: uSeed,
      /** Ping-pong FIFO window index for this frame (0 or 1). */
      fifoBase: uFifoBase
    },
    shapeUniforms,
    buffers,
    allocatorCount,
    packedDataNode: sCD,
    passNames: [
      "emit",
      ...subBirthEventsNode ? ["sub-birth-events"] : [],
      "simulate",
      ...subDeathEventsNode ? ["sub-death-events"] : [],
      ...trailHistoryNode ? ["trail-history"] : []
    ],
    trailMeta: buffers.trailMeta,
    // Emitter-pose uniforms, refreshed once per frame by the CPU (scalar only).
    emitterPose: {
      positionW: uEmitterPos,
      wrapperQuat: uWrapperQuat,
      worldScale: uWorldScale
    },
    forceFieldInfo: ffNodes ? { offset: forceFieldOffset, countUniform: ffNodes.countUniform } : null,
    collisionPlaneInfo: cpNodes ? { offset: collisionOffset, countUniform: cpNodes.countUniform } : null
  };
}
function createSubEmitterInitUpdate(child, childMax, childParams, parent, parentMax, fifo, inheritVelocity, particlesPerEvent, childVelValues) {
  const capacity = Math.max(1, fifo.capacity);
  const perEvent = Math.max(1, particlesPerEvent);
  const windowSize = subEmitterWindowSize(capacity);
  const uSystemSeed = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(nextSystemSeed(), "uint");
  const uSeed = uSystemSeed;
  const uInherit = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(Math.max(0, inheritVelocity)));
  const uFifoBase = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), "uint");
  const uWrapperQuat = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector4__(0, 0, 0, 1));
  const uEmitterPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector4__(0, 0, 0, 0));
  const uWorldScale = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(1, 1, 1));
  const cRadius = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.radius));
  const cThickness = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.radiusThickness));
  const cArc = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.arcDeg));
  const cAngle = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.coneAngleDeg));
  const cRRX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rectangleRotXDeg));
  const cRRY = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rectangleRotYDeg));
  const cRSX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rectangleScaleX));
  const cRSY = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rectangleScaleY));
  const cBSX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.boxScaleX));
  const cBSY = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.boxScaleY));
  const cBSZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.boxScaleZ));
  const cBF = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.boxEmitFrom));
  const cKind = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.shapeKind));
  const cSpeedMin = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.speedMin));
  const cSpeedMax = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.speedMax));
  const cSizeMin = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.sizeMin));
  const cSizeMax = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.sizeMax));
  const cRotMin = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rotMin));
  const cRotMax = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rotMax));
  const cOpMin = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.opacityMin));
  const cOpMax = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.opacityMax));
  const cLifeMin = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.lifeMin));
  const cLifeMax = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.lifeMax));
  const cCRR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(webgpu_sRGBToLinear(childParams.colorRMin)));
  const cCRX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(webgpu_sRGBToLinear(childParams.colorRMax)));
  const cCGR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(webgpu_sRGBToLinear(childParams.colorGMin)));
  const cCGX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(webgpu_sRGBToLinear(childParams.colorGMax)));
  const cCBR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(webgpu_sRGBToLinear(childParams.colorBMin)));
  const cCBX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(webgpu_sRGBToLinear(childParams.colorBMax)));
  const cFrMin = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.startFrameMin));
  const cFrMax = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.startFrameMax));
  const cPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.position, "vec4", childMax);
  const cVel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.velocity, "vec4", childMax);
  const cCol = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.color, "vec4", childMax);
  const cPS = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.particleState, "vec4", childMax);
  const cSV = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.startValues, "vec4", childMax);
  const cEx = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.startColorsExt, "vec4", childMax);
  const cOIA = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(child.orbitalIsActive, "vec4", childMax);
  const cAlloc = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(
    child.allocator,
    "uint",
    Math.max(1, childMax + 1)
  ).toAtomic();
  __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childMax);
  const cRingModU = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(childMax);
  const commandBuffer = new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(
    new Float32Array(4 * (1 + capacity * perEvent)),
    4
  );
  const fifoCounter = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(
    fifo.counter,
    "uint",
    Math.max(1, fifo.counter.array.length)
  ).toAtomic();
  const fifoPayload = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(
    fifo.payload,
    "float",
    Math.max(1, fifo.payload.array.length)
  );
  const sCmd = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(commandBuffer, "vec4", 1 + capacity * perEvent);
  const cParseAxis = (rawAxis, ci) => {
    if (rawAxis && typeof rawAxis === "object" && "min" in rawAxis) {
      const mn = Number(rawAxis.min) || 0;
      const mx = Number(rawAxis.max) || 0;
      return { min: mn, max: mx, isRange: mn !== mx };
    }
    const c = typeof rawAxis === "number" ? rawAxis : 0;
    return { min: c, max: c, isRange: false };
  };
  const cVv = childVelValues ?? {
    linear: [void 0, void 0, void 0],
    orbital: [void 0, void 0, void 0]
  };
  [0, 1, 2].map((k) => cParseAxis(cVv.linear[k]));
  [0, 1, 2].map((k) => cParseAxis(cVv.orbital[k]));
  const otherIdx = uFifoBase.equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)).select(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(0));
  const counterClearKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicStore__(fifoCounter.element(otherIdx), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(0));
  });
  const counterClearNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(counterClearKernel(), 1);
  const commandBuildKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
    const winBase = uFifoBase.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(windowSize)).toVar();
    const count = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__(fifoCounter.element(uFifoBase))).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).equal(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)), () => {
      sCmd.element(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(count, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
    });
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).lessThan(count), () => {
      const eb = winBase.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(SUB_EMITTER_EVENT_STRIDE)));
      const eX = fifoPayload.element(eb).toVar();
      const eY = fifoPayload.element(eb.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1))).toVar();
      const eZ = fifoPayload.element(eb.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2))).toVar();
      const vX = fifoPayload.element(eb.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(3))).toVar();
      const vY = fifoPayload.element(eb.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(4))).toVar();
      const vZ = fifoPayload.element(eb.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(5))).toVar();
      for (let jj = 0; jj < perEvent; jj++) {
        const birthNo = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicAdd__(cAlloc.element(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(1)).toVar();
        const slot = birthNo.mod(cRingModU).toVar();
        const m = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(perEvent)).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(jj)));
        sCmd.element(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).add(m.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)))).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(slot.toFloat(), eX, eY, eZ));
        sCmd.element(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2).add(m.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)))).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(vX, vY, vZ, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
      }
    });
  });
  const commandBuildNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(commandBuildKernel(), capacity);
  const childInitKernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
    const header = sCmd.element(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i).lessThan(header.x.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(perEvent))), () => {
      const m = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(i);
      const mU = i;
      const c0 = sCmd.element(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).add(m.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)))).toVar();
      const c1 = sCmd.element(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2).add(m.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)))).toVar();
      const slot = c0.x;
      const eX = c0.y;
      const eY = c0.z;
      const eZ = c0.w;
      const vX = c1.x;
      const vY = c1.y;
      const vZ = c1.z;
      const parentSpeed = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sqrt__(
        vX.mul(vX).add(vY.mul(vY)).add(vZ.mul(vZ))
      ).toVar();
      const spAdd = parentSpeed.mul(uInherit);
      {
        const rcA = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.SHAPE_A));
        const rcB = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.SHAPE_B));
        const rcC = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.SHAPE_C));
        const rcSpeed = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.SPEED));
        const rcSize = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.SIZE));
        const rcRot = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.ROTATION));
        const rcOpacity = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.OPACITY));
        const rcSheet = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.START_FRAME));
        const rcLife = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.LIFETIME));
        const rcColor = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.COLOR));
        const rcRotOl = pcg01(mU.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(2654435761)).bitXor(uSystemSeed).bitXor(CH.ROTOL));
        const shE = shapeEmitNodes(
          {
            kind: cKind,
            radius: cRadius,
            thickness: cThickness,
            arcDeg: cArc,
            coneAngleDeg: cAngle,
            rectRX: cRRX,
            rectRY: cRRY,
            rectSX: cRSX,
            rectSY: cRSY,
            boxSX: cBSX,
            boxSY: cBSY,
            boxSZ: cBSZ,
            boxFrom: cBF,
            speedMin: cSpeedMin.add(spAdd),
            speedMax: cSpeedMax.add(spAdd)
          },
          rcA,
          rcB,
          rcC,
          rcSpeed
        );
        const [rx, ry, rz] = quatRotateNodes(
          shE.px,
          shE.py,
          shE.pz,
          uWrapperQuat
        );
        const [rvx, rvy, rvz] = quatRotateNodes(
          shE.vx,
          shE.vy,
          shE.vz,
          uWrapperQuat
        );
        const isWorld = uEmitterPos.w.greaterThan(0.5);
        const sxf = isWorld.select(uWorldScale.x, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
        const syf = isWorld.select(uWorldScale.y, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
        const szf = isWorld.select(uWorldScale.z, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
        const px = rx.mul(sxf).add(eX);
        const py = ry.mul(syf).add(eY);
        const pz = rz.mul(szf).add(eZ);
        const opac = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cOpMin, cOpMax, rcOpacity);
        const clR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cCRR, cCRX, rcColor);
        const clG = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cCGR, cCGX, rcColor);
        const clB = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cCBR, cCBX, rcColor);
        const slife = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cLifeMin, cLifeMax, rcLife).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1e3));
        const ssize = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cSizeMin, cSizeMax, rcSize);
        const srot = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cRotMin, cRotMax, rcRot);
        const startFrame = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(cFrMin, cFrMax, rcSheet)).toVar();
        const rotSpeed = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rotOverLifeMin),
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(childParams.rotOverLifeMax),
          rcRotOl
        );
        const stableSeedU = pcgRawU32(
          mixBirthSeed(mU, uSystemSeed, CH.STABLE_SEED)
        ).bitAnd(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uint__(16777215)).toVar();
        cPos.element(slot).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(px, py, pz, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
        cVel.element(slot).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(rvx, rvy, rvz, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)));
        cCol.element(slot).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(clR, clG, clB, opac));
        cPS.element(slot).assign(
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), ssize, srot, startFrame)
        );
        cSV.element(slot).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(slife, ssize, opac, clR));
        cEx.element(slot).assign(
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(clG, clB, rotSpeed, stableSeedU.toFloat())
        );
        cOIA.element(slot).assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(rx, ry, rz, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)));
      }
    });
  });
  const childInitNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(
    childInitKernel(),
    Math.max(1, capacity * perEvent)
  );
  const initPassLayouts = [
    {
      name: "sub-command-build",
      storageBindings: 4,
      // fifoCounter, fifoPayload, allocator, commands
      uniformBindings: 1
      // uFifoBase
    },
    {
      // command buffer + the 7 child pools; NO allocator here.
      name: "sub-child-init",
      storageBindings: 8,
      uniformBindings: 35
      // seed/inherit/pose + 30 child shape scalars
    },
    {
      name: "sub-counter-clear",
      storageBindings: 1,
      uniformBindings: 1
    }
  ];
  return {
    commandBuildNode,
    childInitNode,
    counterClearNode,
    commandBuffer,
    passLayouts: initPassLayouts,
    passName: fifo.trigger === 0 ? "sub-birth" : "sub-death",
    counterClearPassName: "fifo-counter-clear",
    uniforms: {
      seed: uSeed,
      fifoBase: uFifoBase,
      inherit: uInherit,
      positionW: uEmitterPos,
      wrapperQuat: uWrapperQuat
    },
    buffers: child
  };
}
function createTrailRibbonUpdate(desc) {
  const L = desc.length;
  const rows = L + 1;
  const vertexCount = Math.max(1, desc.maxParticles) * Math.max(1, L);
  const uNowMs = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const activeFns = [
    desc.curveFns.width ?? ((t) => t),
    desc.curveFns.opacity ?? ((t) => t),
    desc.curveFns.colorR ?? ((t) => t),
    desc.curveFns.colorG ?? ((t) => t),
    desc.curveFns.colorB ?? ((t) => t)
  ];
  const curveData = new Float32Array(activeFns.length * CURVE_RESOLUTION);
  activeFns.forEach((fn, k) => {
    curveData.set(bakeCurve(fn, CURVE_RESOLUTION), k * CURVE_RESOLUTION);
  });
  const IDX_WIDTH = 0;
  const IDX_OPACITY = 1;
  const IDX_CR = 2;
  const IDX_CG = 3;
  const IDX_CB = 4;
  const aPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(desc.position, "vec4", vertexCount * 2);
  const aNext = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(desc.next, "vec4", vertexCount * 2);
  const aUVA = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(desc.uvColorA, "vec4", vertexCount * 2);
  const aColB = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(desc.colorB, "vec4", vertexCount * 2);
  const hist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(desc.history, "vec4", rows * desc.maxParticles);
  const sMeta = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(
    desc.meta,
    "uint",
    Math.max(1, desc.meta.array.length)
  ).toAtomic();
  const pColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_storage__(desc.particleColor, "vec4", desc.maxParticles);
  const sCD = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_buffer__(curveData, "float", curveData.length);
  const lookupCurve = createCurveLookup(sCD);
  const halfWidthBase = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(desc.width * 0.5);
  const kernel = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const idx = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_instanceIndex__;
    const lf = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(L);
    const rowF = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(rows);
    const i = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(idx).div(lf));
    const s = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(idx).sub(i.mul(lf));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(i.lessThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(desc.maxParticles)), () => {
      const base = i.mul(rowF);
      const cursor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__(sMeta.element(i.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2))))
      ).toVar();
      const count = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_atomicLoad__(sMeta.element(i.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1))))
      ).toVar();
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(count.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5)), () => {
        const raw = cursor.sub(s).add(lf);
        const si = raw.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(raw.div(lf)).mul(lf));
        const sample = hist.element(base.add(si)).toVar();
        const nextRaw = si.add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
        const ni = nextRaw.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(nextRaw.div(lf)).mul(lf));
        const nextSample = hist.element(base.add(ni)).toVar();
        const t = count.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1.5)).select(s.div(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__(count.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1))), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
        const wScale = lookupCurve({
          curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(IDX_WIDTH),
          t
        });
        const oScale = lookupCurve({
          curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(IDX_OPACITY),
          t
        });
        const cr = lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(IDX_CR), t });
        const cg = lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(IDX_CG), t });
        const cb = lookupCurve({ curveIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(IDX_CB), t });
        const pcol = pColor.element(i).toVar();
        const inRange = s.lessThan(count);
        const ageOk = desc.maxTime > 0 ? uNowMs.sub(sample.w).lessThanEqual(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(desc.maxTime)) : inRange;
        const alive = inRange.and(ageOk);
        const hw = alive.select(halfWidthBase.mul(wScale), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
        const alpha = alive.select(oScale.mul(pcol.w), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
        const nPos = count.greaterThan(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1.5)).select(nextSample.xyz, sample.xyz);
        for (let side = 0; side < 2; side++) {
          const vi = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(idx).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(2)).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(side));
          aPos.element(vi).assign(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(sample.x, sample.y, sample.z, hw)
          );
          aNext.element(vi).assign(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(nPos.x, nPos.y, nPos.z, alpha)
          );
          aUVA.element(vi).assign(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(side), t, cr.mul(pcol.x), cg.mul(pcol.y))
          );
          aColB.element(vi).assign(
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(cb.mul(pcol.z), alpha, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0))
          );
        }
      });
    });
  });
  const ribbonNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_compute__(kernel(), vertexCount);
  return {
    ribbonNode,
    // 4 ribbon streams + history + meta + particle color = 7 storage bindings.
    passLayouts: [
      { name: "trail-ribbon", storageBindings: 7, uniformBindings: 2 }
    ],
    uniforms: { nowMs: uNowMs },
    buffers: {
      position: desc.position,
      next: desc.next,
      uvColorA: desc.uvColorA,
      colorB: desc.colorB,
      history: desc.history
    }
  };
}

// src/js/effects/three-particles/three-particles-constants.ts
var POINT_SIZE_SCALE = 100;
var ALPHA_DISCARD_THRESHOLD = 1e-3;
var _dummyTexture = null;
function getDummyTexture() {
  if (!_dummyTexture) {
    _dummyTexture = new __WEBPACK_EXTERNAL_MODULE_three_DataTexture__(new Uint8Array([255, 255, 255, 255]), 1, 1);
    _dummyTexture.needsUpdate = true;
  }
  return _dummyTexture;
}
function createParticleUniforms(sharedUniforms) {
  const dummy = getDummyTexture();
  const map = sharedUniforms.map.value ?? dummy;
  return {
    uMap: map,
    uElapsed: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.elapsed.value)),
    uFps: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.fps.value)),
    uUseFPSForFrameIndex: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.useFPSForFrameIndex.value ? 1 : 0)
    ),
    uTiles: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(sharedUniforms.tiles.value),
    uDiscardBg: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.discardBackgroundColor.value ? 1 : 0)
    ),
    uBgColor: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      new __WEBPACK_EXTERNAL_MODULE_three_Vector3__(
        sharedUniforms.backgroundColor.value.r,
        sharedUniforms.backgroundColor.value.g,
        sharedUniforms.backgroundColor.value.b
      )
    ),
    uBgTolerance: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.backgroundColorTolerance.value)),
    uSoftEnabled: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.softParticlesEnabled.value ? 1 : 0)
    ),
    uSoftIntensity: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(sharedUniforms.softParticlesIntensity.value)),
    uSceneDepthTex: sharedUniforms.sceneDepthTexture.value ?? dummy,
    uCameraNearFar: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(sharedUniforms.cameraNearFar.value)
  };
}
var computeFrameIndex = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({
    vLifetime,
    vStartLifetime,
    vStartFrame,
    uFps,
    uUseFPSForFrameIndex,
    uTiles
  }) => {
    const totalFrames = uTiles.x.mul(uTiles.y);
    const lifePercent = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(vLifetime.div(vStartLifetime), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1));
    const fpsBased = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__(vLifetime.div(1e3).mul(uFps), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
    const lifetimeBased = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_min__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(lifePercent.mul(totalFrames)), totalFrames.sub(1)),
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)
    );
    const fpsResult = uFps.equal(0).select(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), fpsBased);
    const frameOffset = uUseFPSForFrameIndex.greaterThan(0.5).select(fpsResult, lifetimeBased);
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_round__(vStartFrame).add(frameOffset);
  }
);
var computeSpriteSheetUV = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({ baseUV, frameIndex, uTiles }) => {
    const spriteX = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mod__(frameIndex, uTiles.x));
    const spriteY = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_floor__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mod__(frameIndex.div(uTiles.x), uTiles.y));
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(
      baseUV.x.div(uTiles.x).add(spriteX.div(uTiles.x)),
      baseUV.y.div(uTiles.y).add(spriteY.div(uTiles.y))
    );
  }
);
var linearizeDepth = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({ depthSample, near, far }) => {
    const zNdc = depthSample.mul(2).sub(1);
    return near.mul(2).mul(far).div(far.add(near).sub(zNdc.mul(far.sub(near))));
  }
);
var computeSoftParticleFade = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({
    viewZ,
    uSoftEnabled,
    uSoftIntensity,
    uSceneDepthTex,
    uCameraNearFar
  }) => {
    const softFade = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(uSoftEnabled.greaterThan(0.5), () => {
      const depthSample = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__(uSceneDepthTex, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_screenUV__).x;
      const sceneDepthLinear = linearizeDepth({
        depthSample,
        near: uCameraNearFar.x,
        far: uCameraNearFar.y
      });
      const depthDiff = sceneDepthLinear.sub(viewZ);
      softFade.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_smoothstep__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), uSoftIntensity, depthDiff));
    });
    return softFade;
  }
);
function applyBackgroundDiscard({
  texColor,
  uDiscardBg,
  uBgColor,
  uBgTolerance
}) {
  const diff = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
    texColor.x.sub(uBgColor.x),
    texColor.y.sub(uBgColor.y),
    texColor.z.sub(uBgColor.z)
  );
  __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(
    uDiscardBg.greaterThan(0.5).and(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_abs__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(diff)).lessThan(uBgTolerance))
  );
}

// src/js/effects/three-particles/webgpu/tsl-instanced-billboard-material.ts
function createInstancedBillboardTSLMaterial(sharedUniforms, rendererConfig, gpuCompute = false) {
  const u = createParticleUniforms(sharedUniforms);
  const uViewportHeight = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
    typeof sharedUniforms.viewportHeight?.value === "number" ? sharedUniforms.viewportHeight.value : 1
  );
  sharedUniforms.viewportHeight = uViewportHeight;
  const aInstanceOffset = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceOffset");
  const aColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceColor");
  const aParticleState = gpuCompute ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceParticleState") : null;
  const aStartValues = gpuCompute ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceStartValues") : null;
  const aSize = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceSize");
  const aLifetime = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceLifetime");
  const aStartLifetime = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceStartLifetime");
  const aRotation = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceRotation");
  const aStartFrame = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceStartFrame");
  const vColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec4", "vColor");
  const vLifetime = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vLifetime");
  const vStartLifetime = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vStartLifetime");
  const vRotation = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vRotation");
  const vStartFrame = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vStartFrame");
  const vUv = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec2", "vUv");
  const vViewZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vViewZ");
  const vertexNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const clipPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(0, 0, 0, -1).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(aColor.w.greaterThan(0), () => {
      vColor.assign(aColor.toVar());
      if (gpuCompute) {
        vLifetime.assign(aParticleState.x);
        vStartLifetime.assign(aStartValues.x);
        vRotation.assign(aParticleState.z);
        vStartFrame.assign(aParticleState.w);
      } else {
        vLifetime.assign(aLifetime);
        vStartLifetime.assign(aStartLifetime);
        vRotation.assign(aRotation);
        vStartFrame.assign(aStartFrame);
      }
      vUv.assign(
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__.x.add(0.5), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__.y))
      );
      const mvPosition = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(aInstanceOffset.xyz, 1)).toVar();
      const dist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(mvPosition.xyz);
      const sizeVal = gpuCompute ? aParticleState.y : aSize;
      const pointSizePx = sizeVal.mul(POINT_SIZE_SCALE).div(dist);
      const projY = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraProjectionMatrix__.element(1).element(1);
      const perspectiveSize = pointSizePx.mul(mvPosition.z.negate()).div(projY.mul(uViewportHeight).mul(0.5));
      mvPosition.x.addAssign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__.x.mul(perspectiveSize));
      mvPosition.y.addAssign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__.y.mul(perspectiveSize));
      vViewZ.assign(mvPosition.z.negate());
      clipPos.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraProjectionMatrix__.mul(mvPosition));
    });
    return clipPos;
  })();
  const fragmentColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const outColor = vColor.toVar();
    const center = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(0.5, 0.5);
    const centered = vUv.sub(center);
    const cosR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(vRotation);
    const sinR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(vRotation);
    const rotated = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(
      centered.x.mul(cosR).add(centered.y.mul(sinR)),
      centered.x.mul(sinR).negate().add(centered.y.mul(cosR))
    );
    const rotatedUV = rotated.add(center);
    const dist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(rotatedUV.sub(center));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(dist.greaterThan(0.5), () => {
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__();
    });
    const frameIndex = computeFrameIndex({
      vLifetime,
      vStartLifetime,
      vStartFrame,
      uFps: u.uFps,
      uUseFPSForFrameIndex: u.uUseFPSForFrameIndex,
      uTiles: u.uTiles
    });
    const uvPoint = computeSpriteSheetUV({
      baseUV: rotatedUV,
      frameIndex,
      uTiles: u.uTiles
    });
    const texColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__(u.uMap, uvPoint);
    outColor.assign(outColor.mul(texColor));
    applyBackgroundDiscard({
      texColor,
      uDiscardBg: u.uDiscardBg,
      uBgColor: u.uBgColor,
      uBgTolerance: u.uBgTolerance
    });
    const softFade = computeSoftParticleFade({
      viewZ: vViewZ,
      uSoftEnabled: u.uSoftEnabled,
      uSoftIntensity: u.uSoftIntensity,
      uSceneDepthTex: u.uSceneDepthTex,
      uCameraNearFar: u.uCameraNearFar
    });
    outColor.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(outColor.xyz, outColor.w.mul(softFade)));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(outColor.w.lessThan(ALPHA_DISCARD_THRESHOLD));
    return outColor;
  })();
  const material = new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_MeshBasicNodeMaterial__();
  material.transparent = rendererConfig.transparent;
  material.blending = rendererConfig.blending;
  material.depthTest = rendererConfig.depthTest;
  material.depthWrite = rendererConfig.depthWrite;
  material.toneMapped = false;
  material.fog = false;
  material.vertexNode = vertexNode;
  material.colorNode = fragmentColor;
  return material;
}
var applyQuaternion = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(
  ({ v, q }) => {
    const t = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cross__(q.xyz, v).mul(2);
    return v.add(t.mul(q.w)).add(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cross__(q.xyz, t));
  }
);
function createMeshParticleTSLMaterial(sharedUniforms, rendererConfig, gpuCompute = false) {
  const u = createParticleUniforms(sharedUniforms);
  const aInstanceOffset = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceOffset");
  const aColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceColor");
  const aParticleState = gpuCompute ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceParticleState") : null;
  const aStartValues = gpuCompute ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceStartValues") : null;
  const aInstanceQuat = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceQuat");
  const aSize = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceSize");
  const aLifetime = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceLifetime");
  const aStartLifetime = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceStartLifetime");
  const aRotation = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceRotation");
  const aStartFrame = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("instanceStartFrame");
  const vColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec4", "vColor");
  const vLifetime = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vLifetime");
  const vStartLifetime = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vStartLifetime");
  const vStartFrame = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vStartFrame");
  const vRotation = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vRotation");
  const vNormal = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec3", "vNormal");
  const vViewZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vViewZ");
  const vertexSetup = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const clipPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(0, 0, 0, -1).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(aColor.w.greaterThan(0), () => {
      vColor.assign(aColor.toVar());
      if (gpuCompute) {
        vLifetime.assign(aParticleState.x);
        vStartLifetime.assign(aStartValues.x);
        vStartFrame.assign(aParticleState.w);
        vRotation.assign(aParticleState.z);
      } else {
        vLifetime.assign(aLifetime);
        vStartLifetime.assign(aStartLifetime);
        vStartFrame.assign(aStartFrame);
        vRotation.assign(aRotation);
      }
      let quat;
      if (gpuCompute) {
        const halfZ = aParticleState.z.mul(0.5);
        quat = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(0, 0, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(halfZ), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(halfZ));
      } else {
        quat = aInstanceQuat;
      }
      const rotatedPos = applyQuaternion({
        v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__,
        q: quat
      });
      const scaledPos = rotatedPos.mul(gpuCompute ? aParticleState.y : aSize);
      const worldPos = scaledPos.add(aInstanceOffset.xyz);
      const mvPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(worldPos, 1));
      vViewZ.assign(mvPos.z.negate());
      const rotatedNormal = applyQuaternion({
        v: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalLocal__,
        q: quat
      });
      const mvNormal = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(rotatedNormal, 0)).xyz;
      vNormal.assign(mvNormal.normalize());
      clipPos.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraProjectionMatrix__.mul(mvPos));
    });
    return clipPos;
  })();
  const fragmentColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const outColor = vColor.toVar();
    const uvPoint = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uv__()).toVar();
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(u.uTiles.x.greaterThan(1).or(u.uTiles.y.greaterThan(1)), () => {
      const frameIndex = computeFrameIndex({
        vLifetime,
        vStartLifetime,
        vStartFrame,
        uFps: u.uFps,
        uUseFPSForFrameIndex: u.uUseFPSForFrameIndex,
        uTiles: u.uTiles
      });
      uvPoint.assign(
        computeSpriteSheetUV({
          baseUV: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uv__(),
          frameIndex,
          uTiles: u.uTiles
        })
      );
    });
    const texColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__(u.uMap, uvPoint);
    outColor.assign(outColor.mul(texColor));
    applyBackgroundDiscard({
      texColor,
      uDiscardBg: u.uDiscardBg,
      uBgColor: u.uBgColor,
      uBgTolerance: u.uBgTolerance
    });
    const lightIntensity = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).add(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_max__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(vNormal, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(0, 0, 1)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0)))
    );
    outColor.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(outColor.xyz.mul(lightIntensity), outColor.w));
    const softFade = computeSoftParticleFade({
      viewZ: vViewZ,
      uSoftEnabled: u.uSoftEnabled,
      uSoftIntensity: u.uSoftIntensity,
      uSceneDepthTex: u.uSceneDepthTex,
      uCameraNearFar: u.uCameraNearFar
    });
    outColor.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(outColor.xyz, outColor.w.mul(softFade)));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(outColor.w.lessThan(ALPHA_DISCARD_THRESHOLD));
    return outColor;
  })();
  const material = new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_MeshBasicNodeMaterial__();
  material.transparent = rendererConfig.transparent;
  material.blending = rendererConfig.blending;
  material.depthTest = rendererConfig.depthTest;
  material.depthWrite = rendererConfig.depthWrite;
  material.toneMapped = false;
  material.fog = false;
  material.vertexNode = vertexSetup;
  material.colorNode = fragmentColor;
  return material;
}
function createPointSpriteTSLMaterial(sharedUniforms, rendererConfig, gpuCompute = false) {
  const u = createParticleUniforms(sharedUniforms);
  const aColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("color");
  const aParticleState = gpuCompute ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("particleState") : null;
  const aStartValues = gpuCompute ? __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("startValues") : null;
  const aSize = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("size");
  const aLifetime = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("lifetime");
  const aStartLifetime = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("startLifetime");
  const aRotation = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("rotation");
  const aStartFrame = gpuCompute ? null : __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("startFrame");
  const mvPos = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__, 1));
  const sizeVal = gpuCompute ? aParticleState.y : aSize;
  const sizeNode = aColor.w.greaterThan(0).select(sizeVal.mul(POINT_SIZE_SCALE).div(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(mvPos.xyz)), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0));
  const vColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec4", "vColor");
  const vLifetime = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vLifetime");
  const vStartLifetime = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vStartLifetime");
  const vRotation = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vRotation");
  const vStartFrame = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vStartFrame");
  const vViewZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vViewZ");
  const vertexSetup = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(aColor.w.greaterThan(0), () => {
      vColor.assign(aColor.toVar());
      if (gpuCompute) {
        vLifetime.assign(aParticleState.x);
        vStartLifetime.assign(aStartValues.x);
        vRotation.assign(aParticleState.z);
        vStartFrame.assign(aParticleState.w);
      } else {
        vLifetime.assign(aLifetime);
        vStartLifetime.assign(aStartLifetime);
        vRotation.assign(aRotation);
        vStartFrame.assign(aStartFrame);
      }
      vViewZ.assign(mvPos.z.negate());
    });
    return __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_positionLocal__;
  })();
  const fragmentColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const outColor = vColor.toVar();
    const frameIndex = computeFrameIndex({
      vLifetime,
      vStartLifetime,
      vStartFrame,
      uFps: u.uFps,
      uUseFPSForFrameIndex: u.uUseFPSForFrameIndex,
      uTiles: u.uTiles
    });
    const center = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(0.5, 0.5);
    const centered = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(0, 0);
    const cosR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cos__(vRotation);
    const sinR = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_sin__(vRotation);
    const rotated = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(
      centered.x.mul(cosR).add(centered.y.mul(sinR)),
      centered.x.mul(sinR).negate().add(centered.y.mul(cosR))
    );
    const rotatedUV = rotated.add(center);
    const dist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(rotatedUV.sub(center));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(dist.greaterThan(0.5));
    const uvPoint = computeSpriteSheetUV({
      baseUV: rotatedUV,
      frameIndex,
      uTiles: u.uTiles
    });
    const texColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__(u.uMap, uvPoint);
    outColor.assign(outColor.mul(texColor));
    applyBackgroundDiscard({
      texColor,
      uDiscardBg: u.uDiscardBg,
      uBgColor: u.uBgColor,
      uBgTolerance: u.uBgTolerance
    });
    const softFade = computeSoftParticleFade({
      viewZ: vViewZ,
      uSoftEnabled: u.uSoftEnabled,
      uSoftIntensity: u.uSoftIntensity,
      uSceneDepthTex: u.uSceneDepthTex,
      uCameraNearFar: u.uCameraNearFar
    });
    outColor.assign(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(outColor.xyz, outColor.w.mul(softFade)));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(outColor.w.lessThan(ALPHA_DISCARD_THRESHOLD));
    return outColor;
  })();
  const material = new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_PointsNodeMaterial__();
  material.transparent = rendererConfig.transparent;
  material.blending = rendererConfig.blending;
  material.depthTest = rendererConfig.depthTest;
  material.depthWrite = rendererConfig.depthWrite;
  material.toneMapped = false;
  material.fog = false;
  material.sizeNode = sizeNode;
  material.positionNode = vertexSetup;
  material.colorNode = fragmentColor;
  return material;
}
function createTrailUniforms(trailUniforms) {
  const dummy = getDummyTexture();
  const map = trailUniforms.map.value ?? dummy;
  return {
    uMap: map,
    uUseMap: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailUniforms.useMap.value ? 1 : 0)),
    uDiscardBg: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailUniforms.discardBackgroundColor.value ? 1 : 0)
    ),
    uBgColor: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      new trailUniforms.cameraNearFar.value.constructor(
        trailUniforms.backgroundColor.value.r,
        trailUniforms.backgroundColor.value.g,
        trailUniforms.backgroundColor.value.b
      )
    ),
    uBgTolerance: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailUniforms.backgroundColorTolerance.value)),
    uSoftEnabled: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailUniforms.softParticlesEnabled.value ? 1 : 0)
    ),
    uSoftIntensity: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(trailUniforms.softParticlesIntensity.value)),
    uSceneDepthTex: trailUniforms.sceneDepthTexture.value ?? dummy,
    uCameraNearFar: __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_uniform__(trailUniforms.cameraNearFar.value)
  };
}
function createTrailRibbonTSLMaterial(trailUniforms, rendererConfig) {
  const u = createTrailUniforms(trailUniforms);
  const aPosPacked = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("position", "vec4");
  const aNextPacked = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("trailNext", "vec4");
  const aUvColorA = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("trailUVColor", "vec4");
  const aColorBA = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_attribute__("trailColorBA", "vec4");
  const aTrailAlpha = aNextPacked.w;
  const aTrailColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(aUvColorA.z, aUvColorA.w, aColorBA.x, aColorBA.y);
  const aTrailOffset = aUvColorA.x.sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5));
  const aTrailHalfWidth = aPosPacked.w;
  const aTrailNext = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(aNextPacked.x, aNextPacked.y, aNextPacked.z);
  const aTrailUV = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec2__(aUvColorA.x, aUvColorA.y);
  const vAlpha = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vAlpha");
  const vColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec4", "vColor");
  const vUv = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("vec2", "vUv");
  const vViewZ = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_varyingProperty__("float", "vViewZ");
  const positionNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    vAlpha.assign(aTrailAlpha);
    vColor.assign(aTrailColor);
    vUv.assign(aTrailUV);
    const current = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(aPosPacked.x, aPosPacked.y, aPosPacked.z);
    const next = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(aTrailNext);
    const rawTangent = next.sub(current);
    const tangentLen = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(rawTangent);
    const tangent = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(
      tangentLen.lessThan(1e-4).select(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(0, 1, 0), rawTangent)
    );
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(current, 1));
    const viewDir = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraPosition__.sub(current));
    const rawPerp = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cross__(tangent, viewDir);
    const perpLen = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(rawPerp);
    const camRight = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraViewMatrix__.element(0).element(0),
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraViewMatrix__.element(1).element(0),
      __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_cameraViewMatrix__.element(2).element(0)
    );
    const camRightDotTangent = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(camRight, tangent);
    const fallbackPerp = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(
      camRight.sub(tangent.mul(camRightDotTangent))
    );
    const perp = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(
      perpLen.lessThan(1e-4).select(
        fallbackPerp,
        __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(
          __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_mix__(
            fallbackPerp,
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_normalize__(rawPerp),
            __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_smoothstep__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.7), perpLen)
          )
        )
      )
    );
    const offsetPos = current.add(perp.mul(aTrailOffset).mul(aTrailHalfWidth));
    const mvOffset = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_modelViewMatrix__.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec4__(offsetPos, 1));
    vViewZ.assign(mvOffset.z.negate());
    return offsetPos;
  })();
  const colorNode = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Fn__(() => {
    const outColor = vColor.toVar();
    const edgeDist = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(1).sub(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_abs__(vUv.x.mul(2).sub(1)));
    const edgeFade = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_smoothstep__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.4), edgeDist);
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(u.uUseMap.greaterThan(0.5), () => {
      const texColor = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__(u.uMap, vUv);
      const texBrightness = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_dot__(texColor.rgb, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(0.299, 0.587, 0.114));
      outColor.rgb.assign(
        outColor.rgb.mul(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0.5).add(texBrightness.mul(0.5)))
      );
      outColor.a.assign(outColor.a.mul(texColor.a));
    });
    outColor.a.assign(outColor.a.mul(vAlpha).mul(edgeFade));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(outColor.a.lessThan(ALPHA_DISCARD_THRESHOLD));
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_If__(u.uSoftEnabled.greaterThan(0.5), () => {
      const depthSample = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_texture__(u.uSceneDepthTex, __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_screenUV__).x;
      const sceneDepthLinear = linearizeDepth({
        depthSample,
        near: u.uCameraNearFar.x,
        far: u.uCameraNearFar.y
      });
      const depthDiff = sceneDepthLinear.sub(vViewZ);
      const softFade = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_smoothstep__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_float__(0), u.uSoftIntensity, depthDiff);
      outColor.a.assign(outColor.a.mul(softFade));
    });
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(outColor.a.lessThan(ALPHA_DISCARD_THRESHOLD));
    const diff = __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_vec3__(
      outColor.r.sub(u.uBgColor.x),
      outColor.g.sub(u.uBgColor.y),
      outColor.b.sub(u.uBgColor.z)
    );
    __WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_Discard__(
      u.uDiscardBg.greaterThan(0.5).and(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_abs__(__WEBPACK_EXTERNAL_MODULE_three_tsl_3a8d0cc7_length__(diff)).lessThan(u.uBgTolerance))
    );
    return outColor;
  })();
  const material = new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_MeshBasicNodeMaterial__();
  material.transparent = rendererConfig.transparent;
  material.blending = rendererConfig.blending;
  material.depthTest = rendererConfig.depthTest;
  material.depthWrite = rendererConfig.depthWrite;
  material.toneMapped = false;
  material.fog = false;
  material.side = __WEBPACK_EXTERNAL_MODULE_three_DoubleSide__;
  material.positionNode = positionNode;
  material.colorNode = colorNode;
  return material;
}
function createTSLParticleMaterial(rendererType, sharedUniforms, rendererConfig, gpuCompute = false) {
  switch (rendererType) {
    case "INSTANCED" /* INSTANCED */:
      return createInstancedBillboardTSLMaterial(sharedUniforms, rendererConfig, gpuCompute);
    case "MESH" /* MESH */:
      return createMeshParticleTSLMaterial(sharedUniforms, rendererConfig, gpuCompute);
    case "POINTS" /* POINTS */:
    default:
      return createPointSpriteTSLMaterial(sharedUniforms, rendererConfig, gpuCompute);
  }
}
function createTSLTrailMaterial(trailUniforms, rendererConfig) {
  return createTrailRibbonTSLMaterial(trailUniforms, rendererConfig);
}
var pair = (v) => {
  if (typeof v === "number") return [v, v];
  if (v && typeof v === "object") {
    const o = v;
    return [Number(o.min) || 0, Number(o.max) || 0];
  }
  return [0, 0];
};
var shapeKindOf = (t) => {
  switch (t) {
    case "SPHERE":
      return 0;
    case "CONE":
      return 1;
    case "CIRCLE":
      return 2;
    case "RECTANGLE":
      return 3;
    case "BOX":
      return 4;
    default:
      return 0;
  }
};
var boxEmitFromOf = (e) => e === "SHELL" ? 1 : e === "EDGE" ? 2 : 0;
function encodeShapeEmitParams(normalizedConfig, particleSystemId) {
  const bakedCurves = bakeParticleSystemCurves(normalizedConfig, particleSystemId);
  const pairLocal = pair;
  const [lifeMin, lifeMax] = pairLocal(normalizedConfig.startLifetime);
  const [spdMin, spdMax] = pairLocal(normalizedConfig.startSpeed);
  const [szMin, szMax] = pairLocal(normalizedConfig.startSize);
  const [rotMin, rotMax] = pairLocal(normalizedConfig.startRotation);
  const [opMin, opMax] = pairLocal(normalizedConfig.startOpacity);
  const cMin = normalizedConfig.startColor.min || { r: 1, g: 1, b: 1 };
  const cMax = normalizedConfig.startColor.max || { r: 1, g: 1, b: 1 };
  const sf = normalizedConfig.textureSheetAnimation && normalizedConfig.textureSheetAnimation.startFrame || 0;
  const sfPair = pairLocal(sf);
  const shp = normalizedConfig.shape;
  const sph = shp.sphere;
  const cone = shp.cone;
  const circ = shp.circle;
  const rect = shp.rectangle;
  const bx = shp.box;
  const num = (v, fallback) => typeof v === "number" && Number.isFinite(v) ? v : fallback;
  const kind = shapeKindOf(shp.shape);
  return {
    shapeKind: kind,
    radius: shp.shape === "CONE" ? num(cone?.radius, 1) : shp.shape === "CIRCLE" ? num(circ?.radius, 1) : num(sph?.radius, 1),
    radiusThickness: shp.shape === "CONE" ? num(cone?.radiusThickness, 1) : shp.shape === "CIRCLE" ? num(circ?.radiusThickness, 1) : num(sph?.radiusThickness, 1),
    arcDeg: shp.shape === "CONE" ? num(cone?.arc, 360) : shp.shape === "CIRCLE" ? num(circ?.arc, 360) : num(sph?.arc, 360),
    coneAngleDeg: num(cone?.angle, 90),
    rectangleRotXDeg: num(rect?.rotation?.x, 0),
    rectangleRotYDeg: num(rect?.rotation?.y, 0),
    rectangleScaleX: num(rect?.scale?.x, 1),
    rectangleScaleY: num(rect?.scale?.y, 1),
    boxScaleX: num(bx?.scale?.x, 1),
    boxScaleY: num(bx?.scale?.y, 1),
    boxScaleZ: num(bx?.scale?.z, 1),
    boxEmitFrom: boxEmitFromOf(bx?.emitFrom),
    speedMin: spdMin,
    speedMax: spdMax,
    sizeMin: szMin,
    sizeMax: szMax,
    rotMin,
    rotMax,
    opacityMin: opMin,
    opacityMax: opMax,
    lifeMin,
    lifeMax,
    colorRMin: cMin.r,
    colorRMax: cMax.r,
    colorGMin: cMin.g,
    colorGMax: cMax.g,
    colorBMin: cMin.b,
    colorBMax: cMax.b,
    startFrameMin: sfPair[0],
    startFrameMax: sfPair[1],
    // Separate rotationOverLifetime range (never the startRotation pair).
    rotOverLifeMin: (() => {
      const rol = normalizedConfig.rotationOverLifetime;
      return typeof rol?.min === "number" && Number.isFinite(rol.min) ? rol.min : 0;
    })(),
    rotOverLifeMax: (() => {
      const rol = normalizedConfig.rotationOverLifetime;
      return typeof rol?.max === "number" && Number.isFinite(rol.max) ? rol.max : 0;
    })(),
    noiseOctaves: num(normalizedConfig.noise?.octaves, 1),
    noiseUseRandomOffset: !!normalizedConfig.noise?.useRandomOffset,
    rotationCurveActive: normalizedConfig.rotationOverLifetime.isActive,
    rotationalXCurve: bakedCurves.orbitalVelX ?? -1,
    rotationalYCurve: bakedCurves.orbitalVelY ?? -1,
    rotationalZCurve: bakedCurves.orbitalVelZ ?? -1,
    linearXCurve: bakedCurves.linearVelX ?? -1,
    linearYCurve: bakedCurves.linearVelY ?? -1,
    linearZCurve: bakedCurves.linearVelZ ?? -1
  };
}
function createComputePipeline(maxParticles, instanced, normalizedConfig, particleSystemId, forceFieldCount, collisionPlaneCount = 0, subFifos, trailDesc) {
  const bakedCurves = bakeParticleSystemCurves(normalizedConfig, particleSystemId);
  const v = normalizedConfig.velocityOverLifetime;
  const flags = {
    sizeOverLifetime: normalizedConfig.sizeOverLifetime.isActive,
    opacityOverLifetime: normalizedConfig.opacityOverLifetime.isActive,
    colorOverLifetime: normalizedConfig.colorOverLifetime.isActive,
    rotationOverLifetime: normalizedConfig.rotationOverLifetime.isActive,
    linearVelocity: v.isActive && (webgpu_isLifeTimeCurve(v.linear.x ?? 0) || webgpu_isLifeTimeCurve(v.linear.y ?? 0) || webgpu_isLifeTimeCurve(v.linear.z ?? 0) || v.linear.x !== 0 || v.linear.y !== 0 || v.linear.z !== 0),
    orbitalVelocity: v.isActive && (webgpu_isLifeTimeCurve(v.orbital.x ?? 0) || webgpu_isLifeTimeCurve(v.orbital.y ?? 0) || webgpu_isLifeTimeCurve(v.orbital.z ?? 0) || v.orbital.x !== 0 || v.orbital.y !== 0 || v.orbital.z !== 0),
    noise: normalizedConfig.noise.isActive,
    forceFields: forceFieldCount > 0,
    collisionPlanes: collisionPlaneCount > 0
  };
  const shapeParams = encodeShapeEmitParams(
    normalizedConfig,
    particleSystemId
  );
  const velocityValues = {
    linear: [v.linear.x, v.linear.y, v.linear.z],
    orbital: [
      v.orbital.x,
      v.orbital.y,
      v.orbital.z
    ]
  };
  if (trailDesc && !trailDesc.meta) {
    trailDesc.meta = new __WEBPACK_EXTERNAL_MODULE_three_webgpu_84e9d76f_StorageBufferAttribute__(
      new Uint32Array(Math.max(1, maxParticles) * 2),
      1
    );
  }
  const built = createModifierStorageBuffers(
    maxParticles,
    instanced,
    bakedCurves.data,
    flags.forceFields,
    flags.collisionPlanes,
    trailDesc ? trailDesc.length : 0
  );
  if (trailDesc && built.buffers.trailMeta) {
    trailDesc.meta = built.buffers.trailMeta;
  }
  return createModifierComputeUpdate(
    built.buffers,
    maxParticles,
    bakedCurves,
    flags,
    shapeParams,
    forceFieldCount,
    collisionPlaneCount,
    subFifos ?? [],
    trailDesc,
    velocityValues
  );
}

// src/webgpu.ts
function enableWebGPU(renderer) {
  const factory = {
    createTSLParticleMaterial,
    createTSLTrailMaterial,
    createComputePipeline,
    encodeForceFieldsForGPU,
    encodeCollisionPlanesForGPU,
    createSubEmitterFifoAttribute,
    createSubEmitterInitUpdate,
    createTrailRibbonUpdate,
    encodeShapeEmitParams
  };
  return registerTSLMaterialFactory(
    factory,
    renderer !== void 0 ? { renderer } : void 0
  );
}


//# sourceMappingURL=webgpu.js.map
//# sourceMappingURL=webgpu.js.map
export { CH, assertNamed, createComputePipeline, createModifierStorageBuffers, createSubEmitterFifoAttribute, createSubEmitterInitUpdate, createTSLParticleMaterial, createTSLTrailMaterial, createTrailRibbonUpdate, enableWebGPU, encodeCollisionPlanesForGPU, encodeForceFieldsForGPU, encodeShapeEmitParams, mixBirthSeed, nextSystemSeed, normalizeBackgroundToVector3, normalizeDepthTextureValue, normalizeTextureValue, normalizeVector2Value, pcg01, pcgRawU32, randomChannel, resolveWebGPUEffectiveRendererType, subEmitterWindowSize };
